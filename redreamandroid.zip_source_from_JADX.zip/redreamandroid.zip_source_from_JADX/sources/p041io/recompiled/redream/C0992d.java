package p041io.recompiled.redream;

import android.os.Bundle;
import android.support.p031v7.app.C0571c;

/* renamed from: io.recompiled.redream.d */
public class C0992d extends C0571c {
    /* access modifiers changed from: 0000 */
    /* renamed from: k */
    public void mo4878k() {
        getWindow().getDecorView().setSystemUiVisibility(1792);
    }

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        mo4878k();
    }

    /* access modifiers changed from: protected */
    public void onResume() {
        super.onResume();
        mo4878k();
    }
}
