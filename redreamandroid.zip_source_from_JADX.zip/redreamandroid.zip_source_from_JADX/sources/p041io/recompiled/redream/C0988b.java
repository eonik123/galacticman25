package p041io.recompiled.redream;

import android.app.Activity;

/* renamed from: io.recompiled.redream.b */
class C0988b extends Thread {

    /* renamed from: a */
    private Activity f3506a;

    /* renamed from: b */
    private String f3507b;

    /* renamed from: c */
    private String f3508c;

    /* renamed from: d */
    private String f3509d;

    /* renamed from: e */
    private String f3510e;

    public C0988b(Activity activity, String str, String str2, String str3, String str4) {
        this.f3506a = activity;
        this.f3507b = str;
        this.f3508c = str2;
        this.f3509d = str3;
        this.f3510e = str4;
    }

    public void run() {
        MainActivity.main(this.f3506a, this.f3507b, this.f3508c, this.f3509d, this.f3510e);
    }
}
