package p041io.recompiled.redream;

import android.os.Bundle;
import android.text.method.LinkMovementMethod;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import java.net.URLEncoder;
import p041io.recompiled.redream.C0989c.C0990a;
import p041io.recompiled.redream.C0989c.C0991b;

/* renamed from: io.recompiled.redream.ActivateActivity */
public class ActivateActivity extends C0992d {

    /* renamed from: k */
    static final /* synthetic */ boolean f3446k = true;

    /* renamed from: A */
    private String f3447A;

    /* renamed from: l */
    private ViewGroup f3448l;

    /* renamed from: m */
    private ViewGroup f3449m;

    /* renamed from: n */
    private ViewGroup f3450n;

    /* renamed from: o */
    private TextView f3451o;

    /* renamed from: p */
    private EditText f3452p;

    /* renamed from: q */
    private EditText f3453q;

    /* renamed from: r */
    private TextView f3454r;

    /* renamed from: s */
    private Button f3455s;

    /* renamed from: t */
    private ProgressBar f3456t;

    /* renamed from: u */
    private EditText f3457u;

    /* renamed from: v */
    private EditText f3458v;

    /* renamed from: w */
    private TextView f3459w;

    /* renamed from: x */
    private Button f3460x;

    /* renamed from: y */
    private ProgressBar f3461y;

    /* renamed from: z */
    private String f3462z;

    /* renamed from: a */
    private void m5118a(C0991b bVar) {
        if (f3446k || bVar.f3512a == 200) {
            licenseWrite(bVar.f3513b);
            finish();
            return;
        }
        throw new AssertionError();
    }

    /* access modifiers changed from: private */
    /* renamed from: b */
    public void m5121b(C0991b bVar) {
        if (bVar.f3512a != 200) {
            m5125l();
        } else {
            m5118a(bVar);
        }
    }

    /* access modifiers changed from: private */
    /* renamed from: c */
    public void m5123c(C0991b bVar) {
        TextView textView;
        int i;
        if (bVar.f3512a != 200) {
            if (bVar.f3513b.equals("bad_receipt") || bVar.f3513b.equals("bad_email_pass")) {
                textView = this.f3454r;
                i = R.string.register_error_bad_email_pass;
            } else {
                textView = this.f3454r;
                i = R.string.register_error_unknown;
            }
            textView.setText(i);
            this.f3454r.setVisibility(0);
            this.f3452p.setEnabled(f3446k);
            this.f3453q.setEnabled(f3446k);
            this.f3455s.setEnabled(f3446k);
            this.f3456t.setVisibility(4);
            return;
        }
        m5118a(bVar);
    }

    /* access modifiers changed from: private */
    /* renamed from: d */
    public void m5124d(C0991b bVar) {
        TextView textView;
        int i;
        if (bVar.f3512a != 200) {
            if (bVar.f3513b.equals("bad_email_pass")) {
                textView = this.f3459w;
                i = R.string.login_error_bad_email_pass;
            } else if (bVar.f3513b.equals("no_license")) {
                textView = this.f3459w;
                i = R.string.login_error_no_license;
            } else {
                textView = this.f3459w;
                i = R.string.login_error_unknown;
            }
            textView.setText(i);
            this.f3459w.setVisibility(0);
            this.f3457u.setEnabled(f3446k);
            this.f3458v.setEnabled(f3446k);
            this.f3460x.setEnabled(f3446k);
            this.f3461y.setVisibility(4);
            return;
        }
        m5118a(bVar);
    }

    /* renamed from: l */
    private void m5125l() {
        this.f3448l.setVisibility(8);
        this.f3449m.setVisibility(0);
    }

    public static native int licenseWrite(String str);

    /* renamed from: m */
    private void m5126m() {
        this.f3448l.setVisibility(8);
        this.f3450n.setVisibility(0);
    }

    /* renamed from: n */
    private void m5127n() {
        try {
            String format = String.format("receipt=%s&signature=%s", new Object[]{URLEncoder.encode(this.f3462z, "utf-8"), URLEncoder.encode(this.f3447A, "utf-8")});
            new C0989c(new C0990a() {
                /* renamed from: a */
                public void mo4826a(final C0991b bVar) {
                    ActivateActivity.this.runOnUiThread(new Runnable() {
                        public void run() {
                            ActivateActivity.this.m5121b(bVar);
                        }
                    });
                }
            }).execute(new String[]{"https://redream.io/android/activate", format});
        } catch (Exception unused) {
            Log.d("redream", "receipt encoding failed");
        }
    }

    /* access modifiers changed from: private */
    /* renamed from: o */
    public void m5128o() {
        this.f3452p.setEnabled(false);
        this.f3453q.setEnabled(false);
        this.f3455s.setEnabled(false);
        this.f3456t.setVisibility(0);
        try {
            String format = String.format("receipt=%s&signature=%s&email=%s&password=%s", new Object[]{URLEncoder.encode(this.f3462z, "utf-8"), URLEncoder.encode(this.f3447A, "utf-8"), URLEncoder.encode(this.f3452p.getText().toString(), "utf-8"), URLEncoder.encode(this.f3453q.getText().toString(), "utf-8")});
            new C0989c(new C0990a() {
                /* renamed from: a */
                public void mo4826a(final C0991b bVar) {
                    ActivateActivity.this.runOnUiThread(new Runnable() {
                        public void run() {
                            ActivateActivity.this.m5123c(bVar);
                        }
                    });
                }
            }).execute(new String[]{"https://redream.io/android/register", format});
        } catch (Exception unused) {
            Log.d("redream", "register encoding failed");
        }
    }

    /* access modifiers changed from: private */
    /* renamed from: p */
    public void m5129p() {
        this.f3457u.setEnabled(false);
        this.f3458v.setEnabled(false);
        this.f3460x.setEnabled(false);
        this.f3461y.setVisibility(0);
        try {
            String format = String.format("email=%s&password=%s", new Object[]{URLEncoder.encode(this.f3457u.getText().toString(), "utf-8"), URLEncoder.encode(this.f3458v.getText().toString(), "utf-8")});
            new C0989c(new C0990a() {
                /* renamed from: a */
                public void mo4826a(final C0991b bVar) {
                    ActivateActivity.this.runOnUiThread(new Runnable() {
                        public void run() {
                            ActivateActivity.this.m5124d(bVar);
                        }
                    });
                }
            }).execute(new String[]{"https://redream.io/android/login", format});
        } catch (Exception unused) {
            Log.d("redream", "login encoding failed");
        }
    }

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        Bundle extras = getIntent().getExtras();
        setContentView((int) R.layout.dialog_activate);
        this.f3448l = (ViewGroup) findViewById(R.id.layout_progress);
        this.f3449m = (ViewGroup) findViewById(R.id.layout_register);
        this.f3450n = (ViewGroup) findViewById(R.id.layout_login);
        this.f3451o = (TextView) findViewById(R.id.register_instructions);
        this.f3452p = (EditText) findViewById(R.id.register_email);
        this.f3453q = (EditText) findViewById(R.id.register_password);
        this.f3454r = (TextView) findViewById(R.id.register_error);
        this.f3455s = (Button) findViewById(R.id.register_submit);
        this.f3456t = (ProgressBar) findViewById(R.id.register_progress);
        this.f3457u = (EditText) findViewById(R.id.login_email);
        this.f3458v = (EditText) findViewById(R.id.login_password);
        this.f3459w = (TextView) findViewById(R.id.login_error);
        this.f3460x = (Button) findViewById(R.id.login_submit);
        this.f3461y = (ProgressBar) findViewById(R.id.login_progress);
        this.f3451o.setMovementMethod(LinkMovementMethod.getInstance());
        this.f3451o.setLinksClickable(f3446k);
        this.f3455s.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                ActivateActivity.this.m5128o();
            }
        });
        this.f3460x.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                ActivateActivity.this.m5129p();
            }
        });
        if (extras != null) {
            this.f3462z = extras.getString("receipt", null);
            this.f3447A = extras.getString("signature", null);
            m5127n();
            return;
        }
        m5126m();
    }
}
