package p041io.recompiled.redream;

import android.os.AsyncTask;

/* renamed from: io.recompiled.redream.c */
public class C0989c extends AsyncTask<String, Void, C0991b> {

    /* renamed from: a */
    public C0990a f3511a = null;

    /* renamed from: io.recompiled.redream.c$a */
    public interface C0990a {
        /* renamed from: a */
        void mo4826a(C0991b bVar);
    }

    /* renamed from: io.recompiled.redream.c$b */
    public class C0991b {

        /* renamed from: a */
        public int f3512a;

        /* renamed from: b */
        public String f3513b;

        public C0991b() {
        }
    }

    public C0989c(C0990a aVar) {
        this.f3511a = aVar;
    }

    /* access modifiers changed from: protected */
    /* JADX WARNING: Can't wrap try/catch for region: R(11:0|1|2|3|4|5|6|15|(2:7|(1:9)(1:14))|12|13) */
    /* JADX WARNING: Missing exception handler attribute for start block: B:5:0x0055 */
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public p041io.recompiled.redream.C0989c.C0991b doInBackground(java.lang.String... r8) {
        /*
            r7 = this;
            io.recompiled.redream.c$b r0 = new io.recompiled.redream.c$b
            r0.<init>()
            java.io.ByteArrayOutputStream r1 = new java.io.ByteArrayOutputStream
            r1.<init>()
            java.net.URL r2 = new java.net.URL     // Catch:{ Exception -> 0x0069 }
            r3 = 0
            r4 = r8[r3]     // Catch:{ Exception -> 0x0069 }
            r2.<init>(r4)     // Catch:{ Exception -> 0x0069 }
            r4 = 1
            r8 = r8[r4]     // Catch:{ Exception -> 0x0069 }
            java.lang.String r5 = "UTF-8"
            byte[] r8 = r8.getBytes(r5)     // Catch:{ Exception -> 0x0069 }
            java.net.URLConnection r2 = r2.openConnection()     // Catch:{ Exception -> 0x0069 }
            javax.net.ssl.HttpsURLConnection r2 = (javax.net.ssl.HttpsURLConnection) r2     // Catch:{ Exception -> 0x0069 }
            java.lang.String r5 = "POST"
            r2.setRequestMethod(r5)     // Catch:{ Exception -> 0x0069 }
            java.lang.String r5 = "Content-Type"
            java.lang.String r6 = "application/x-www-form-urlencoded"
            r2.setRequestProperty(r5, r6)     // Catch:{ Exception -> 0x0069 }
            java.lang.String r5 = "Content-Length"
            int r6 = r8.length     // Catch:{ Exception -> 0x0069 }
            java.lang.String r6 = java.lang.String.valueOf(r6)     // Catch:{ Exception -> 0x0069 }
            r2.setRequestProperty(r5, r6)     // Catch:{ Exception -> 0x0069 }
            r2.setDoOutput(r4)     // Catch:{ Exception -> 0x0069 }
            java.io.OutputStream r4 = r2.getOutputStream()     // Catch:{ Exception -> 0x0069 }
            r4.write(r8)     // Catch:{ Exception -> 0x0069 }
            int r8 = r2.getResponseCode()     // Catch:{ Exception -> 0x0069 }
            r0.f3512a = r8     // Catch:{ Exception -> 0x0069 }
            r8 = 4096(0x1000, float:5.74E-42)
            byte[] r8 = new byte[r8]     // Catch:{ Exception -> 0x0069 }
            java.io.BufferedInputStream r4 = new java.io.BufferedInputStream     // Catch:{ IOException -> 0x0055 }
            java.io.InputStream r5 = r2.getInputStream()     // Catch:{ IOException -> 0x0055 }
            r4.<init>(r5)     // Catch:{ IOException -> 0x0055 }
            goto L_0x005e
        L_0x0055:
            java.io.BufferedInputStream r4 = new java.io.BufferedInputStream     // Catch:{ Exception -> 0x0069 }
            java.io.InputStream r2 = r2.getErrorStream()     // Catch:{ Exception -> 0x0069 }
            r4.<init>(r2)     // Catch:{ Exception -> 0x0069 }
        L_0x005e:
            int r2 = r4.read(r8)     // Catch:{ Exception -> 0x0069 }
            r5 = -1
            if (r2 == r5) goto L_0x0073
            r1.write(r8, r3, r2)     // Catch:{ Exception -> 0x0069 }
            goto L_0x005e
        L_0x0069:
            r8 = move-exception
            java.lang.String r2 = "redream"
            java.lang.String r8 = r8.toString()
            android.util.Log.d(r2, r8)
        L_0x0073:
            java.lang.String r8 = r1.toString()
            r0.f3513b = r8
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: p041io.recompiled.redream.C0989c.doInBackground(java.lang.String[]):io.recompiled.redream.c$b");
    }

    /* access modifiers changed from: protected */
    /* renamed from: a */
    public void onPostExecute(C0991b bVar) {
        this.f3511a.mo4826a(bVar);
    }
}
