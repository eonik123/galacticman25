package p041io.recompiled.redream;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import com.android.billingclient.api.C0966f;
import java.util.List;
import p041io.recompiled.redream.C0982a.C0987a;

/* renamed from: io.recompiled.redream.UpgradeActivity */
public class UpgradeActivity extends C0992d implements C0987a {

    /* renamed from: k */
    private C0982a f3485k;

    /* renamed from: l */
    private ViewGroup f3486l;

    /* renamed from: m */
    private ViewGroup f3487m;

    /* renamed from: n */
    private Button f3488n;

    /* renamed from: o */
    private Button f3489o;

    /* access modifiers changed from: private */
    /* renamed from: a */
    public void m5139a(View view) {
        this.f3485k.mo4866a("premium_android", "inapp");
    }

    /* access modifiers changed from: private */
    /* renamed from: b */
    public void m5141b(View view) {
        startActivity(new Intent(getApplicationContext(), ActivateActivity.class));
        finish();
    }

    /* renamed from: l */
    private void m5143l() {
        this.f3486l.setVisibility(8);
        this.f3487m.setVisibility(0);
    }

    /* renamed from: a */
    public void mo4860a(List<C0966f> list) {
        C0966f fVar = null;
        for (C0966f fVar2 : list) {
            if (fVar2.mo4807a().equals("premium_android")) {
                fVar = fVar2;
            }
        }
        if (fVar != null) {
            Intent intent = new Intent(getApplicationContext(), ActivateActivity.class);
            intent.putExtra("receipt", fVar.mo4809c());
            intent.putExtra("signature", fVar.mo4810d());
            startActivity(intent);
            finish();
            return;
        }
        m5143l();
    }

    /* renamed from: b_ */
    public void mo4861b_() {
        StringBuilder sb = new StringBuilder();
        sb.append("onBillingClientSetupFinished ");
        sb.append(this.f3485k.mo4868b());
        Log.d("redream", sb.toString());
        if (this.f3485k.mo4868b() != 0) {
            m5143l();
        } else {
            this.f3488n.setEnabled(true);
        }
    }

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView((int) R.layout.dialog_upgrade);
        this.f3485k = new C0982a(this, this);
        this.f3486l = (ViewGroup) findViewById(R.id.layout_progress);
        this.f3487m = (ViewGroup) findViewById(R.id.layout_upgrade);
        this.f3488n = (Button) findViewById(R.id.btn_purchase);
        this.f3489o = (Button) findViewById(R.id.btn_login);
        this.f3488n.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                UpgradeActivity.this.m5139a(view);
            }
        });
        this.f3489o.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                UpgradeActivity.this.m5141b(view);
            }
        });
    }

    public void onDestroy() {
        if (this.f3485k != null) {
            this.f3485k.mo4864a();
        }
        super.onDestroy();
    }

    /* access modifiers changed from: protected */
    public void onResume() {
        super.onResume();
        if (this.f3485k.mo4868b() == 0) {
            this.f3485k.mo4869c();
        }
    }
}
