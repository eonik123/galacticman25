package p041io.recompiled.redream;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.hardware.input.InputManager;
import android.hardware.input.InputManager.InputDeviceListener;
import android.media.AudioManager;
import android.os.Bundle;
import android.os.Environment;
import android.provider.Settings.Secure;
import android.support.annotation.Keep;
import android.support.p018v4.p019a.C0293a;
import android.view.InputDevice;
import android.view.InputDevice.MotionRange;
import android.view.InputEvent;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.Surface;
import android.view.SurfaceHolder;
import android.view.SurfaceHolder.Callback;
import android.view.SurfaceView;
import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/* renamed from: io.recompiled.redream.MainActivity */
public class MainActivity extends Activity implements InputDeviceListener, Callback {

    /* renamed from: a */
    static final /* synthetic */ boolean f3474a = true;

    /* renamed from: b */
    private AudioManager f3475b;

    /* renamed from: c */
    private InputManager f3476c;

    /* renamed from: d */
    private Map<String, Short> f3477d;

    /* renamed from: e */
    private SurfaceView f3478e;

    /* renamed from: f */
    private Object f3479f;

    /* renamed from: g */
    private Boolean f3480g;

    /* renamed from: h */
    private Thread f3481h;

    static {
        System.loadLibrary("redream");
    }

    /* renamed from: a */
    private boolean m5133a(InputEvent inputEvent) {
        InputDevice device = inputEvent.getDevice();
        boolean z = false;
        if (device == null) {
            return false;
        }
        if ((device.getSources() & 16777232) == 16777232) {
            z = f3474a;
        }
        return z;
    }

    public static native void appDestroy();

    public static native void appPause();

    public static native void appResume();

    /* renamed from: b */
    private void m5134b() {
        this.f3478e = new SurfaceView(this);
        this.f3478e.setKeepScreenOn(f3474a);
        this.f3478e.getHolder().addCallback(this);
        setContentView(this.f3478e);
    }

    /* renamed from: c */
    private void m5135c() {
        this.f3478e.getHolder().removeCallback(this);
        this.f3478e = null;
    }

    /* renamed from: d */
    private void m5136d() {
        this.f3476c.registerInputDeviceListener(this, null);
    }

    public static native void deviceAdded(int i);

    public static native void deviceChanged(int i);

    public static native void deviceRemoved(int i);

    /* renamed from: e */
    private void m5137e() {
        this.f3477d.clear();
        this.f3476c.unregisterInputDeviceListener(this);
    }

    public static native void joyAxis(int i, int i2, short s);

    public static native void joyButton(int i, int i2, short s);

    public static native boolean keyPress(int i, short s);

    public static native int main(Activity activity, String str, String str2, String str3, String str4);

    public static native void surfaceCreated();

    public static native void surfaceDestroyed();

    public static native void surfaceResized(int i, int i2);

    public static native void touchDown(int i, int i2, int i3);

    public static native void touchMove(int i, int i2, int i3);

    public static native void touchUp(int i, int i2, int i3);

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo4830a() {
        getWindow().getDecorView().setSystemUiVisibility(5894);
    }

    @Keep
    public int audioFramesPerBuffer() {
        return Integer.parseInt(this.f3475b.getProperty("android.media.property.OUTPUT_FRAMES_PER_BUFFER"));
    }

    @Keep
    public int audioSampleRate() {
        return Integer.parseInt(this.f3475b.getProperty("android.media.property.OUTPUT_SAMPLE_RATE"));
    }

    @Keep
    public boolean canReadExternalStorageDir() {
        if (C0293a.m1185a((Context) this, "android.permission.READ_EXTERNAL_STORAGE") != 0) {
            return false;
        }
        return f3474a;
    }

    /* access modifiers changed from: 0000 */
    @Keep
    public void close() {
        runOnUiThread(new Runnable() {
            public void run() {
                MainActivity.this.finishAndRemoveTask();
            }
        });
    }

    @Keep
    public String deviceDescriptor(int i) {
        return this.f3476c.getInputDevice(i).getDescriptor();
    }

    @Keep
    public String deviceName(int i) {
        return this.f3476c.getInputDevice(i).getName();
    }

    @Keep
    public String externalStorageDir() {
        return Environment.getExternalStorageDirectory().getAbsolutePath();
    }

    @Keep
    public void hapticVibrate() {
        this.f3478e.performHapticFeedback(1, 2);
    }

    @Keep
    public int[] inputDevices() {
        int[] inputDeviceIds = this.f3476c.getInputDeviceIds();
        ArrayList arrayList = new ArrayList();
        for (int i = 0; i < inputDeviceIds.length; i++) {
            if ((this.f3476c.getInputDevice(inputDeviceIds[i]).getSources() & 16777232) == 16777232) {
                arrayList.add(Integer.valueOf(inputDeviceIds[i]));
            }
        }
        int[] iArr = new int[arrayList.size()];
        for (int i2 = 0; i2 < arrayList.size(); i2++) {
            iArr[i2] = ((Integer) arrayList.get(i2)).intValue();
        }
        return iArr;
    }

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        String absolutePath = getFilesDir().getAbsolutePath();
        String str = null;
        File externalFilesDir = getExternalFilesDir(null);
        String absolutePath2 = externalFilesDir != null ? externalFilesDir.getAbsolutePath() : null;
        String str2 = absolutePath2 != null ? absolutePath2 : absolutePath;
        String string = Secure.getString(getContentResolver(), "android_id");
        Intent intent = getIntent();
        String action = intent.getAction();
        if (action != null && action.equals("android.intent.action.VIEW")) {
            str = intent.getData().getPath();
        }
        String str3 = str;
        this.f3475b = (AudioManager) getSystemService("audio");
        this.f3476c = (InputManager) getSystemService("input");
        this.f3477d = new HashMap();
        mo4830a();
        m5134b();
        m5136d();
        C0988b bVar = new C0988b(this, str2, absolutePath, string, str3);
        this.f3481h = bVar;
        this.f3481h.start();
    }

    /* access modifiers changed from: protected */
    public void onDestroy() {
        appDestroy();
        try {
            this.f3481h.join();
        } catch (InterruptedException unused) {
        }
        this.f3481h = null;
        m5135c();
        m5137e();
        super.onDestroy();
    }

    public boolean onGenericMotionEvent(MotionEvent motionEvent) {
        if (!m5133a(motionEvent)) {
            return false;
        }
        InputDevice device = motionEvent.getDevice();
        if (motionEvent.getActionMasked() != 2) {
            return false;
        }
        List motionRanges = device.getMotionRanges();
        int historySize = motionEvent.getHistorySize();
        for (int i = 0; i < motionRanges.size(); i++) {
            MotionRange motionRange = (MotionRange) motionRanges.get(i);
            int axis = motionRange.getAxis();
            if (motionRange.isFromSource(16777232)) {
                String format = String.format("%d-%d", new Object[]{Integer.valueOf(device.getId()), Integer.valueOf(axis)});
                Short sh = (Short) this.f3477d.get(format);
                int i2 = 0;
                while (i2 <= historySize) {
                    short axisValue = (short) ((int) ((((((i2 == historySize ? motionEvent.getAxisValue(axis) : motionEvent.getHistoricalAxisValue(axis, i2)) - motionRange.getMin()) / motionRange.getRange()) * 2.0f) - 1.0f) * 32767.0f));
                    if (sh == null || axisValue != sh.shortValue()) {
                        joyAxis(device.getId(), axis, axisValue);
                        sh = Short.valueOf(axisValue);
                    }
                    i2++;
                }
                this.f3477d.put(format, sh);
            }
        }
        return f3474a;
    }

    public void onInputDeviceAdded(int i) {
        deviceAdded(i);
    }

    public void onInputDeviceChanged(int i) {
        deviceChanged(i);
    }

    public void onInputDeviceRemoved(int i) {
        deviceRemoved(i);
    }

    public boolean onKeyDown(int i, KeyEvent keyEvent) {
        if (!m5133a(keyEvent)) {
            return keyPress(i, Short.MAX_VALUE);
        }
        joyButton(keyEvent.getDevice().getId(), i, Short.MAX_VALUE);
        return f3474a;
    }

    public boolean onKeyUp(int i, KeyEvent keyEvent) {
        if (!m5133a(keyEvent)) {
            return keyPress(i, 0);
        }
        joyButton(keyEvent.getDevice().getId(), i, 0);
        return f3474a;
    }

    /* access modifiers changed from: protected */
    public void onPause() {
        super.onPause();
        appPause();
    }

    public void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        if (i == 101) {
            boolean z = false;
            if (iArr.length > 0 && iArr[0] == 0) {
                z = f3474a;
            }
            this.f3480g = Boolean.valueOf(z);
            synchronized (this.f3479f) {
                this.f3479f.notify();
            }
        }
    }

    /* access modifiers changed from: protected */
    public void onResume() {
        super.onResume();
        mo4830a();
        appResume();
    }

    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean onTouchEvent(android.view.MotionEvent r6) {
        /*
            r5 = this;
            int r0 = r6.getActionMasked()
            int r1 = r6.getActionIndex()
            r2 = 0
            r3 = 1
            switch(r0) {
                case 0: goto L_0x0043;
                case 1: goto L_0x0028;
                case 2: goto L_0x000e;
                case 3: goto L_0x0028;
                case 4: goto L_0x000d;
                case 5: goto L_0x0043;
                case 6: goto L_0x0028;
                default: goto L_0x000d;
            }
        L_0x000d:
            return r3
        L_0x000e:
            int r0 = r6.getPointerCount()
            if (r2 >= r0) goto L_0x005d
            int r0 = r6.getPointerId(r2)
            float r1 = r6.getX(r2)
            int r1 = (int) r1
            float r4 = r6.getY(r2)
            int r4 = (int) r4
            touchMove(r0, r1, r4)
            int r2 = r2 + 1
            goto L_0x000e
        L_0x0028:
            int r0 = r6.getPointerId(r1)
            float r4 = r6.getX(r1)
            int r4 = (int) r4
            float r6 = r6.getY(r1)
            int r6 = (int) r6
            touchUp(r0, r4, r6)
            android.view.SurfaceView r6 = r5.f3478e
            android.view.ViewParent r6 = r6.getParent()
            r6.requestDisallowInterceptTouchEvent(r2)
            return r3
        L_0x0043:
            int r0 = r6.getPointerId(r1)
            float r2 = r6.getX(r1)
            int r2 = (int) r2
            float r6 = r6.getY(r1)
            int r6 = (int) r6
            touchDown(r0, r2, r6)
            android.view.SurfaceView r6 = r5.f3478e
            android.view.ViewParent r6 = r6.getParent()
            r6.requestDisallowInterceptTouchEvent(r3)
        L_0x005d:
            return r3
        */
        throw new UnsupportedOperationException("Method not decompiled: p041io.recompiled.redream.MainActivity.onTouchEvent(android.view.MotionEvent):boolean");
    }

    /* JADX WARNING: Exception block dominator not found, dom blocks: [] */
    /* JADX WARNING: Missing exception handler attribute for start block: B:11:0x0028 */
    @android.support.annotation.Keep
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean reqReadExternalStorageDir() {
        /*
            r2 = this;
            boolean r0 = f3474a
            if (r0 != 0) goto L_0x000e
            java.lang.Object r0 = r2.f3479f
            if (r0 == 0) goto L_0x000e
            java.lang.AssertionError r0 = new java.lang.AssertionError
            r0.<init>()
            throw r0
        L_0x000e:
            java.lang.Object r0 = new java.lang.Object
            r0.<init>()
            r2.f3479f = r0
            io.recompiled.redream.MainActivity$1 r0 = new io.recompiled.redream.MainActivity$1
            r0.<init>(r2)
            r2.runOnUiThread(r0)
            java.lang.Object r0 = r2.f3479f
            monitor-enter(r0)
            java.lang.Object r1 = r2.f3479f     // Catch:{ InterruptedException -> 0x0028 }
            r1.wait()     // Catch:{ InterruptedException -> 0x0028 }
            goto L_0x0028
        L_0x0026:
            r1 = move-exception
            goto L_0x0033
        L_0x0028:
            monitor-exit(r0)     // Catch:{ all -> 0x0026 }
            r0 = 0
            r2.f3479f = r0
            java.lang.Boolean r0 = r2.f3480g
            boolean r0 = r0.booleanValue()
            return r0
        L_0x0033:
            monitor-exit(r0)     // Catch:{ all -> 0x0026 }
            throw r1
        */
        throw new UnsupportedOperationException("Method not decompiled: p041io.recompiled.redream.MainActivity.reqReadExternalStorageDir():boolean");
    }

    @Keep
    public void showUpgradeDialog() {
        startActivity(new Intent(this, UpgradeActivity.class));
    }

    public void surfaceChanged(SurfaceHolder surfaceHolder, int i, int i2, int i3) {
        surfaceResized(i2, i3);
    }

    public void surfaceCreated(SurfaceHolder surfaceHolder) {
        surfaceCreated();
    }

    public void surfaceDestroyed(SurfaceHolder surfaceHolder) {
        surfaceDestroyed();
    }

    @Keep
    public Surface videoSurface() {
        return this.f3478e.getHolder().getSurface();
    }
}
