package p041io.recompiled.redream;

import android.app.Activity;
import android.content.Context;
import android.util.Log;
import com.android.billingclient.api.C0948b;
import com.android.billingclient.api.C0962d;
import com.android.billingclient.api.C0963e;
import com.android.billingclient.api.C0966f;
import com.android.billingclient.api.C0966f.C0967a;
import com.android.billingclient.api.C0968g;
import java.util.ArrayList;
import java.util.List;

/* renamed from: io.recompiled.redream.a */
public class C0982a implements C0968g {
    /* access modifiers changed from: private */

    /* renamed from: a */
    public C0948b f3492a;
    /* access modifiers changed from: private */

    /* renamed from: b */
    public final C0987a f3493b;
    /* access modifiers changed from: private */

    /* renamed from: c */
    public final Activity f3494c;
    /* access modifiers changed from: private */

    /* renamed from: d */
    public boolean f3495d;
    /* access modifiers changed from: private */

    /* renamed from: e */
    public int f3496e = -1;

    /* renamed from: f */
    private final List<C0966f> f3497f = new ArrayList();

    /* renamed from: io.recompiled.redream.a$a */
    public interface C0987a {
        /* renamed from: a */
        void mo4860a(List<C0966f> list);

        /* renamed from: b_ */
        void mo4861b_();
    }

    public C0982a(Activity activity, C0987a aVar) {
        Log.d("redream", "Creating Billing client.");
        this.f3494c = activity;
        this.f3493b = aVar;
        this.f3492a = C0948b.m5045a((Context) this.f3494c).mo4775a(this).mo4776a();
        Log.d("redream", "Starting setup.");
        mo4865a((Runnable) new Runnable() {
            public void run() {
                C0982a.this.f3493b.mo4861b_();
                Log.d("redream", "Setup successful. Querying inventory.");
                C0982a.this.mo4869c();
            }
        });
    }

    /* access modifiers changed from: private */
    /* renamed from: a */
    public void m5148a(C0967a aVar) {
        if (this.f3492a == null || aVar.mo4814a() != 0) {
            StringBuilder sb = new StringBuilder();
            sb.append("Billing client was null or result code (");
            sb.append(aVar.mo4814a());
            sb.append(") was bad - quitting");
            Log.w("redream", sb.toString());
            return;
        }
        Log.d("redream", "Query inventory was successful.");
        this.f3497f.clear();
        mo4816a(0, aVar.mo4815b());
    }

    /* renamed from: a */
    private void m5149a(C0966f fVar) {
        StringBuilder sb = new StringBuilder();
        sb.append("Got a verified purchase: ");
        sb.append(fVar);
        Log.d("redream", sb.toString());
        this.f3497f.add(fVar);
    }

    /* renamed from: b */
    private void m5153b(Runnable runnable) {
        if (this.f3495d) {
            runnable.run();
        } else {
            mo4865a(runnable);
        }
    }

    /* renamed from: a */
    public void mo4864a() {
        Log.d("redream", "Destroying the manager.");
        if (this.f3492a != null && this.f3492a.mo4773a()) {
            this.f3492a.mo4774b();
            this.f3492a = null;
        }
    }

    /* renamed from: a */
    public void mo4816a(int i, List<C0966f> list) {
        if (i == 0) {
            for (C0966f a : list) {
                m5149a(a);
            }
            this.f3493b.mo4860a(this.f3497f);
        } else if (i == 1) {
            Log.i("redream", "onPurchasesUpdated() - user cancelled the purchase flow - skipping");
        } else {
            StringBuilder sb = new StringBuilder();
            sb.append("onPurchasesUpdated() got unknown resultCode: ");
            sb.append(i);
            Log.w("redream", sb.toString());
        }
    }

    /* renamed from: a */
    public void mo4865a(final Runnable runnable) {
        this.f3492a.mo4772a((C0962d) new C0962d() {
            /* renamed from: a */
            public void mo4793a() {
                C0982a.this.f3495d = false;
            }

            /* renamed from: a */
            public void mo4794a(int i) {
                StringBuilder sb = new StringBuilder();
                sb.append("Setup finished. Response code: ");
                sb.append(i);
                Log.d("redream", sb.toString());
                C0982a.this.f3496e = i;
                if (i == 0) {
                    C0982a.this.f3495d = true;
                }
                if (runnable != null) {
                    runnable.run();
                }
            }
        });
    }

    /* renamed from: a */
    public void mo4866a(String str, String str2) {
        mo4867a(str, null, str2);
    }

    /* renamed from: a */
    public void mo4867a(final String str, final ArrayList<String> arrayList, final String str2) {
        m5153b((Runnable) new Runnable() {
            public void run() {
                String str = "redream";
                StringBuilder sb = new StringBuilder();
                sb.append("Launching in-app purchase flow. Replace old SKU? ");
                sb.append(arrayList != null);
                Log.d(str, sb.toString());
                C0982a.this.f3492a.mo4770a(C0982a.this.f3494c, C0963e.m5092i().mo4803a(str).mo4806b(str2).mo4804a(arrayList).mo4805a());
            }
        });
    }

    /* renamed from: b */
    public int mo4868b() {
        return this.f3496e;
    }

    /* renamed from: c */
    public void mo4869c() {
        m5153b((Runnable) new Runnable() {
            public void run() {
                long currentTimeMillis = System.currentTimeMillis();
                C0967a a = C0982a.this.f3492a.mo4771a("inapp");
                StringBuilder sb = new StringBuilder();
                sb.append("Querying purchases elapsed time: ");
                sb.append(System.currentTimeMillis() - currentTimeMillis);
                sb.append("ms");
                Log.i("redream", sb.toString());
                if (a.mo4814a() != 0) {
                    StringBuilder sb2 = new StringBuilder();
                    sb2.append("queryPurchases() got an error response code: ");
                    sb2.append(a.mo4814a());
                    Log.w("redream", sb2.toString());
                }
                C0982a.this.m5148a(a);
            }
        });
    }
}
