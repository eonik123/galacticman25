package androidx.core.graphics.drawable;

import android.content.res.ColorStateList;
import android.os.Parcelable;
import android.support.p018v4.graphics.drawable.IconCompat;
import androidx.versionedparcelable.C0938a;

public class IconCompatParcelizer {
    public static IconCompat read(C0938a aVar) {
        IconCompat iconCompat = new IconCompat();
        iconCompat.f1350a = aVar.mo4735b(iconCompat.f1350a, 1);
        iconCompat.f1352c = aVar.mo4740b(iconCompat.f1352c, 2);
        iconCompat.f1353d = aVar.mo4736b(iconCompat.f1353d, 3);
        iconCompat.f1354e = aVar.mo4735b(iconCompat.f1354e, 4);
        iconCompat.f1355f = aVar.mo4735b(iconCompat.f1355f, 5);
        iconCompat.f1356g = (ColorStateList) aVar.mo4736b(iconCompat.f1356g, 6);
        iconCompat.f1358j = aVar.mo4737b(iconCompat.f1358j, 7);
        iconCompat.mo1784c();
        return iconCompat;
    }

    public static void write(IconCompat iconCompat, C0938a aVar) {
        aVar.mo4731a(true, true);
        iconCompat.mo1782a(aVar.mo4734a());
        aVar.mo4725a(iconCompat.f1350a, 1);
        aVar.mo4733a(iconCompat.f1352c, 2);
        aVar.mo4727a(iconCompat.f1353d, 3);
        aVar.mo4725a(iconCompat.f1354e, 4);
        aVar.mo4725a(iconCompat.f1355f, 5);
        aVar.mo4727a((Parcelable) iconCompat.f1356g, 6);
        aVar.mo4730a(iconCompat.f1358j, 7);
    }
}
