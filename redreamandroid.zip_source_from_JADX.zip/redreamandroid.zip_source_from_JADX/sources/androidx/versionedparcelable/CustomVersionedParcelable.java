package androidx.versionedparcelable;

public abstract class CustomVersionedParcelable implements C0940c {
    /* renamed from: a */
    public void mo1782a(boolean z) {
    }

    /* renamed from: c */
    public void mo1784c() {
    }
}
