package androidx.versionedparcelable;

import android.os.Parcelable;
import java.lang.reflect.InvocationTargetException;

/* renamed from: androidx.versionedparcelable.a */
public abstract class C0938a {
    /* renamed from: a */
    protected static <T extends C0940c> T m4967a(String str, C0938a aVar) {
        try {
            return (C0940c) Class.forName(str, true, C0938a.class.getClassLoader()).getDeclaredMethod("read", new Class[]{C0938a.class}).invoke(null, new Object[]{aVar});
        } catch (IllegalAccessException e) {
            throw new RuntimeException("VersionedParcel encountered IllegalAccessException", e);
        } catch (InvocationTargetException e2) {
            if (e2.getCause() instanceof RuntimeException) {
                throw ((RuntimeException) e2.getCause());
            }
            throw new RuntimeException("VersionedParcel encountered InvocationTargetException", e2);
        } catch (NoSuchMethodException e3) {
            throw new RuntimeException("VersionedParcel encountered NoSuchMethodException", e3);
        } catch (ClassNotFoundException e4) {
            throw new RuntimeException("VersionedParcel encountered ClassNotFoundException", e4);
        }
    }

    /* renamed from: a */
    private static Class m4968a(Class<? extends C0940c> cls) {
        return Class.forName(String.format("%s.%sParcelizer", new Object[]{cls.getPackage().getName(), cls.getSimpleName()}), false, cls.getClassLoader());
    }

    /* renamed from: a */
    protected static <T extends C0940c> void m4969a(T t, C0938a aVar) {
        try {
            m4971c(t).getDeclaredMethod("write", new Class[]{t.getClass(), C0938a.class}).invoke(null, new Object[]{t, aVar});
        } catch (IllegalAccessException e) {
            throw new RuntimeException("VersionedParcel encountered IllegalAccessException", e);
        } catch (InvocationTargetException e2) {
            if (e2.getCause() instanceof RuntimeException) {
                throw ((RuntimeException) e2.getCause());
            }
            throw new RuntimeException("VersionedParcel encountered InvocationTargetException", e2);
        } catch (NoSuchMethodException e3) {
            throw new RuntimeException("VersionedParcel encountered NoSuchMethodException", e3);
        } catch (ClassNotFoundException e4) {
            throw new RuntimeException("VersionedParcel encountered ClassNotFoundException", e4);
        }
    }

    /* renamed from: b */
    private void m4970b(C0940c cVar) {
        try {
            mo4729a(m4968a(cVar.getClass()).getName());
        } catch (ClassNotFoundException e) {
            StringBuilder sb = new StringBuilder();
            sb.append(cVar.getClass().getSimpleName());
            sb.append(" does not have a Parcelizer");
            throw new RuntimeException(sb.toString(), e);
        }
    }

    /* renamed from: c */
    private static <T extends C0940c> Class m4971c(T t) {
        return m4968a(t.getClass());
    }

    /* access modifiers changed from: protected */
    /* renamed from: a */
    public abstract void mo4724a(int i);

    /* renamed from: a */
    public void mo4725a(int i, int i2) {
        mo4742c(i2);
        mo4724a(i);
    }

    /* access modifiers changed from: protected */
    /* renamed from: a */
    public abstract void mo4726a(Parcelable parcelable);

    /* renamed from: a */
    public void mo4727a(Parcelable parcelable, int i) {
        mo4742c(i);
        mo4726a(parcelable);
    }

    /* access modifiers changed from: protected */
    /* renamed from: a */
    public void mo4728a(C0940c cVar) {
        if (cVar == null) {
            mo4729a((String) null);
            return;
        }
        m4970b(cVar);
        C0938a c = mo4741c();
        m4969a((T) cVar, c);
        c.mo4738b();
    }

    /* access modifiers changed from: protected */
    /* renamed from: a */
    public abstract void mo4729a(String str);

    /* renamed from: a */
    public void mo4730a(String str, int i) {
        mo4742c(i);
        mo4729a(str);
    }

    /* renamed from: a */
    public void mo4731a(boolean z, boolean z2) {
    }

    /* access modifiers changed from: protected */
    /* renamed from: a */
    public abstract void mo4732a(byte[] bArr);

    /* renamed from: a */
    public void mo4733a(byte[] bArr, int i) {
        mo4742c(i);
        mo4732a(bArr);
    }

    /* renamed from: a */
    public boolean mo4734a() {
        return false;
    }

    /* renamed from: b */
    public int mo4735b(int i, int i2) {
        return !mo4739b(i2) ? i : mo4743d();
    }

    /* renamed from: b */
    public <T extends Parcelable> T mo4736b(T t, int i) {
        return !mo4739b(i) ? t : mo4746g();
    }

    /* renamed from: b */
    public String mo4737b(String str, int i) {
        return !mo4739b(i) ? str : mo4744e();
    }

    /* access modifiers changed from: protected */
    /* renamed from: b */
    public abstract void mo4738b();

    /* access modifiers changed from: protected */
    /* renamed from: b */
    public abstract boolean mo4739b(int i);

    /* renamed from: b */
    public byte[] mo4740b(byte[] bArr, int i) {
        return !mo4739b(i) ? bArr : mo4745f();
    }

    /* access modifiers changed from: protected */
    /* renamed from: c */
    public abstract C0938a mo4741c();

    /* access modifiers changed from: protected */
    /* renamed from: c */
    public abstract void mo4742c(int i);

    /* access modifiers changed from: protected */
    /* renamed from: d */
    public abstract int mo4743d();

    /* access modifiers changed from: protected */
    /* renamed from: e */
    public abstract String mo4744e();

    /* access modifiers changed from: protected */
    /* renamed from: f */
    public abstract byte[] mo4745f();

    /* access modifiers changed from: protected */
    /* renamed from: g */
    public abstract <T extends Parcelable> T mo4746g();

    /* access modifiers changed from: protected */
    /* renamed from: h */
    public <T extends C0940c> T mo4747h() {
        String e = mo4744e();
        if (e == null) {
            return null;
        }
        return m4967a(e, mo4741c());
    }
}
