package androidx.versionedparcelable;

import android.os.Parcel;
import android.os.Parcelable;
import android.util.SparseIntArray;

/* renamed from: androidx.versionedparcelable.b */
class C0939b extends C0938a {

    /* renamed from: a */
    private final SparseIntArray f3369a;

    /* renamed from: b */
    private final Parcel f3370b;

    /* renamed from: c */
    private final int f3371c;

    /* renamed from: d */
    private final int f3372d;

    /* renamed from: e */
    private final String f3373e;

    /* renamed from: f */
    private int f3374f;

    /* renamed from: g */
    private int f3375g;

    C0939b(Parcel parcel) {
        this(parcel, parcel.dataPosition(), parcel.dataSize(), "");
    }

    C0939b(Parcel parcel, int i, int i2, String str) {
        this.f3369a = new SparseIntArray();
        this.f3374f = -1;
        this.f3375g = 0;
        this.f3370b = parcel;
        this.f3371c = i;
        this.f3372d = i2;
        this.f3375g = this.f3371c;
        this.f3373e = str;
    }

    /* renamed from: d */
    private int m4996d(int i) {
        while (this.f3375g < this.f3372d) {
            this.f3370b.setDataPosition(this.f3375g);
            int readInt = this.f3370b.readInt();
            int readInt2 = this.f3370b.readInt();
            this.f3375g += readInt;
            if (readInt2 == i) {
                return this.f3370b.dataPosition();
            }
        }
        return -1;
    }

    /* renamed from: a */
    public void mo4724a(int i) {
        this.f3370b.writeInt(i);
    }

    /* renamed from: a */
    public void mo4726a(Parcelable parcelable) {
        this.f3370b.writeParcelable(parcelable, 0);
    }

    /* renamed from: a */
    public void mo4729a(String str) {
        this.f3370b.writeString(str);
    }

    /* renamed from: a */
    public void mo4732a(byte[] bArr) {
        if (bArr != null) {
            this.f3370b.writeInt(bArr.length);
            this.f3370b.writeByteArray(bArr);
            return;
        }
        this.f3370b.writeInt(-1);
    }

    /* renamed from: b */
    public void mo4738b() {
        if (this.f3374f >= 0) {
            int i = this.f3369a.get(this.f3374f);
            int dataPosition = this.f3370b.dataPosition();
            int i2 = dataPosition - i;
            this.f3370b.setDataPosition(i);
            this.f3370b.writeInt(i2);
            this.f3370b.setDataPosition(dataPosition);
        }
    }

    /* renamed from: b */
    public boolean mo4739b(int i) {
        int d = m4996d(i);
        if (d == -1) {
            return false;
        }
        this.f3370b.setDataPosition(d);
        return true;
    }

    /* access modifiers changed from: protected */
    /* renamed from: c */
    public C0938a mo4741c() {
        Parcel parcel = this.f3370b;
        int dataPosition = this.f3370b.dataPosition();
        int i = this.f3375g == this.f3371c ? this.f3372d : this.f3375g;
        StringBuilder sb = new StringBuilder();
        sb.append(this.f3373e);
        sb.append("  ");
        return new C0939b(parcel, dataPosition, i, sb.toString());
    }

    /* renamed from: c */
    public void mo4742c(int i) {
        mo4738b();
        this.f3374f = i;
        this.f3369a.put(i, this.f3370b.dataPosition());
        mo4724a(0);
        mo4724a(i);
    }

    /* renamed from: d */
    public int mo4743d() {
        return this.f3370b.readInt();
    }

    /* renamed from: e */
    public String mo4744e() {
        return this.f3370b.readString();
    }

    /* renamed from: f */
    public byte[] mo4745f() {
        int readInt = this.f3370b.readInt();
        if (readInt < 0) {
            return null;
        }
        byte[] bArr = new byte[readInt];
        this.f3370b.readByteArray(bArr);
        return bArr;
    }

    /* renamed from: g */
    public <T extends Parcelable> T mo4746g() {
        return this.f3370b.readParcelable(getClass().getClassLoader());
    }
}
