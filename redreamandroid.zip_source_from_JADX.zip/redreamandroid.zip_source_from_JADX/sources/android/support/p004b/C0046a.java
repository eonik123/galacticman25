package android.support.p004b;

import io.recompiled.redream.R;

/* renamed from: android.support.b.a */
public final class C0046a {

    /* renamed from: android.support.b.a$a */
    public static final class C0047a {
        public static final int alpha = 2130903079;
        public static final int coordinatorLayoutStyle = 2130903198;
        public static final int font = 2130903248;
        public static final int fontProviderAuthority = 2130903250;
        public static final int fontProviderCerts = 2130903251;
        public static final int fontProviderFetchStrategy = 2130903252;
        public static final int fontProviderFetchTimeout = 2130903253;
        public static final int fontProviderPackage = 2130903254;
        public static final int fontProviderQuery = 2130903255;
        public static final int fontStyle = 2130903256;
        public static final int fontVariationSettings = 2130903257;
        public static final int fontWeight = 2130903258;
        public static final int keylines = 2130903302;
        public static final int layout_anchor = 2130903307;
        public static final int layout_anchorGravity = 2130903308;
        public static final int layout_behavior = 2130903309;
        public static final int layout_dodgeInsetEdges = 2130903312;
        public static final int layout_insetEdge = 2130903313;
        public static final int layout_keyline = 2130903314;
        public static final int statusBarBackground = 2130903405;
        public static final int ttcIndex = 2130903503;
    }

    /* renamed from: android.support.b.a$b */
    public static final class C0048b {
        public static final int TextAppearance_Compat_Notification = 2131624217;
        public static final int TextAppearance_Compat_Notification_Info = 2131624218;
        public static final int TextAppearance_Compat_Notification_Line2 = 2131624219;
        public static final int TextAppearance_Compat_Notification_Time = 2131624220;
        public static final int TextAppearance_Compat_Notification_Title = 2131624221;
        public static final int Widget_Compat_NotificationActionContainer = 2131624387;
        public static final int Widget_Compat_NotificationActionText = 2131624388;
        public static final int Widget_Support_CoordinatorLayout = 2131624435;
    }

    /* renamed from: android.support.b.a$c */
    public static final class C0049c {
        public static final int[] ColorStateListItem = {16843173, 16843551, R.attr.alpha};
        public static final int ColorStateListItem_alpha = 2;
        public static final int ColorStateListItem_android_alpha = 1;
        public static final int ColorStateListItem_android_color = 0;
        public static final int[] CoordinatorLayout = {R.attr.keylines, R.attr.statusBarBackground};
        public static final int[] CoordinatorLayout_Layout = {16842931, R.attr.layout_anchor, R.attr.layout_anchorGravity, R.attr.layout_behavior, R.attr.layout_dodgeInsetEdges, R.attr.layout_insetEdge, R.attr.layout_keyline};
        public static final int CoordinatorLayout_Layout_android_layout_gravity = 0;
        public static final int CoordinatorLayout_Layout_layout_anchor = 1;
        public static final int CoordinatorLayout_Layout_layout_anchorGravity = 2;
        public static final int CoordinatorLayout_Layout_layout_behavior = 3;
        public static final int CoordinatorLayout_Layout_layout_dodgeInsetEdges = 4;
        public static final int CoordinatorLayout_Layout_layout_insetEdge = 5;
        public static final int CoordinatorLayout_Layout_layout_keyline = 6;
        public static final int CoordinatorLayout_keylines = 0;
        public static final int CoordinatorLayout_statusBarBackground = 1;
        public static final int[] FontFamily = {R.attr.fontProviderAuthority, R.attr.fontProviderCerts, R.attr.fontProviderFetchStrategy, R.attr.fontProviderFetchTimeout, R.attr.fontProviderPackage, R.attr.fontProviderQuery};
        public static final int[] FontFamilyFont = {16844082, 16844083, 16844095, 16844143, 16844144, R.attr.font, R.attr.fontStyle, R.attr.fontVariationSettings, R.attr.fontWeight, R.attr.ttcIndex};
        public static final int FontFamilyFont_android_font = 0;
        public static final int FontFamilyFont_android_fontStyle = 2;
        public static final int FontFamilyFont_android_fontVariationSettings = 4;
        public static final int FontFamilyFont_android_fontWeight = 1;
        public static final int FontFamilyFont_android_ttcIndex = 3;
        public static final int FontFamilyFont_font = 5;
        public static final int FontFamilyFont_fontStyle = 6;
        public static final int FontFamilyFont_fontVariationSettings = 7;
        public static final int FontFamilyFont_fontWeight = 8;
        public static final int FontFamilyFont_ttcIndex = 9;
        public static final int FontFamily_fontProviderAuthority = 0;
        public static final int FontFamily_fontProviderCerts = 1;
        public static final int FontFamily_fontProviderFetchStrategy = 2;
        public static final int FontFamily_fontProviderFetchTimeout = 3;
        public static final int FontFamily_fontProviderPackage = 4;
        public static final int FontFamily_fontProviderQuery = 5;
        public static final int[] GradientColor = {16843165, 16843166, 16843169, 16843170, 16843171, 16843172, 16843265, 16843275, 16844048, 16844049, 16844050, 16844051};
        public static final int[] GradientColorItem = {16843173, 16844052};
        public static final int GradientColorItem_android_color = 0;
        public static final int GradientColorItem_android_offset = 1;
        public static final int GradientColor_android_centerColor = 7;
        public static final int GradientColor_android_centerX = 3;
        public static final int GradientColor_android_centerY = 4;
        public static final int GradientColor_android_endColor = 1;
        public static final int GradientColor_android_endX = 10;
        public static final int GradientColor_android_endY = 11;
        public static final int GradientColor_android_gradientRadius = 5;
        public static final int GradientColor_android_startColor = 0;
        public static final int GradientColor_android_startX = 8;
        public static final int GradientColor_android_startY = 9;
        public static final int GradientColor_android_tileMode = 6;
        public static final int GradientColor_android_type = 2;
    }
}
