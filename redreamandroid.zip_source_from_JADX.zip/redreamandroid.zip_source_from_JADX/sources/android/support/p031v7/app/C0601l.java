package android.support.p031v7.app;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.support.p018v4.p028h.C0495r;
import android.support.p018v4.p028h.C0502v;
import android.support.p018v4.p028h.C0506w;
import android.support.p018v4.p028h.C0507x;
import android.support.p018v4.p028h.C0508y;
import android.support.p031v7.app.C0565a.C0567b;
import android.support.p031v7.p032a.C0540a.C0541a;
import android.support.p031v7.p032a.C0540a.C0546f;
import android.support.p031v7.p032a.C0540a.C0550j;
import android.support.p031v7.view.C0626a;
import android.support.p031v7.view.C0627b;
import android.support.p031v7.view.C0627b.C0628a;
import android.support.p031v7.view.C0634g;
import android.support.p031v7.view.C0637h;
import android.support.p031v7.view.menu.C0655h;
import android.support.p031v7.view.menu.C0655h.C0656a;
import android.support.p031v7.widget.ActionBarContainer;
import android.support.p031v7.widget.ActionBarContextView;
import android.support.p031v7.widget.ActionBarOverlayLayout;
import android.support.p031v7.widget.ActionBarOverlayLayout.C0687a;
import android.support.p031v7.widget.C0756aj;
import android.support.p031v7.widget.C0856bf;
import android.support.p031v7.widget.Toolbar;
import android.util.TypedValue;
import android.view.ContextThemeWrapper;
import android.view.KeyCharacterMap;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Interpolator;
import java.lang.ref.WeakReference;
import java.util.ArrayList;

/* renamed from: android.support.v7.app.l */
public class C0601l extends C0565a implements C0687a {

    /* renamed from: s */
    static final /* synthetic */ boolean f1817s = true;

    /* renamed from: t */
    private static final Interpolator f1818t = new AccelerateInterpolator();

    /* renamed from: u */
    private static final Interpolator f1819u = new DecelerateInterpolator();

    /* renamed from: A */
    private boolean f1820A;

    /* renamed from: B */
    private boolean f1821B;

    /* renamed from: C */
    private ArrayList<C0567b> f1822C = new ArrayList<>();

    /* renamed from: D */
    private boolean f1823D;

    /* renamed from: E */
    private int f1824E = 0;

    /* renamed from: F */
    private boolean f1825F;

    /* renamed from: G */
    private boolean f1826G = f1817s;

    /* renamed from: H */
    private boolean f1827H;

    /* renamed from: a */
    Context f1828a;

    /* renamed from: b */
    ActionBarOverlayLayout f1829b;

    /* renamed from: c */
    ActionBarContainer f1830c;

    /* renamed from: d */
    C0756aj f1831d;

    /* renamed from: e */
    ActionBarContextView f1832e;

    /* renamed from: f */
    View f1833f;

    /* renamed from: g */
    C0856bf f1834g;

    /* renamed from: h */
    C0605a f1835h;

    /* renamed from: i */
    C0627b f1836i;

    /* renamed from: j */
    C0628a f1837j;

    /* renamed from: k */
    boolean f1838k = f1817s;

    /* renamed from: l */
    boolean f1839l;

    /* renamed from: m */
    boolean f1840m;

    /* renamed from: n */
    C0637h f1841n;

    /* renamed from: o */
    boolean f1842o;

    /* renamed from: p */
    final C0506w f1843p = new C0507x() {
        /* renamed from: b */
        public void mo1967b(View view) {
            if (C0601l.this.f1838k && C0601l.this.f1833f != null) {
                C0601l.this.f1833f.setTranslationY(0.0f);
                C0601l.this.f1830c.setTranslationY(0.0f);
            }
            C0601l.this.f1830c.setVisibility(8);
            C0601l.this.f1830c.setTransitioning(false);
            C0601l.this.f1841n = null;
            C0601l.this.mo2343h();
            if (C0601l.this.f1829b != null) {
                C0495r.m2160o(C0601l.this.f1829b);
            }
        }
    };

    /* renamed from: q */
    final C0506w f1844q = new C0507x() {
        /* renamed from: b */
        public void mo1967b(View view) {
            C0601l.this.f1841n = null;
            C0601l.this.f1830c.requestLayout();
        }
    };

    /* renamed from: r */
    final C0508y f1845r = new C0508y() {
        /* renamed from: a */
        public void mo1969a(View view) {
            ((View) C0601l.this.f1830c.getParent()).invalidate();
        }
    };

    /* renamed from: v */
    private Context f1846v;

    /* renamed from: w */
    private Activity f1847w;

    /* renamed from: x */
    private Dialog f1848x;

    /* renamed from: y */
    private ArrayList<Object> f1849y = new ArrayList<>();

    /* renamed from: z */
    private int f1850z = -1;

    /* renamed from: android.support.v7.app.l$a */
    public class C0605a extends C0627b implements C0656a {

        /* renamed from: b */
        private final Context f1855b;

        /* renamed from: c */
        private final C0655h f1856c;

        /* renamed from: d */
        private C0628a f1857d;

        /* renamed from: e */
        private WeakReference<View> f1858e;

        public C0605a(Context context, C0628a aVar) {
            this.f1855b = context;
            this.f1857d = aVar;
            this.f1856c = new C0655h(context).mo2697a(1);
            this.f1856c.mo2705a((C0656a) this);
        }

        /* renamed from: a */
        public MenuInflater mo2352a() {
            return new C0634g(this.f1855b);
        }

        /* renamed from: a */
        public void mo2353a(int i) {
            mo2359b((CharSequence) C0601l.this.f1828a.getResources().getString(i));
        }

        /* renamed from: a */
        public void mo2264a(C0655h hVar) {
            if (this.f1857d != null) {
                mo2361d();
                C0601l.this.f1832e.mo2980a();
            }
        }

        /* renamed from: a */
        public void mo2354a(View view) {
            C0601l.this.f1832e.setCustomView(view);
            this.f1858e = new WeakReference<>(view);
        }

        /* renamed from: a */
        public void mo2355a(CharSequence charSequence) {
            C0601l.this.f1832e.setSubtitle(charSequence);
        }

        /* renamed from: a */
        public void mo2356a(boolean z) {
            super.mo2356a(z);
            C0601l.this.f1832e.setTitleOptional(z);
        }

        /* renamed from: a */
        public boolean mo2267a(C0655h hVar, MenuItem menuItem) {
            if (this.f1857d != null) {
                return this.f1857d.mo2300a((C0627b) this, menuItem);
            }
            return false;
        }

        /* renamed from: b */
        public Menu mo2357b() {
            return this.f1856c;
        }

        /* renamed from: b */
        public void mo2358b(int i) {
            mo2355a((CharSequence) C0601l.this.f1828a.getResources().getString(i));
        }

        /* renamed from: b */
        public void mo2359b(CharSequence charSequence) {
            C0601l.this.f1832e.setTitle(charSequence);
        }

        /* renamed from: c */
        public void mo2360c() {
            if (C0601l.this.f1835h == this) {
                if (!C0601l.m2658a(C0601l.this.f1839l, C0601l.this.f1840m, false)) {
                    C0601l.this.f1836i = this;
                    C0601l.this.f1837j = this.f1857d;
                } else {
                    this.f1857d.mo2298a(this);
                }
                this.f1857d = null;
                C0601l.this.mo2348j(false);
                C0601l.this.f1832e.mo2981b();
                C0601l.this.f1831d.mo3613a().sendAccessibilityEvent(32);
                C0601l.this.f1829b.setHideOnContentScrollEnabled(C0601l.this.f1842o);
                C0601l.this.f1835h = null;
            }
        }

        /* renamed from: d */
        public void mo2361d() {
            if (C0601l.this.f1835h == this) {
                this.f1856c.mo2746h();
                try {
                    this.f1857d.mo2301b(this, this.f1856c);
                } finally {
                    this.f1856c.mo2748i();
                }
            }
        }

        /* renamed from: e */
        public boolean mo2362e() {
            this.f1856c.mo2746h();
            try {
                return this.f1857d.mo2299a((C0627b) this, (Menu) this.f1856c);
            } finally {
                this.f1856c.mo2748i();
            }
        }

        /* renamed from: f */
        public CharSequence mo2363f() {
            return C0601l.this.f1832e.getTitle();
        }

        /* renamed from: g */
        public CharSequence mo2364g() {
            return C0601l.this.f1832e.getSubtitle();
        }

        /* renamed from: h */
        public boolean mo2365h() {
            return C0601l.this.f1832e.mo2983d();
        }

        /* renamed from: i */
        public View mo2366i() {
            if (this.f1858e != null) {
                return (View) this.f1858e.get();
            }
            return null;
        }
    }

    public C0601l(Activity activity, boolean z) {
        this.f1847w = activity;
        View decorView = activity.getWindow().getDecorView();
        m2657a(decorView);
        if (!z) {
            this.f1833f = decorView.findViewById(16908290);
        }
    }

    public C0601l(Dialog dialog) {
        this.f1848x = dialog;
        m2657a(dialog.getWindow().getDecorView());
    }

    /* renamed from: a */
    private void m2657a(View view) {
        this.f1829b = (ActionBarOverlayLayout) view.findViewById(C0546f.decor_content_parent);
        if (this.f1829b != null) {
            this.f1829b.setActionBarVisibilityCallback(this);
        }
        this.f1831d = m2659b(view.findViewById(C0546f.action_bar));
        this.f1832e = (ActionBarContextView) view.findViewById(C0546f.action_context_bar);
        this.f1830c = (ActionBarContainer) view.findViewById(C0546f.action_bar_container);
        if (this.f1831d == null || this.f1832e == null || this.f1830c == null) {
            StringBuilder sb = new StringBuilder();
            sb.append(getClass().getSimpleName());
            sb.append(" can only be used ");
            sb.append("with a compatible window decor layout");
            throw new IllegalStateException(sb.toString());
        }
        this.f1828a = this.f1831d.mo3622b();
        boolean z = (this.f1831d.mo3639o() & 4) != 0;
        if (z) {
            this.f1820A = f1817s;
        }
        C0626a a = C0626a.m2803a(this.f1828a);
        mo2181a(a.mo2496f() || z);
        m2660k(a.mo2494d());
        TypedArray obtainStyledAttributes = this.f1828a.obtainStyledAttributes(null, C0550j.ActionBar, C0541a.actionBarStyle, 0);
        if (obtainStyledAttributes.getBoolean(C0550j.ActionBar_hideOnContentScroll, false)) {
            mo2185b((boolean) f1817s);
        }
        int dimensionPixelSize = obtainStyledAttributes.getDimensionPixelSize(C0550j.ActionBar_elevation, 0);
        if (dimensionPixelSize != 0) {
            mo2178a((float) dimensionPixelSize);
        }
        obtainStyledAttributes.recycle();
    }

    /* renamed from: a */
    static boolean m2658a(boolean z, boolean z2, boolean z3) {
        if (z3) {
            return f1817s;
        }
        if (z || z2) {
            return false;
        }
        return f1817s;
    }

    /* renamed from: b */
    private C0756aj m2659b(View view) {
        if (view instanceof C0756aj) {
            return (C0756aj) view;
        }
        if (view instanceof Toolbar) {
            return ((Toolbar) view).getWrapper();
        }
        StringBuilder sb = new StringBuilder();
        sb.append("Can't make a decor toolbar out of ");
        sb.append(view != null ? view.getClass().getSimpleName() : "null");
        throw new IllegalStateException(sb.toString());
    }

    /* renamed from: k */
    private void m2660k(boolean z) {
        this.f1823D = z;
        if (!this.f1823D) {
            this.f1831d.mo3617a((C0856bf) null);
            this.f1830c.setTabContainer(this.f1834g);
        } else {
            this.f1830c.setTabContainer(null);
            this.f1831d.mo3617a(this.f1834g);
        }
        int i = mo2345i();
        boolean z2 = f1817s;
        boolean z3 = i == 2;
        if (this.f1834g != null) {
            if (z3) {
                this.f1834g.setVisibility(0);
                if (this.f1829b != null) {
                    C0495r.m2160o(this.f1829b);
                }
            } else {
                this.f1834g.setVisibility(8);
            }
        }
        this.f1831d.mo3621a(!this.f1823D && z3);
        ActionBarOverlayLayout actionBarOverlayLayout = this.f1829b;
        if (this.f1823D || !z3) {
            z2 = false;
        }
        actionBarOverlayLayout.setHasNonEmbeddedTabs(z2);
    }

    /* renamed from: l */
    private void m2661l(boolean z) {
        if (m2658a(this.f1839l, this.f1840m, this.f1825F)) {
            if (!this.f1826G) {
                this.f1826G = f1817s;
                mo2344h(z);
            }
        } else if (this.f1826G) {
            this.f1826G = false;
            mo2346i(z);
        }
    }

    /* renamed from: n */
    private void m2662n() {
        if (!this.f1825F) {
            this.f1825F = f1817s;
            if (this.f1829b != null) {
                this.f1829b.setShowingForActionMode(f1817s);
            }
            m2661l(false);
        }
    }

    /* renamed from: o */
    private void m2663o() {
        if (this.f1825F) {
            this.f1825F = false;
            if (this.f1829b != null) {
                this.f1829b.setShowingForActionMode(false);
            }
            m2661l(false);
        }
    }

    /* renamed from: p */
    private boolean m2664p() {
        return C0495r.m2168w(this.f1830c);
    }

    /* renamed from: a */
    public int mo2176a() {
        return this.f1831d.mo3639o();
    }

    /* renamed from: a */
    public C0627b mo2177a(C0628a aVar) {
        if (this.f1835h != null) {
            this.f1835h.mo2360c();
        }
        this.f1829b.setHideOnContentScrollEnabled(false);
        this.f1832e.mo2982c();
        C0605a aVar2 = new C0605a(this.f1832e.getContext(), aVar);
        if (!aVar2.mo2362e()) {
            return null;
        }
        this.f1835h = aVar2;
        aVar2.mo2361d();
        this.f1832e.mo2979a(aVar2);
        mo2348j(f1817s);
        this.f1832e.sendAccessibilityEvent(32);
        return aVar2;
    }

    /* renamed from: a */
    public void mo2178a(float f) {
        C0495r.m2124a((View) this.f1830c, f);
    }

    /* renamed from: a */
    public void mo2339a(int i) {
        this.f1824E = i;
    }

    /* renamed from: a */
    public void mo2340a(int i, int i2) {
        int o = this.f1831d.mo3639o();
        if ((i2 & 4) != 0) {
            this.f1820A = f1817s;
        }
        this.f1831d.mo3625c((i & i2) | ((~i2) & o));
    }

    /* renamed from: a */
    public void mo2179a(Configuration configuration) {
        m2660k(C0626a.m2803a(this.f1828a).mo2494d());
    }

    /* renamed from: a */
    public void mo2180a(CharSequence charSequence) {
        this.f1831d.mo3620a(charSequence);
    }

    /* renamed from: a */
    public void mo2181a(boolean z) {
        this.f1831d.mo3624b(z);
    }

    /* renamed from: a */
    public boolean mo2182a(int i, KeyEvent keyEvent) {
        if (this.f1835h == null) {
            return false;
        }
        Menu b = this.f1835h.mo2357b();
        if (b == null) {
            return false;
        }
        int keyboardType = KeyCharacterMap.load(keyEvent != null ? keyEvent.getDeviceId() : -1).getKeyboardType();
        boolean z = f1817s;
        if (keyboardType == 1) {
            z = false;
        }
        b.setQwertyMode(z);
        return b.performShortcut(i, keyEvent, 0);
    }

    /* renamed from: b */
    public Context mo2184b() {
        if (this.f1846v == null) {
            TypedValue typedValue = new TypedValue();
            this.f1828a.getTheme().resolveAttribute(C0541a.actionBarWidgetTheme, typedValue, f1817s);
            int i = typedValue.resourceId;
            if (i != 0) {
                this.f1846v = new ContextThemeWrapper(this.f1828a, i);
            } else {
                this.f1846v = this.f1828a;
            }
        }
        return this.f1846v;
    }

    /* renamed from: b */
    public void mo2185b(boolean z) {
        if (!z || this.f1829b.mo3007a()) {
            this.f1842o = z;
            this.f1829b.setHideOnContentScrollEnabled(z);
            return;
        }
        throw new IllegalStateException("Action bar must be in overlay mode (Window.FEATURE_OVERLAY_ACTION_BAR) to enable hide on content scroll");
    }

    /* renamed from: c */
    public void mo2186c(boolean z) {
        if (!this.f1820A) {
            mo2341f(z);
        }
    }

    /* renamed from: d */
    public void mo2188d(boolean z) {
        this.f1827H = z;
        if (!z && this.f1841n != null) {
            this.f1841n.mo2545c();
        }
    }

    /* renamed from: e */
    public void mo2190e(boolean z) {
        if (z != this.f1821B) {
            this.f1821B = z;
            int size = this.f1822C.size();
            for (int i = 0; i < size; i++) {
                ((C0567b) this.f1822C.get(i)).mo2194a(z);
            }
        }
    }

    /* renamed from: f */
    public void mo2341f(boolean z) {
        mo2340a(z ? 4 : 0, 4);
    }

    /* renamed from: f */
    public boolean mo2192f() {
        if (this.f1831d == null || !this.f1831d.mo3626c()) {
            return false;
        }
        this.f1831d.mo3627d();
        return f1817s;
    }

    /* renamed from: g */
    public void mo2342g(boolean z) {
        this.f1838k = z;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: h */
    public void mo2343h() {
        if (this.f1837j != null) {
            this.f1837j.mo2298a(this.f1836i);
            this.f1836i = null;
            this.f1837j = null;
        }
    }

    /* renamed from: h */
    public void mo2344h(boolean z) {
        if (this.f1841n != null) {
            this.f1841n.mo2545c();
        }
        this.f1830c.setVisibility(0);
        if (this.f1824E != 0 || (!this.f1827H && !z)) {
            this.f1830c.setAlpha(1.0f);
            this.f1830c.setTranslationY(0.0f);
            if (this.f1838k && this.f1833f != null) {
                this.f1833f.setTranslationY(0.0f);
            }
            this.f1844q.mo1967b(null);
        } else {
            this.f1830c.setTranslationY(0.0f);
            float f = (float) (-this.f1830c.getHeight());
            if (z) {
                int[] iArr = {0, 0};
                this.f1830c.getLocationInWindow(iArr);
                f -= (float) iArr[1];
            }
            this.f1830c.setTranslationY(f);
            C0637h hVar = new C0637h();
            C0502v b = C0495r.m2156k(this.f1830c).mo1958b(0.0f);
            b.mo1956a(this.f1845r);
            hVar.mo2539a(b);
            if (this.f1838k && this.f1833f != null) {
                this.f1833f.setTranslationY(f);
                hVar.mo2539a(C0495r.m2156k(this.f1833f).mo1958b(0.0f));
            }
            hVar.mo2542a(f1819u);
            hVar.mo2538a(250);
            hVar.mo2541a(this.f1844q);
            this.f1841n = hVar;
            hVar.mo2543a();
        }
        if (this.f1829b != null) {
            C0495r.m2160o(this.f1829b);
        }
    }

    /* renamed from: i */
    public int mo2345i() {
        return this.f1831d.mo3640p();
    }

    /* renamed from: i */
    public void mo2346i(boolean z) {
        if (this.f1841n != null) {
            this.f1841n.mo2545c();
        }
        if (this.f1824E != 0 || (!this.f1827H && !z)) {
            this.f1843p.mo1967b(null);
            return;
        }
        this.f1830c.setAlpha(1.0f);
        this.f1830c.setTransitioning(f1817s);
        C0637h hVar = new C0637h();
        float f = (float) (-this.f1830c.getHeight());
        if (z) {
            int[] iArr = {0, 0};
            this.f1830c.getLocationInWindow(iArr);
            f -= (float) iArr[1];
        }
        C0502v b = C0495r.m2156k(this.f1830c).mo1958b(f);
        b.mo1956a(this.f1845r);
        hVar.mo2539a(b);
        if (this.f1838k && this.f1833f != null) {
            hVar.mo2539a(C0495r.m2156k(this.f1833f).mo1958b(f));
        }
        hVar.mo2542a(f1818t);
        hVar.mo2538a(250);
        hVar.mo2541a(this.f1843p);
        this.f1841n = hVar;
        hVar.mo2543a();
    }

    /* renamed from: j */
    public void mo2347j() {
        if (this.f1840m) {
            this.f1840m = false;
            m2661l(f1817s);
        }
    }

    /* renamed from: j */
    public void mo2348j(boolean z) {
        C0502v vVar;
        C0502v vVar2;
        if (z) {
            m2662n();
        } else {
            m2663o();
        }
        if (m2664p()) {
            if (z) {
                vVar = this.f1831d.mo3612a(4, 100);
                vVar2 = this.f1832e.mo2978a(0, 200);
            } else {
                vVar2 = this.f1831d.mo3612a(0, 200);
                vVar = this.f1832e.mo2978a(8, 100);
            }
            C0637h hVar = new C0637h();
            hVar.mo2540a(vVar, vVar2);
            hVar.mo2543a();
        } else if (z) {
            this.f1831d.mo3628d(4);
            this.f1832e.setVisibility(0);
        } else {
            this.f1831d.mo3628d(0);
            this.f1832e.setVisibility(8);
        }
    }

    /* renamed from: k */
    public void mo2349k() {
        if (!this.f1840m) {
            this.f1840m = f1817s;
            m2661l(f1817s);
        }
    }

    /* renamed from: l */
    public void mo2350l() {
        if (this.f1841n != null) {
            this.f1841n.mo2545c();
            this.f1841n = null;
        }
    }

    /* renamed from: m */
    public void mo2351m() {
    }
}
