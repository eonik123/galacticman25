package android.support.p031v7.app;

import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.content.DialogInterface.OnDismissListener;
import android.content.DialogInterface.OnKeyListener;
import android.content.DialogInterface.OnMultiChoiceClickListener;
import android.content.res.TypedArray;
import android.database.Cursor;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.os.Handler;
import android.os.Message;
import android.support.p018v4.p028h.C0495r;
import android.support.p018v4.widget.NestedScrollView;
import android.support.p018v4.widget.NestedScrollView.C0511b;
import android.support.p031v7.p032a.C0540a.C0541a;
import android.support.p031v7.p032a.C0540a.C0546f;
import android.support.p031v7.p032a.C0540a.C0550j;
import android.support.p031v7.widget.C0787as.C0788a;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewParent;
import android.view.ViewStub;
import android.view.Window;
import android.widget.AbsListView;
import android.widget.AbsListView.OnScrollListener;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import java.lang.ref.WeakReference;

/* renamed from: android.support.v7.app.AlertController */
class AlertController {

    /* renamed from: A */
    private int f1570A;

    /* renamed from: B */
    private boolean f1571B = false;

    /* renamed from: C */
    private CharSequence f1572C;

    /* renamed from: D */
    private Drawable f1573D;

    /* renamed from: E */
    private CharSequence f1574E;

    /* renamed from: F */
    private Drawable f1575F;

    /* renamed from: G */
    private CharSequence f1576G;

    /* renamed from: H */
    private Drawable f1577H;

    /* renamed from: I */
    private int f1578I = 0;

    /* renamed from: J */
    private Drawable f1579J;

    /* renamed from: K */
    private ImageView f1580K;

    /* renamed from: L */
    private TextView f1581L;

    /* renamed from: M */
    private TextView f1582M;

    /* renamed from: N */
    private View f1583N;

    /* renamed from: O */
    private int f1584O;

    /* renamed from: P */
    private int f1585P;

    /* renamed from: Q */
    private boolean f1586Q;

    /* renamed from: R */
    private int f1587R = 0;

    /* renamed from: S */
    private final OnClickListener f1588S = new OnClickListener() {
        /* JADX WARNING: Removed duplicated region for block: B:18:0x003a  */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public void onClick(android.view.View r3) {
            /*
                r2 = this;
                android.support.v7.app.AlertController r0 = android.support.p031v7.app.AlertController.this
                android.widget.Button r0 = r0.f1591c
                if (r3 != r0) goto L_0x0015
                android.support.v7.app.AlertController r0 = android.support.p031v7.app.AlertController.this
                android.os.Message r0 = r0.f1592d
                if (r0 == 0) goto L_0x0015
                android.support.v7.app.AlertController r3 = android.support.p031v7.app.AlertController.this
                android.os.Message r3 = r3.f1592d
            L_0x0010:
                android.os.Message r3 = android.os.Message.obtain(r3)
                goto L_0x0038
            L_0x0015:
                android.support.v7.app.AlertController r0 = android.support.p031v7.app.AlertController.this
                android.widget.Button r0 = r0.f1593e
                if (r3 != r0) goto L_0x0026
                android.support.v7.app.AlertController r0 = android.support.p031v7.app.AlertController.this
                android.os.Message r0 = r0.f1594f
                if (r0 == 0) goto L_0x0026
                android.support.v7.app.AlertController r3 = android.support.p031v7.app.AlertController.this
                android.os.Message r3 = r3.f1594f
                goto L_0x0010
            L_0x0026:
                android.support.v7.app.AlertController r0 = android.support.p031v7.app.AlertController.this
                android.widget.Button r0 = r0.f1595g
                if (r3 != r0) goto L_0x0037
                android.support.v7.app.AlertController r3 = android.support.p031v7.app.AlertController.this
                android.os.Message r3 = r3.f1596h
                if (r3 == 0) goto L_0x0037
                android.support.v7.app.AlertController r3 = android.support.p031v7.app.AlertController.this
                android.os.Message r3 = r3.f1596h
                goto L_0x0010
            L_0x0037:
                r3 = 0
            L_0x0038:
                if (r3 == 0) goto L_0x003d
                r3.sendToTarget()
            L_0x003d:
                android.support.v7.app.AlertController r3 = android.support.p031v7.app.AlertController.this
                android.os.Handler r3 = r3.f1604p
                r0 = 1
                android.support.v7.app.AlertController r1 = android.support.p031v7.app.AlertController.this
                android.support.v7.app.g r1 = r1.f1589a
                android.os.Message r3 = r3.obtainMessage(r0, r1)
                r3.sendToTarget()
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: android.support.p031v7.app.AlertController.C05511.onClick(android.view.View):void");
        }
    };

    /* renamed from: a */
    final C0592g f1589a;

    /* renamed from: b */
    ListView f1590b;

    /* renamed from: c */
    Button f1591c;

    /* renamed from: d */
    Message f1592d;

    /* renamed from: e */
    Button f1593e;

    /* renamed from: f */
    Message f1594f;

    /* renamed from: g */
    Button f1595g;

    /* renamed from: h */
    Message f1596h;

    /* renamed from: i */
    NestedScrollView f1597i;

    /* renamed from: j */
    ListAdapter f1598j;

    /* renamed from: k */
    int f1599k = -1;

    /* renamed from: l */
    int f1600l;

    /* renamed from: m */
    int f1601m;

    /* renamed from: n */
    int f1602n;

    /* renamed from: o */
    int f1603o;

    /* renamed from: p */
    Handler f1604p;

    /* renamed from: q */
    private final Context f1605q;

    /* renamed from: r */
    private final Window f1606r;

    /* renamed from: s */
    private final int f1607s;

    /* renamed from: t */
    private CharSequence f1608t;

    /* renamed from: u */
    private CharSequence f1609u;

    /* renamed from: v */
    private View f1610v;

    /* renamed from: w */
    private int f1611w;

    /* renamed from: x */
    private int f1612x;

    /* renamed from: y */
    private int f1613y;

    /* renamed from: z */
    private int f1614z;

    /* renamed from: android.support.v7.app.AlertController$RecycleListView */
    public static class RecycleListView extends ListView {

        /* renamed from: a */
        private final int f1628a;

        /* renamed from: b */
        private final int f1629b;

        public RecycleListView(Context context) {
            this(context, null);
        }

        public RecycleListView(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, C0550j.RecycleListView);
            this.f1629b = obtainStyledAttributes.getDimensionPixelOffset(C0550j.RecycleListView_paddingBottomNoButtons, -1);
            this.f1628a = obtainStyledAttributes.getDimensionPixelOffset(C0550j.RecycleListView_paddingTopNoTitle, -1);
        }

        /* renamed from: a */
        public void mo2150a(boolean z, boolean z2) {
            if (!z2 || !z) {
                setPadding(getPaddingLeft(), z ? getPaddingTop() : this.f1628a, getPaddingRight(), z2 ? getPaddingBottom() : this.f1629b);
            }
        }
    }

    /* renamed from: android.support.v7.app.AlertController$a */
    public static class C0556a {

        /* renamed from: A */
        public int f1630A;

        /* renamed from: B */
        public int f1631B;

        /* renamed from: C */
        public int f1632C;

        /* renamed from: D */
        public int f1633D;

        /* renamed from: E */
        public boolean f1634E = false;

        /* renamed from: F */
        public boolean[] f1635F;

        /* renamed from: G */
        public boolean f1636G;

        /* renamed from: H */
        public boolean f1637H;

        /* renamed from: I */
        public int f1638I = -1;

        /* renamed from: J */
        public OnMultiChoiceClickListener f1639J;

        /* renamed from: K */
        public Cursor f1640K;

        /* renamed from: L */
        public String f1641L;

        /* renamed from: M */
        public String f1642M;

        /* renamed from: N */
        public OnItemSelectedListener f1643N;

        /* renamed from: O */
        public C0561a f1644O;

        /* renamed from: P */
        public boolean f1645P = true;

        /* renamed from: a */
        public final Context f1646a;

        /* renamed from: b */
        public final LayoutInflater f1647b;

        /* renamed from: c */
        public int f1648c = 0;

        /* renamed from: d */
        public Drawable f1649d;

        /* renamed from: e */
        public int f1650e = 0;

        /* renamed from: f */
        public CharSequence f1651f;

        /* renamed from: g */
        public View f1652g;

        /* renamed from: h */
        public CharSequence f1653h;

        /* renamed from: i */
        public CharSequence f1654i;

        /* renamed from: j */
        public Drawable f1655j;

        /* renamed from: k */
        public DialogInterface.OnClickListener f1656k;

        /* renamed from: l */
        public CharSequence f1657l;

        /* renamed from: m */
        public Drawable f1658m;

        /* renamed from: n */
        public DialogInterface.OnClickListener f1659n;

        /* renamed from: o */
        public CharSequence f1660o;

        /* renamed from: p */
        public Drawable f1661p;

        /* renamed from: q */
        public DialogInterface.OnClickListener f1662q;

        /* renamed from: r */
        public boolean f1663r;

        /* renamed from: s */
        public OnCancelListener f1664s;

        /* renamed from: t */
        public OnDismissListener f1665t;

        /* renamed from: u */
        public OnKeyListener f1666u;

        /* renamed from: v */
        public CharSequence[] f1667v;

        /* renamed from: w */
        public ListAdapter f1668w;

        /* renamed from: x */
        public DialogInterface.OnClickListener f1669x;

        /* renamed from: y */
        public int f1670y;

        /* renamed from: z */
        public View f1671z;

        /* renamed from: android.support.v7.app.AlertController$a$a */
        public interface C0561a {
            /* renamed from: a */
            void mo2157a(ListView listView);
        }

        public C0556a(Context context) {
            this.f1646a = context;
            this.f1663r = true;
            this.f1647b = (LayoutInflater) context.getSystemService("layout_inflater");
        }

        /* JADX WARNING: type inference failed for: r9v0, types: [android.widget.ListAdapter] */
        /* JADX WARNING: type inference failed for: r9v1, types: [android.support.v7.app.AlertController$c] */
        /* JADX WARNING: type inference failed for: r9v2, types: [android.widget.ListAdapter] */
        /* JADX WARNING: type inference failed for: r2v2, types: [android.widget.SimpleCursorAdapter] */
        /* JADX WARNING: type inference failed for: r9v4 */
        /* JADX WARNING: type inference failed for: r1v24, types: [android.support.v7.app.AlertController$a$2] */
        /* JADX WARNING: type inference failed for: r1v25, types: [android.support.v7.app.AlertController$a$1] */
        /* JADX WARNING: type inference failed for: r9v7 */
        /* JADX WARNING: type inference failed for: r9v8 */
        /* JADX WARNING: type inference failed for: r1v26, types: [android.support.v7.app.AlertController$a$2] */
        /* JADX WARNING: type inference failed for: r1v27, types: [android.support.v7.app.AlertController$a$1] */
        /* JADX WARNING: Multi-variable type inference failed. Error: jadx.core.utils.exceptions.JadxRuntimeException: No candidate types for var: r9v4
          assigns: [?[OBJECT, ARRAY], android.support.v7.app.AlertController$a$2, android.support.v7.app.AlertController$a$1]
          uses: [android.widget.ListAdapter, android.support.v7.app.AlertController$a$2, android.support.v7.app.AlertController$a$1]
          mth insns count: 72
        	at jadx.core.dex.visitors.typeinference.TypeSearch.fillTypeCandidates(TypeSearch.java:237)
        	at java.base/java.util.ArrayList.forEach(ArrayList.java:1540)
        	at jadx.core.dex.visitors.typeinference.TypeSearch.run(TypeSearch.java:53)
        	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.runMultiVariableSearch(TypeInferenceVisitor.java:99)
        	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.visit(TypeInferenceVisitor.java:92)
        	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:27)
        	at jadx.core.dex.visitors.DepthTraversal.lambda$visit$1(DepthTraversal.java:14)
        	at java.base/java.util.ArrayList.forEach(ArrayList.java:1540)
        	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:14)
        	at jadx.core.dex.visitors.DepthTraversal.lambda$visit$0(DepthTraversal.java:13)
        	at java.base/java.util.ArrayList.forEach(ArrayList.java:1540)
        	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:13)
        	at jadx.core.ProcessClass.process(ProcessClass.java:30)
        	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:311)
        	at jadx.api.JavaClass.decompile(JavaClass.java:62)
        	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:217)
         */
        /* JADX WARNING: Removed duplicated region for block: B:30:0x0098  */
        /* JADX WARNING: Removed duplicated region for block: B:33:0x00a1  */
        /* JADX WARNING: Removed duplicated region for block: B:34:0x00a5  */
        /* JADX WARNING: Unknown variable types count: 6 */
        /* renamed from: b */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        private void m2440b(final android.support.p031v7.app.AlertController r11) {
            /*
                r10 = this;
                android.view.LayoutInflater r0 = r10.f1647b
                int r1 = r11.f1600l
                r2 = 0
                android.view.View r0 = r0.inflate(r1, r2)
                android.support.v7.app.AlertController$RecycleListView r0 = (android.support.p031v7.app.AlertController.RecycleListView) r0
                boolean r1 = r10.f1636G
                r8 = 1
                if (r1 == 0) goto L_0x0035
                android.database.Cursor r1 = r10.f1640K
                if (r1 != 0) goto L_0x0026
                android.support.v7.app.AlertController$a$1 r9 = new android.support.v7.app.AlertController$a$1
                android.content.Context r3 = r10.f1646a
                int r4 = r11.f1601m
                r5 = 16908308(0x1020014, float:2.3877285E-38)
                java.lang.CharSequence[] r6 = r10.f1667v
                r1 = r9
                r2 = r10
                r7 = r0
                r1.<init>(r3, r4, r5, r6, r7)
                goto L_0x006e
            L_0x0026:
                android.support.v7.app.AlertController$a$2 r9 = new android.support.v7.app.AlertController$a$2
                android.content.Context r3 = r10.f1646a
                android.database.Cursor r4 = r10.f1640K
                r5 = 0
                r1 = r9
                r2 = r10
                r6 = r0
                r7 = r11
                r1.<init>(r3, r4, r5, r6, r7)
                goto L_0x006e
            L_0x0035:
                boolean r1 = r10.f1637H
                if (r1 == 0) goto L_0x003d
                int r1 = r11.f1602n
            L_0x003b:
                r4 = r1
                goto L_0x0040
            L_0x003d:
                int r1 = r11.f1603o
                goto L_0x003b
            L_0x0040:
                android.database.Cursor r1 = r10.f1640K
                r2 = 16908308(0x1020014, float:2.3877285E-38)
                if (r1 == 0) goto L_0x005e
                android.widget.SimpleCursorAdapter r1 = new android.widget.SimpleCursorAdapter
                android.content.Context r3 = r10.f1646a
                android.database.Cursor r5 = r10.f1640K
                java.lang.String[] r6 = new java.lang.String[r8]
                java.lang.String r7 = r10.f1641L
                r9 = 0
                r6[r9] = r7
                int[] r7 = new int[r8]
                r7[r9] = r2
                r2 = r1
                r2.<init>(r3, r4, r5, r6, r7)
                r9 = r1
                goto L_0x006e
            L_0x005e:
                android.widget.ListAdapter r1 = r10.f1668w
                if (r1 == 0) goto L_0x0065
                android.widget.ListAdapter r9 = r10.f1668w
                goto L_0x006e
            L_0x0065:
                android.support.v7.app.AlertController$c r9 = new android.support.v7.app.AlertController$c
                android.content.Context r1 = r10.f1646a
                java.lang.CharSequence[] r3 = r10.f1667v
                r9.<init>(r1, r4, r2, r3)
            L_0x006e:
                android.support.v7.app.AlertController$a$a r1 = r10.f1644O
                if (r1 == 0) goto L_0x0077
                android.support.v7.app.AlertController$a$a r1 = r10.f1644O
                r1.mo2157a(r0)
            L_0x0077:
                r11.f1598j = r9
                int r1 = r10.f1638I
                r11.f1599k = r1
                android.content.DialogInterface$OnClickListener r1 = r10.f1669x
                if (r1 == 0) goto L_0x008a
                android.support.v7.app.AlertController$a$3 r1 = new android.support.v7.app.AlertController$a$3
                r1.<init>(r11)
            L_0x0086:
                r0.setOnItemClickListener(r1)
                goto L_0x0094
            L_0x008a:
                android.content.DialogInterface$OnMultiChoiceClickListener r1 = r10.f1639J
                if (r1 == 0) goto L_0x0094
                android.support.v7.app.AlertController$a$4 r1 = new android.support.v7.app.AlertController$a$4
                r1.<init>(r0, r11)
                goto L_0x0086
            L_0x0094:
                android.widget.AdapterView$OnItemSelectedListener r1 = r10.f1643N
                if (r1 == 0) goto L_0x009d
                android.widget.AdapterView$OnItemSelectedListener r1 = r10.f1643N
                r0.setOnItemSelectedListener(r1)
            L_0x009d:
                boolean r1 = r10.f1637H
                if (r1 == 0) goto L_0x00a5
                r0.setChoiceMode(r8)
                goto L_0x00ad
            L_0x00a5:
                boolean r1 = r10.f1636G
                if (r1 == 0) goto L_0x00ad
                r1 = 2
                r0.setChoiceMode(r1)
            L_0x00ad:
                r11.f1590b = r0
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: android.support.p031v7.app.AlertController.C0556a.m2440b(android.support.v7.app.AlertController):void");
        }

        /* renamed from: a */
        public void mo2151a(AlertController alertController) {
            if (this.f1652g != null) {
                alertController.mo2140b(this.f1652g);
            } else {
                if (this.f1651f != null) {
                    alertController.mo2137a(this.f1651f);
                }
                if (this.f1649d != null) {
                    alertController.mo2135a(this.f1649d);
                }
                if (this.f1648c != 0) {
                    alertController.mo2139b(this.f1648c);
                }
                if (this.f1650e != 0) {
                    alertController.mo2139b(alertController.mo2143c(this.f1650e));
                }
            }
            if (this.f1653h != null) {
                alertController.mo2141b(this.f1653h);
            }
            if (!(this.f1654i == null && this.f1655j == null)) {
                alertController.mo2134a(-1, this.f1654i, this.f1656k, (Message) null, this.f1655j);
            }
            if (!(this.f1657l == null && this.f1658m == null)) {
                alertController.mo2134a(-2, this.f1657l, this.f1659n, (Message) null, this.f1658m);
            }
            if (!(this.f1660o == null && this.f1661p == null)) {
                alertController.mo2134a(-3, this.f1660o, this.f1662q, (Message) null, this.f1661p);
            }
            if (!(this.f1667v == null && this.f1640K == null && this.f1668w == null)) {
                m2440b(alertController);
            }
            if (this.f1671z == null) {
                if (this.f1670y != 0) {
                    alertController.mo2133a(this.f1670y);
                }
            } else if (this.f1634E) {
                alertController.mo2136a(this.f1671z, this.f1630A, this.f1631B, this.f1632C, this.f1633D);
            } else {
                alertController.mo2144c(this.f1671z);
            }
        }
    }

    /* renamed from: android.support.v7.app.AlertController$b */
    private static final class C0562b extends Handler {

        /* renamed from: a */
        private WeakReference<DialogInterface> f1684a;

        public C0562b(DialogInterface dialogInterface) {
            this.f1684a = new WeakReference<>(dialogInterface);
        }

        public void handleMessage(Message message) {
            int i = message.what;
            if (i != 1) {
                switch (i) {
                    case -3:
                    case -2:
                    case -1:
                        ((DialogInterface.OnClickListener) message.obj).onClick((DialogInterface) this.f1684a.get(), message.what);
                        return;
                    default:
                        return;
                }
            } else {
                ((DialogInterface) message.obj).dismiss();
            }
        }
    }

    /* renamed from: android.support.v7.app.AlertController$c */
    private static class C0563c extends ArrayAdapter<CharSequence> {
        public C0563c(Context context, int i, int i2, CharSequence[] charSequenceArr) {
            super(context, i, i2, charSequenceArr);
        }

        public long getItemId(int i) {
            return (long) i;
        }

        public boolean hasStableIds() {
            return true;
        }
    }

    public AlertController(Context context, C0592g gVar, Window window) {
        this.f1605q = context;
        this.f1589a = gVar;
        this.f1606r = window;
        this.f1604p = new C0562b(gVar);
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(null, C0550j.AlertDialog, C0541a.alertDialogStyle, 0);
        this.f1584O = obtainStyledAttributes.getResourceId(C0550j.AlertDialog_android_layout, 0);
        this.f1585P = obtainStyledAttributes.getResourceId(C0550j.AlertDialog_buttonPanelSideLayout, 0);
        this.f1600l = obtainStyledAttributes.getResourceId(C0550j.AlertDialog_listLayout, 0);
        this.f1601m = obtainStyledAttributes.getResourceId(C0550j.AlertDialog_multiChoiceItemLayout, 0);
        this.f1602n = obtainStyledAttributes.getResourceId(C0550j.AlertDialog_singleChoiceItemLayout, 0);
        this.f1603o = obtainStyledAttributes.getResourceId(C0550j.AlertDialog_listItemLayout, 0);
        this.f1586Q = obtainStyledAttributes.getBoolean(C0550j.AlertDialog_showTitle, true);
        this.f1607s = obtainStyledAttributes.getDimensionPixelSize(C0550j.AlertDialog_buttonIconDimen, 0);
        obtainStyledAttributes.recycle();
        gVar.mo2326a(1);
    }

    /* renamed from: a */
    private ViewGroup m2413a(View view, View view2) {
        if (view == null) {
            if (view2 instanceof ViewStub) {
                view2 = ((ViewStub) view2).inflate();
            }
            return (ViewGroup) view2;
        }
        if (view2 != null) {
            ViewParent parent = view2.getParent();
            if (parent instanceof ViewGroup) {
                ((ViewGroup) parent).removeView(view2);
            }
        }
        if (view instanceof ViewStub) {
            view = ((ViewStub) view).inflate();
        }
        return (ViewGroup) view;
    }

    /* renamed from: a */
    static void m2414a(View view, View view2, View view3) {
        int i = 4;
        if (view2 != null) {
            view2.setVisibility(view.canScrollVertically(-1) ? 0 : 4);
        }
        if (view3 != null) {
            if (view.canScrollVertically(1)) {
                i = 0;
            }
            view3.setVisibility(i);
        }
    }

    /* renamed from: a */
    private void m2415a(ViewGroup viewGroup) {
        boolean z = false;
        View view = this.f1610v != null ? this.f1610v : this.f1611w != 0 ? LayoutInflater.from(this.f1605q).inflate(this.f1611w, viewGroup, false) : null;
        if (view != null) {
            z = true;
        }
        if (!z || !m2419a(view)) {
            this.f1606r.setFlags(131072, 131072);
        }
        if (z) {
            FrameLayout frameLayout = (FrameLayout) this.f1606r.findViewById(C0546f.custom);
            frameLayout.addView(view, new LayoutParams(-1, -1));
            if (this.f1571B) {
                frameLayout.setPadding(this.f1612x, this.f1613y, this.f1614z, this.f1570A);
            }
            if (this.f1590b != null) {
                ((C0788a) viewGroup.getLayoutParams()).f2782g = 0.0f;
            }
        } else {
            viewGroup.setVisibility(8);
        }
    }

    /* renamed from: a */
    private void m2416a(ViewGroup viewGroup, View view, int i, int i2) {
        final View findViewById = this.f1606r.findViewById(C0546f.scrollIndicatorUp);
        View findViewById2 = this.f1606r.findViewById(C0546f.scrollIndicatorDown);
        if (VERSION.SDK_INT >= 23) {
            C0495r.m2126a(view, i, i2);
            if (findViewById != null) {
                viewGroup.removeView(findViewById);
            }
            if (findViewById2 != null) {
                viewGroup.removeView(findViewById2);
            }
        } else {
            final View view2 = null;
            if (findViewById != null && (i & 1) == 0) {
                viewGroup.removeView(findViewById);
                findViewById = null;
            }
            if (findViewById2 == null || (i & 2) != 0) {
                view2 = findViewById2;
            } else {
                viewGroup.removeView(findViewById2);
            }
            if (!(findViewById == null && view2 == null)) {
                if (this.f1609u != null) {
                    this.f1597i.setOnScrollChangeListener(new C0511b() {
                        /* renamed from: a */
                        public void mo2039a(NestedScrollView nestedScrollView, int i, int i2, int i3, int i4) {
                            AlertController.m2414a(nestedScrollView, findViewById, view2);
                        }
                    });
                    this.f1597i.post(new Runnable() {
                        public void run() {
                            AlertController.m2414a(AlertController.this.f1597i, findViewById, view2);
                        }
                    });
                } else if (this.f1590b != null) {
                    this.f1590b.setOnScrollListener(new OnScrollListener() {
                        public void onScroll(AbsListView absListView, int i, int i2, int i3) {
                            AlertController.m2414a(absListView, findViewById, view2);
                        }

                        public void onScrollStateChanged(AbsListView absListView, int i) {
                        }
                    });
                    this.f1590b.post(new Runnable() {
                        public void run() {
                            AlertController.m2414a(AlertController.this.f1590b, findViewById, view2);
                        }
                    });
                } else {
                    if (findViewById != null) {
                        viewGroup.removeView(findViewById);
                    }
                    if (view2 != null) {
                        viewGroup.removeView(view2);
                    }
                }
            }
        }
    }

    /* renamed from: a */
    private void m2417a(Button button) {
        LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) button.getLayoutParams();
        layoutParams.gravity = 1;
        layoutParams.weight = 0.5f;
        button.setLayoutParams(layoutParams);
    }

    /* renamed from: a */
    private static boolean m2418a(Context context) {
        TypedValue typedValue = new TypedValue();
        context.getTheme().resolveAttribute(C0541a.alertDialogCenterButtons, typedValue, true);
        return typedValue.data != 0;
    }

    /* renamed from: a */
    static boolean m2419a(View view) {
        if (view.onCheckIsTextEditor()) {
            return true;
        }
        if (!(view instanceof ViewGroup)) {
            return false;
        }
        ViewGroup viewGroup = (ViewGroup) view;
        int childCount = viewGroup.getChildCount();
        while (childCount > 0) {
            childCount--;
            if (m2419a(viewGroup.getChildAt(childCount))) {
                return true;
            }
        }
        return false;
    }

    /* renamed from: b */
    private int m2420b() {
        return this.f1585P == 0 ? this.f1584O : this.f1587R == 1 ? this.f1585P : this.f1584O;
    }

    /* renamed from: b */
    private void m2421b(ViewGroup viewGroup) {
        if (this.f1583N != null) {
            viewGroup.addView(this.f1583N, 0, new LayoutParams(-1, -2));
            this.f1606r.findViewById(C0546f.title_template).setVisibility(8);
            return;
        }
        this.f1580K = (ImageView) this.f1606r.findViewById(16908294);
        if (!(!TextUtils.isEmpty(this.f1608t)) || !this.f1586Q) {
            this.f1606r.findViewById(C0546f.title_template).setVisibility(8);
            this.f1580K.setVisibility(8);
            viewGroup.setVisibility(8);
            return;
        }
        this.f1581L = (TextView) this.f1606r.findViewById(C0546f.alertTitle);
        this.f1581L.setText(this.f1608t);
        if (this.f1578I != 0) {
            this.f1580K.setImageResource(this.f1578I);
        } else if (this.f1579J != null) {
            this.f1580K.setImageDrawable(this.f1579J);
        } else {
            this.f1581L.setPadding(this.f1580K.getPaddingLeft(), this.f1580K.getPaddingTop(), this.f1580K.getPaddingRight(), this.f1580K.getPaddingBottom());
            this.f1580K.setVisibility(8);
        }
    }

    /* renamed from: c */
    private void m2422c() {
        View findViewById = this.f1606r.findViewById(C0546f.parentPanel);
        View findViewById2 = findViewById.findViewById(C0546f.topPanel);
        View findViewById3 = findViewById.findViewById(C0546f.contentPanel);
        View findViewById4 = findViewById.findViewById(C0546f.buttonPanel);
        ViewGroup viewGroup = (ViewGroup) findViewById.findViewById(C0546f.customPanel);
        m2415a(viewGroup);
        View findViewById5 = viewGroup.findViewById(C0546f.topPanel);
        View findViewById6 = viewGroup.findViewById(C0546f.contentPanel);
        View findViewById7 = viewGroup.findViewById(C0546f.buttonPanel);
        ViewGroup a = m2413a(findViewById5, findViewById2);
        ViewGroup a2 = m2413a(findViewById6, findViewById3);
        ViewGroup a3 = m2413a(findViewById7, findViewById4);
        m2423c(a2);
        m2424d(a3);
        m2421b(a);
        char c = 0;
        boolean z = (viewGroup == null || viewGroup.getVisibility() == 8) ? false : true;
        boolean z2 = (a == null || a.getVisibility() == 8) ? false : true;
        boolean z3 = (a3 == null || a3.getVisibility() == 8) ? false : true;
        if (!z3 && a2 != null) {
            View findViewById8 = a2.findViewById(C0546f.textSpacerNoButtons);
            if (findViewById8 != null) {
                findViewById8.setVisibility(0);
            }
        }
        if (z2) {
            if (this.f1597i != null) {
                this.f1597i.setClipToPadding(true);
            }
            View view = null;
            if (!(this.f1609u == null && this.f1590b == null)) {
                view = a.findViewById(C0546f.titleDividerNoCustom);
            }
            if (view != null) {
                view.setVisibility(0);
            }
        } else if (a2 != null) {
            View findViewById9 = a2.findViewById(C0546f.textSpacerNoTitle);
            if (findViewById9 != null) {
                findViewById9.setVisibility(0);
            }
        }
        if (this.f1590b instanceof RecycleListView) {
            ((RecycleListView) this.f1590b).mo2150a(z2, z3);
        }
        if (!z) {
            View view2 = this.f1590b != null ? this.f1590b : this.f1597i;
            if (view2 != null) {
                if (z3) {
                    c = 2;
                }
                m2416a(a2, view2, z2 | c ? 1 : 0, 3);
            }
        }
        ListView listView = this.f1590b;
        if (listView != null && this.f1598j != null) {
            listView.setAdapter(this.f1598j);
            int i = this.f1599k;
            if (i > -1) {
                listView.setItemChecked(i, true);
                listView.setSelection(i);
            }
        }
    }

    /* renamed from: c */
    private void m2423c(ViewGroup viewGroup) {
        this.f1597i = (NestedScrollView) this.f1606r.findViewById(C0546f.scrollView);
        this.f1597i.setFocusable(false);
        this.f1597i.setNestedScrollingEnabled(false);
        this.f1582M = (TextView) viewGroup.findViewById(16908299);
        if (this.f1582M != null) {
            if (this.f1609u != null) {
                this.f1582M.setText(this.f1609u);
                return;
            }
            this.f1582M.setVisibility(8);
            this.f1597i.removeView(this.f1582M);
            if (this.f1590b != null) {
                ViewGroup viewGroup2 = (ViewGroup) this.f1597i.getParent();
                int indexOfChild = viewGroup2.indexOfChild(this.f1597i);
                viewGroup2.removeViewAt(indexOfChild);
                viewGroup2.addView(this.f1590b, indexOfChild, new LayoutParams(-1, -1));
                return;
            }
            viewGroup.setVisibility(8);
        }
    }

    /* renamed from: d */
    private void m2424d(ViewGroup viewGroup) {
        boolean z;
        Button button;
        this.f1591c = (Button) viewGroup.findViewById(16908313);
        this.f1591c.setOnClickListener(this.f1588S);
        boolean z2 = true;
        if (!TextUtils.isEmpty(this.f1572C) || this.f1573D != null) {
            this.f1591c.setText(this.f1572C);
            if (this.f1573D != null) {
                this.f1573D.setBounds(0, 0, this.f1607s, this.f1607s);
                this.f1591c.setCompoundDrawables(this.f1573D, null, null, null);
            }
            this.f1591c.setVisibility(0);
            z = true;
        } else {
            this.f1591c.setVisibility(8);
            z = false;
        }
        this.f1593e = (Button) viewGroup.findViewById(16908314);
        this.f1593e.setOnClickListener(this.f1588S);
        if (!TextUtils.isEmpty(this.f1574E) || this.f1575F != null) {
            this.f1593e.setText(this.f1574E);
            if (this.f1575F != null) {
                this.f1575F.setBounds(0, 0, this.f1607s, this.f1607s);
                this.f1593e.setCompoundDrawables(this.f1575F, null, null, null);
            }
            this.f1593e.setVisibility(0);
            z |= true;
        } else {
            this.f1593e.setVisibility(8);
        }
        this.f1595g = (Button) viewGroup.findViewById(16908315);
        this.f1595g.setOnClickListener(this.f1588S);
        if (!TextUtils.isEmpty(this.f1576G) || this.f1577H != null) {
            this.f1595g.setText(this.f1576G);
            if (this.f1573D != null) {
                this.f1573D.setBounds(0, 0, this.f1607s, this.f1607s);
                this.f1591c.setCompoundDrawables(this.f1573D, null, null, null);
            }
            this.f1595g.setVisibility(0);
            z |= true;
        } else {
            this.f1595g.setVisibility(8);
        }
        if (m2418a(this.f1605q)) {
            if (z) {
                button = this.f1591c;
            } else if (z) {
                button = this.f1593e;
            } else if (z) {
                button = this.f1595g;
            }
            m2417a(button);
        }
        if (!z) {
            z2 = false;
        }
        if (!z2) {
            viewGroup.setVisibility(8);
        }
    }

    /* renamed from: a */
    public void mo2132a() {
        this.f1589a.setContentView(m2420b());
        m2422c();
    }

    /* renamed from: a */
    public void mo2133a(int i) {
        this.f1610v = null;
        this.f1611w = i;
        this.f1571B = false;
    }

    /* renamed from: a */
    public void mo2134a(int i, CharSequence charSequence, DialogInterface.OnClickListener onClickListener, Message message, Drawable drawable) {
        if (message == null && onClickListener != null) {
            message = this.f1604p.obtainMessage(i, onClickListener);
        }
        switch (i) {
            case -3:
                this.f1576G = charSequence;
                this.f1596h = message;
                this.f1577H = drawable;
                return;
            case -2:
                this.f1574E = charSequence;
                this.f1594f = message;
                this.f1575F = drawable;
                return;
            case -1:
                this.f1572C = charSequence;
                this.f1592d = message;
                this.f1573D = drawable;
                return;
            default:
                throw new IllegalArgumentException("Button does not exist");
        }
    }

    /* renamed from: a */
    public void mo2135a(Drawable drawable) {
        this.f1579J = drawable;
        this.f1578I = 0;
        if (this.f1580K != null) {
            if (drawable != null) {
                this.f1580K.setVisibility(0);
                this.f1580K.setImageDrawable(drawable);
                return;
            }
            this.f1580K.setVisibility(8);
        }
    }

    /* renamed from: a */
    public void mo2136a(View view, int i, int i2, int i3, int i4) {
        this.f1610v = view;
        this.f1611w = 0;
        this.f1571B = true;
        this.f1612x = i;
        this.f1613y = i2;
        this.f1614z = i3;
        this.f1570A = i4;
    }

    /* renamed from: a */
    public void mo2137a(CharSequence charSequence) {
        this.f1608t = charSequence;
        if (this.f1581L != null) {
            this.f1581L.setText(charSequence);
        }
    }

    /* renamed from: a */
    public boolean mo2138a(int i, KeyEvent keyEvent) {
        return this.f1597i != null && this.f1597i.mo1983a(keyEvent);
    }

    /* renamed from: b */
    public void mo2139b(int i) {
        this.f1579J = null;
        this.f1578I = i;
        if (this.f1580K != null) {
            if (i != 0) {
                this.f1580K.setVisibility(0);
                this.f1580K.setImageResource(this.f1578I);
                return;
            }
            this.f1580K.setVisibility(8);
        }
    }

    /* renamed from: b */
    public void mo2140b(View view) {
        this.f1583N = view;
    }

    /* renamed from: b */
    public void mo2141b(CharSequence charSequence) {
        this.f1609u = charSequence;
        if (this.f1582M != null) {
            this.f1582M.setText(charSequence);
        }
    }

    /* renamed from: b */
    public boolean mo2142b(int i, KeyEvent keyEvent) {
        return this.f1597i != null && this.f1597i.mo1983a(keyEvent);
    }

    /* renamed from: c */
    public int mo2143c(int i) {
        TypedValue typedValue = new TypedValue();
        this.f1605q.getTheme().resolveAttribute(i, typedValue, true);
        return typedValue.resourceId;
    }

    /* renamed from: c */
    public void mo2144c(View view) {
        this.f1610v = view;
        this.f1611w = 0;
        this.f1571B = false;
    }
}
