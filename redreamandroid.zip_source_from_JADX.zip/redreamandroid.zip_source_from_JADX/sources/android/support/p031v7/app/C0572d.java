package android.support.p031v7.app;

import android.support.p031v7.view.C0627b;
import android.support.p031v7.view.C0627b.C0628a;

/* renamed from: android.support.v7.app.d */
public interface C0572d {
    /* renamed from: a */
    C0627b mo2211a(C0628a aVar);

    /* renamed from: a */
    void mo2213a(C0627b bVar);

    /* renamed from: b */
    void mo2218b(C0627b bVar);
}
