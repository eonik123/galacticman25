package android.support.p031v7.app;

import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.TypedArray;
import android.os.Build.VERSION;
import android.support.p018v4.p027g.C0412a;
import android.support.p018v4.p028h.C0495r;
import android.support.p031v7.p032a.C0540a.C0550j;
import android.support.p031v7.view.C0630d;
import android.support.p031v7.widget.AppCompatButton;
import android.support.p031v7.widget.C0866bk;
import android.support.p031v7.widget.C0904f;
import android.support.p031v7.widget.C0906h;
import android.support.p031v7.widget.C0907i;
import android.support.p031v7.widget.C0915l;
import android.support.p031v7.widget.C0917n;
import android.support.p031v7.widget.C0919p;
import android.support.p031v7.widget.C0920q;
import android.support.p031v7.widget.C0923t;
import android.support.p031v7.widget.C0924u;
import android.support.p031v7.widget.C0925v;
import android.support.p031v7.widget.C0927x;
import android.support.p031v7.widget.C0936z;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Map;

/* renamed from: android.support.v7.app.AppCompatViewInflater */
public class AppCompatViewInflater {
    private static final String LOG_TAG = "AppCompatViewInflater";
    private static final String[] sClassPrefixList = {"android.widget.", "android.view.", "android.webkit."};
    private static final Map<String, Constructor<? extends View>> sConstructorMap = new C0412a();
    private static final Class<?>[] sConstructorSignature = {Context.class, AttributeSet.class};
    private static final int[] sOnClickAttrs = {16843375};
    private final Object[] mConstructorArgs = new Object[2];

    /* renamed from: android.support.v7.app.AppCompatViewInflater$a */
    private static class C0564a implements OnClickListener {

        /* renamed from: a */
        private final View f1685a;

        /* renamed from: b */
        private final String f1686b;

        /* renamed from: c */
        private Method f1687c;

        /* renamed from: d */
        private Context f1688d;

        public C0564a(View view, String str) {
            this.f1685a = view;
            this.f1686b = str;
        }

        /* renamed from: a */
        private void m2443a(Context context, String str) {
            String str2;
            while (context != null) {
                try {
                    if (!context.isRestricted()) {
                        Method method = context.getClass().getMethod(this.f1686b, new Class[]{View.class});
                        if (method != null) {
                            this.f1687c = method;
                            this.f1688d = context;
                            return;
                        }
                    }
                } catch (NoSuchMethodException unused) {
                }
                context = context instanceof ContextWrapper ? ((ContextWrapper) context).getBaseContext() : null;
            }
            int id = this.f1685a.getId();
            if (id == -1) {
                str2 = "";
            } else {
                StringBuilder sb = new StringBuilder();
                sb.append(" with id '");
                sb.append(this.f1685a.getContext().getResources().getResourceEntryName(id));
                sb.append("'");
                str2 = sb.toString();
            }
            StringBuilder sb2 = new StringBuilder();
            sb2.append("Could not find method ");
            sb2.append(this.f1686b);
            sb2.append("(View) in a parent or ancestor Context for android:onClick ");
            sb2.append("attribute defined on view ");
            sb2.append(this.f1685a.getClass());
            sb2.append(str2);
            throw new IllegalStateException(sb2.toString());
        }

        public void onClick(View view) {
            if (this.f1687c == null) {
                m2443a(this.f1685a.getContext(), this.f1686b);
            }
            try {
                this.f1687c.invoke(this.f1688d, new Object[]{view});
            } catch (IllegalAccessException e) {
                throw new IllegalStateException("Could not execute non-public method for android:onClick", e);
            } catch (InvocationTargetException e2) {
                throw new IllegalStateException("Could not execute method for android:onClick", e2);
            }
        }
    }

    private void checkOnClickListener(View view, AttributeSet attributeSet) {
        Context context = view.getContext();
        if ((context instanceof ContextWrapper) && (VERSION.SDK_INT < 15 || C0495r.m2118A(view))) {
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, sOnClickAttrs);
            String string = obtainStyledAttributes.getString(0);
            if (string != null) {
                view.setOnClickListener(new C0564a(view, string));
            }
            obtainStyledAttributes.recycle();
        }
    }

    private View createViewByPrefix(Context context, String str, String str2) {
        String str3;
        Constructor constructor = (Constructor) sConstructorMap.get(str);
        if (constructor == null) {
            try {
                ClassLoader classLoader = context.getClassLoader();
                if (str2 != null) {
                    StringBuilder sb = new StringBuilder();
                    sb.append(str2);
                    sb.append(str);
                    str3 = sb.toString();
                } else {
                    str3 = str;
                }
                constructor = classLoader.loadClass(str3).asSubclass(View.class).getConstructor(sConstructorSignature);
                sConstructorMap.put(str, constructor);
            } catch (Exception unused) {
                return null;
            }
        }
        constructor.setAccessible(true);
        return (View) constructor.newInstance(this.mConstructorArgs);
    }

    private View createViewFromTag(Context context, String str, AttributeSet attributeSet) {
        if (str.equals("view")) {
            str = attributeSet.getAttributeValue(null, "class");
        }
        try {
            this.mConstructorArgs[0] = context;
            this.mConstructorArgs[1] = attributeSet;
            if (-1 == str.indexOf(46)) {
                for (String createViewByPrefix : sClassPrefixList) {
                    View createViewByPrefix2 = createViewByPrefix(context, str, createViewByPrefix);
                    if (createViewByPrefix2 != null) {
                        return createViewByPrefix2;
                    }
                }
                this.mConstructorArgs[0] = null;
                this.mConstructorArgs[1] = null;
                return null;
            }
            View createViewByPrefix3 = createViewByPrefix(context, str, null);
            this.mConstructorArgs[0] = null;
            this.mConstructorArgs[1] = null;
            return createViewByPrefix3;
        } catch (Exception unused) {
            return null;
        } finally {
            this.mConstructorArgs[0] = null;
            this.mConstructorArgs[1] = null;
        }
    }

    private static Context themifyContext(Context context, AttributeSet attributeSet, boolean z, boolean z2) {
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, C0550j.View, 0, 0);
        int resourceId = z ? obtainStyledAttributes.getResourceId(C0550j.View_android_theme, 0) : 0;
        if (z2 && resourceId == 0) {
            resourceId = obtainStyledAttributes.getResourceId(C0550j.View_theme, 0);
            if (resourceId != 0) {
                Log.i(LOG_TAG, "app:theme is now deprecated. Please move to using android:theme instead.");
            }
        }
        obtainStyledAttributes.recycle();
        return resourceId != 0 ? (!(context instanceof C0630d) || ((C0630d) context).mo2503a() != resourceId) ? new C0630d(context, resourceId) : context : context;
    }

    private void verifyNotNull(View view, String str) {
        if (view == null) {
            StringBuilder sb = new StringBuilder();
            sb.append(getClass().getName());
            sb.append(" asked to inflate view for <");
            sb.append(str);
            sb.append(">, but returned null");
            throw new IllegalStateException(sb.toString());
        }
    }

    /* access modifiers changed from: protected */
    public C0904f createAutoCompleteTextView(Context context, AttributeSet attributeSet) {
        return new C0904f(context, attributeSet);
    }

    /* access modifiers changed from: protected */
    public AppCompatButton createButton(Context context, AttributeSet attributeSet) {
        return new AppCompatButton(context, attributeSet);
    }

    /* access modifiers changed from: protected */
    public C0906h createCheckBox(Context context, AttributeSet attributeSet) {
        return new C0906h(context, attributeSet);
    }

    /* access modifiers changed from: protected */
    public C0907i createCheckedTextView(Context context, AttributeSet attributeSet) {
        return new C0907i(context, attributeSet);
    }

    /* access modifiers changed from: protected */
    public C0915l createEditText(Context context, AttributeSet attributeSet) {
        return new C0915l(context, attributeSet);
    }

    /* access modifiers changed from: protected */
    public C0917n createImageButton(Context context, AttributeSet attributeSet) {
        return new C0917n(context, attributeSet);
    }

    /* access modifiers changed from: protected */
    public C0919p createImageView(Context context, AttributeSet attributeSet) {
        return new C0919p(context, attributeSet);
    }

    /* access modifiers changed from: protected */
    public C0920q createMultiAutoCompleteTextView(Context context, AttributeSet attributeSet) {
        return new C0920q(context, attributeSet);
    }

    /* access modifiers changed from: protected */
    public C0923t createRadioButton(Context context, AttributeSet attributeSet) {
        return new C0923t(context, attributeSet);
    }

    /* access modifiers changed from: protected */
    public C0924u createRatingBar(Context context, AttributeSet attributeSet) {
        return new C0924u(context, attributeSet);
    }

    /* access modifiers changed from: protected */
    public C0925v createSeekBar(Context context, AttributeSet attributeSet) {
        return new C0925v(context, attributeSet);
    }

    /* access modifiers changed from: protected */
    public C0927x createSpinner(Context context, AttributeSet attributeSet) {
        return new C0927x(context, attributeSet);
    }

    /* access modifiers changed from: protected */
    public C0936z createTextView(Context context, AttributeSet attributeSet) {
        return new C0936z(context, attributeSet);
    }

    /* access modifiers changed from: protected */
    public View createView(Context context, String str, AttributeSet attributeSet) {
        return null;
    }

    /* access modifiers changed from: 0000 */
    public final View createView(View view, String str, Context context, AttributeSet attributeSet, boolean z, boolean z2, boolean z3, boolean z4) {
        View view2;
        Context context2 = (!z || view == null) ? context : view.getContext();
        if (z2 || z3) {
            context2 = themifyContext(context2, attributeSet, z2, z3);
        }
        if (z4) {
            context2 = C0866bk.m4633a(context2);
        }
        char c = 65535;
        switch (str.hashCode()) {
            case -1946472170:
                if (str.equals("RatingBar")) {
                    c = 11;
                    break;
                }
                break;
            case -1455429095:
                if (str.equals("CheckedTextView")) {
                    c = 8;
                    break;
                }
                break;
            case -1346021293:
                if (str.equals("MultiAutoCompleteTextView")) {
                    c = 10;
                    break;
                }
                break;
            case -938935918:
                if (str.equals("TextView")) {
                    c = 0;
                    break;
                }
                break;
            case -937446323:
                if (str.equals("ImageButton")) {
                    c = 5;
                    break;
                }
                break;
            case -658531749:
                if (str.equals("SeekBar")) {
                    c = 12;
                    break;
                }
                break;
            case -339785223:
                if (str.equals("Spinner")) {
                    c = 4;
                    break;
                }
                break;
            case 776382189:
                if (str.equals("RadioButton")) {
                    c = 7;
                    break;
                }
                break;
            case 1125864064:
                if (str.equals("ImageView")) {
                    c = 1;
                    break;
                }
                break;
            case 1413872058:
                if (str.equals("AutoCompleteTextView")) {
                    c = 9;
                    break;
                }
                break;
            case 1601505219:
                if (str.equals("CheckBox")) {
                    c = 6;
                    break;
                }
                break;
            case 1666676343:
                if (str.equals("EditText")) {
                    c = 3;
                    break;
                }
                break;
            case 2001146706:
                if (str.equals("Button")) {
                    c = 2;
                    break;
                }
                break;
        }
        switch (c) {
            case 0:
                view2 = createTextView(context2, attributeSet);
                break;
            case 1:
                view2 = createImageView(context2, attributeSet);
                break;
            case 2:
                view2 = createButton(context2, attributeSet);
                break;
            case 3:
                view2 = createEditText(context2, attributeSet);
                break;
            case 4:
                view2 = createSpinner(context2, attributeSet);
                break;
            case 5:
                view2 = createImageButton(context2, attributeSet);
                break;
            case 6:
                view2 = createCheckBox(context2, attributeSet);
                break;
            case 7:
                view2 = createRadioButton(context2, attributeSet);
                break;
            case 8:
                view2 = createCheckedTextView(context2, attributeSet);
                break;
            case 9:
                view2 = createAutoCompleteTextView(context2, attributeSet);
                break;
            case 10:
                view2 = createMultiAutoCompleteTextView(context2, attributeSet);
                break;
            case 11:
                view2 = createRatingBar(context2, attributeSet);
                break;
            case 12:
                view2 = createSeekBar(context2, attributeSet);
                break;
            default:
                view2 = createView(context2, str, attributeSet);
                break;
        }
        verifyNotNull(view2, str);
        if (view2 == null && context != context2) {
            view2 = createViewFromTag(context2, str, attributeSet);
        }
        if (view2 != null) {
            checkOnClickListener(view2, attributeSet);
        }
        return view2;
    }
}
