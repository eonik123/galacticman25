package android.support.p031v7.app;

import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.DialogInterface.OnKeyListener;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.p031v7.app.AlertController.C0556a;
import android.support.p031v7.p032a.C0540a.C0541a;
import android.util.TypedValue;
import android.view.ContextThemeWrapper;
import android.view.KeyEvent;
import android.view.View;
import android.widget.ListAdapter;

/* renamed from: android.support.v7.app.b */
public class C0569b extends C0592g implements DialogInterface {

    /* renamed from: a */
    final AlertController f1690a = new AlertController(getContext(), this, getWindow());

    /* renamed from: android.support.v7.app.b$a */
    public static class C0570a {

        /* renamed from: a */
        private final C0556a f1691a;

        /* renamed from: b */
        private final int f1692b;

        public C0570a(Context context) {
            this(context, C0569b.m2468a(context, 0));
        }

        public C0570a(Context context, int i) {
            this.f1691a = new C0556a(new ContextThemeWrapper(context, C0569b.m2468a(context, i)));
            this.f1692b = i;
        }

        /* renamed from: a */
        public Context mo2204a() {
            return this.f1691a.f1646a;
        }

        /* renamed from: a */
        public C0570a mo2205a(OnKeyListener onKeyListener) {
            this.f1691a.f1666u = onKeyListener;
            return this;
        }

        /* renamed from: a */
        public C0570a mo2206a(Drawable drawable) {
            this.f1691a.f1649d = drawable;
            return this;
        }

        /* renamed from: a */
        public C0570a mo2207a(View view) {
            this.f1691a.f1652g = view;
            return this;
        }

        /* renamed from: a */
        public C0570a mo2208a(ListAdapter listAdapter, OnClickListener onClickListener) {
            this.f1691a.f1668w = listAdapter;
            this.f1691a.f1669x = onClickListener;
            return this;
        }

        /* renamed from: a */
        public C0570a mo2209a(CharSequence charSequence) {
            this.f1691a.f1651f = charSequence;
            return this;
        }

        /* renamed from: b */
        public C0569b mo2210b() {
            C0569b bVar = new C0569b(this.f1691a.f1646a, this.f1692b);
            this.f1691a.mo2151a(bVar.f1690a);
            bVar.setCancelable(this.f1691a.f1663r);
            if (this.f1691a.f1663r) {
                bVar.setCanceledOnTouchOutside(true);
            }
            bVar.setOnCancelListener(this.f1691a.f1664s);
            bVar.setOnDismissListener(this.f1691a.f1665t);
            if (this.f1691a.f1666u != null) {
                bVar.setOnKeyListener(this.f1691a.f1666u);
            }
            return bVar;
        }
    }

    protected C0569b(Context context, int i) {
        super(context, m2468a(context, i));
    }

    /* renamed from: a */
    static int m2468a(Context context, int i) {
        if (((i >>> 24) & 255) >= 1) {
            return i;
        }
        TypedValue typedValue = new TypedValue();
        context.getTheme().resolveAttribute(C0541a.alertDialogTheme, typedValue, true);
        return typedValue.resourceId;
    }

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.f1690a.mo2132a();
    }

    public boolean onKeyDown(int i, KeyEvent keyEvent) {
        if (this.f1690a.mo2138a(i, keyEvent)) {
            return true;
        }
        return super.onKeyDown(i, keyEvent);
    }

    public boolean onKeyUp(int i, KeyEvent keyEvent) {
        if (this.f1690a.mo2142b(i, keyEvent)) {
            return true;
        }
        return super.onKeyUp(i, keyEvent);
    }

    public void setTitle(CharSequence charSequence) {
        super.setTitle(charSequence);
        this.f1690a.mo2137a(charSequence);
    }
}
