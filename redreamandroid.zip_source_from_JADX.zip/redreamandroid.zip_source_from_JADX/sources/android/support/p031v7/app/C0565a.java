package android.support.p031v7.app;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.support.p031v7.p032a.C0540a.C0550j;
import android.support.p031v7.view.C0627b;
import android.support.p031v7.view.C0627b.C0628a;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewGroup.MarginLayoutParams;

/* renamed from: android.support.v7.app.a */
public abstract class C0565a {

    /* renamed from: android.support.v7.app.a$a */
    public static class C0566a extends MarginLayoutParams {

        /* renamed from: a */
        public int f1689a;

        public C0566a(int i, int i2) {
            super(i, i2);
            this.f1689a = 0;
            this.f1689a = 8388627;
        }

        public C0566a(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            this.f1689a = 0;
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, C0550j.ActionBarLayout);
            this.f1689a = obtainStyledAttributes.getInt(C0550j.ActionBarLayout_android_layout_gravity, 0);
            obtainStyledAttributes.recycle();
        }

        public C0566a(C0566a aVar) {
            super(aVar);
            this.f1689a = 0;
            this.f1689a = aVar.f1689a;
        }

        public C0566a(LayoutParams layoutParams) {
            super(layoutParams);
            this.f1689a = 0;
        }
    }

    /* renamed from: android.support.v7.app.a$b */
    public interface C0567b {
        /* renamed from: a */
        void mo2194a(boolean z);
    }

    @Deprecated
    /* renamed from: android.support.v7.app.a$c */
    public static abstract class C0568c {
        /* renamed from: a */
        public abstract Drawable mo2195a();

        /* renamed from: b */
        public abstract CharSequence mo2196b();

        /* renamed from: c */
        public abstract View mo2197c();

        /* renamed from: d */
        public abstract void mo2198d();

        /* renamed from: e */
        public abstract CharSequence mo2199e();
    }

    /* renamed from: a */
    public abstract int mo2176a();

    /* renamed from: a */
    public C0627b mo2177a(C0628a aVar) {
        return null;
    }

    /* renamed from: a */
    public void mo2178a(float f) {
        if (f != 0.0f) {
            throw new UnsupportedOperationException("Setting a non-zero elevation is not supported in this action bar configuration.");
        }
    }

    /* renamed from: a */
    public void mo2179a(Configuration configuration) {
    }

    /* renamed from: a */
    public void mo2180a(CharSequence charSequence) {
    }

    /* renamed from: a */
    public void mo2181a(boolean z) {
    }

    /* renamed from: a */
    public boolean mo2182a(int i, KeyEvent keyEvent) {
        return false;
    }

    /* renamed from: a */
    public boolean mo2183a(KeyEvent keyEvent) {
        return false;
    }

    /* renamed from: b */
    public Context mo2184b() {
        return null;
    }

    /* renamed from: b */
    public void mo2185b(boolean z) {
        if (z) {
            throw new UnsupportedOperationException("Hide on content scroll is not supported in this action bar configuration.");
        }
    }

    /* renamed from: c */
    public void mo2186c(boolean z) {
    }

    /* renamed from: c */
    public boolean mo2187c() {
        return false;
    }

    /* renamed from: d */
    public void mo2188d(boolean z) {
    }

    /* renamed from: d */
    public boolean mo2189d() {
        return false;
    }

    /* renamed from: e */
    public void mo2190e(boolean z) {
    }

    /* renamed from: e */
    public boolean mo2191e() {
        return false;
    }

    /* renamed from: f */
    public boolean mo2192f() {
        return false;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: g */
    public void mo2193g() {
    }
}
