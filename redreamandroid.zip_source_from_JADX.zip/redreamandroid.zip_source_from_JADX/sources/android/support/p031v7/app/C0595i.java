package android.support.p031v7.app;

import android.content.Context;
import android.content.res.Configuration;
import android.support.p018v4.p028h.C0495r;
import android.support.p031v7.app.C0565a.C0567b;
import android.support.p031v7.view.menu.C0655h;
import android.support.p031v7.view.menu.C0655h.C0656a;
import android.support.p031v7.view.menu.C0671o.C0672a;
import android.support.p031v7.widget.C0756aj;
import android.view.KeyCharacterMap;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window.Callback;
import java.util.ArrayList;

/* renamed from: android.support.v7.app.i */
class C0595i extends C0565a {

    /* renamed from: a */
    C0756aj f1794a;

    /* renamed from: b */
    Callback f1795b;

    /* renamed from: c */
    private boolean f1796c;

    /* renamed from: d */
    private boolean f1797d;

    /* renamed from: e */
    private ArrayList<C0567b> f1798e;

    /* renamed from: f */
    private final Runnable f1799f;

    /* renamed from: android.support.v7.app.i$a */
    private final class C0596a implements C0672a {

        /* renamed from: b */
        private boolean f1801b;

        C0596a() {
        }

        /* renamed from: a */
        public void mo2296a(C0655h hVar, boolean z) {
            if (!this.f1801b) {
                this.f1801b = true;
                C0595i.this.f1794a.mo3638n();
                if (C0595i.this.f1795b != null) {
                    C0595i.this.f1795b.onPanelClosed(108, hVar);
                }
                this.f1801b = false;
            }
        }

        /* renamed from: a */
        public boolean mo2297a(C0655h hVar) {
            if (C0595i.this.f1795b == null) {
                return false;
            }
            C0595i.this.f1795b.onMenuOpened(108, hVar);
            return true;
        }
    }

    /* renamed from: android.support.v7.app.i$b */
    private final class C0597b implements C0656a {
        C0597b() {
        }

        /* renamed from: a */
        public void mo2264a(C0655h hVar) {
            if (C0595i.this.f1795b != null) {
                if (C0595i.this.f1794a.mo3633i()) {
                    C0595i.this.f1795b.onPanelClosed(108, hVar);
                } else if (C0595i.this.f1795b.onPreparePanel(0, null, hVar)) {
                    C0595i.this.f1795b.onMenuOpened(108, hVar);
                }
            }
        }

        /* renamed from: a */
        public boolean mo2267a(C0655h hVar, MenuItem menuItem) {
            return false;
        }
    }

    /* renamed from: h */
    private Menu m2628h() {
        if (!this.f1796c) {
            this.f1794a.mo3616a((C0672a) new C0596a(), (C0656a) new C0597b());
            this.f1796c = true;
        }
        return this.f1794a.mo3641q();
    }

    /* renamed from: a */
    public int mo2176a() {
        return this.f1794a.mo3639o();
    }

    /* renamed from: a */
    public void mo2178a(float f) {
        C0495r.m2124a((View) this.f1794a.mo3613a(), f);
    }

    /* renamed from: a */
    public void mo2179a(Configuration configuration) {
        super.mo2179a(configuration);
    }

    /* renamed from: a */
    public void mo2180a(CharSequence charSequence) {
        this.f1794a.mo3620a(charSequence);
    }

    /* renamed from: a */
    public void mo2181a(boolean z) {
    }

    /* renamed from: a */
    public boolean mo2182a(int i, KeyEvent keyEvent) {
        Menu h = m2628h();
        if (h == null) {
            return false;
        }
        boolean z = true;
        if (KeyCharacterMap.load(keyEvent != null ? keyEvent.getDeviceId() : -1).getKeyboardType() == 1) {
            z = false;
        }
        h.setQwertyMode(z);
        return h.performShortcut(i, keyEvent, 0);
    }

    /* renamed from: a */
    public boolean mo2183a(KeyEvent keyEvent) {
        if (keyEvent.getAction() == 1) {
            mo2187c();
        }
        return true;
    }

    /* renamed from: b */
    public Context mo2184b() {
        return this.f1794a.mo3622b();
    }

    /* renamed from: c */
    public void mo2186c(boolean z) {
    }

    /* renamed from: c */
    public boolean mo2187c() {
        return this.f1794a.mo3635k();
    }

    /* renamed from: d */
    public void mo2188d(boolean z) {
    }

    /* renamed from: d */
    public boolean mo2189d() {
        return this.f1794a.mo3636l();
    }

    /* renamed from: e */
    public void mo2190e(boolean z) {
        if (z != this.f1797d) {
            this.f1797d = z;
            int size = this.f1798e.size();
            for (int i = 0; i < size; i++) {
                ((C0567b) this.f1798e.get(i)).mo2194a(z);
            }
        }
    }

    /* renamed from: e */
    public boolean mo2191e() {
        this.f1794a.mo3613a().removeCallbacks(this.f1799f);
        C0495r.m2134a((View) this.f1794a.mo3613a(), this.f1799f);
        return true;
    }

    /* renamed from: f */
    public boolean mo2192f() {
        if (!this.f1794a.mo3626c()) {
            return false;
        }
        this.f1794a.mo3627d();
        return true;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: g */
    public void mo2193g() {
        this.f1794a.mo3613a().removeCallbacks(this.f1799f);
    }
}
