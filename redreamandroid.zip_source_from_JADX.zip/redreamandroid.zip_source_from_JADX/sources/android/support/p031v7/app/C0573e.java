package android.support.p031v7.app;

import android.app.Activity;
import android.app.Dialog;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.MenuInflater;
import android.view.View;
import android.view.ViewGroup.LayoutParams;

/* renamed from: android.support.v7.app.e */
public abstract class C0573e {

    /* renamed from: a */
    private static int f1696a = -1;

    C0573e() {
    }

    /* renamed from: a */
    public static C0573e m2493a(Activity activity, C0572d dVar) {
        return new C0574f(activity, activity.getWindow(), dVar);
    }

    /* renamed from: a */
    public static C0573e m2494a(Dialog dialog, C0572d dVar) {
        return new C0574f(dialog.getContext(), dialog.getWindow(), dVar);
    }

    /* renamed from: j */
    public static int m2495j() {
        return f1696a;
    }

    /* renamed from: a */
    public abstract C0565a mo2238a();

    /* renamed from: a */
    public abstract <T extends View> T mo2239a(int i);

    /* renamed from: a */
    public abstract void mo2240a(Configuration configuration);

    /* renamed from: a */
    public abstract void mo2241a(Bundle bundle);

    /* renamed from: a */
    public abstract void mo2242a(View view);

    /* renamed from: a */
    public abstract void mo2243a(View view, LayoutParams layoutParams);

    /* renamed from: a */
    public abstract void mo2244a(CharSequence charSequence);

    /* renamed from: b */
    public abstract MenuInflater mo2245b();

    /* renamed from: b */
    public abstract void mo2246b(int i);

    /* renamed from: b */
    public abstract void mo2247b(Bundle bundle);

    /* renamed from: b */
    public abstract void mo2248b(View view, LayoutParams layoutParams);

    /* renamed from: c */
    public abstract void mo2249c();

    /* renamed from: c */
    public abstract void mo2250c(Bundle bundle);

    /* renamed from: c */
    public abstract boolean mo2251c(int i);

    /* renamed from: d */
    public abstract void mo2252d();

    /* renamed from: e */
    public abstract void mo2253e();

    /* renamed from: f */
    public abstract void mo2254f();

    /* renamed from: g */
    public abstract void mo2255g();

    /* renamed from: h */
    public abstract void mo2256h();

    /* renamed from: i */
    public abstract boolean mo2257i();
}
