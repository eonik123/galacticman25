package android.support.p031v7.app;

import android.annotation.SuppressLint;
import android.content.Context;
import android.location.Location;
import android.location.LocationManager;
import android.support.p018v4.p019a.C0311c;
import android.util.Log;
import java.util.Calendar;

/* renamed from: android.support.v7.app.k */
class C0599k {

    /* renamed from: a */
    private static C0599k f1807a;

    /* renamed from: b */
    private final Context f1808b;

    /* renamed from: c */
    private final LocationManager f1809c;

    /* renamed from: d */
    private final C0600a f1810d = new C0600a();

    /* renamed from: android.support.v7.app.k$a */
    private static class C0600a {

        /* renamed from: a */
        boolean f1811a;

        /* renamed from: b */
        long f1812b;

        /* renamed from: c */
        long f1813c;

        /* renamed from: d */
        long f1814d;

        /* renamed from: e */
        long f1815e;

        /* renamed from: f */
        long f1816f;

        C0600a() {
        }
    }

    C0599k(Context context, LocationManager locationManager) {
        this.f1808b = context;
        this.f1809c = locationManager;
    }

    /* renamed from: a */
    private Location m2651a(String str) {
        try {
            if (this.f1809c.isProviderEnabled(str)) {
                return this.f1809c.getLastKnownLocation(str);
            }
        } catch (Exception e) {
            Log.d("TwilightManager", "Failed to get last known location", e);
        }
        return null;
    }

    /* renamed from: a */
    static C0599k m2652a(Context context) {
        if (f1807a == null) {
            Context applicationContext = context.getApplicationContext();
            f1807a = new C0599k(applicationContext, (LocationManager) applicationContext.getSystemService("location"));
        }
        return f1807a;
    }

    /* renamed from: a */
    private void m2653a(Location location) {
        long j;
        C0600a aVar = this.f1810d;
        long currentTimeMillis = System.currentTimeMillis();
        C0598j a = C0598j.m2649a();
        C0598j jVar = a;
        jVar.mo2337a(currentTimeMillis - 86400000, location.getLatitude(), location.getLongitude());
        long j2 = a.f1804a;
        jVar.mo2337a(currentTimeMillis, location.getLatitude(), location.getLongitude());
        boolean z = true;
        if (a.f1806c != 1) {
            z = false;
        }
        boolean z2 = z;
        long j3 = a.f1805b;
        long j4 = j2;
        long j5 = a.f1804a;
        long j6 = j3;
        boolean z3 = z2;
        a.mo2337a(86400000 + currentTimeMillis, location.getLatitude(), location.getLongitude());
        long j7 = a.f1805b;
        if (j6 == -1 || j5 == -1) {
            j = 43200000 + currentTimeMillis;
        } else {
            long j8 = currentTimeMillis > j5 ? 0 + j7 : currentTimeMillis > j6 ? 0 + j5 : 0 + j6;
            j = j8 + 60000;
        }
        aVar.f1811a = z3;
        aVar.f1812b = j4;
        aVar.f1813c = j6;
        aVar.f1814d = j5;
        aVar.f1815e = j7;
        aVar.f1816f = j;
    }

    @SuppressLint({"MissingPermission"})
    /* renamed from: b */
    private Location m2654b() {
        Location location = null;
        Location a = C0311c.m1262a(this.f1808b, "android.permission.ACCESS_COARSE_LOCATION") == 0 ? m2651a("network") : null;
        if (C0311c.m1262a(this.f1808b, "android.permission.ACCESS_FINE_LOCATION") == 0) {
            location = m2651a("gps");
        }
        if (location == null || a == null) {
            if (location != null) {
                a = location;
            }
            return a;
        }
        if (location.getTime() > a.getTime()) {
            a = location;
        }
        return a;
    }

    /* renamed from: c */
    private boolean m2655c() {
        return this.f1810d.f1816f > System.currentTimeMillis();
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public boolean mo2338a() {
        C0600a aVar = this.f1810d;
        if (m2655c()) {
            return aVar.f1811a;
        }
        Location b = m2654b();
        if (b != null) {
            m2653a(b);
            return aVar.f1811a;
        }
        Log.i("TwilightManager", "Could not get last known location. This is probably because the app does not have any location permissions. Falling back to hardcoded sunrise/sunset values.");
        int i = Calendar.getInstance().get(11);
        return i < 6 || i >= 22;
    }
}
