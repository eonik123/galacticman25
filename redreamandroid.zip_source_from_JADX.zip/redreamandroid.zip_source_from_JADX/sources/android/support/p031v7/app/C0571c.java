package android.support.p031v7.app;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.support.p018v4.app.C0316a;
import android.support.p018v4.app.C0333f;
import android.support.p018v4.app.C0382t;
import android.support.p018v4.app.C0387y;
import android.support.p018v4.app.C0387y.C0388a;
import android.support.p031v7.view.C0627b;
import android.support.p031v7.view.C0627b.C0628a;
import android.support.p031v7.widget.C0878bs;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup.LayoutParams;
import android.view.Window;

/* renamed from: android.support.v7.app.c */
public class C0571c extends C0333f implements C0388a, C0572d {

    /* renamed from: k */
    private C0573e f1693k;

    /* renamed from: l */
    private int f1694l = 0;

    /* renamed from: m */
    private Resources f1695m;

    /* renamed from: a */
    private boolean m2476a(int i, KeyEvent keyEvent) {
        if (VERSION.SDK_INT < 26 && !keyEvent.isCtrlPressed() && !KeyEvent.metaStateHasNoModifiers(keyEvent.getMetaState()) && keyEvent.getRepeatCount() == 0 && !KeyEvent.isModifierKey(keyEvent.getKeyCode())) {
            Window window = getWindow();
            if (!(window == null || window.getDecorView() == null || !window.getDecorView().dispatchKeyShortcutEvent(keyEvent))) {
                return true;
            }
        }
        return false;
    }

    /* renamed from: a */
    public C0627b mo2211a(C0628a aVar) {
        return null;
    }

    /* renamed from: a */
    public void mo2212a(C0387y yVar) {
        yVar.mo1540a((Activity) this);
    }

    /* renamed from: a */
    public void mo2213a(C0627b bVar) {
    }

    /* renamed from: a */
    public boolean mo2214a(Intent intent) {
        return C0382t.m1707a((Activity) this, intent);
    }

    /* renamed from: a_ */
    public Intent mo1546a_() {
        return C0382t.m1705a(this);
    }

    public void addContentView(View view, LayoutParams layoutParams) {
        mo2227j().mo2248b(view, layoutParams);
    }

    /* renamed from: b */
    public void mo2216b(Intent intent) {
        C0382t.m1710b((Activity) this, intent);
    }

    /* renamed from: b */
    public void mo2217b(C0387y yVar) {
    }

    /* renamed from: b */
    public void mo2218b(C0627b bVar) {
    }

    public void closeOptionsMenu() {
        C0565a g = mo2221g();
        if (!getWindow().hasFeature(0)) {
            return;
        }
        if (g == null || !g.mo2189d()) {
            super.closeOptionsMenu();
        }
    }

    public boolean dispatchKeyEvent(KeyEvent keyEvent) {
        int keyCode = keyEvent.getKeyCode();
        C0565a g = mo2221g();
        if (keyCode != 82 || g == null || !g.mo2183a(keyEvent)) {
            return super.dispatchKeyEvent(keyEvent);
        }
        return true;
    }

    /* renamed from: e */
    public void mo1308e() {
        mo2227j().mo2254f();
    }

    public <T extends View> T findViewById(int i) {
        return mo2227j().mo2239a(i);
    }

    /* renamed from: g */
    public C0565a mo2221g() {
        return mo2227j().mo2238a();
    }

    public MenuInflater getMenuInflater() {
        return mo2227j().mo2245b();
    }

    public Resources getResources() {
        if (this.f1695m == null && C0878bs.m4717a()) {
            this.f1695m = new C0878bs(this, super.getResources());
        }
        return this.f1695m == null ? super.getResources() : this.f1695m;
    }

    /* renamed from: h */
    public boolean mo2224h() {
        Intent a_ = mo1546a_();
        if (a_ == null) {
            return false;
        }
        if (mo2214a(a_)) {
            C0387y a = C0387y.m1718a((Context) this);
            mo2212a(a);
            mo2217b(a);
            a.mo1543a();
            try {
                C0316a.m1286a(this);
            } catch (IllegalStateException unused) {
                finish();
            }
        } else {
            mo2216b(a_);
        }
        return true;
    }

    @Deprecated
    /* renamed from: i */
    public void mo2225i() {
    }

    public void invalidateOptionsMenu() {
        mo2227j().mo2254f();
    }

    /* renamed from: j */
    public C0573e mo2227j() {
        if (this.f1693k == null) {
            this.f1693k = C0573e.m2493a((Activity) this, (C0572d) this);
        }
        return this.f1693k;
    }

    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        mo2227j().mo2240a(configuration);
        if (this.f1695m != null) {
            this.f1695m.updateConfiguration(configuration, super.getResources().getDisplayMetrics());
        }
    }

    public void onContentChanged() {
        mo2225i();
    }

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        C0573e j = mo2227j();
        j.mo2256h();
        j.mo2241a(bundle);
        if (j.mo2257i() && this.f1694l != 0) {
            if (VERSION.SDK_INT >= 23) {
                onApplyThemeResource(getTheme(), this.f1694l, false);
            } else {
                setTheme(this.f1694l);
            }
        }
        super.onCreate(bundle);
    }

    /* access modifiers changed from: protected */
    public void onDestroy() {
        super.onDestroy();
        mo2227j().mo2255g();
    }

    public boolean onKeyDown(int i, KeyEvent keyEvent) {
        if (m2476a(i, keyEvent)) {
            return true;
        }
        return super.onKeyDown(i, keyEvent);
    }

    public final boolean onMenuItemSelected(int i, MenuItem menuItem) {
        if (super.onMenuItemSelected(i, menuItem)) {
            return true;
        }
        C0565a g = mo2221g();
        if (menuItem.getItemId() != 16908332 || g == null || (g.mo2176a() & 4) == 0) {
            return false;
        }
        return mo2224h();
    }

    public boolean onMenuOpened(int i, Menu menu) {
        return super.onMenuOpened(i, menu);
    }

    public void onPanelClosed(int i, Menu menu) {
        super.onPanelClosed(i, menu);
    }

    /* access modifiers changed from: protected */
    public void onPostCreate(Bundle bundle) {
        super.onPostCreate(bundle);
        mo2227j().mo2247b(bundle);
    }

    /* access modifiers changed from: protected */
    public void onPostResume() {
        super.onPostResume();
        mo2227j().mo2253e();
    }

    /* access modifiers changed from: protected */
    public void onSaveInstanceState(Bundle bundle) {
        super.onSaveInstanceState(bundle);
        mo2227j().mo2250c(bundle);
    }

    /* access modifiers changed from: protected */
    public void onStart() {
        super.onStart();
        mo2227j().mo2249c();
    }

    /* access modifiers changed from: protected */
    public void onStop() {
        super.onStop();
        mo2227j().mo2252d();
    }

    /* access modifiers changed from: protected */
    public void onTitleChanged(CharSequence charSequence, int i) {
        super.onTitleChanged(charSequence, i);
        mo2227j().mo2244a(charSequence);
    }

    public void openOptionsMenu() {
        C0565a g = mo2221g();
        if (!getWindow().hasFeature(0)) {
            return;
        }
        if (g == null || !g.mo2187c()) {
            super.openOptionsMenu();
        }
    }

    public void setContentView(int i) {
        mo2227j().mo2246b(i);
    }

    public void setContentView(View view) {
        mo2227j().mo2242a(view);
    }

    public void setContentView(View view, LayoutParams layoutParams) {
        mo2227j().mo2243a(view, layoutParams);
    }

    public void setTheme(int i) {
        super.setTheme(i);
        this.f1694l = i;
    }
}
