package android.support.p031v7.app;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.support.p018v4.p028h.C0481e;
import android.support.p018v4.p028h.C0481e.C0482a;
import android.support.p031v7.p032a.C0540a.C0541a;
import android.support.p031v7.view.C0627b;
import android.support.p031v7.view.C0627b.C0628a;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup.LayoutParams;

/* renamed from: android.support.v7.app.g */
public class C0592g extends Dialog implements C0572d {

    /* renamed from: a */
    private C0573e f1783a;

    /* renamed from: b */
    private final C0482a f1784b = new C0482a() {
        /* renamed from: a */
        public boolean mo1537a(KeyEvent keyEvent) {
            return C0592g.this.mo2327a(keyEvent);
        }
    };

    public C0592g(Context context, int i) {
        super(context, m2615a(context, i));
        mo2325a().mo2241a((Bundle) null);
        mo2325a().mo2257i();
    }

    /* renamed from: a */
    private static int m2615a(Context context, int i) {
        if (i != 0) {
            return i;
        }
        TypedValue typedValue = new TypedValue();
        context.getTheme().resolveAttribute(C0541a.dialogTheme, typedValue, true);
        return typedValue.resourceId;
    }

    /* renamed from: a */
    public C0573e mo2325a() {
        if (this.f1783a == null) {
            this.f1783a = C0573e.m2494a((Dialog) this, (C0572d) this);
        }
        return this.f1783a;
    }

    /* renamed from: a */
    public C0627b mo2211a(C0628a aVar) {
        return null;
    }

    /* renamed from: a */
    public void mo2213a(C0627b bVar) {
    }

    /* renamed from: a */
    public boolean mo2326a(int i) {
        return mo2325a().mo2251c(i);
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public boolean mo2327a(KeyEvent keyEvent) {
        return super.dispatchKeyEvent(keyEvent);
    }

    public void addContentView(View view, LayoutParams layoutParams) {
        mo2325a().mo2248b(view, layoutParams);
    }

    /* renamed from: b */
    public void mo2218b(C0627b bVar) {
    }

    public boolean dispatchKeyEvent(KeyEvent keyEvent) {
        return C0481e.m2076a(this.f1784b, getWindow().getDecorView(), this, keyEvent);
    }

    public <T extends View> T findViewById(int i) {
        return mo2325a().mo2239a(i);
    }

    public void invalidateOptionsMenu() {
        mo2325a().mo2254f();
    }

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        mo2325a().mo2256h();
        super.onCreate(bundle);
        mo2325a().mo2241a(bundle);
    }

    /* access modifiers changed from: protected */
    public void onStop() {
        super.onStop();
        mo2325a().mo2252d();
    }

    public void setContentView(int i) {
        mo2325a().mo2246b(i);
    }

    public void setContentView(View view) {
        mo2325a().mo2242a(view);
    }

    public void setContentView(View view, LayoutParams layoutParams) {
        mo2325a().mo2243a(view, layoutParams);
    }

    public void setTitle(int i) {
        super.setTitle(i);
        mo2325a().mo2244a((CharSequence) getContext().getString(i));
    }

    public void setTitle(CharSequence charSequence) {
        super.setTitle(charSequence);
        mo2325a().mo2244a(charSequence);
    }
}
