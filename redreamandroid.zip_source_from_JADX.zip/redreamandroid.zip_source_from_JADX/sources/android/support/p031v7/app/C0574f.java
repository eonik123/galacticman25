package android.support.p031v7.app;

import android.app.Activity;
import android.app.UiModeManager;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager.NameNotFoundException;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.Resources.NotFoundException;
import android.content.res.Resources.Theme;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.support.p018v4.app.C0382t;
import android.support.p018v4.p028h.C0481e;
import android.support.p018v4.p028h.C0481e.C0482a;
import android.support.p018v4.p028h.C0483f;
import android.support.p018v4.p028h.C0493p;
import android.support.p018v4.p028h.C0495r;
import android.support.p018v4.p028h.C0502v;
import android.support.p018v4.p028h.C0506w;
import android.support.p018v4.p028h.C0507x;
import android.support.p018v4.p028h.C0509z;
import android.support.p031v7.p032a.C0540a.C0541a;
import android.support.p031v7.p032a.C0540a.C0543c;
import android.support.p031v7.p032a.C0540a.C0546f;
import android.support.p031v7.p032a.C0540a.C0547g;
import android.support.p031v7.p032a.C0540a.C0549i;
import android.support.p031v7.p032a.C0540a.C0550j;
import android.support.p031v7.p033b.p034a.C0606a;
import android.support.p031v7.view.C0627b;
import android.support.p031v7.view.C0627b.C0628a;
import android.support.p031v7.view.C0630d;
import android.support.p031v7.view.C0632f.C0633a;
import android.support.p031v7.view.C0634g;
import android.support.p031v7.view.C0639i;
import android.support.p031v7.view.menu.C0652f;
import android.support.p031v7.view.menu.C0655h;
import android.support.p031v7.view.menu.C0655h.C0656a;
import android.support.p031v7.view.menu.C0671o;
import android.support.p031v7.view.menu.C0671o.C0672a;
import android.support.p031v7.view.menu.C0673p;
import android.support.p031v7.widget.ActionBarContextView;
import android.support.p031v7.widget.C0755ai;
import android.support.p031v7.widget.C0777ao;
import android.support.p031v7.widget.C0777ao.C0778a;
import android.support.p031v7.widget.C0869bn;
import android.support.p031v7.widget.C0878bs;
import android.support.p031v7.widget.C0885bv;
import android.support.p031v7.widget.C0909k;
import android.support.p031v7.widget.ContentFrameLayout;
import android.support.p031v7.widget.ContentFrameLayout.C0696a;
import android.text.TextUtils;
import android.util.AndroidRuntimeException;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.Log;
import android.util.TypedValue;
import android.view.ActionMode;
import android.view.KeyCharacterMap;
import android.view.KeyEvent;
import android.view.KeyboardShortcutGroup;
import android.view.LayoutInflater;
import android.view.LayoutInflater.Factory2;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewGroup.MarginLayoutParams;
import android.view.ViewParent;
import android.view.Window;
import android.view.Window.Callback;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.PopupWindow;
import android.widget.TextView;
import java.lang.Thread.UncaughtExceptionHandler;
import java.util.List;
import org.xmlpull.v1.XmlPullParser;

/* renamed from: android.support.v7.app.f */
class C0574f extends C0573e implements C0656a, Factory2 {

    /* renamed from: u */
    private static final boolean f1697u = (VERSION.SDK_INT < 21);

    /* renamed from: v */
    private static final int[] f1698v = {16842836};

    /* renamed from: w */
    private static boolean f1699w = true;

    /* renamed from: A */
    private C0591g f1700A;

    /* renamed from: B */
    private boolean f1701B = true;

    /* renamed from: C */
    private boolean f1702C;

    /* renamed from: D */
    private ViewGroup f1703D;

    /* renamed from: E */
    private TextView f1704E;

    /* renamed from: F */
    private View f1705F;

    /* renamed from: G */
    private boolean f1706G;

    /* renamed from: H */
    private boolean f1707H;

    /* renamed from: I */
    private boolean f1708I;

    /* renamed from: J */
    private C0590f[] f1709J;

    /* renamed from: K */
    private C0590f f1710K;

    /* renamed from: L */
    private boolean f1711L;

    /* renamed from: M */
    private int f1712M = -100;

    /* renamed from: N */
    private boolean f1713N;

    /* renamed from: O */
    private C0587d f1714O;

    /* renamed from: P */
    private final Runnable f1715P = new Runnable() {
        public void run() {
            if ((C0574f.this.f1739t & 1) != 0) {
                C0574f.this.mo2276g(0);
            }
            if ((C0574f.this.f1739t & 4096) != 0) {
                C0574f.this.mo2276g(108);
            }
            C0574f.this.f1738s = false;
            C0574f.this.f1739t = 0;
        }
    };

    /* renamed from: Q */
    private boolean f1716Q;

    /* renamed from: R */
    private Rect f1717R;

    /* renamed from: S */
    private Rect f1718S;

    /* renamed from: T */
    private AppCompatViewInflater f1719T;

    /* renamed from: a */
    final Context f1720a;

    /* renamed from: b */
    final Window f1721b;

    /* renamed from: c */
    final Callback f1722c;

    /* renamed from: d */
    final Callback f1723d;

    /* renamed from: e */
    final C0572d f1724e;

    /* renamed from: f */
    C0565a f1725f;

    /* renamed from: g */
    MenuInflater f1726g;

    /* renamed from: h */
    C0627b f1727h;

    /* renamed from: i */
    ActionBarContextView f1728i;

    /* renamed from: j */
    PopupWindow f1729j;

    /* renamed from: k */
    Runnable f1730k;

    /* renamed from: l */
    C0502v f1731l = null;

    /* renamed from: m */
    boolean f1732m;

    /* renamed from: n */
    boolean f1733n;

    /* renamed from: o */
    boolean f1734o;

    /* renamed from: p */
    boolean f1735p;

    /* renamed from: q */
    boolean f1736q;

    /* renamed from: r */
    boolean f1737r;

    /* renamed from: s */
    boolean f1738s;

    /* renamed from: t */
    int f1739t;

    /* renamed from: x */
    private CharSequence f1740x;

    /* renamed from: y */
    private C0755ai f1741y;

    /* renamed from: z */
    private C0583a f1742z;

    /* renamed from: android.support.v7.app.f$a */
    private final class C0583a implements C0672a {
        C0583a() {
        }

        /* renamed from: a */
        public void mo2296a(C0655h hVar, boolean z) {
            C0574f.this.mo2270b(hVar);
        }

        /* renamed from: a */
        public boolean mo2297a(C0655h hVar) {
            Callback l = C0574f.this.mo2280l();
            if (l != null) {
                l.onMenuOpened(108, hVar);
            }
            return true;
        }
    }

    /* renamed from: android.support.v7.app.f$b */
    class C0584b implements C0628a {

        /* renamed from: b */
        private C0628a f1753b;

        public C0584b(C0628a aVar) {
            this.f1753b = aVar;
        }

        /* renamed from: a */
        public void mo2298a(C0627b bVar) {
            this.f1753b.mo2298a(bVar);
            if (C0574f.this.f1729j != null) {
                C0574f.this.f1721b.getDecorView().removeCallbacks(C0574f.this.f1730k);
            }
            if (C0574f.this.f1728i != null) {
                C0574f.this.mo2287q();
                C0574f.this.f1731l = C0495r.m2156k(C0574f.this.f1728i).mo1953a(0.0f);
                C0574f.this.f1731l.mo1955a((C0506w) new C0507x() {
                    /* renamed from: b */
                    public void mo1967b(View view) {
                        C0574f.this.f1728i.setVisibility(8);
                        if (C0574f.this.f1729j != null) {
                            C0574f.this.f1729j.dismiss();
                        } else if (C0574f.this.f1728i.getParent() instanceof View) {
                            C0495r.m2160o((View) C0574f.this.f1728i.getParent());
                        }
                        C0574f.this.f1728i.removeAllViews();
                        C0574f.this.f1731l.mo1955a((C0506w) null);
                        C0574f.this.f1731l = null;
                    }
                });
            }
            if (C0574f.this.f1724e != null) {
                C0574f.this.f1724e.mo2218b(C0574f.this.f1727h);
            }
            C0574f.this.f1727h = null;
        }

        /* renamed from: a */
        public boolean mo2299a(C0627b bVar, Menu menu) {
            return this.f1753b.mo2299a(bVar, menu);
        }

        /* renamed from: a */
        public boolean mo2300a(C0627b bVar, MenuItem menuItem) {
            return this.f1753b.mo2300a(bVar, menuItem);
        }

        /* renamed from: b */
        public boolean mo2301b(C0627b bVar, Menu menu) {
            return this.f1753b.mo2301b(bVar, menu);
        }
    }

    /* renamed from: android.support.v7.app.f$c */
    class C0586c extends C0639i {
        C0586c(Callback callback) {
            super(callback);
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public final ActionMode mo2302a(ActionMode.Callback callback) {
            C0633a aVar = new C0633a(C0574f.this.f1720a, callback);
            C0627b a = C0574f.this.mo2260a((C0628a) aVar);
            if (a != null) {
                return aVar.mo2528b(a);
            }
            return null;
        }

        public boolean dispatchKeyEvent(KeyEvent keyEvent) {
            return C0574f.this.mo2268a(keyEvent) || super.dispatchKeyEvent(keyEvent);
        }

        public boolean dispatchKeyShortcutEvent(KeyEvent keyEvent) {
            return super.dispatchKeyShortcutEvent(keyEvent) || C0574f.this.mo2266a(keyEvent.getKeyCode(), keyEvent);
        }

        public void onContentChanged() {
        }

        public boolean onCreatePanelMenu(int i, Menu menu) {
            if (i != 0 || (menu instanceof C0655h)) {
                return super.onCreatePanelMenu(i, menu);
            }
            return false;
        }

        public boolean onMenuOpened(int i, Menu menu) {
            super.onMenuOpened(i, menu);
            C0574f.this.mo2274e(i);
            return true;
        }

        public void onPanelClosed(int i, Menu menu) {
            super.onPanelClosed(i, menu);
            C0574f.this.mo2273d(i);
        }

        public boolean onPreparePanel(int i, View view, Menu menu) {
            C0655h hVar = menu instanceof C0655h ? (C0655h) menu : null;
            if (i == 0 && hVar == null) {
                return false;
            }
            if (hVar != null) {
                hVar.mo2731c(true);
            }
            boolean onPreparePanel = super.onPreparePanel(i, view, menu);
            if (hVar != null) {
                hVar.mo2731c(false);
            }
            return onPreparePanel;
        }

        public void onProvideKeyboardShortcuts(List<KeyboardShortcutGroup> list, Menu menu, int i) {
            C0590f a = C0574f.this.mo2258a(0, true);
            if (!(a == null || a.f1772j == null)) {
                menu = a.f1772j;
            }
            super.onProvideKeyboardShortcuts(list, menu, i);
        }

        public ActionMode onWindowStartingActionMode(ActionMode.Callback callback) {
            if (VERSION.SDK_INT >= 23) {
                return null;
            }
            return C0574f.this.mo2286p() ? mo2302a(callback) : super.onWindowStartingActionMode(callback);
        }

        public ActionMode onWindowStartingActionMode(ActionMode.Callback callback, int i) {
            return (!C0574f.this.mo2286p() || i != 0) ? super.onWindowStartingActionMode(callback, i) : mo2302a(callback);
        }
    }

    /* renamed from: android.support.v7.app.f$d */
    final class C0587d {

        /* renamed from: b */
        private C0599k f1757b;

        /* renamed from: c */
        private boolean f1758c;

        /* renamed from: d */
        private BroadcastReceiver f1759d;

        /* renamed from: e */
        private IntentFilter f1760e;

        C0587d(C0599k kVar) {
            this.f1757b = kVar;
            this.f1758c = kVar.mo2338a();
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public int mo2313a() {
            this.f1758c = this.f1757b.mo2338a();
            return this.f1758c ? 2 : 1;
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: b */
        public void mo2314b() {
            boolean a = this.f1757b.mo2338a();
            if (a != this.f1758c) {
                this.f1758c = a;
                C0574f.this.mo2257i();
            }
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: c */
        public void mo2315c() {
            mo2316d();
            if (this.f1759d == null) {
                this.f1759d = new BroadcastReceiver() {
                    public void onReceive(Context context, Intent intent) {
                        C0587d.this.mo2314b();
                    }
                };
            }
            if (this.f1760e == null) {
                this.f1760e = new IntentFilter();
                this.f1760e.addAction("android.intent.action.TIME_SET");
                this.f1760e.addAction("android.intent.action.TIMEZONE_CHANGED");
                this.f1760e.addAction("android.intent.action.TIME_TICK");
            }
            C0574f.this.f1720a.registerReceiver(this.f1759d, this.f1760e);
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: d */
        public void mo2316d() {
            if (this.f1759d != null) {
                C0574f.this.f1720a.unregisterReceiver(this.f1759d);
                this.f1759d = null;
            }
        }
    }

    /* renamed from: android.support.v7.app.f$e */
    private class C0589e extends ContentFrameLayout {
        public C0589e(Context context) {
            super(context);
        }

        /* renamed from: a */
        private boolean m2608a(int i, int i2) {
            return i < -5 || i2 < -5 || i > getWidth() + 5 || i2 > getHeight() + 5;
        }

        public boolean dispatchKeyEvent(KeyEvent keyEvent) {
            return C0574f.this.mo2268a(keyEvent) || super.dispatchKeyEvent(keyEvent);
        }

        public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
            if (motionEvent.getAction() != 0 || !m2608a((int) motionEvent.getX(), (int) motionEvent.getY())) {
                return super.onInterceptTouchEvent(motionEvent);
            }
            C0574f.this.mo2275f(0);
            return true;
        }

        public void setBackgroundResource(int i) {
            setBackgroundDrawable(C0606a.m2714b(getContext(), i));
        }
    }

    /* renamed from: android.support.v7.app.f$f */
    protected static final class C0590f {

        /* renamed from: a */
        int f1763a;

        /* renamed from: b */
        int f1764b;

        /* renamed from: c */
        int f1765c;

        /* renamed from: d */
        int f1766d;

        /* renamed from: e */
        int f1767e;

        /* renamed from: f */
        int f1768f;

        /* renamed from: g */
        ViewGroup f1769g;

        /* renamed from: h */
        View f1770h;

        /* renamed from: i */
        View f1771i;

        /* renamed from: j */
        C0655h f1772j;

        /* renamed from: k */
        C0652f f1773k;

        /* renamed from: l */
        Context f1774l;

        /* renamed from: m */
        boolean f1775m;

        /* renamed from: n */
        boolean f1776n;

        /* renamed from: o */
        boolean f1777o;

        /* renamed from: p */
        public boolean f1778p;

        /* renamed from: q */
        boolean f1779q = false;

        /* renamed from: r */
        boolean f1780r;

        /* renamed from: s */
        Bundle f1781s;

        C0590f(int i) {
            this.f1763a = i;
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public C0673p mo2321a(C0672a aVar) {
            if (this.f1772j == null) {
                return null;
            }
            if (this.f1773k == null) {
                this.f1773k = new C0652f(this.f1774l, C0547g.abc_list_menu_item_layout);
                this.f1773k.mo2640a(aVar);
                this.f1772j.mo2707a((C0671o) this.f1773k);
            }
            return this.f1773k.mo2677a(this.f1769g);
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public void mo2322a(Context context) {
            TypedValue typedValue = new TypedValue();
            Theme newTheme = context.getResources().newTheme();
            newTheme.setTo(context.getTheme());
            newTheme.resolveAttribute(C0541a.actionBarPopupTheme, typedValue, true);
            if (typedValue.resourceId != 0) {
                newTheme.applyStyle(typedValue.resourceId, true);
            }
            newTheme.resolveAttribute(C0541a.panelMenuListTheme, typedValue, true);
            newTheme.applyStyle(typedValue.resourceId != 0 ? typedValue.resourceId : C0549i.Theme_AppCompat_CompactMenu, true);
            C0630d dVar = new C0630d(context, 0);
            dVar.getTheme().setTo(newTheme);
            this.f1774l = dVar;
            TypedArray obtainStyledAttributes = dVar.obtainStyledAttributes(C0550j.AppCompatTheme);
            this.f1764b = obtainStyledAttributes.getResourceId(C0550j.AppCompatTheme_panelBackground, 0);
            this.f1768f = obtainStyledAttributes.getResourceId(C0550j.AppCompatTheme_android_windowAnimationStyle, 0);
            obtainStyledAttributes.recycle();
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public void mo2323a(C0655h hVar) {
            if (hVar != this.f1772j) {
                if (this.f1772j != null) {
                    this.f1772j.mo2727b((C0671o) this.f1773k);
                }
                this.f1772j = hVar;
                if (!(hVar == null || this.f1773k == null)) {
                    hVar.mo2707a((C0671o) this.f1773k);
                }
            }
        }

        /* renamed from: a */
        public boolean mo2324a() {
            boolean z = false;
            if (this.f1770h == null) {
                return false;
            }
            if (this.f1771i != null) {
                return true;
            }
            if (this.f1773k.mo2678a().getCount() > 0) {
                z = true;
            }
            return z;
        }
    }

    /* renamed from: android.support.v7.app.f$g */
    private final class C0591g implements C0672a {
        C0591g() {
        }

        /* renamed from: a */
        public void mo2296a(C0655h hVar, boolean z) {
            C0655h q = hVar.mo2759q();
            boolean z2 = q != hVar;
            C0574f fVar = C0574f.this;
            if (z2) {
                hVar = q;
            }
            C0590f a = fVar.mo2259a((Menu) hVar);
            if (a != null) {
                if (z2) {
                    C0574f.this.mo2262a(a.f1763a, a, q);
                    C0574f.this.mo2263a(a, true);
                    return;
                }
                C0574f.this.mo2263a(a, z);
            }
        }

        /* renamed from: a */
        public boolean mo2297a(C0655h hVar) {
            if (hVar == null && C0574f.this.f1732m) {
                Callback l = C0574f.this.mo2280l();
                if (l != null && !C0574f.this.f1737r) {
                    l.onMenuOpened(108, hVar);
                }
            }
            return true;
        }
    }

    static {
        if (f1697u && !f1699w) {
            final UncaughtExceptionHandler defaultUncaughtExceptionHandler = Thread.getDefaultUncaughtExceptionHandler();
            Thread.setDefaultUncaughtExceptionHandler(new UncaughtExceptionHandler() {
                /* renamed from: a */
                private boolean m2587a(Throwable th) {
                    if (!(th instanceof NotFoundException)) {
                        return false;
                    }
                    String message = th.getMessage();
                    if (message != null) {
                        return message.contains("drawable") || message.contains("Drawable");
                    }
                    return false;
                }

                public void uncaughtException(Thread thread, Throwable th) {
                    if (m2587a(th)) {
                        StringBuilder sb = new StringBuilder();
                        sb.append(th.getMessage());
                        sb.append(". If the resource you are trying to use is a vector resource, you may be referencing it in an unsupported way. See AppCompatDelegate.setCompatVectorFromResourcesEnabled() for more info.");
                        NotFoundException notFoundException = new NotFoundException(sb.toString());
                        notFoundException.initCause(th.getCause());
                        notFoundException.setStackTrace(th.getStackTrace());
                        defaultUncaughtExceptionHandler.uncaughtException(thread, notFoundException);
                        return;
                    }
                    defaultUncaughtExceptionHandler.uncaughtException(thread, th);
                }
            });
        }
    }

    C0574f(Context context, Window window, C0572d dVar) {
        this.f1720a = context;
        this.f1721b = window;
        this.f1724e = dVar;
        this.f1722c = this.f1721b.getCallback();
        if (this.f1722c instanceof C0586c) {
            throw new IllegalStateException("AppCompat has already installed itself into the Window");
        }
        this.f1723d = new C0586c(this.f1722c);
        this.f1721b.setCallback(this.f1723d);
        C0869bn a = C0869bn.m4637a(context, (AttributeSet) null, f1698v);
        Drawable b = a.mo4430b(0);
        if (b != null) {
            this.f1721b.setBackgroundDrawable(b);
        }
        a.mo4427a();
    }

    /* renamed from: A */
    private boolean m2516A() {
        boolean z = false;
        if (!this.f1713N || !(this.f1720a instanceof Activity)) {
            return false;
        }
        try {
            if ((this.f1720a.getPackageManager().getActivityInfo(new ComponentName(this.f1720a, this.f1720a.getClass()), 0).configChanges & 512) == 0) {
                z = true;
            }
            return z;
        } catch (NameNotFoundException e) {
            Log.d("AppCompatDelegate", "Exception while getting ActivityInfo", e);
            return true;
        }
    }

    /* renamed from: a */
    private void m2517a(C0590f fVar, KeyEvent keyEvent) {
        int i;
        if (!fVar.f1777o && !this.f1737r) {
            if (fVar.f1763a == 0) {
                if ((this.f1720a.getResources().getConfiguration().screenLayout & 15) == 4) {
                    return;
                }
            }
            Callback l = mo2280l();
            if (l == null || l.onMenuOpened(fVar.f1763a, fVar.f1772j)) {
                WindowManager windowManager = (WindowManager) this.f1720a.getSystemService("window");
                if (windowManager != null && m2523b(fVar, keyEvent)) {
                    if (fVar.f1769g == null || fVar.f1779q) {
                        if (fVar.f1769g == null) {
                            if (!m2519a(fVar) || fVar.f1769g == null) {
                                return;
                            }
                        } else if (fVar.f1779q && fVar.f1769g.getChildCount() > 0) {
                            fVar.f1769g.removeAllViews();
                        }
                        if (m2524c(fVar) && fVar.mo2324a()) {
                            LayoutParams layoutParams = fVar.f1770h.getLayoutParams();
                            if (layoutParams == null) {
                                layoutParams = new LayoutParams(-2, -2);
                            }
                            fVar.f1769g.setBackgroundResource(fVar.f1764b);
                            ViewParent parent = fVar.f1770h.getParent();
                            if (parent != null && (parent instanceof ViewGroup)) {
                                ((ViewGroup) parent).removeView(fVar.f1770h);
                            }
                            fVar.f1769g.addView(fVar.f1770h, layoutParams);
                            if (!fVar.f1770h.hasFocus()) {
                                fVar.f1770h.requestFocus();
                            }
                        } else {
                            return;
                        }
                    } else if (fVar.f1771i != null) {
                        LayoutParams layoutParams2 = fVar.f1771i.getLayoutParams();
                        if (layoutParams2 != null && layoutParams2.width == -1) {
                            i = -1;
                            fVar.f1776n = false;
                            WindowManager.LayoutParams layoutParams3 = new WindowManager.LayoutParams(i, -2, fVar.f1766d, fVar.f1767e, 1002, 8519680, -3);
                            layoutParams3.gravity = fVar.f1765c;
                            layoutParams3.windowAnimations = fVar.f1768f;
                            windowManager.addView(fVar.f1769g, layoutParams3);
                            fVar.f1777o = true;
                            return;
                        }
                    }
                    i = -2;
                    fVar.f1776n = false;
                    WindowManager.LayoutParams layoutParams32 = new WindowManager.LayoutParams(i, -2, fVar.f1766d, fVar.f1767e, 1002, 8519680, -3);
                    layoutParams32.gravity = fVar.f1765c;
                    layoutParams32.windowAnimations = fVar.f1768f;
                    windowManager.addView(fVar.f1769g, layoutParams32);
                    fVar.f1777o = true;
                    return;
                }
                return;
            }
            mo2263a(fVar, true);
        }
    }

    /* renamed from: a */
    private void m2518a(C0655h hVar, boolean z) {
        if (this.f1741y == null || !this.f1741y.mo3013e() || (ViewConfiguration.get(this.f1720a).hasPermanentMenuKey() && !this.f1741y.mo3016g())) {
            C0590f a = mo2258a(0, true);
            a.f1779q = true;
            mo2263a(a, false);
            m2517a(a, (KeyEvent) null);
            return;
        }
        Callback l = mo2280l();
        if (this.f1741y.mo3014f() && z) {
            this.f1741y.mo3024i();
            if (!this.f1737r) {
                l.onPanelClosed(108, mo2258a(0, true).f1772j);
            }
        } else if (l != null && !this.f1737r) {
            if (this.f1738s && (this.f1739t & 1) != 0) {
                this.f1721b.getDecorView().removeCallbacks(this.f1715P);
                this.f1715P.run();
            }
            C0590f a2 = mo2258a(0, true);
            if (a2.f1772j != null && !a2.f1780r && l.onPreparePanel(0, a2.f1771i, a2.f1772j)) {
                l.onMenuOpened(108, a2.f1772j);
                this.f1741y.mo3023h();
            }
        }
    }

    /* renamed from: a */
    private boolean m2519a(C0590f fVar) {
        fVar.mo2322a(mo2281m());
        fVar.f1769g = new C0589e(fVar.f1774l);
        fVar.f1765c = 81;
        return true;
    }

    /* renamed from: a */
    private boolean m2520a(C0590f fVar, int i, KeyEvent keyEvent, int i2) {
        boolean z = false;
        if (keyEvent.isSystem()) {
            return false;
        }
        if ((fVar.f1775m || m2523b(fVar, keyEvent)) && fVar.f1772j != null) {
            z = fVar.f1772j.performShortcut(i, keyEvent, i2);
        }
        if (z && (i2 & 1) == 0 && this.f1741y == null) {
            mo2263a(fVar, true);
        }
        return z;
    }

    /* renamed from: a */
    private boolean m2521a(ViewParent viewParent) {
        if (viewParent == null) {
            return false;
        }
        View decorView = this.f1721b.getDecorView();
        while (viewParent != null) {
            if (viewParent == decorView || !(viewParent instanceof View) || C0495r.m2171z((View) viewParent)) {
                return false;
            }
            viewParent = viewParent.getParent();
        }
        return true;
    }

    /* renamed from: b */
    private boolean m2522b(C0590f fVar) {
        Context context = this.f1720a;
        if ((fVar.f1763a == 0 || fVar.f1763a == 108) && this.f1741y != null) {
            TypedValue typedValue = new TypedValue();
            Theme theme = context.getTheme();
            theme.resolveAttribute(C0541a.actionBarTheme, typedValue, true);
            Theme theme2 = null;
            if (typedValue.resourceId != 0) {
                theme2 = context.getResources().newTheme();
                theme2.setTo(theme);
                theme2.applyStyle(typedValue.resourceId, true);
                theme2.resolveAttribute(C0541a.actionBarWidgetTheme, typedValue, true);
            } else {
                theme.resolveAttribute(C0541a.actionBarWidgetTheme, typedValue, true);
            }
            if (typedValue.resourceId != 0) {
                if (theme2 == null) {
                    theme2 = context.getResources().newTheme();
                    theme2.setTo(theme);
                }
                theme2.applyStyle(typedValue.resourceId, true);
            }
            if (theme2 != null) {
                Context dVar = new C0630d(context, 0);
                dVar.getTheme().setTo(theme2);
                context = dVar;
            }
        }
        C0655h hVar = new C0655h(context);
        hVar.mo2705a((C0656a) this);
        fVar.mo2323a(hVar);
        return true;
    }

    /* renamed from: b */
    private boolean m2523b(C0590f fVar, KeyEvent keyEvent) {
        if (this.f1737r) {
            return false;
        }
        if (fVar.f1775m) {
            return true;
        }
        if (!(this.f1710K == null || this.f1710K == fVar)) {
            mo2263a(this.f1710K, false);
        }
        Callback l = mo2280l();
        if (l != null) {
            fVar.f1771i = l.onCreatePanelView(fVar.f1763a);
        }
        boolean z = fVar.f1763a == 0 || fVar.f1763a == 108;
        if (z && this.f1741y != null) {
            this.f1741y.mo3025j();
        }
        if (fVar.f1771i == null && (!z || !(mo2279k() instanceof C0595i))) {
            if (fVar.f1772j == null || fVar.f1780r) {
                if (fVar.f1772j == null && (!m2522b(fVar) || fVar.f1772j == null)) {
                    return false;
                }
                if (z && this.f1741y != null) {
                    if (this.f1742z == null) {
                        this.f1742z = new C0583a();
                    }
                    this.f1741y.mo3006a(fVar.f1772j, this.f1742z);
                }
                fVar.f1772j.mo2746h();
                if (!l.onCreatePanelMenu(fVar.f1763a, fVar.f1772j)) {
                    fVar.mo2323a((C0655h) null);
                    if (z && this.f1741y != null) {
                        this.f1741y.mo3006a(null, this.f1742z);
                    }
                    return false;
                }
                fVar.f1780r = false;
            }
            fVar.f1772j.mo2746h();
            if (fVar.f1781s != null) {
                fVar.f1772j.mo2725b(fVar.f1781s);
                fVar.f1781s = null;
            }
            if (!l.onPreparePanel(0, fVar.f1771i, fVar.f1772j)) {
                if (z && this.f1741y != null) {
                    this.f1741y.mo3006a(null, this.f1742z);
                }
                fVar.f1772j.mo2748i();
                return false;
            }
            fVar.f1778p = KeyCharacterMap.load(keyEvent != null ? keyEvent.getDeviceId() : -1).getKeyboardType() != 1;
            fVar.f1772j.setQwertyMode(fVar.f1778p);
            fVar.f1772j.mo2748i();
        }
        fVar.f1775m = true;
        fVar.f1776n = false;
        this.f1710K = fVar;
        return true;
    }

    /* renamed from: c */
    private boolean m2524c(C0590f fVar) {
        if (fVar.f1771i != null) {
            fVar.f1770h = fVar.f1771i;
            return true;
        } else if (fVar.f1772j == null) {
            return false;
        } else {
            if (this.f1700A == null) {
                this.f1700A = new C0591g();
            }
            fVar.f1770h = (View) fVar.mo2321a((C0672a) this.f1700A);
            return fVar.f1770h != null;
        }
    }

    /* renamed from: d */
    private boolean m2525d(int i, KeyEvent keyEvent) {
        if (keyEvent.getRepeatCount() == 0) {
            C0590f a = mo2258a(i, true);
            if (!a.f1777o) {
                return m2523b(a, keyEvent);
            }
        }
        return false;
    }

    /* JADX WARNING: Removed duplicated region for block: B:34:0x006e  */
    /* renamed from: e */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private boolean m2526e(int r4, android.view.KeyEvent r5) {
        /*
            r3 = this;
            android.support.v7.view.b r0 = r3.f1727h
            r1 = 0
            if (r0 == 0) goto L_0x0006
            return r1
        L_0x0006:
            r0 = 1
            android.support.v7.app.f$f r2 = r3.mo2258a(r4, r0)
            if (r4 != 0) goto L_0x0045
            android.support.v7.widget.ai r4 = r3.f1741y
            if (r4 == 0) goto L_0x0045
            android.support.v7.widget.ai r4 = r3.f1741y
            boolean r4 = r4.mo3013e()
            if (r4 == 0) goto L_0x0045
            android.content.Context r4 = r3.f1720a
            android.view.ViewConfiguration r4 = android.view.ViewConfiguration.get(r4)
            boolean r4 = r4.hasPermanentMenuKey()
            if (r4 != 0) goto L_0x0045
            android.support.v7.widget.ai r4 = r3.f1741y
            boolean r4 = r4.mo3014f()
            if (r4 != 0) goto L_0x003e
            boolean r4 = r3.f1737r
            if (r4 != 0) goto L_0x0065
            boolean r4 = r3.m2523b(r2, r5)
            if (r4 == 0) goto L_0x0065
            android.support.v7.widget.ai r4 = r3.f1741y
            boolean r4 = r4.mo3023h()
            goto L_0x006c
        L_0x003e:
            android.support.v7.widget.ai r4 = r3.f1741y
            boolean r4 = r4.mo3024i()
            goto L_0x006c
        L_0x0045:
            boolean r4 = r2.f1777o
            if (r4 != 0) goto L_0x0067
            boolean r4 = r2.f1776n
            if (r4 == 0) goto L_0x004e
            goto L_0x0067
        L_0x004e:
            boolean r4 = r2.f1775m
            if (r4 == 0) goto L_0x0065
            boolean r4 = r2.f1780r
            if (r4 == 0) goto L_0x005d
            r2.f1775m = r1
            boolean r4 = r3.m2523b(r2, r5)
            goto L_0x005e
        L_0x005d:
            r4 = r0
        L_0x005e:
            if (r4 == 0) goto L_0x0065
            r3.m2517a(r2, r5)
            r4 = r0
            goto L_0x006c
        L_0x0065:
            r4 = r1
            goto L_0x006c
        L_0x0067:
            boolean r4 = r2.f1777o
            r3.mo2263a(r2, r0)
        L_0x006c:
            if (r4 == 0) goto L_0x0085
            android.content.Context r5 = r3.f1720a
            java.lang.String r0 = "audio"
            java.lang.Object r5 = r5.getSystemService(r0)
            android.media.AudioManager r5 = (android.media.AudioManager) r5
            if (r5 == 0) goto L_0x007e
            r5.playSoundEffect(r1)
            return r4
        L_0x007e:
            java.lang.String r5 = "AppCompatDelegate"
            java.lang.String r0 = "Couldn't get audio manager"
            android.util.Log.w(r5, r0)
        L_0x0085:
            return r4
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.p031v7.app.C0574f.m2526e(int, android.view.KeyEvent):boolean");
    }

    /* renamed from: j */
    private void m2527j(int i) {
        this.f1739t = (1 << i) | this.f1739t;
        if (!this.f1738s) {
            C0495r.m2134a(this.f1721b.getDecorView(), this.f1715P);
            this.f1738s = true;
        }
    }

    /* renamed from: k */
    private int m2528k(int i) {
        if (i == 8) {
            Log.i("AppCompatDelegate", "You should now use the AppCompatDelegate.FEATURE_SUPPORT_ACTION_BAR id when requesting this feature.");
            return 108;
        }
        if (i == 9) {
            Log.i("AppCompatDelegate", "You should now use the AppCompatDelegate.FEATURE_SUPPORT_ACTION_BAR_OVERLAY id when requesting this feature.");
            i = 109;
        }
        return i;
    }

    /* renamed from: l */
    private boolean m2529l(int i) {
        Resources resources = this.f1720a.getResources();
        Configuration configuration = resources.getConfiguration();
        int i2 = configuration.uiMode & 48;
        int i3 = i == 2 ? 32 : 16;
        if (i2 == i3) {
            return false;
        }
        if (m2516A()) {
            ((Activity) this.f1720a).recreate();
        } else {
            Configuration configuration2 = new Configuration(configuration);
            DisplayMetrics displayMetrics = resources.getDisplayMetrics();
            configuration2.uiMode = i3 | (configuration2.uiMode & -49);
            resources.updateConfiguration(configuration2, displayMetrics);
            if (VERSION.SDK_INT < 26) {
                C0594h.m2623a(resources);
            }
        }
        return true;
    }

    /* JADX WARNING: Removed duplicated region for block: B:14:0x0034  */
    /* renamed from: t */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private void m2530t() {
        /*
            r3 = this;
            r3.m2531u()
            boolean r0 = r3.f1732m
            if (r0 == 0) goto L_0x003b
            android.support.v7.app.a r0 = r3.f1725f
            if (r0 == 0) goto L_0x000c
            return
        L_0x000c:
            android.view.Window$Callback r0 = r3.f1722c
            boolean r0 = r0 instanceof android.app.Activity
            if (r0 == 0) goto L_0x0020
            android.support.v7.app.l r0 = new android.support.v7.app.l
            android.view.Window$Callback r1 = r3.f1722c
            android.app.Activity r1 = (android.app.Activity) r1
            boolean r2 = r3.f1733n
            r0.<init>(r1, r2)
        L_0x001d:
            r3.f1725f = r0
            goto L_0x0030
        L_0x0020:
            android.view.Window$Callback r0 = r3.f1722c
            boolean r0 = r0 instanceof android.app.Dialog
            if (r0 == 0) goto L_0x0030
            android.support.v7.app.l r0 = new android.support.v7.app.l
            android.view.Window$Callback r1 = r3.f1722c
            android.app.Dialog r1 = (android.app.Dialog) r1
            r0.<init>(r1)
            goto L_0x001d
        L_0x0030:
            android.support.v7.app.a r0 = r3.f1725f
            if (r0 == 0) goto L_0x003b
            android.support.v7.app.a r0 = r3.f1725f
            boolean r1 = r3.f1716Q
            r0.mo2186c(r1)
        L_0x003b:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.p031v7.app.C0574f.m2530t():void");
    }

    /* renamed from: u */
    private void m2531u() {
        if (!this.f1702C) {
            this.f1703D = m2532v();
            CharSequence n = mo2282n();
            if (!TextUtils.isEmpty(n)) {
                if (this.f1741y != null) {
                    this.f1741y.setWindowTitle(n);
                } else if (mo2279k() != null) {
                    mo2279k().mo2180a(n);
                } else if (this.f1704E != null) {
                    this.f1704E.setText(n);
                }
            }
            m2533w();
            mo2265a(this.f1703D);
            this.f1702C = true;
            C0590f a = mo2258a(0, false);
            if (this.f1737r) {
                return;
            }
            if (a == null || a.f1772j == null) {
                m2527j(108);
            }
        }
    }

    /* renamed from: v */
    private ViewGroup m2532v() {
        ViewGroup viewGroup;
        TypedArray obtainStyledAttributes = this.f1720a.obtainStyledAttributes(C0550j.AppCompatTheme);
        if (!obtainStyledAttributes.hasValue(C0550j.AppCompatTheme_windowActionBar)) {
            obtainStyledAttributes.recycle();
            throw new IllegalStateException("You need to use a Theme.AppCompat theme (or descendant) with this activity.");
        }
        if (obtainStyledAttributes.getBoolean(C0550j.AppCompatTheme_windowNoTitle, false)) {
            mo2251c(1);
        } else if (obtainStyledAttributes.getBoolean(C0550j.AppCompatTheme_windowActionBar, false)) {
            mo2251c(108);
        }
        if (obtainStyledAttributes.getBoolean(C0550j.AppCompatTheme_windowActionBarOverlay, false)) {
            mo2251c(109);
        }
        if (obtainStyledAttributes.getBoolean(C0550j.AppCompatTheme_windowActionModeOverlay, false)) {
            mo2251c(10);
        }
        this.f1735p = obtainStyledAttributes.getBoolean(C0550j.AppCompatTheme_android_windowIsFloating, false);
        obtainStyledAttributes.recycle();
        this.f1721b.getDecorView();
        LayoutInflater from = LayoutInflater.from(this.f1720a);
        if (this.f1736q) {
            viewGroup = (ViewGroup) from.inflate(this.f1734o ? C0547g.abc_screen_simple_overlay_action_mode : C0547g.abc_screen_simple, null);
            if (VERSION.SDK_INT >= 21) {
                C0495r.m2133a((View) viewGroup, (C0493p) new C0493p() {
                    /* renamed from: a */
                    public C0509z mo884a(View view, C0509z zVar) {
                        int b = zVar.mo1972b();
                        int h = C0574f.this.mo2277h(b);
                        if (b != h) {
                            zVar = zVar.mo1971a(zVar.mo1970a(), h, zVar.mo1973c(), zVar.mo1974d());
                        }
                        return C0495r.m2123a(view, zVar);
                    }
                });
            } else {
                ((C0777ao) viewGroup).setOnFitSystemWindowsListener(new C0778a() {
                    /* renamed from: a */
                    public void mo2292a(Rect rect) {
                        rect.top = C0574f.this.mo2277h(rect.top);
                    }
                });
            }
        } else if (this.f1735p) {
            viewGroup = (ViewGroup) from.inflate(C0547g.abc_dialog_title_material, null);
            this.f1733n = false;
            this.f1732m = false;
        } else if (this.f1732m) {
            TypedValue typedValue = new TypedValue();
            this.f1720a.getTheme().resolveAttribute(C0541a.actionBarTheme, typedValue, true);
            viewGroup = (ViewGroup) LayoutInflater.from(typedValue.resourceId != 0 ? new C0630d(this.f1720a, typedValue.resourceId) : this.f1720a).inflate(C0547g.abc_screen_toolbar, null);
            this.f1741y = (C0755ai) viewGroup.findViewById(C0546f.decor_content_parent);
            this.f1741y.setWindowCallback(mo2280l());
            if (this.f1733n) {
                this.f1741y.mo3005a(109);
            }
            if (this.f1706G) {
                this.f1741y.mo3005a(2);
            }
            if (this.f1707H) {
                this.f1741y.mo3005a(5);
            }
        } else {
            viewGroup = null;
        }
        if (viewGroup == null) {
            StringBuilder sb = new StringBuilder();
            sb.append("AppCompat does not support the current theme features: { windowActionBar: ");
            sb.append(this.f1732m);
            sb.append(", windowActionBarOverlay: ");
            sb.append(this.f1733n);
            sb.append(", android:windowIsFloating: ");
            sb.append(this.f1735p);
            sb.append(", windowActionModeOverlay: ");
            sb.append(this.f1734o);
            sb.append(", windowNoTitle: ");
            sb.append(this.f1736q);
            sb.append(" }");
            throw new IllegalArgumentException(sb.toString());
        }
        if (this.f1741y == null) {
            this.f1704E = (TextView) viewGroup.findViewById(C0546f.title);
        }
        C0885bv.m4758b(viewGroup);
        ContentFrameLayout contentFrameLayout = (ContentFrameLayout) viewGroup.findViewById(C0546f.action_bar_activity_content);
        ViewGroup viewGroup2 = (ViewGroup) this.f1721b.findViewById(16908290);
        if (viewGroup2 != null) {
            while (viewGroup2.getChildCount() > 0) {
                View childAt = viewGroup2.getChildAt(0);
                viewGroup2.removeViewAt(0);
                contentFrameLayout.addView(childAt);
            }
            viewGroup2.setId(-1);
            contentFrameLayout.setId(16908290);
            if (viewGroup2 instanceof FrameLayout) {
                ((FrameLayout) viewGroup2).setForeground(null);
            }
        }
        this.f1721b.setContentView(viewGroup);
        contentFrameLayout.setAttachListener(new C0696a() {
            /* renamed from: a */
            public void mo2293a() {
            }

            /* renamed from: b */
            public void mo2294b() {
                C0574f.this.mo2289s();
            }
        });
        return viewGroup;
    }

    /* renamed from: w */
    private void m2533w() {
        ContentFrameLayout contentFrameLayout = (ContentFrameLayout) this.f1703D.findViewById(16908290);
        View decorView = this.f1721b.getDecorView();
        contentFrameLayout.mo3140a(decorView.getPaddingLeft(), decorView.getPaddingTop(), decorView.getPaddingRight(), decorView.getPaddingBottom());
        TypedArray obtainStyledAttributes = this.f1720a.obtainStyledAttributes(C0550j.AppCompatTheme);
        obtainStyledAttributes.getValue(C0550j.AppCompatTheme_windowMinWidthMajor, contentFrameLayout.getMinWidthMajor());
        obtainStyledAttributes.getValue(C0550j.AppCompatTheme_windowMinWidthMinor, contentFrameLayout.getMinWidthMinor());
        if (obtainStyledAttributes.hasValue(C0550j.AppCompatTheme_windowFixedWidthMajor)) {
            obtainStyledAttributes.getValue(C0550j.AppCompatTheme_windowFixedWidthMajor, contentFrameLayout.getFixedWidthMajor());
        }
        if (obtainStyledAttributes.hasValue(C0550j.AppCompatTheme_windowFixedWidthMinor)) {
            obtainStyledAttributes.getValue(C0550j.AppCompatTheme_windowFixedWidthMinor, contentFrameLayout.getFixedWidthMinor());
        }
        if (obtainStyledAttributes.hasValue(C0550j.AppCompatTheme_windowFixedHeightMajor)) {
            obtainStyledAttributes.getValue(C0550j.AppCompatTheme_windowFixedHeightMajor, contentFrameLayout.getFixedHeightMajor());
        }
        if (obtainStyledAttributes.hasValue(C0550j.AppCompatTheme_windowFixedHeightMinor)) {
            obtainStyledAttributes.getValue(C0550j.AppCompatTheme_windowFixedHeightMinor, contentFrameLayout.getFixedHeightMinor());
        }
        obtainStyledAttributes.recycle();
        contentFrameLayout.requestLayout();
    }

    /* renamed from: x */
    private void m2534x() {
        if (this.f1702C) {
            throw new AndroidRuntimeException("Window feature must be requested before adding content");
        }
    }

    /* renamed from: y */
    private int m2535y() {
        return this.f1712M != -100 ? this.f1712M : m2495j();
    }

    /* renamed from: z */
    private void m2536z() {
        if (this.f1714O == null) {
            this.f1714O = new C0587d(C0599k.m2652a(this.f1720a));
        }
    }

    /* renamed from: a */
    public C0565a mo2238a() {
        m2530t();
        return this.f1725f;
    }

    /* access modifiers changed from: protected */
    /* renamed from: a */
    public C0590f mo2258a(int i, boolean z) {
        C0590f[] fVarArr = this.f1709J;
        if (fVarArr == null || fVarArr.length <= i) {
            C0590f[] fVarArr2 = new C0590f[(i + 1)];
            if (fVarArr != null) {
                System.arraycopy(fVarArr, 0, fVarArr2, 0, fVarArr.length);
            }
            this.f1709J = fVarArr2;
            fVarArr = fVarArr2;
        }
        C0590f fVar = fVarArr[i];
        if (fVar != null) {
            return fVar;
        }
        C0590f fVar2 = new C0590f(i);
        fVarArr[i] = fVar2;
        return fVar2;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public C0590f mo2259a(Menu menu) {
        C0590f[] fVarArr = this.f1709J;
        int length = fVarArr != null ? fVarArr.length : 0;
        for (int i = 0; i < length; i++) {
            C0590f fVar = fVarArr[i];
            if (fVar != null && fVar.f1772j == menu) {
                return fVar;
            }
        }
        return null;
    }

    /* renamed from: a */
    public C0627b mo2260a(C0628a aVar) {
        if (aVar == null) {
            throw new IllegalArgumentException("ActionMode callback can not be null.");
        }
        if (this.f1727h != null) {
            this.f1727h.mo2360c();
        }
        C0584b bVar = new C0584b(aVar);
        C0565a a = mo2238a();
        if (a != null) {
            this.f1727h = a.mo2177a((C0628a) bVar);
            if (!(this.f1727h == null || this.f1724e == null)) {
                this.f1724e.mo2213a(this.f1727h);
            }
        }
        if (this.f1727h == null) {
            this.f1727h = mo2269b((C0628a) bVar);
        }
        return this.f1727h;
    }

    /* renamed from: a */
    public <T extends View> T mo2239a(int i) {
        m2531u();
        return this.f1721b.findViewById(i);
    }

    /* renamed from: a */
    public View mo2261a(View view, String str, Context context, AttributeSet attributeSet) {
        AppCompatViewInflater appCompatViewInflater;
        boolean z = false;
        if (this.f1719T == null) {
            String string = this.f1720a.obtainStyledAttributes(C0550j.AppCompatTheme).getString(C0550j.AppCompatTheme_viewInflaterClass);
            if (string == null || AppCompatViewInflater.class.getName().equals(string)) {
                appCompatViewInflater = new AppCompatViewInflater();
            } else {
                try {
                    this.f1719T = (AppCompatViewInflater) Class.forName(string).getDeclaredConstructor(new Class[0]).newInstance(new Object[0]);
                } catch (Throwable th) {
                    StringBuilder sb = new StringBuilder();
                    sb.append("Failed to instantiate custom view inflater ");
                    sb.append(string);
                    sb.append(". Falling back to default.");
                    Log.i("AppCompatDelegate", sb.toString(), th);
                    appCompatViewInflater = new AppCompatViewInflater();
                }
            }
            this.f1719T = appCompatViewInflater;
        }
        if (f1697u) {
            if (!(attributeSet instanceof XmlPullParser)) {
                z = m2521a((ViewParent) view);
            } else if (((XmlPullParser) attributeSet).getDepth() > 1) {
                z = true;
            }
        }
        return this.f1719T.createView(view, str, context, attributeSet, z, f1697u, true, C0878bs.m4717a());
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo2262a(int i, C0590f fVar, Menu menu) {
        if (menu == null) {
            if (fVar == null && i >= 0 && i < this.f1709J.length) {
                fVar = this.f1709J[i];
            }
            if (fVar != null) {
                menu = fVar.f1772j;
            }
        }
        if ((fVar == null || fVar.f1777o) && !this.f1737r) {
            this.f1722c.onPanelClosed(i, menu);
        }
    }

    /* renamed from: a */
    public void mo2240a(Configuration configuration) {
        if (this.f1732m && this.f1702C) {
            C0565a a = mo2238a();
            if (a != null) {
                a.mo2179a(configuration);
            }
        }
        C0909k.m4874a().mo4572a(this.f1720a);
        mo2257i();
    }

    /* renamed from: a */
    public void mo2241a(Bundle bundle) {
        if (this.f1722c instanceof Activity) {
            String str = null;
            try {
                str = C0382t.m1708b((Activity) this.f1722c);
            } catch (IllegalArgumentException unused) {
            }
            if (str != null) {
                C0565a k = mo2279k();
                if (k == null) {
                    this.f1716Q = true;
                } else {
                    k.mo2186c(true);
                }
            }
        }
        if (bundle != null && this.f1712M == -100) {
            this.f1712M = bundle.getInt("appcompat:local_night_mode", -100);
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo2263a(C0590f fVar, boolean z) {
        if (!z || fVar.f1763a != 0 || this.f1741y == null || !this.f1741y.mo3014f()) {
            WindowManager windowManager = (WindowManager) this.f1720a.getSystemService("window");
            if (!(windowManager == null || !fVar.f1777o || fVar.f1769g == null)) {
                windowManager.removeView(fVar.f1769g);
                if (z) {
                    mo2262a(fVar.f1763a, fVar, null);
                }
            }
            fVar.f1775m = false;
            fVar.f1776n = false;
            fVar.f1777o = false;
            fVar.f1770h = null;
            fVar.f1779q = true;
            if (this.f1710K == fVar) {
                this.f1710K = null;
            }
            return;
        }
        mo2270b(fVar.f1772j);
    }

    /* renamed from: a */
    public void mo2264a(C0655h hVar) {
        m2518a(hVar, true);
    }

    /* renamed from: a */
    public void mo2242a(View view) {
        m2531u();
        ViewGroup viewGroup = (ViewGroup) this.f1703D.findViewById(16908290);
        viewGroup.removeAllViews();
        viewGroup.addView(view);
        this.f1722c.onContentChanged();
    }

    /* renamed from: a */
    public void mo2243a(View view, LayoutParams layoutParams) {
        m2531u();
        ViewGroup viewGroup = (ViewGroup) this.f1703D.findViewById(16908290);
        viewGroup.removeAllViews();
        viewGroup.addView(view, layoutParams);
        this.f1722c.onContentChanged();
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo2265a(ViewGroup viewGroup) {
    }

    /* renamed from: a */
    public final void mo2244a(CharSequence charSequence) {
        this.f1740x = charSequence;
        if (this.f1741y != null) {
            this.f1741y.setWindowTitle(charSequence);
        } else if (mo2279k() != null) {
            mo2279k().mo2180a(charSequence);
        } else {
            if (this.f1704E != null) {
                this.f1704E.setText(charSequence);
            }
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public boolean mo2266a(int i, KeyEvent keyEvent) {
        C0565a a = mo2238a();
        if (a != null && a.mo2182a(i, keyEvent)) {
            return true;
        }
        if (this.f1710K == null || !m2520a(this.f1710K, keyEvent.getKeyCode(), keyEvent, 1)) {
            if (this.f1710K == null) {
                C0590f a2 = mo2258a(0, true);
                m2523b(a2, keyEvent);
                boolean a3 = m2520a(a2, keyEvent.getKeyCode(), keyEvent, 1);
                a2.f1775m = false;
                if (a3) {
                    return true;
                }
            }
            return false;
        }
        if (this.f1710K != null) {
            this.f1710K.f1776n = true;
        }
        return true;
    }

    /* renamed from: a */
    public boolean mo2267a(C0655h hVar, MenuItem menuItem) {
        Callback l = mo2280l();
        if (l != null && !this.f1737r) {
            C0590f a = mo2259a((Menu) hVar.mo2759q());
            if (a != null) {
                return l.onMenuItemSelected(a.f1763a, menuItem);
            }
        }
        return false;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public boolean mo2268a(KeyEvent keyEvent) {
        boolean z = true;
        if ((this.f1722c instanceof C0482a) || (this.f1722c instanceof C0592g)) {
            View decorView = this.f1721b.getDecorView();
            if (decorView != null && C0481e.m2077a(decorView, keyEvent)) {
                return true;
            }
        }
        if (keyEvent.getKeyCode() == 82 && this.f1722c.dispatchKeyEvent(keyEvent)) {
            return true;
        }
        int keyCode = keyEvent.getKeyCode();
        if (keyEvent.getAction() != 0) {
            z = false;
        }
        return z ? mo2272c(keyCode, keyEvent) : mo2271b(keyCode, keyEvent);
    }

    /* access modifiers changed from: 0000 */
    /* JADX WARNING: Removed duplicated region for block: B:15:0x0029  */
    /* JADX WARNING: Removed duplicated region for block: B:16:0x002d  */
    /* renamed from: b */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public android.support.p031v7.view.C0627b mo2269b(android.support.p031v7.view.C0627b.C0628a r8) {
        /*
            r7 = this;
            r7.mo2287q()
            android.support.v7.view.b r0 = r7.f1727h
            if (r0 == 0) goto L_0x000c
            android.support.v7.view.b r0 = r7.f1727h
            r0.mo2360c()
        L_0x000c:
            boolean r0 = r8 instanceof android.support.p031v7.app.C0574f.C0584b
            if (r0 != 0) goto L_0x0016
            android.support.v7.app.f$b r0 = new android.support.v7.app.f$b
            r0.<init>(r8)
            r8 = r0
        L_0x0016:
            android.support.v7.app.d r0 = r7.f1724e
            r1 = 0
            if (r0 == 0) goto L_0x0026
            boolean r0 = r7.f1737r
            if (r0 != 0) goto L_0x0026
            android.support.v7.app.d r0 = r7.f1724e     // Catch:{ AbstractMethodError -> 0x0026 }
            android.support.v7.view.b r0 = r0.mo2211a(r8)     // Catch:{ AbstractMethodError -> 0x0026 }
            goto L_0x0027
        L_0x0026:
            r0 = r1
        L_0x0027:
            if (r0 == 0) goto L_0x002d
            r7.f1727h = r0
            goto L_0x016a
        L_0x002d:
            android.support.v7.widget.ActionBarContextView r0 = r7.f1728i
            r2 = 0
            r3 = 1
            if (r0 != 0) goto L_0x00da
            boolean r0 = r7.f1735p
            if (r0 == 0) goto L_0x00bb
            android.util.TypedValue r0 = new android.util.TypedValue
            r0.<init>()
            android.content.Context r4 = r7.f1720a
            android.content.res.Resources$Theme r4 = r4.getTheme()
            int r5 = android.support.p031v7.p032a.C0540a.C0541a.actionBarTheme
            r4.resolveAttribute(r5, r0, r3)
            int r5 = r0.resourceId
            if (r5 == 0) goto L_0x006c
            android.content.Context r5 = r7.f1720a
            android.content.res.Resources r5 = r5.getResources()
            android.content.res.Resources$Theme r5 = r5.newTheme()
            r5.setTo(r4)
            int r4 = r0.resourceId
            r5.applyStyle(r4, r3)
            android.support.v7.view.d r4 = new android.support.v7.view.d
            android.content.Context r6 = r7.f1720a
            r4.<init>(r6, r2)
            android.content.res.Resources$Theme r6 = r4.getTheme()
            r6.setTo(r5)
            goto L_0x006e
        L_0x006c:
            android.content.Context r4 = r7.f1720a
        L_0x006e:
            android.support.v7.widget.ActionBarContextView r5 = new android.support.v7.widget.ActionBarContextView
            r5.<init>(r4)
            r7.f1728i = r5
            android.widget.PopupWindow r5 = new android.widget.PopupWindow
            int r6 = android.support.p031v7.p032a.C0540a.C0541a.actionModePopupWindowStyle
            r5.<init>(r4, r1, r6)
            r7.f1729j = r5
            android.widget.PopupWindow r5 = r7.f1729j
            r6 = 2
            android.support.p018v4.widget.C0529k.m2338a(r5, r6)
            android.widget.PopupWindow r5 = r7.f1729j
            android.support.v7.widget.ActionBarContextView r6 = r7.f1728i
            r5.setContentView(r6)
            android.widget.PopupWindow r5 = r7.f1729j
            r6 = -1
            r5.setWidth(r6)
            android.content.res.Resources$Theme r5 = r4.getTheme()
            int r6 = android.support.p031v7.p032a.C0540a.C0541a.actionBarSize
            r5.resolveAttribute(r6, r0, r3)
            int r0 = r0.data
            android.content.res.Resources r4 = r4.getResources()
            android.util.DisplayMetrics r4 = r4.getDisplayMetrics()
            int r0 = android.util.TypedValue.complexToDimensionPixelSize(r0, r4)
            android.support.v7.widget.ActionBarContextView r4 = r7.f1728i
            r4.setContentHeight(r0)
            android.widget.PopupWindow r0 = r7.f1729j
            r4 = -2
            r0.setHeight(r4)
            android.support.v7.app.f$6 r0 = new android.support.v7.app.f$6
            r0.<init>()
            r7.f1730k = r0
            goto L_0x00da
        L_0x00bb:
            android.view.ViewGroup r0 = r7.f1703D
            int r4 = android.support.p031v7.p032a.C0540a.C0546f.action_mode_bar_stub
            android.view.View r0 = r0.findViewById(r4)
            android.support.v7.widget.ViewStubCompat r0 = (android.support.p031v7.widget.ViewStubCompat) r0
            if (r0 == 0) goto L_0x00da
            android.content.Context r4 = r7.mo2281m()
            android.view.LayoutInflater r4 = android.view.LayoutInflater.from(r4)
            r0.setLayoutInflater(r4)
            android.view.View r0 = r0.mo3502a()
            android.support.v7.widget.ActionBarContextView r0 = (android.support.p031v7.widget.ActionBarContextView) r0
            r7.f1728i = r0
        L_0x00da:
            android.support.v7.widget.ActionBarContextView r0 = r7.f1728i
            if (r0 == 0) goto L_0x016a
            r7.mo2287q()
            android.support.v7.widget.ActionBarContextView r0 = r7.f1728i
            r0.mo2982c()
            android.support.v7.view.e r0 = new android.support.v7.view.e
            android.support.v7.widget.ActionBarContextView r4 = r7.f1728i
            android.content.Context r4 = r4.getContext()
            android.support.v7.widget.ActionBarContextView r5 = r7.f1728i
            android.widget.PopupWindow r6 = r7.f1729j
            if (r6 != 0) goto L_0x00f5
            goto L_0x00f6
        L_0x00f5:
            r3 = r2
        L_0x00f6:
            r0.<init>(r4, r5, r8, r3)
            android.view.Menu r3 = r0.mo2357b()
            boolean r8 = r8.mo2299a(r0, r3)
            if (r8 == 0) goto L_0x0168
            r0.mo2361d()
            android.support.v7.widget.ActionBarContextView r8 = r7.f1728i
            r8.mo2979a(r0)
            r7.f1727h = r0
            boolean r8 = r7.mo2283o()
            r0 = 1065353216(0x3f800000, float:1.0)
            if (r8 == 0) goto L_0x0132
            android.support.v7.widget.ActionBarContextView r8 = r7.f1728i
            r1 = 0
            r8.setAlpha(r1)
            android.support.v7.widget.ActionBarContextView r8 = r7.f1728i
            android.support.v4.h.v r8 = android.support.p018v4.p028h.C0495r.m2156k(r8)
            android.support.v4.h.v r8 = r8.mo1953a(r0)
            r7.f1731l = r8
            android.support.v4.h.v r8 = r7.f1731l
            android.support.v7.app.f$7 r0 = new android.support.v7.app.f$7
            r0.<init>()
            r8.mo1955a(r0)
            goto L_0x0158
        L_0x0132:
            android.support.v7.widget.ActionBarContextView r8 = r7.f1728i
            r8.setAlpha(r0)
            android.support.v7.widget.ActionBarContextView r8 = r7.f1728i
            r8.setVisibility(r2)
            android.support.v7.widget.ActionBarContextView r8 = r7.f1728i
            r0 = 32
            r8.sendAccessibilityEvent(r0)
            android.support.v7.widget.ActionBarContextView r8 = r7.f1728i
            android.view.ViewParent r8 = r8.getParent()
            boolean r8 = r8 instanceof android.view.View
            if (r8 == 0) goto L_0x0158
            android.support.v7.widget.ActionBarContextView r8 = r7.f1728i
            android.view.ViewParent r8 = r8.getParent()
            android.view.View r8 = (android.view.View) r8
            android.support.p018v4.p028h.C0495r.m2160o(r8)
        L_0x0158:
            android.widget.PopupWindow r8 = r7.f1729j
            if (r8 == 0) goto L_0x016a
            android.view.Window r8 = r7.f1721b
            android.view.View r8 = r8.getDecorView()
            java.lang.Runnable r0 = r7.f1730k
            r8.post(r0)
            goto L_0x016a
        L_0x0168:
            r7.f1727h = r1
        L_0x016a:
            android.support.v7.view.b r8 = r7.f1727h
            if (r8 == 0) goto L_0x0179
            android.support.v7.app.d r8 = r7.f1724e
            if (r8 == 0) goto L_0x0179
            android.support.v7.app.d r8 = r7.f1724e
            android.support.v7.view.b r0 = r7.f1727h
            r8.mo2213a(r0)
        L_0x0179:
            android.support.v7.view.b r8 = r7.f1727h
            return r8
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.p031v7.app.C0574f.mo2269b(android.support.v7.view.b$a):android.support.v7.view.b");
    }

    /* renamed from: b */
    public MenuInflater mo2245b() {
        if (this.f1726g == null) {
            m2530t();
            this.f1726g = new C0634g(this.f1725f != null ? this.f1725f.mo2184b() : this.f1720a);
        }
        return this.f1726g;
    }

    /* renamed from: b */
    public void mo2246b(int i) {
        m2531u();
        ViewGroup viewGroup = (ViewGroup) this.f1703D.findViewById(16908290);
        viewGroup.removeAllViews();
        LayoutInflater.from(this.f1720a).inflate(i, viewGroup);
        this.f1722c.onContentChanged();
    }

    /* renamed from: b */
    public void mo2247b(Bundle bundle) {
        m2531u();
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: b */
    public void mo2270b(C0655h hVar) {
        if (!this.f1708I) {
            this.f1708I = true;
            this.f1741y.mo3026k();
            Callback l = mo2280l();
            if (l != null && !this.f1737r) {
                l.onPanelClosed(108, hVar);
            }
            this.f1708I = false;
        }
    }

    /* renamed from: b */
    public void mo2248b(View view, LayoutParams layoutParams) {
        m2531u();
        ((ViewGroup) this.f1703D.findViewById(16908290)).addView(view, layoutParams);
        this.f1722c.onContentChanged();
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: b */
    public boolean mo2271b(int i, KeyEvent keyEvent) {
        if (i == 4) {
            boolean z = this.f1711L;
            this.f1711L = false;
            C0590f a = mo2258a(0, false);
            if (a == null || !a.f1777o) {
                return mo2288r();
            }
            if (!z) {
                mo2263a(a, true);
            }
            return true;
        } else if (i != 82) {
            return false;
        } else {
            m2526e(0, keyEvent);
            return true;
        }
    }

    /* renamed from: c */
    public void mo2249c() {
        mo2257i();
    }

    /* renamed from: c */
    public void mo2250c(Bundle bundle) {
        if (this.f1712M != -100) {
            bundle.putInt("appcompat:local_night_mode", this.f1712M);
        }
    }

    /* renamed from: c */
    public boolean mo2251c(int i) {
        int k = m2528k(i);
        if (this.f1736q && k == 108) {
            return false;
        }
        if (this.f1732m && k == 1) {
            this.f1732m = false;
        }
        switch (k) {
            case 1:
                m2534x();
                this.f1736q = true;
                return true;
            case 2:
                m2534x();
                this.f1706G = true;
                return true;
            case 5:
                m2534x();
                this.f1707H = true;
                return true;
            case 10:
                m2534x();
                this.f1734o = true;
                return true;
            case 108:
                m2534x();
                this.f1732m = true;
                return true;
            case 109:
                m2534x();
                this.f1733n = true;
                return true;
            default:
                return this.f1721b.requestFeature(k);
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: c */
    public boolean mo2272c(int i, KeyEvent keyEvent) {
        boolean z = true;
        if (i == 4) {
            if ((keyEvent.getFlags() & 128) == 0) {
                z = false;
            }
            this.f1711L = z;
            return false;
        } else if (i != 82) {
            return false;
        } else {
            m2525d(0, keyEvent);
            return true;
        }
    }

    /* renamed from: d */
    public void mo2252d() {
        C0565a a = mo2238a();
        if (a != null) {
            a.mo2188d(false);
        }
        if (this.f1714O != null) {
            this.f1714O.mo2316d();
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: d */
    public void mo2273d(int i) {
        if (i == 108) {
            C0565a a = mo2238a();
            if (a != null) {
                a.mo2190e(false);
            }
        } else if (i == 0) {
            C0590f a2 = mo2258a(i, true);
            if (a2.f1777o) {
                mo2263a(a2, false);
            }
        }
    }

    /* renamed from: e */
    public void mo2253e() {
        C0565a a = mo2238a();
        if (a != null) {
            a.mo2188d(true);
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: e */
    public void mo2274e(int i) {
        if (i == 108) {
            C0565a a = mo2238a();
            if (a != null) {
                a.mo2190e(true);
            }
        }
    }

    /* renamed from: f */
    public void mo2254f() {
        C0565a a = mo2238a();
        if (a == null || !a.mo2191e()) {
            m2527j(0);
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: f */
    public void mo2275f(int i) {
        mo2263a(mo2258a(i, true), true);
    }

    /* renamed from: g */
    public void mo2255g() {
        if (this.f1738s) {
            this.f1721b.getDecorView().removeCallbacks(this.f1715P);
        }
        this.f1737r = true;
        if (this.f1725f != null) {
            this.f1725f.mo2193g();
        }
        if (this.f1714O != null) {
            this.f1714O.mo2316d();
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: g */
    public void mo2276g(int i) {
        C0590f a = mo2258a(i, true);
        if (a.f1772j != null) {
            Bundle bundle = new Bundle();
            a.f1772j.mo2704a(bundle);
            if (bundle.size() > 0) {
                a.f1781s = bundle;
            }
            a.f1772j.mo2746h();
            a.f1772j.clear();
        }
        a.f1780r = true;
        a.f1779q = true;
        if ((i == 108 || i == 0) && this.f1741y != null) {
            C0590f a2 = mo2258a(0, false);
            if (a2 != null) {
                a2.f1775m = false;
                m2523b(a2, (KeyEvent) null);
            }
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: h */
    public int mo2277h(int i) {
        boolean z;
        boolean z2;
        int i2 = 0;
        if (this.f1728i == null || !(this.f1728i.getLayoutParams() instanceof MarginLayoutParams)) {
            z = false;
        } else {
            MarginLayoutParams marginLayoutParams = (MarginLayoutParams) this.f1728i.getLayoutParams();
            z = true;
            if (this.f1728i.isShown()) {
                if (this.f1717R == null) {
                    this.f1717R = new Rect();
                    this.f1718S = new Rect();
                }
                Rect rect = this.f1717R;
                Rect rect2 = this.f1718S;
                rect.set(0, i, 0, 0);
                C0885bv.m4756a(this.f1703D, rect, rect2);
                if (marginLayoutParams.topMargin != (rect2.top == 0 ? i : 0)) {
                    marginLayoutParams.topMargin = i;
                    if (this.f1705F == null) {
                        this.f1705F = new View(this.f1720a);
                        this.f1705F.setBackgroundColor(this.f1720a.getResources().getColor(C0543c.abc_input_method_navigation_guard));
                        this.f1703D.addView(this.f1705F, -1, new LayoutParams(-1, i));
                    } else {
                        LayoutParams layoutParams = this.f1705F.getLayoutParams();
                        if (layoutParams.height != i) {
                            layoutParams.height = i;
                            this.f1705F.setLayoutParams(layoutParams);
                        }
                    }
                    z2 = true;
                } else {
                    z2 = false;
                }
                if (this.f1705F == null) {
                    z = false;
                }
                if (!this.f1734o && z) {
                    i = 0;
                }
            } else if (marginLayoutParams.topMargin != 0) {
                marginLayoutParams.topMargin = 0;
                z2 = true;
                z = false;
            } else {
                z2 = false;
                z = false;
            }
            if (z2) {
                this.f1728i.setLayoutParams(marginLayoutParams);
            }
        }
        if (this.f1705F != null) {
            View view = this.f1705F;
            if (!z) {
                i2 = 8;
            }
            view.setVisibility(i2);
        }
        return i;
    }

    /* renamed from: h */
    public void mo2256h() {
        LayoutInflater from = LayoutInflater.from(this.f1720a);
        if (from.getFactory() == null) {
            C0483f.m2079a(from, this);
            return;
        }
        if (!(from.getFactory2() instanceof C0574f)) {
            Log.i("AppCompatDelegate", "The Activity's LayoutInflater already has a Factory installed so we can not install AppCompat's");
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: i */
    public int mo2278i(int i) {
        if (i == -100) {
            return -1;
        }
        if (i != 0) {
            return i;
        }
        if (VERSION.SDK_INT >= 23 && ((UiModeManager) this.f1720a.getSystemService(UiModeManager.class)).getNightMode() == 0) {
            return -1;
        }
        m2536z();
        return this.f1714O.mo2313a();
    }

    /* renamed from: i */
    public boolean mo2257i() {
        int y = m2535y();
        int i = mo2278i(y);
        boolean l = i != -1 ? m2529l(i) : false;
        if (y == 0) {
            m2536z();
            this.f1714O.mo2315c();
        }
        this.f1713N = true;
        return l;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: k */
    public final C0565a mo2279k() {
        return this.f1725f;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: l */
    public final Callback mo2280l() {
        return this.f1721b.getCallback();
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: m */
    public final Context mo2281m() {
        C0565a a = mo2238a();
        Context b = a != null ? a.mo2184b() : null;
        return b == null ? this.f1720a : b;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: n */
    public final CharSequence mo2282n() {
        return this.f1722c instanceof Activity ? ((Activity) this.f1722c).getTitle() : this.f1740x;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: o */
    public final boolean mo2283o() {
        return this.f1702C && this.f1703D != null && C0495r.m2168w(this.f1703D);
    }

    public final View onCreateView(View view, String str, Context context, AttributeSet attributeSet) {
        return mo2261a(view, str, context, attributeSet);
    }

    public View onCreateView(String str, Context context, AttributeSet attributeSet) {
        return onCreateView(null, str, context, attributeSet);
    }

    /* renamed from: p */
    public boolean mo2286p() {
        return this.f1701B;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: q */
    public void mo2287q() {
        if (this.f1731l != null) {
            this.f1731l.mo1960b();
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: r */
    public boolean mo2288r() {
        if (this.f1727h != null) {
            this.f1727h.mo2360c();
            return true;
        }
        C0565a a = mo2238a();
        return a != null && a.mo2192f();
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: s */
    public void mo2289s() {
        if (this.f1741y != null) {
            this.f1741y.mo3026k();
        }
        if (this.f1729j != null) {
            this.f1721b.getDecorView().removeCallbacks(this.f1730k);
            if (this.f1729j.isShowing()) {
                try {
                    this.f1729j.dismiss();
                } catch (IllegalArgumentException unused) {
                }
            }
            this.f1729j = null;
        }
        mo2287q();
        C0590f a = mo2258a(0, false);
        if (a != null && a.f1772j != null) {
            a.f1772j.close();
        }
    }
}
