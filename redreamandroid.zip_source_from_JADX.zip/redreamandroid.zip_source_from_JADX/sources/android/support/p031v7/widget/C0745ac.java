package android.support.p031v7.widget;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;

/* renamed from: android.support.v7.widget.ac */
class C0745ac extends C0748ae {
    C0745ac() {
    }

    /* renamed from: a */
    public void mo3553a() {
        C0852bc.f3057a = new C0853a() {
            /* renamed from: a */
            public void mo3554a(Canvas canvas, RectF rectF, float f, Paint paint) {
                canvas.drawRoundRect(rectF, f, f, paint);
            }
        };
    }
}
