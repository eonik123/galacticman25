package android.support.p031v7.widget;

import android.app.SearchManager;
import android.app.SearchableInfo;
import android.content.ComponentName;
import android.content.Context;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.Resources.NotFoundException;
import android.database.Cursor;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.Drawable.ConstantState;
import android.net.Uri;
import android.net.Uri.Builder;
import android.os.Bundle;
import android.support.p018v4.p019a.C0293a;
import android.support.p018v4.widget.C0530l;
import android.support.p031v7.p032a.C0540a.C0541a;
import android.support.p031v7.p032a.C0540a.C0546f;
import android.text.SpannableString;
import android.text.TextUtils;
import android.text.style.TextAppearanceSpan;
import android.util.Log;
import android.util.TypedValue;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import java.io.FileNotFoundException;
import java.util.List;
import java.util.WeakHashMap;

/* renamed from: android.support.v7.widget.bh */
class C0862bh extends C0530l implements OnClickListener {

    /* renamed from: j */
    private final SearchManager f3104j = ((SearchManager) this.f1516d.getSystemService("search"));

    /* renamed from: k */
    private final SearchView f3105k;

    /* renamed from: l */
    private final SearchableInfo f3106l;

    /* renamed from: m */
    private final Context f3107m;

    /* renamed from: n */
    private final WeakHashMap<String, ConstantState> f3108n;

    /* renamed from: o */
    private final int f3109o;

    /* renamed from: p */
    private boolean f3110p = false;

    /* renamed from: q */
    private int f3111q = 1;

    /* renamed from: r */
    private ColorStateList f3112r;

    /* renamed from: s */
    private int f3113s = -1;

    /* renamed from: t */
    private int f3114t = -1;

    /* renamed from: u */
    private int f3115u = -1;

    /* renamed from: v */
    private int f3116v = -1;

    /* renamed from: w */
    private int f3117w = -1;

    /* renamed from: x */
    private int f3118x = -1;

    /* renamed from: android.support.v7.widget.bh$a */
    private static final class C0863a {

        /* renamed from: a */
        public final TextView f3119a;

        /* renamed from: b */
        public final TextView f3120b;

        /* renamed from: c */
        public final ImageView f3121c;

        /* renamed from: d */
        public final ImageView f3122d;

        /* renamed from: e */
        public final ImageView f3123e;

        public C0863a(View view) {
            this.f3119a = (TextView) view.findViewById(16908308);
            this.f3120b = (TextView) view.findViewById(16908309);
            this.f3121c = (ImageView) view.findViewById(16908295);
            this.f3122d = (ImageView) view.findViewById(16908296);
            this.f3123e = (ImageView) view.findViewById(C0546f.edit_query);
        }
    }

    public C0862bh(Context context, SearchView searchView, SearchableInfo searchableInfo, WeakHashMap<String, ConstantState> weakHashMap) {
        super(context, searchView.getSuggestionRowLayout(), null, true);
        this.f3105k = searchView;
        this.f3106l = searchableInfo;
        this.f3109o = searchView.getSuggestionCommitIconResId();
        this.f3107m = context;
        this.f3108n = weakHashMap;
    }

    /* renamed from: a */
    private Drawable m4603a(ComponentName componentName) {
        String flattenToShortString = componentName.flattenToShortString();
        ConstantState constantState = null;
        if (this.f3108n.containsKey(flattenToShortString)) {
            ConstantState constantState2 = (ConstantState) this.f3108n.get(flattenToShortString);
            if (constantState2 == null) {
                return null;
            }
            return constantState2.newDrawable(this.f3107m.getResources());
        }
        Drawable b = m4610b(componentName);
        if (b != null) {
            constantState = b.getConstantState();
        }
        this.f3108n.put(flattenToShortString, constantState);
        return b;
    }

    /* renamed from: a */
    private Drawable m4604a(String str) {
        Drawable drawable = null;
        if (str != null && !str.isEmpty()) {
            if ("0".equals(str)) {
                return null;
            }
            try {
                int parseInt = Integer.parseInt(str);
                StringBuilder sb = new StringBuilder();
                sb.append("android.resource://");
                sb.append(this.f3107m.getPackageName());
                sb.append("/");
                sb.append(parseInt);
                String sb2 = sb.toString();
                Drawable b = m4612b(sb2);
                if (b != null) {
                    return b;
                }
                Drawable a = C0293a.m1186a(this.f3107m, parseInt);
                m4609a(sb2, a);
                return a;
            } catch (NumberFormatException unused) {
                Drawable b2 = m4612b(str);
                if (b2 != null) {
                    return b2;
                }
                drawable = m4611b(Uri.parse(str));
                m4609a(str, drawable);
            } catch (NotFoundException unused2) {
                StringBuilder sb3 = new StringBuilder();
                sb3.append("Icon resource not found: ");
                sb3.append(str);
                Log.w("SuggestionsAdapter", sb3.toString());
                return null;
            }
        }
        return drawable;
    }

    /* renamed from: a */
    private static String m4605a(Cursor cursor, int i) {
        if (i == -1) {
            return null;
        }
        try {
            return cursor.getString(i);
        } catch (Exception e) {
            Log.e("SuggestionsAdapter", "unexpected error retrieving valid column from cursor, did the remote process die?", e);
            return null;
        }
    }

    /* renamed from: a */
    public static String m4606a(Cursor cursor, String str) {
        return m4605a(cursor, cursor.getColumnIndex(str));
    }

    /* renamed from: a */
    private void m4607a(ImageView imageView, Drawable drawable, int i) {
        imageView.setImageDrawable(drawable);
        if (drawable == null) {
            imageView.setVisibility(i);
            return;
        }
        imageView.setVisibility(0);
        drawable.setVisible(false, false);
        drawable.setVisible(true, false);
    }

    /* renamed from: a */
    private void m4608a(TextView textView, CharSequence charSequence) {
        textView.setText(charSequence);
        textView.setVisibility(TextUtils.isEmpty(charSequence) ? 8 : 0);
    }

    /* renamed from: a */
    private void m4609a(String str, Drawable drawable) {
        if (drawable != null) {
            this.f3108n.put(str, drawable.getConstantState());
        }
    }

    /* renamed from: b */
    private Drawable m4610b(ComponentName componentName) {
        String str;
        String nameNotFoundException;
        PackageManager packageManager = this.f1516d.getPackageManager();
        try {
            ActivityInfo activityInfo = packageManager.getActivityInfo(componentName, 128);
            int iconResource = activityInfo.getIconResource();
            if (iconResource == 0) {
                return null;
            }
            Drawable drawable = packageManager.getDrawable(componentName.getPackageName(), iconResource, activityInfo.applicationInfo);
            if (drawable != null) {
                return drawable;
            }
            str = "SuggestionsAdapter";
            StringBuilder sb = new StringBuilder();
            sb.append("Invalid icon resource ");
            sb.append(iconResource);
            sb.append(" for ");
            sb.append(componentName.flattenToShortString());
            nameNotFoundException = sb.toString();
            Log.w(str, nameNotFoundException);
            return null;
        } catch (NameNotFoundException e) {
            str = "SuggestionsAdapter";
            nameNotFoundException = e.toString();
        }
    }

    /* JADX WARNING: Can't wrap try/catch for region: R(3:7|8|9) */
    /* JADX WARNING: Code restructure failed: missing block: B:8:?, code lost:
        r2 = new java.lang.StringBuilder();
        r2.append("Resource does not exist: ");
        r2.append(r7);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:9:0x0028, code lost:
        throw new java.io.FileNotFoundException(r2.toString());
     */
    /* JADX WARNING: Missing exception handler attribute for start block: B:7:0x0012 */
    /* renamed from: b */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private android.graphics.drawable.Drawable m4611b(android.net.Uri r7) {
        /*
            r6 = this;
            r0 = 0
            java.lang.String r1 = r7.getScheme()     // Catch:{ FileNotFoundException -> 0x0089 }
            java.lang.String r2 = "android.resource"
            boolean r1 = r2.equals(r1)     // Catch:{ FileNotFoundException -> 0x0089 }
            if (r1 == 0) goto L_0x0029
            android.graphics.drawable.Drawable r1 = r6.mo4411a(r7)     // Catch:{ NotFoundException -> 0x0012 }
            return r1
        L_0x0012:
            java.io.FileNotFoundException r1 = new java.io.FileNotFoundException     // Catch:{ FileNotFoundException -> 0x0089 }
            java.lang.StringBuilder r2 = new java.lang.StringBuilder     // Catch:{ FileNotFoundException -> 0x0089 }
            r2.<init>()     // Catch:{ FileNotFoundException -> 0x0089 }
            java.lang.String r3 = "Resource does not exist: "
            r2.append(r3)     // Catch:{ FileNotFoundException -> 0x0089 }
            r2.append(r7)     // Catch:{ FileNotFoundException -> 0x0089 }
            java.lang.String r2 = r2.toString()     // Catch:{ FileNotFoundException -> 0x0089 }
            r1.<init>(r2)     // Catch:{ FileNotFoundException -> 0x0089 }
            throw r1     // Catch:{ FileNotFoundException -> 0x0089 }
        L_0x0029:
            android.content.Context r1 = r6.f3107m     // Catch:{ FileNotFoundException -> 0x0089 }
            android.content.ContentResolver r1 = r1.getContentResolver()     // Catch:{ FileNotFoundException -> 0x0089 }
            java.io.InputStream r1 = r1.openInputStream(r7)     // Catch:{ FileNotFoundException -> 0x0089 }
            if (r1 != 0) goto L_0x004c
            java.io.FileNotFoundException r1 = new java.io.FileNotFoundException     // Catch:{ FileNotFoundException -> 0x0089 }
            java.lang.StringBuilder r2 = new java.lang.StringBuilder     // Catch:{ FileNotFoundException -> 0x0089 }
            r2.<init>()     // Catch:{ FileNotFoundException -> 0x0089 }
            java.lang.String r3 = "Failed to open "
            r2.append(r3)     // Catch:{ FileNotFoundException -> 0x0089 }
            r2.append(r7)     // Catch:{ FileNotFoundException -> 0x0089 }
            java.lang.String r2 = r2.toString()     // Catch:{ FileNotFoundException -> 0x0089 }
            r1.<init>(r2)     // Catch:{ FileNotFoundException -> 0x0089 }
            throw r1     // Catch:{ FileNotFoundException -> 0x0089 }
        L_0x004c:
            android.graphics.drawable.Drawable r2 = android.graphics.drawable.Drawable.createFromStream(r1, r0)     // Catch:{ all -> 0x006c }
            r1.close()     // Catch:{ IOException -> 0x0054 }
            return r2
        L_0x0054:
            r1 = move-exception
            java.lang.String r3 = "SuggestionsAdapter"
            java.lang.StringBuilder r4 = new java.lang.StringBuilder     // Catch:{ FileNotFoundException -> 0x0089 }
            r4.<init>()     // Catch:{ FileNotFoundException -> 0x0089 }
            java.lang.String r5 = "Error closing icon stream for "
            r4.append(r5)     // Catch:{ FileNotFoundException -> 0x0089 }
            r4.append(r7)     // Catch:{ FileNotFoundException -> 0x0089 }
            java.lang.String r4 = r4.toString()     // Catch:{ FileNotFoundException -> 0x0089 }
            android.util.Log.e(r3, r4, r1)     // Catch:{ FileNotFoundException -> 0x0089 }
            return r2
        L_0x006c:
            r2 = move-exception
            r1.close()     // Catch:{ IOException -> 0x0071 }
            goto L_0x0088
        L_0x0071:
            r1 = move-exception
            java.lang.String r3 = "SuggestionsAdapter"
            java.lang.StringBuilder r4 = new java.lang.StringBuilder     // Catch:{ FileNotFoundException -> 0x0089 }
            r4.<init>()     // Catch:{ FileNotFoundException -> 0x0089 }
            java.lang.String r5 = "Error closing icon stream for "
            r4.append(r5)     // Catch:{ FileNotFoundException -> 0x0089 }
            r4.append(r7)     // Catch:{ FileNotFoundException -> 0x0089 }
            java.lang.String r4 = r4.toString()     // Catch:{ FileNotFoundException -> 0x0089 }
            android.util.Log.e(r3, r4, r1)     // Catch:{ FileNotFoundException -> 0x0089 }
        L_0x0088:
            throw r2     // Catch:{ FileNotFoundException -> 0x0089 }
        L_0x0089:
            r1 = move-exception
            java.lang.String r2 = "SuggestionsAdapter"
            java.lang.StringBuilder r3 = new java.lang.StringBuilder
            r3.<init>()
            java.lang.String r4 = "Icon not found: "
            r3.append(r4)
            r3.append(r7)
            java.lang.String r7 = ", "
            r3.append(r7)
            java.lang.String r7 = r1.getMessage()
            r3.append(r7)
            java.lang.String r7 = r3.toString()
            android.util.Log.w(r2, r7)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.p031v7.widget.C0862bh.m4611b(android.net.Uri):android.graphics.drawable.Drawable");
    }

    /* renamed from: b */
    private Drawable m4612b(String str) {
        ConstantState constantState = (ConstantState) this.f3108n.get(str);
        if (constantState == null) {
            return null;
        }
        return constantState.newDrawable();
    }

    /* renamed from: b */
    private CharSequence m4613b(CharSequence charSequence) {
        if (this.f3112r == null) {
            TypedValue typedValue = new TypedValue();
            this.f1516d.getTheme().resolveAttribute(C0541a.textColorSearchUrl, typedValue, true);
            this.f3112r = this.f1516d.getResources().getColorStateList(typedValue.resourceId);
        }
        SpannableString spannableString = new SpannableString(charSequence);
        TextAppearanceSpan textAppearanceSpan = new TextAppearanceSpan(null, 0, 0, this.f3112r, null);
        spannableString.setSpan(textAppearanceSpan, 0, charSequence.length(), 33);
        return spannableString;
    }

    /* renamed from: d */
    private void m4614d(Cursor cursor) {
        Bundle extras = cursor != null ? cursor.getExtras() : null;
        if (extras == null || extras.getBoolean("in_progress")) {
        }
    }

    /* renamed from: e */
    private Drawable m4615e(Cursor cursor) {
        if (this.f3116v == -1) {
            return null;
        }
        Drawable a = m4604a(cursor.getString(this.f3116v));
        return a != null ? a : m4617g(cursor);
    }

    /* renamed from: f */
    private Drawable m4616f(Cursor cursor) {
        if (this.f3117w == -1) {
            return null;
        }
        return m4604a(cursor.getString(this.f3117w));
    }

    /* renamed from: g */
    private Drawable m4617g(Cursor cursor) {
        Drawable a = m4603a(this.f3106l.getSearchActivity());
        return a != null ? a : this.f1516d.getPackageManager().getDefaultActivityIcon();
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public Cursor mo4410a(SearchableInfo searchableInfo, String str, int i) {
        String[] strArr = null;
        if (searchableInfo == null) {
            return null;
        }
        String suggestAuthority = searchableInfo.getSuggestAuthority();
        if (suggestAuthority == null) {
            return null;
        }
        Builder fragment = new Builder().scheme("content").authority(suggestAuthority).query("").fragment("");
        String suggestPath = searchableInfo.getSuggestPath();
        if (suggestPath != null) {
            fragment.appendEncodedPath(suggestPath);
        }
        fragment.appendPath("search_suggest_query");
        String suggestSelection = searchableInfo.getSuggestSelection();
        if (suggestSelection != null) {
            strArr = new String[]{str};
        } else {
            fragment.appendPath(str);
        }
        String[] strArr2 = strArr;
        if (i > 0) {
            fragment.appendQueryParameter("limit", String.valueOf(i));
        }
        return this.f1516d.getContentResolver().query(fragment.build(), null, suggestSelection, strArr2, null);
    }

    /* renamed from: a */
    public Cursor mo2075a(CharSequence charSequence) {
        String charSequence2 = charSequence == null ? "" : charSequence.toString();
        if (this.f3105k.getVisibility() != 0 || this.f3105k.getWindowVisibility() != 0) {
            return null;
        }
        try {
            Cursor a = mo4410a(this.f3106l, charSequence2, 50);
            if (a != null) {
                a.getCount();
                return a;
            }
        } catch (RuntimeException e) {
            Log.w("SuggestionsAdapter", "Search suggestions query threw an exception.", e);
        }
        return null;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public Drawable mo4411a(Uri uri) {
        int i;
        String authority = uri.getAuthority();
        if (TextUtils.isEmpty(authority)) {
            StringBuilder sb = new StringBuilder();
            sb.append("No authority: ");
            sb.append(uri);
            throw new FileNotFoundException(sb.toString());
        }
        try {
            Resources resourcesForApplication = this.f1516d.getPackageManager().getResourcesForApplication(authority);
            List pathSegments = uri.getPathSegments();
            if (pathSegments == null) {
                StringBuilder sb2 = new StringBuilder();
                sb2.append("No path: ");
                sb2.append(uri);
                throw new FileNotFoundException(sb2.toString());
            }
            int size = pathSegments.size();
            if (size == 1) {
                try {
                    i = Integer.parseInt((String) pathSegments.get(0));
                } catch (NumberFormatException unused) {
                    StringBuilder sb3 = new StringBuilder();
                    sb3.append("Single path segment is not a resource ID: ");
                    sb3.append(uri);
                    throw new FileNotFoundException(sb3.toString());
                }
            } else if (size == 2) {
                i = resourcesForApplication.getIdentifier((String) pathSegments.get(1), (String) pathSegments.get(0), authority);
            } else {
                StringBuilder sb4 = new StringBuilder();
                sb4.append("More than two path segments: ");
                sb4.append(uri);
                throw new FileNotFoundException(sb4.toString());
            }
            if (i != 0) {
                return resourcesForApplication.getDrawable(i);
            }
            StringBuilder sb5 = new StringBuilder();
            sb5.append("No resource found for: ");
            sb5.append(uri);
            throw new FileNotFoundException(sb5.toString());
        } catch (NameNotFoundException unused2) {
            StringBuilder sb6 = new StringBuilder();
            sb6.append("No package found for authority: ");
            sb6.append(uri);
            throw new FileNotFoundException(sb6.toString());
        }
    }

    /* renamed from: a */
    public View mo2076a(Context context, Cursor cursor, ViewGroup viewGroup) {
        View a = super.mo2076a(context, cursor, viewGroup);
        a.setTag(new C0863a(a));
        ((ImageView) a.findViewById(C0546f.edit_query)).setImageResource(this.f3109o);
        return a;
    }

    /* renamed from: a */
    public void mo4412a(int i) {
        this.f3111q = i;
    }

    /* renamed from: a */
    public void mo2078a(Cursor cursor) {
        if (this.f3110p) {
            Log.w("SuggestionsAdapter", "Tried to change cursor after adapter was closed.");
            if (cursor != null) {
                cursor.close();
            }
            return;
        }
        try {
            super.mo2078a(cursor);
            if (cursor != null) {
                this.f3113s = cursor.getColumnIndex("suggest_text_1");
                this.f3114t = cursor.getColumnIndex("suggest_text_2");
                this.f3115u = cursor.getColumnIndex("suggest_text_2_url");
                this.f3116v = cursor.getColumnIndex("suggest_icon_1");
                this.f3117w = cursor.getColumnIndex("suggest_icon_2");
                this.f3118x = cursor.getColumnIndex("suggest_flags");
            }
        } catch (Exception e) {
            Log.e("SuggestionsAdapter", "error changing cursor and caching columns", e);
        }
    }

    /* renamed from: a */
    public void mo2079a(View view, Context context, Cursor cursor) {
        C0863a aVar = (C0863a) view.getTag();
        int i = this.f3118x != -1 ? cursor.getInt(this.f3118x) : 0;
        if (aVar.f3119a != null) {
            m4608a(aVar.f3119a, (CharSequence) m4605a(cursor, this.f3113s));
        }
        if (aVar.f3120b != null) {
            String a = m4605a(cursor, this.f3115u);
            CharSequence b = a != null ? m4613b((CharSequence) a) : m4605a(cursor, this.f3114t);
            if (TextUtils.isEmpty(b)) {
                if (aVar.f3119a != null) {
                    aVar.f3119a.setSingleLine(false);
                    aVar.f3119a.setMaxLines(2);
                }
            } else if (aVar.f3119a != null) {
                aVar.f3119a.setSingleLine(true);
                aVar.f3119a.setMaxLines(1);
            }
            m4608a(aVar.f3120b, b);
        }
        if (aVar.f3121c != null) {
            m4607a(aVar.f3121c, m4615e(cursor), 4);
        }
        if (aVar.f3122d != null) {
            m4607a(aVar.f3122d, m4616f(cursor), 8);
        }
        if (this.f3111q == 2 || (this.f3111q == 1 && (i & 1) != 0)) {
            aVar.f3123e.setVisibility(0);
            aVar.f3123e.setTag(aVar.f3119a.getText());
            aVar.f3123e.setOnClickListener(this);
            return;
        }
        aVar.f3123e.setVisibility(8);
    }

    /* renamed from: c */
    public CharSequence mo2083c(Cursor cursor) {
        if (cursor == null) {
            return null;
        }
        String a = m4606a(cursor, "suggest_intent_query");
        if (a != null) {
            return a;
        }
        if (this.f3106l.shouldRewriteQueryFromData()) {
            String a2 = m4606a(cursor, "suggest_intent_data");
            if (a2 != null) {
                return a2;
            }
        }
        if (this.f3106l.shouldRewriteQueryFromText()) {
            String a3 = m4606a(cursor, "suggest_text_1");
            if (a3 != null) {
                return a3;
            }
        }
        return null;
    }

    public View getDropDownView(int i, View view, ViewGroup viewGroup) {
        try {
            return super.getDropDownView(i, view, viewGroup);
        } catch (RuntimeException e) {
            Log.w("SuggestionsAdapter", "Search suggestions cursor threw exception.", e);
            View b = mo2081b(this.f1516d, this.f1515c, viewGroup);
            if (b != null) {
                ((C0863a) b.getTag()).f3119a.setText(e.toString());
            }
            return b;
        }
    }

    public View getView(int i, View view, ViewGroup viewGroup) {
        try {
            return super.getView(i, view, viewGroup);
        } catch (RuntimeException e) {
            Log.w("SuggestionsAdapter", "Search suggestions cursor threw exception.", e);
            View a = mo2076a(this.f1516d, this.f1515c, viewGroup);
            if (a != null) {
                ((C0863a) a.getTag()).f3119a.setText(e.toString());
            }
            return a;
        }
    }

    public boolean hasStableIds() {
        return false;
    }

    public void notifyDataSetChanged() {
        super.notifyDataSetChanged();
        m4614d(mo2074a());
    }

    public void notifyDataSetInvalidated() {
        super.notifyDataSetInvalidated();
        m4614d(mo2074a());
    }

    public void onClick(View view) {
        Object tag = view.getTag();
        if (tag instanceof CharSequence) {
            this.f3105k.mo3247a((CharSequence) tag);
        }
    }
}
