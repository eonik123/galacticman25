package android.support.p031v7.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.database.DataSetObserver;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.support.p018v4.p028h.C0495r;
import android.support.p018v4.widget.C0529k;
import android.support.p031v7.p032a.C0540a.C0541a;
import android.support.p031v7.p032a.C0540a.C0550j;
import android.support.p031v7.view.menu.C0677s;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.View.OnTouchListener;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.AbsListView;
import android.widget.AbsListView.OnScrollListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.PopupWindow.OnDismissListener;
import java.lang.reflect.Method;

/* renamed from: android.support.v7.widget.at */
public class C0789at implements C0677s {

    /* renamed from: a */
    private static Method f2784a;

    /* renamed from: b */
    private static Method f2785b;

    /* renamed from: h */
    private static Method f2786h;

    /* renamed from: A */
    private Drawable f2787A;

    /* renamed from: B */
    private OnItemClickListener f2788B;

    /* renamed from: C */
    private OnItemSelectedListener f2789C;

    /* renamed from: D */
    private final C0795d f2790D;

    /* renamed from: E */
    private final C0794c f2791E;

    /* renamed from: F */
    private final C0792a f2792F;

    /* renamed from: G */
    private Runnable f2793G;

    /* renamed from: H */
    private final Rect f2794H;

    /* renamed from: I */
    private Rect f2795I;

    /* renamed from: J */
    private boolean f2796J;

    /* renamed from: c */
    C0769am f2797c;

    /* renamed from: d */
    int f2798d;

    /* renamed from: e */
    final C0796e f2799e;

    /* renamed from: f */
    final Handler f2800f;

    /* renamed from: g */
    PopupWindow f2801g;

    /* renamed from: i */
    private Context f2802i;

    /* renamed from: j */
    private ListAdapter f2803j;

    /* renamed from: k */
    private int f2804k;

    /* renamed from: l */
    private int f2805l;

    /* renamed from: m */
    private int f2806m;

    /* renamed from: n */
    private int f2807n;

    /* renamed from: o */
    private int f2808o;

    /* renamed from: p */
    private boolean f2809p;

    /* renamed from: q */
    private boolean f2810q;

    /* renamed from: r */
    private boolean f2811r;

    /* renamed from: s */
    private boolean f2812s;

    /* renamed from: t */
    private int f2813t;

    /* renamed from: u */
    private boolean f2814u;

    /* renamed from: v */
    private boolean f2815v;

    /* renamed from: w */
    private View f2816w;

    /* renamed from: x */
    private int f2817x;

    /* renamed from: y */
    private DataSetObserver f2818y;

    /* renamed from: z */
    private View f2819z;

    /* renamed from: android.support.v7.widget.at$a */
    private class C0792a implements Runnable {
        C0792a() {
        }

        public void run() {
            C0789at.this.mo3793m();
        }
    }

    /* renamed from: android.support.v7.widget.at$b */
    private class C0793b extends DataSetObserver {
        C0793b() {
        }

        public void onChanged() {
            if (C0789at.this.mo2665d()) {
                C0789at.this.mo2655a();
            }
        }

        public void onInvalidated() {
            C0789at.this.mo2662c();
        }
    }

    /* renamed from: android.support.v7.widget.at$c */
    private class C0794c implements OnScrollListener {
        C0794c() {
        }

        public void onScroll(AbsListView absListView, int i, int i2, int i3) {
        }

        public void onScrollStateChanged(AbsListView absListView, int i) {
            if (i == 1 && !C0789at.this.mo3794n() && C0789at.this.f2801g.getContentView() != null) {
                C0789at.this.f2800f.removeCallbacks(C0789at.this.f2799e);
                C0789at.this.f2799e.run();
            }
        }
    }

    /* renamed from: android.support.v7.widget.at$d */
    private class C0795d implements OnTouchListener {
        C0795d() {
        }

        public boolean onTouch(View view, MotionEvent motionEvent) {
            int action = motionEvent.getAction();
            int x = (int) motionEvent.getX();
            int y = (int) motionEvent.getY();
            if (action == 0 && C0789at.this.f2801g != null && C0789at.this.f2801g.isShowing() && x >= 0 && x < C0789at.this.f2801g.getWidth() && y >= 0 && y < C0789at.this.f2801g.getHeight()) {
                C0789at.this.f2800f.postDelayed(C0789at.this.f2799e, 250);
            } else if (action == 1) {
                C0789at.this.f2800f.removeCallbacks(C0789at.this.f2799e);
            }
            return false;
        }
    }

    /* renamed from: android.support.v7.widget.at$e */
    private class C0796e implements Runnable {
        C0796e() {
        }

        public void run() {
            if (C0789at.this.f2797c != null && C0495r.m2171z(C0789at.this.f2797c) && C0789at.this.f2797c.getCount() > C0789at.this.f2797c.getChildCount() && C0789at.this.f2797c.getChildCount() <= C0789at.this.f2798d) {
                C0789at.this.f2801g.setInputMethodMode(2);
                C0789at.this.mo2655a();
            }
        }
    }

    static {
        try {
            f2784a = PopupWindow.class.getDeclaredMethod("setClipToScreenEnabled", new Class[]{Boolean.TYPE});
        } catch (NoSuchMethodException unused) {
            Log.i("ListPopupWindow", "Could not find method setClipToScreenEnabled() on PopupWindow. Oh well.");
        }
        try {
            f2785b = PopupWindow.class.getDeclaredMethod("getMaxAvailableHeight", new Class[]{View.class, Integer.TYPE, Boolean.TYPE});
        } catch (NoSuchMethodException unused2) {
            Log.i("ListPopupWindow", "Could not find method getMaxAvailableHeight(View, int, boolean) on PopupWindow. Oh well.");
        }
        try {
            f2786h = PopupWindow.class.getDeclaredMethod("setEpicenterBounds", new Class[]{Rect.class});
        } catch (NoSuchMethodException unused3) {
            Log.i("ListPopupWindow", "Could not find method setEpicenterBounds(Rect) on PopupWindow. Oh well.");
        }
    }

    public C0789at(Context context) {
        this(context, null, C0541a.listPopupWindowStyle);
    }

    public C0789at(Context context, AttributeSet attributeSet, int i) {
        this(context, attributeSet, i, 0);
    }

    public C0789at(Context context, AttributeSet attributeSet, int i, int i2) {
        this.f2804k = -2;
        this.f2805l = -2;
        this.f2808o = 1002;
        this.f2810q = true;
        this.f2813t = 0;
        this.f2814u = false;
        this.f2815v = false;
        this.f2798d = Integer.MAX_VALUE;
        this.f2817x = 0;
        this.f2799e = new C0796e();
        this.f2790D = new C0795d();
        this.f2791E = new C0794c();
        this.f2792F = new C0792a();
        this.f2794H = new Rect();
        this.f2802i = context;
        this.f2800f = new Handler(context.getMainLooper());
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, C0550j.ListPopupWindow, i, i2);
        this.f2806m = obtainStyledAttributes.getDimensionPixelOffset(C0550j.ListPopupWindow_android_dropDownHorizontalOffset, 0);
        this.f2807n = obtainStyledAttributes.getDimensionPixelOffset(C0550j.ListPopupWindow_android_dropDownVerticalOffset, 0);
        if (this.f2807n != 0) {
            this.f2809p = true;
        }
        obtainStyledAttributes.recycle();
        this.f2801g = new C0921r(context, attributeSet, i, i2);
        this.f2801g.setInputMethodMode(1);
    }

    /* renamed from: a */
    private int m3933a(View view, int i, boolean z) {
        if (f2785b != null) {
            try {
                return ((Integer) f2785b.invoke(this.f2801g, new Object[]{view, Integer.valueOf(i), Boolean.valueOf(z)})).intValue();
            } catch (Exception unused) {
                Log.i("ListPopupWindow", "Could not call getMaxAvailableHeightMethod(View, int, boolean) on PopupWindow. Using the public version.");
            }
        }
        return this.f2801g.getMaxAvailableHeight(view, i);
    }

    /* renamed from: b */
    private void mo4669b() {
        if (this.f2816w != null) {
            ViewParent parent = this.f2816w.getParent();
            if (parent instanceof ViewGroup) {
                ((ViewGroup) parent).removeView(this.f2816w);
            }
        }
    }

    /* renamed from: c */
    private void mo3808c(boolean z) {
        if (f2784a != null) {
            try {
                f2784a.invoke(this.f2801g, new Object[]{Boolean.valueOf(z)});
            } catch (Exception unused) {
                Log.i("ListPopupWindow", "Could not call setClipToScreenEnabled() on PopupWindow. Oh well.");
            }
        }
    }

    /* renamed from: f */
    private int mo4670f() {
        int i;
        int i2;
        int makeMeasureSpec;
        int i3;
        View view;
        int i4;
        int i5;
        boolean z = true;
        if (this.f2797c == null) {
            Context context = this.f2802i;
            this.f2793G = new Runnable() {
                public void run() {
                    View i = C0789at.this.mo3788i();
                    if (i != null && i.getWindowToken() != null) {
                        C0789at.this.mo2655a();
                    }
                }
            };
            this.f2797c = mo3769a(context, !this.f2796J);
            if (this.f2787A != null) {
                this.f2797c.setSelector(this.f2787A);
            }
            this.f2797c.setAdapter(this.f2803j);
            this.f2797c.setOnItemClickListener(this.f2788B);
            this.f2797c.setFocusable(true);
            this.f2797c.setFocusableInTouchMode(true);
            this.f2797c.setOnItemSelectedListener(new OnItemSelectedListener() {
                public void onItemSelected(AdapterView<?> adapterView, View view, int i, long j) {
                    if (i != -1) {
                        C0769am amVar = C0789at.this.f2797c;
                        if (amVar != null) {
                            amVar.setListSelectionHidden(false);
                        }
                    }
                }

                public void onNothingSelected(AdapterView<?> adapterView) {
                }
            });
            this.f2797c.setOnScrollListener(this.f2791E);
            if (this.f2789C != null) {
                this.f2797c.setOnItemSelectedListener(this.f2789C);
            }
            View view2 = this.f2797c;
            View view3 = this.f2816w;
            if (view3 != null) {
                LinearLayout linearLayout = new LinearLayout(context);
                linearLayout.setOrientation(1);
                LayoutParams layoutParams = new LayoutParams(-1, 0, 1.0f);
                switch (this.f2817x) {
                    case 0:
                        linearLayout.addView(view3);
                        linearLayout.addView(view2, layoutParams);
                        break;
                    case 1:
                        linearLayout.addView(view2, layoutParams);
                        linearLayout.addView(view3);
                        break;
                    default:
                        StringBuilder sb = new StringBuilder();
                        sb.append("Invalid hint position ");
                        sb.append(this.f2817x);
                        Log.e("ListPopupWindow", sb.toString());
                        break;
                }
                if (this.f2805l >= 0) {
                    i5 = this.f2805l;
                    i4 = Integer.MIN_VALUE;
                } else {
                    i5 = 0;
                    i4 = 0;
                }
                view3.measure(MeasureSpec.makeMeasureSpec(i5, i4), 0);
                LayoutParams layoutParams2 = (LayoutParams) view3.getLayoutParams();
                i = view3.getMeasuredHeight() + layoutParams2.topMargin + layoutParams2.bottomMargin;
                view = linearLayout;
            } else {
                i = 0;
                view = view2;
            }
            this.f2801g.setContentView(view);
        } else {
            ViewGroup viewGroup = (ViewGroup) this.f2801g.getContentView();
            View view4 = this.f2816w;
            if (view4 != null) {
                LayoutParams layoutParams3 = (LayoutParams) view4.getLayoutParams();
                i = view4.getMeasuredHeight() + layoutParams3.topMargin + layoutParams3.bottomMargin;
            } else {
                i = 0;
            }
        }
        Drawable background = this.f2801g.getBackground();
        if (background != null) {
            background.getPadding(this.f2794H);
            i2 = this.f2794H.top + this.f2794H.bottom;
            if (!this.f2809p) {
                this.f2807n = -this.f2794H.top;
            }
        } else {
            this.f2794H.setEmpty();
            i2 = 0;
        }
        if (this.f2801g.getInputMethodMode() != 2) {
            z = false;
        }
        int a = m3933a(mo3788i(), this.f2807n, z);
        if (this.f2814u || this.f2804k == -1) {
            return a + i2;
        }
        switch (this.f2805l) {
            case -2:
                makeMeasureSpec = MeasureSpec.makeMeasureSpec(this.f2802i.getResources().getDisplayMetrics().widthPixels - (this.f2794H.left + this.f2794H.right), Integer.MIN_VALUE);
                break;
            case -1:
                i3 = this.f2802i.getResources().getDisplayMetrics().widthPixels - (this.f2794H.left + this.f2794H.right);
                break;
            default:
                i3 = this.f2805l;
                break;
        }
        makeMeasureSpec = MeasureSpec.makeMeasureSpec(i3, 1073741824);
        int a2 = this.f2797c.mo3672a(makeMeasureSpec, 0, -1, a - i, -1);
        if (a2 > 0) {
            i += i2 + this.f2797c.getPaddingTop() + this.f2797c.getPaddingBottom();
        }
        return a2 + i;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public C0769am mo3769a(Context context, boolean z) {
        return new C0769am(context, z);
    }

    /* renamed from: a */
    public void mo2655a() {
        int f = mo4670f();
        boolean n = mo3794n();
        C0529k.m2338a(this.f2801g, this.f2808o);
        boolean z = true;
        if (!this.f2801g.isShowing()) {
            int i = this.f2805l == -1 ? -1 : this.f2805l == -2 ? mo3788i().getWidth() : this.f2805l;
            if (this.f2804k == -1) {
                f = -1;
            } else if (this.f2804k != -2) {
                f = this.f2804k;
            }
            this.f2801g.setWidth(i);
            this.f2801g.setHeight(f);
            mo3808c(true);
            this.f2801g.setOutsideTouchable(!this.f2815v && !this.f2814u);
            this.f2801g.setTouchInterceptor(this.f2790D);
            if (this.f2812s) {
                C0529k.m2340a(this.f2801g, this.f2811r);
            }
            if (f2786h != null) {
                try {
                    f2786h.invoke(this.f2801g, new Object[]{this.f2795I});
                } catch (Exception e) {
                    Log.e("ListPopupWindow", "Could not invoke setEpicenterBounds on PopupWindow", e);
                }
            }
            C0529k.m2339a(this.f2801g, mo3788i(), this.f2806m, this.f2807n, this.f2813t);
            this.f2797c.setSelection(-1);
            if (!this.f2796J || this.f2797c.isInTouchMode()) {
                mo3793m();
            }
            if (!this.f2796J) {
                this.f2800f.post(this.f2792F);
            }
        } else if (C0495r.m2171z(mo3788i())) {
            int i2 = this.f2805l == -1 ? -1 : this.f2805l == -2 ? mo3788i().getWidth() : this.f2805l;
            if (this.f2804k == -1) {
                if (!n) {
                    f = -1;
                }
                if (n) {
                    this.f2801g.setWidth(this.f2805l == -1 ? -1 : 0);
                    this.f2801g.setHeight(0);
                } else {
                    this.f2801g.setWidth(this.f2805l == -1 ? -1 : 0);
                    this.f2801g.setHeight(-1);
                }
            } else if (this.f2804k != -2) {
                f = this.f2804k;
            }
            PopupWindow popupWindow = this.f2801g;
            if (this.f2815v || this.f2814u) {
                z = false;
            }
            popupWindow.setOutsideTouchable(z);
            this.f2801g.update(mo3788i(), this.f2806m, this.f2807n, i2 < 0 ? -1 : i2, f < 0 ? -1 : f);
        }
    }

    /* renamed from: a */
    public void mo3770a(int i) {
        this.f2817x = i;
    }

    /* renamed from: a */
    public void mo3771a(Rect rect) {
        this.f2795I = rect;
    }

    /* renamed from: a */
    public void mo3772a(Drawable drawable) {
        this.f2801g.setBackgroundDrawable(drawable);
    }

    /* renamed from: a */
    public void mo3773a(OnItemClickListener onItemClickListener) {
        this.f2788B = onItemClickListener;
    }

    /* renamed from: a */
    public void mo3774a(ListAdapter listAdapter) {
        if (this.f2818y == null) {
            this.f2818y = new C0793b();
        } else if (this.f2803j != null) {
            this.f2803j.unregisterDataSetObserver(this.f2818y);
        }
        this.f2803j = listAdapter;
        if (listAdapter != null) {
            listAdapter.registerDataSetObserver(this.f2818y);
        }
        if (this.f2797c != null) {
            this.f2797c.setAdapter(this.f2803j);
        }
    }

    /* renamed from: a */
    public void mo3775a(OnDismissListener onDismissListener) {
        this.f2801g.setOnDismissListener(onDismissListener);
    }

    /* renamed from: a */
    public void mo3776a(boolean z) {
        this.f2796J = z;
        this.f2801g.setFocusable(z);
    }

    /* renamed from: b */
    public void mo3777b(int i) {
        this.f2801g.setAnimationStyle(i);
    }

    /* renamed from: b */
    public void mo3778b(View view) {
        this.f2819z = view;
    }

    /* renamed from: b */
    public void mo3779b(boolean z) {
        this.f2812s = true;
        this.f2811r = z;
    }

    /* renamed from: c */
    public void mo2662c() {
        this.f2801g.dismiss();
        mo4669b();
        this.f2801g.setContentView(null);
        this.f2797c = null;
        this.f2800f.removeCallbacks(this.f2799e);
    }

    /* renamed from: c */
    public void mo3780c(int i) {
        this.f2806m = i;
    }

    /* renamed from: d */
    public void mo3781d(int i) {
        this.f2807n = i;
        this.f2809p = true;
    }

    /* renamed from: d */
    public boolean mo2665d() {
        return this.f2801g.isShowing();
    }

    /* renamed from: e */
    public ListView mo2666e() {
        return this.f2797c;
    }

    /* renamed from: e */
    public void mo3782e(int i) {
        this.f2813t = i;
    }

    /* renamed from: f */
    public void mo3783f(int i) {
        this.f2805l = i;
    }

    /* renamed from: g */
    public void mo3784g(int i) {
        Drawable background = this.f2801g.getBackground();
        if (background != null) {
            background.getPadding(this.f2794H);
            this.f2805l = this.f2794H.left + this.f2794H.right + i;
            return;
        }
        mo3783f(i);
    }

    /* renamed from: g */
    public boolean mo3785g() {
        return this.f2796J;
    }

    /* renamed from: h */
    public Drawable mo3786h() {
        return this.f2801g.getBackground();
    }

    /* renamed from: h */
    public void mo3787h(int i) {
        this.f2801g.setInputMethodMode(i);
    }

    /* renamed from: i */
    public View mo3788i() {
        return this.f2819z;
    }

    /* renamed from: i */
    public void mo3789i(int i) {
        C0769am amVar = this.f2797c;
        if (mo2665d() && amVar != null) {
            amVar.setListSelectionHidden(false);
            amVar.setSelection(i);
            if (amVar.getChoiceMode() != 0) {
                amVar.setItemChecked(i, true);
            }
        }
    }

    /* renamed from: j */
    public int mo3790j() {
        return this.f2806m;
    }

    /* renamed from: k */
    public int mo3791k() {
        if (!this.f2809p) {
            return 0;
        }
        return this.f2807n;
    }

    /* renamed from: l */
    public int mo3792l() {
        return this.f2805l;
    }

    /* renamed from: m */
    public void mo3793m() {
        C0769am amVar = this.f2797c;
        if (amVar != null) {
            amVar.setListSelectionHidden(true);
            amVar.requestLayout();
        }
    }

    /* renamed from: n */
    public boolean mo3794n() {
        return this.f2801g.getInputMethodMode() == 2;
    }
}
