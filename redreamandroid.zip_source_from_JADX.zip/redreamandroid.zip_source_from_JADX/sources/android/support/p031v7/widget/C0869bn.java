package android.support.p031v7.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.support.p018v4.p019a.p020a.C0304f;
import android.support.p018v4.p019a.p020a.C0304f.C0305a;
import android.support.p031v7.p033b.p034a.C0606a;
import android.util.AttributeSet;
import android.util.TypedValue;

/* renamed from: android.support.v7.widget.bn */
public class C0869bn {

    /* renamed from: a */
    private final Context f3143a;

    /* renamed from: b */
    private final TypedArray f3144b;

    /* renamed from: c */
    private TypedValue f3145c;

    private C0869bn(Context context, TypedArray typedArray) {
        this.f3143a = context;
        this.f3144b = typedArray;
    }

    /* renamed from: a */
    public static C0869bn m4636a(Context context, int i, int[] iArr) {
        return new C0869bn(context, context.obtainStyledAttributes(i, iArr));
    }

    /* renamed from: a */
    public static C0869bn m4637a(Context context, AttributeSet attributeSet, int[] iArr) {
        return new C0869bn(context, context.obtainStyledAttributes(attributeSet, iArr));
    }

    /* renamed from: a */
    public static C0869bn m4638a(Context context, AttributeSet attributeSet, int[] iArr, int i, int i2) {
        return new C0869bn(context, context.obtainStyledAttributes(attributeSet, iArr, i, i2));
    }

    /* renamed from: a */
    public float mo4423a(int i, float f) {
        return this.f3144b.getFloat(i, f);
    }

    /* renamed from: a */
    public int mo4424a(int i, int i2) {
        return this.f3144b.getInt(i, i2);
    }

    /* renamed from: a */
    public Typeface mo4425a(int i, int i2, C0305a aVar) {
        int resourceId = this.f3144b.getResourceId(i, 0);
        if (resourceId == 0) {
            return null;
        }
        if (this.f3145c == null) {
            this.f3145c = new TypedValue();
        }
        return C0304f.m1231a(this.f3143a, resourceId, this.f3145c, i2, aVar);
    }

    /* renamed from: a */
    public Drawable mo4426a(int i) {
        if (this.f3144b.hasValue(i)) {
            int resourceId = this.f3144b.getResourceId(i, 0);
            if (resourceId != 0) {
                return C0606a.m2714b(this.f3143a, resourceId);
            }
        }
        return this.f3144b.getDrawable(i);
    }

    /* renamed from: a */
    public void mo4427a() {
        this.f3144b.recycle();
    }

    /* renamed from: a */
    public boolean mo4428a(int i, boolean z) {
        return this.f3144b.getBoolean(i, z);
    }

    /* renamed from: b */
    public int mo4429b(int i, int i2) {
        return this.f3144b.getColor(i, i2);
    }

    /* renamed from: b */
    public Drawable mo4430b(int i) {
        if (this.f3144b.hasValue(i)) {
            int resourceId = this.f3144b.getResourceId(i, 0);
            if (resourceId != 0) {
                return C0909k.m4874a().mo4570a(this.f3143a, resourceId, true);
            }
        }
        return null;
    }

    /* renamed from: c */
    public int mo4431c(int i, int i2) {
        return this.f3144b.getInteger(i, i2);
    }

    /* renamed from: c */
    public CharSequence mo4432c(int i) {
        return this.f3144b.getText(i);
    }

    /* renamed from: d */
    public int mo4433d(int i, int i2) {
        return this.f3144b.getDimensionPixelOffset(i, i2);
    }

    /* renamed from: d */
    public String mo4434d(int i) {
        return this.f3144b.getString(i);
    }

    /* renamed from: e */
    public int mo4435e(int i, int i2) {
        return this.f3144b.getDimensionPixelSize(i, i2);
    }

    /* renamed from: e */
    public ColorStateList mo4436e(int i) {
        if (this.f3144b.hasValue(i)) {
            int resourceId = this.f3144b.getResourceId(i, 0);
            if (resourceId != 0) {
                ColorStateList a = C0606a.m2711a(this.f3143a, resourceId);
                if (a != null) {
                    return a;
                }
            }
        }
        return this.f3144b.getColorStateList(i);
    }

    /* renamed from: f */
    public int mo4437f(int i, int i2) {
        return this.f3144b.getLayoutDimension(i, i2);
    }

    /* renamed from: f */
    public CharSequence[] mo4438f(int i) {
        return this.f3144b.getTextArray(i);
    }

    /* renamed from: g */
    public int mo4439g(int i, int i2) {
        return this.f3144b.getResourceId(i, i2);
    }

    /* renamed from: g */
    public boolean mo4440g(int i) {
        return this.f3144b.hasValue(i);
    }
}
