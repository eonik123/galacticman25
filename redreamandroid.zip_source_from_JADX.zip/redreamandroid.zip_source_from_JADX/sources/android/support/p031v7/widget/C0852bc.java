package android.support.p031v7.widget;

import android.content.res.ColorStateList;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Path.FillType;
import android.graphics.RadialGradient;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader.TileMode;
import android.graphics.drawable.Drawable;

/* renamed from: android.support.v7.widget.bc */
class C0852bc extends Drawable {

    /* renamed from: a */
    static C0853a f3057a;

    /* renamed from: b */
    private static final double f3058b = Math.cos(Math.toRadians(45.0d));

    /* renamed from: c */
    private final int f3059c;

    /* renamed from: d */
    private Paint f3060d;

    /* renamed from: e */
    private Paint f3061e;

    /* renamed from: f */
    private Paint f3062f;

    /* renamed from: g */
    private final RectF f3063g;

    /* renamed from: h */
    private float f3064h;

    /* renamed from: i */
    private Path f3065i;

    /* renamed from: j */
    private float f3066j;

    /* renamed from: k */
    private float f3067k;

    /* renamed from: l */
    private float f3068l;

    /* renamed from: m */
    private ColorStateList f3069m;

    /* renamed from: n */
    private boolean f3070n;

    /* renamed from: o */
    private final int f3071o;

    /* renamed from: p */
    private final int f3072p;

    /* renamed from: q */
    private boolean f3073q;

    /* renamed from: r */
    private boolean f3074r;

    /* renamed from: android.support.v7.widget.bc$a */
    interface C0853a {
        /* renamed from: a */
        void mo3554a(Canvas canvas, RectF rectF, float f, Paint paint);
    }

    /* renamed from: a */
    static float m4538a(float f, float f2, boolean z) {
        return z ? (float) (((double) (f * 1.5f)) + ((1.0d - f3058b) * ((double) f2))) : f * 1.5f;
    }

    /* renamed from: a */
    private void m4539a(float f, float f2) {
        if (f < 0.0f) {
            StringBuilder sb = new StringBuilder();
            sb.append("Invalid shadow size ");
            sb.append(f);
            sb.append(". Must be >= 0");
            throw new IllegalArgumentException(sb.toString());
        } else if (f2 < 0.0f) {
            StringBuilder sb2 = new StringBuilder();
            sb2.append("Invalid max shadow size ");
            sb2.append(f2);
            sb2.append(". Must be >= 0");
            throw new IllegalArgumentException(sb2.toString());
        } else {
            float d = (float) m4544d(f);
            float d2 = (float) m4544d(f2);
            if (d > d2) {
                if (!this.f3074r) {
                    this.f3074r = true;
                }
                d = d2;
            }
            if (this.f3068l != d || this.f3066j != d2) {
                this.f3068l = d;
                this.f3066j = d2;
                this.f3067k = (float) ((int) ((d * 1.5f) + ((float) this.f3059c) + 0.5f));
                this.f3070n = true;
                invalidateSelf();
            }
        }
    }

    /* renamed from: a */
    private void m4540a(Canvas canvas) {
        float f = (-this.f3064h) - this.f3067k;
        float f2 = this.f3064h + ((float) this.f3059c) + (this.f3068l / 2.0f);
        float f3 = 2.0f * f2;
        boolean z = this.f3063g.width() - f3 > 0.0f;
        boolean z2 = this.f3063g.height() - f3 > 0.0f;
        int save = canvas.save();
        canvas.translate(this.f3063g.left + f2, this.f3063g.top + f2);
        canvas.drawPath(this.f3065i, this.f3061e);
        if (z) {
            canvas.drawRect(0.0f, f, this.f3063g.width() - f3, -this.f3064h, this.f3062f);
        }
        canvas.restoreToCount(save);
        int save2 = canvas.save();
        canvas.translate(this.f3063g.right - f2, this.f3063g.bottom - f2);
        canvas.rotate(180.0f);
        canvas.drawPath(this.f3065i, this.f3061e);
        if (z) {
            canvas.drawRect(0.0f, f, this.f3063g.width() - f3, (-this.f3064h) + this.f3067k, this.f3062f);
        }
        canvas.restoreToCount(save2);
        int save3 = canvas.save();
        canvas.translate(this.f3063g.left + f2, this.f3063g.bottom - f2);
        canvas.rotate(270.0f);
        canvas.drawPath(this.f3065i, this.f3061e);
        if (z2) {
            canvas.drawRect(0.0f, f, this.f3063g.height() - f3, -this.f3064h, this.f3062f);
        }
        canvas.restoreToCount(save3);
        int save4 = canvas.save();
        canvas.translate(this.f3063g.right - f2, this.f3063g.top + f2);
        canvas.rotate(90.0f);
        canvas.drawPath(this.f3065i, this.f3061e);
        if (z2) {
            canvas.drawRect(0.0f, f, this.f3063g.height() - f3, -this.f3064h, this.f3062f);
        }
        canvas.restoreToCount(save4);
    }

    /* renamed from: b */
    static float m4541b(float f, float f2, boolean z) {
        return z ? (float) (((double) f) + ((1.0d - f3058b) * ((double) f2))) : f;
    }

    /* renamed from: b */
    private void m4542b(ColorStateList colorStateList) {
        if (colorStateList == null) {
            colorStateList = ColorStateList.valueOf(0);
        }
        this.f3069m = colorStateList;
        this.f3060d.setColor(this.f3069m.getColorForState(getState(), this.f3069m.getDefaultColor()));
    }

    /* renamed from: b */
    private void m4543b(Rect rect) {
        float f = this.f3066j * 1.5f;
        this.f3063g.set(((float) rect.left) + this.f3066j, ((float) rect.top) + f, ((float) rect.right) - this.f3066j, ((float) rect.bottom) - f);
        m4545g();
    }

    /* renamed from: d */
    private int m4544d(float f) {
        int i = (int) (f + 0.5f);
        return i % 2 == 1 ? i - 1 : i;
    }

    /* renamed from: g */
    private void m4545g() {
        RectF rectF = new RectF(-this.f3064h, -this.f3064h, this.f3064h, this.f3064h);
        RectF rectF2 = new RectF(rectF);
        rectF2.inset(-this.f3067k, -this.f3067k);
        if (this.f3065i == null) {
            this.f3065i = new Path();
        } else {
            this.f3065i.reset();
        }
        this.f3065i.setFillType(FillType.EVEN_ODD);
        this.f3065i.moveTo(-this.f3064h, 0.0f);
        this.f3065i.rLineTo(-this.f3067k, 0.0f);
        this.f3065i.arcTo(rectF2, 180.0f, 90.0f, false);
        this.f3065i.arcTo(rectF, 270.0f, -90.0f, false);
        this.f3065i.close();
        float f = this.f3064h / (this.f3064h + this.f3067k);
        Paint paint = this.f3061e;
        RadialGradient radialGradient = new RadialGradient(0.0f, 0.0f, this.f3064h + this.f3067k, new int[]{this.f3071o, this.f3071o, this.f3072p}, new float[]{0.0f, f, 1.0f}, TileMode.CLAMP);
        paint.setShader(radialGradient);
        Paint paint2 = this.f3062f;
        LinearGradient linearGradient = new LinearGradient(0.0f, (-this.f3064h) + this.f3067k, 0.0f, (-this.f3064h) - this.f3067k, new int[]{this.f3071o, this.f3071o, this.f3072p}, new float[]{0.0f, 0.5f, 1.0f}, TileMode.CLAMP);
        paint2.setShader(linearGradient);
        this.f3062f.setAntiAlias(false);
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public float mo4343a() {
        return this.f3064h;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo4344a(float f) {
        if (f < 0.0f) {
            StringBuilder sb = new StringBuilder();
            sb.append("Invalid radius ");
            sb.append(f);
            sb.append(". Must be >= 0");
            throw new IllegalArgumentException(sb.toString());
        }
        float f2 = (float) ((int) (f + 0.5f));
        if (this.f3064h != f2) {
            this.f3064h = f2;
            this.f3070n = true;
            invalidateSelf();
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo4345a(ColorStateList colorStateList) {
        m4542b(colorStateList);
        invalidateSelf();
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo4346a(Rect rect) {
        getPadding(rect);
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo4347a(boolean z) {
        this.f3073q = z;
        invalidateSelf();
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: b */
    public float mo4348b() {
        return this.f3068l;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: b */
    public void mo4349b(float f) {
        m4539a(f, this.f3066j);
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: c */
    public float mo4350c() {
        return this.f3066j;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: c */
    public void mo4351c(float f) {
        m4539a(this.f3068l, f);
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: d */
    public float mo4352d() {
        return (Math.max(this.f3066j, this.f3064h + ((float) this.f3059c) + (this.f3066j / 2.0f)) * 2.0f) + ((this.f3066j + ((float) this.f3059c)) * 2.0f);
    }

    public void draw(Canvas canvas) {
        if (this.f3070n) {
            m4543b(getBounds());
            this.f3070n = false;
        }
        canvas.translate(0.0f, this.f3068l / 2.0f);
        m4540a(canvas);
        canvas.translate(0.0f, (-this.f3068l) / 2.0f);
        f3057a.mo3554a(canvas, this.f3063g, this.f3064h, this.f3060d);
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: e */
    public float mo4354e() {
        return (Math.max(this.f3066j, this.f3064h + ((float) this.f3059c) + ((this.f3066j * 1.5f) / 2.0f)) * 2.0f) + (((this.f3066j * 1.5f) + ((float) this.f3059c)) * 2.0f);
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: f */
    public ColorStateList mo4355f() {
        return this.f3069m;
    }

    public int getOpacity() {
        return -3;
    }

    public boolean getPadding(Rect rect) {
        int ceil = (int) Math.ceil((double) m4538a(this.f3066j, this.f3064h, this.f3073q));
        int ceil2 = (int) Math.ceil((double) m4541b(this.f3066j, this.f3064h, this.f3073q));
        rect.set(ceil2, ceil, ceil2, ceil);
        return true;
    }

    public boolean isStateful() {
        return (this.f3069m != null && this.f3069m.isStateful()) || super.isStateful();
    }

    /* access modifiers changed from: protected */
    public void onBoundsChange(Rect rect) {
        super.onBoundsChange(rect);
        this.f3070n = true;
    }

    /* access modifiers changed from: protected */
    public boolean onStateChange(int[] iArr) {
        int colorForState = this.f3069m.getColorForState(iArr, this.f3069m.getDefaultColor());
        if (this.f3060d.getColor() == colorForState) {
            return false;
        }
        this.f3060d.setColor(colorForState);
        this.f3070n = true;
        invalidateSelf();
        return true;
    }

    public void setAlpha(int i) {
        this.f3060d.setAlpha(i);
        this.f3061e.setAlpha(i);
        this.f3062f.setAlpha(i);
    }

    public void setColorFilter(ColorFilter colorFilter) {
        this.f3060d.setColorFilter(colorFilter);
    }
}
