package android.support.p031v7.widget;

import android.content.Context;
import android.content.res.Configuration;
import android.graphics.drawable.Drawable;
import android.support.p031v7.app.C0565a.C0568c;
import android.support.p031v7.p032a.C0540a.C0541a;
import android.support.p031v7.view.C0626a;
import android.support.p031v7.widget.C0787as.C0788a;
import android.text.TextUtils;
import android.text.TextUtils.TruncateAt;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Interpolator;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.BaseAdapter;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.Spinner;
import android.widget.TextView;

/* renamed from: android.support.v7.widget.bf */
public class C0856bf extends HorizontalScrollView implements OnItemSelectedListener {

    /* renamed from: j */
    private static final Interpolator f3083j = new DecelerateInterpolator();

    /* renamed from: a */
    Runnable f3084a;

    /* renamed from: b */
    C0787as f3085b;

    /* renamed from: c */
    int f3086c;

    /* renamed from: d */
    int f3087d;

    /* renamed from: e */
    private C0859b f3088e;

    /* renamed from: f */
    private Spinner f3089f;

    /* renamed from: g */
    private boolean f3090g;

    /* renamed from: h */
    private int f3091h;

    /* renamed from: i */
    private int f3092i;

    /* renamed from: android.support.v7.widget.bf$a */
    private class C0858a extends BaseAdapter {
        C0858a() {
        }

        public int getCount() {
            return C0856bf.this.f3085b.getChildCount();
        }

        public Object getItem(int i) {
            return ((C0860c) C0856bf.this.f3085b.getChildAt(i)).mo4389b();
        }

        public long getItemId(int i) {
            return (long) i;
        }

        public View getView(int i, View view, ViewGroup viewGroup) {
            if (view == null) {
                return C0856bf.this.mo4370a((C0568c) getItem(i), true);
            }
            ((C0860c) view).mo4388a((C0568c) getItem(i));
            return view;
        }
    }

    /* renamed from: android.support.v7.widget.bf$b */
    private class C0859b implements OnClickListener {
        C0859b() {
        }

        public void onClick(View view) {
            ((C0860c) view).mo4389b().mo2198d();
            int childCount = C0856bf.this.f3085b.getChildCount();
            for (int i = 0; i < childCount; i++) {
                View childAt = C0856bf.this.f3085b.getChildAt(i);
                childAt.setSelected(childAt == view);
            }
        }
    }

    /* renamed from: android.support.v7.widget.bf$c */
    private class C0860c extends LinearLayout {

        /* renamed from: b */
        private final int[] f3098b = {16842964};

        /* renamed from: c */
        private C0568c f3099c;

        /* renamed from: d */
        private TextView f3100d;

        /* renamed from: e */
        private ImageView f3101e;

        /* renamed from: f */
        private View f3102f;

        public C0860c(Context context, C0568c cVar, boolean z) {
            super(context, null, C0541a.actionBarTabStyle);
            this.f3099c = cVar;
            C0869bn a = C0869bn.m4638a(context, null, this.f3098b, C0541a.actionBarTabStyle, 0);
            if (a.mo4440g(0)) {
                setBackgroundDrawable(a.mo4426a(0));
            }
            a.mo4427a();
            if (z) {
                setGravity(8388627);
            }
            mo4387a();
        }

        /* renamed from: a */
        public void mo4387a() {
            C0568c cVar = this.f3099c;
            View c = cVar.mo2197c();
            CharSequence charSequence = null;
            if (c != null) {
                ViewParent parent = c.getParent();
                if (parent != this) {
                    if (parent != null) {
                        ((ViewGroup) parent).removeView(c);
                    }
                    addView(c);
                }
                this.f3102f = c;
                if (this.f3100d != null) {
                    this.f3100d.setVisibility(8);
                }
                if (this.f3101e != null) {
                    this.f3101e.setVisibility(8);
                    this.f3101e.setImageDrawable(null);
                }
            } else {
                if (this.f3102f != null) {
                    removeView(this.f3102f);
                    this.f3102f = null;
                }
                Drawable a = cVar.mo2195a();
                CharSequence b = cVar.mo2196b();
                if (a != null) {
                    if (this.f3101e == null) {
                        C0919p pVar = new C0919p(getContext());
                        LayoutParams layoutParams = new LayoutParams(-2, -2);
                        layoutParams.gravity = 16;
                        pVar.setLayoutParams(layoutParams);
                        addView(pVar, 0);
                        this.f3101e = pVar;
                    }
                    this.f3101e.setImageDrawable(a);
                    this.f3101e.setVisibility(0);
                } else if (this.f3101e != null) {
                    this.f3101e.setVisibility(8);
                    this.f3101e.setImageDrawable(null);
                }
                boolean z = !TextUtils.isEmpty(b);
                if (z) {
                    if (this.f3100d == null) {
                        C0936z zVar = new C0936z(getContext(), null, C0541a.actionBarTabTextStyle);
                        zVar.setEllipsize(TruncateAt.END);
                        LayoutParams layoutParams2 = new LayoutParams(-2, -2);
                        layoutParams2.gravity = 16;
                        zVar.setLayoutParams(layoutParams2);
                        addView(zVar);
                        this.f3100d = zVar;
                    }
                    this.f3100d.setText(b);
                    this.f3100d.setVisibility(0);
                } else if (this.f3100d != null) {
                    this.f3100d.setVisibility(8);
                    this.f3100d.setText(null);
                }
                if (this.f3101e != null) {
                    this.f3101e.setContentDescription(cVar.mo2199e());
                }
                if (!z) {
                    charSequence = cVar.mo2199e();
                }
                C0873bp.m4703a(this, charSequence);
            }
        }

        /* renamed from: a */
        public void mo4388a(C0568c cVar) {
            this.f3099c = cVar;
            mo4387a();
        }

        /* renamed from: b */
        public C0568c mo4389b() {
            return this.f3099c;
        }

        public void onInitializeAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
            super.onInitializeAccessibilityEvent(accessibilityEvent);
            accessibilityEvent.setClassName(C0568c.class.getName());
        }

        public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo accessibilityNodeInfo) {
            super.onInitializeAccessibilityNodeInfo(accessibilityNodeInfo);
            accessibilityNodeInfo.setClassName(C0568c.class.getName());
        }

        public void onMeasure(int i, int i2) {
            super.onMeasure(i, i2);
            if (C0856bf.this.f3086c > 0 && getMeasuredWidth() > C0856bf.this.f3086c) {
                super.onMeasure(MeasureSpec.makeMeasureSpec(C0856bf.this.f3086c, 1073741824), i2);
            }
        }

        public void setSelected(boolean z) {
            boolean z2 = isSelected() != z;
            super.setSelected(z);
            if (z2 && z) {
                sendAccessibilityEvent(4);
            }
        }
    }

    /* renamed from: a */
    private boolean m4569a() {
        return this.f3089f != null && this.f3089f.getParent() == this;
    }

    /* renamed from: b */
    private void m4570b() {
        if (!m4569a()) {
            if (this.f3089f == null) {
                this.f3089f = m4572d();
            }
            removeView(this.f3085b);
            addView(this.f3089f, new ViewGroup.LayoutParams(-2, -1));
            if (this.f3089f.getAdapter() == null) {
                this.f3089f.setAdapter(new C0858a());
            }
            if (this.f3084a != null) {
                removeCallbacks(this.f3084a);
                this.f3084a = null;
            }
            this.f3089f.setSelection(this.f3092i);
        }
    }

    /* renamed from: c */
    private boolean m4571c() {
        if (!m4569a()) {
            return false;
        }
        removeView(this.f3089f);
        addView(this.f3085b, new ViewGroup.LayoutParams(-2, -1));
        setTabSelected(this.f3089f.getSelectedItemPosition());
        return false;
    }

    /* renamed from: d */
    private Spinner m4572d() {
        C0927x xVar = new C0927x(getContext(), null, C0541a.actionDropDownStyle);
        xVar.setLayoutParams(new C0788a(-2, -1));
        xVar.setOnItemSelectedListener(this);
        return xVar;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public C0860c mo4370a(C0568c cVar, boolean z) {
        C0860c cVar2 = new C0860c(getContext(), cVar, z);
        if (z) {
            cVar2.setBackgroundDrawable(null);
            cVar2.setLayoutParams(new AbsListView.LayoutParams(-1, this.f3091h));
            return cVar2;
        }
        cVar2.setFocusable(true);
        if (this.f3088e == null) {
            this.f3088e = new C0859b();
        }
        cVar2.setOnClickListener(this.f3088e);
        return cVar2;
    }

    /* renamed from: a */
    public void mo4371a(int i) {
        final View childAt = this.f3085b.getChildAt(i);
        if (this.f3084a != null) {
            removeCallbacks(this.f3084a);
        }
        this.f3084a = new Runnable() {
            public void run() {
                C0856bf.this.smoothScrollTo(childAt.getLeft() - ((C0856bf.this.getWidth() - childAt.getWidth()) / 2), 0);
                C0856bf.this.f3084a = null;
            }
        };
        post(this.f3084a);
    }

    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (this.f3084a != null) {
            post(this.f3084a);
        }
    }

    /* access modifiers changed from: protected */
    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        C0626a a = C0626a.m2803a(getContext());
        setContentHeight(a.mo2495e());
        this.f3087d = a.mo2497g();
    }

    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        if (this.f3084a != null) {
            removeCallbacks(this.f3084a);
        }
    }

    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long j) {
        ((C0860c) view).mo4389b().mo2198d();
    }

    public void onMeasure(int i, int i2) {
        int i3;
        int mode = MeasureSpec.getMode(i);
        boolean z = true;
        boolean z2 = mode == 1073741824;
        setFillViewport(z2);
        int childCount = this.f3085b.getChildCount();
        if (childCount <= 1 || !(mode == 1073741824 || mode == Integer.MIN_VALUE)) {
            i3 = -1;
        } else {
            if (childCount > 2) {
                this.f3086c = (int) (((float) MeasureSpec.getSize(i)) * 0.4f);
            } else {
                this.f3086c = MeasureSpec.getSize(i) / 2;
            }
            i3 = Math.min(this.f3086c, this.f3087d);
        }
        this.f3086c = i3;
        int makeMeasureSpec = MeasureSpec.makeMeasureSpec(this.f3091h, 1073741824);
        if (z2 || !this.f3090g) {
            z = false;
        }
        if (z) {
            this.f3085b.measure(0, makeMeasureSpec);
            if (this.f3085b.getMeasuredWidth() > MeasureSpec.getSize(i)) {
                m4570b();
                int measuredWidth = getMeasuredWidth();
                super.onMeasure(i, makeMeasureSpec);
                int measuredWidth2 = getMeasuredWidth();
                if (z2 && measuredWidth != measuredWidth2) {
                    setTabSelected(this.f3092i);
                    return;
                }
            }
        }
        m4571c();
        int measuredWidth3 = getMeasuredWidth();
        super.onMeasure(i, makeMeasureSpec);
        int measuredWidth22 = getMeasuredWidth();
        if (z2) {
        }
    }

    public void onNothingSelected(AdapterView<?> adapterView) {
    }

    public void setAllowCollapse(boolean z) {
        this.f3090g = z;
    }

    public void setContentHeight(int i) {
        this.f3091h = i;
        requestLayout();
    }

    public void setTabSelected(int i) {
        this.f3092i = i;
        int childCount = this.f3085b.getChildCount();
        int i2 = 0;
        while (i2 < childCount) {
            View childAt = this.f3085b.getChildAt(i2);
            boolean z = i2 == i;
            childAt.setSelected(z);
            if (z) {
                mo4371a(i);
            }
            i2++;
        }
        if (this.f3089f != null && i >= 0) {
            this.f3089f.setSelection(i);
        }
    }
}
