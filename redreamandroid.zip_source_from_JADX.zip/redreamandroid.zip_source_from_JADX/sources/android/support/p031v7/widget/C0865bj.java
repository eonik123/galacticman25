package android.support.p031v7.widget;

import android.content.res.Resources.Theme;
import android.widget.SpinnerAdapter;

/* renamed from: android.support.v7.widget.bj */
public interface C0865bj extends SpinnerAdapter {
    /* renamed from: a */
    Theme mo4416a();

    /* renamed from: a */
    void mo4417a(Theme theme);
}
