package android.support.p031v7.widget;

import android.view.View;

/* renamed from: android.support.v7.widget.bt */
class C0879bt {

    /* renamed from: a */
    final C0881b f3190a;

    /* renamed from: b */
    C0880a f3191b = new C0880a();

    /* renamed from: android.support.v7.widget.bt$a */
    static class C0880a {

        /* renamed from: a */
        int f3192a = 0;

        /* renamed from: b */
        int f3193b;

        /* renamed from: c */
        int f3194c;

        /* renamed from: d */
        int f3195d;

        /* renamed from: e */
        int f3196e;

        C0880a() {
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public int mo4465a(int i, int i2) {
            if (i > i2) {
                return 1;
            }
            return i == i2 ? 2 : 4;
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public void mo4466a() {
            this.f3192a = 0;
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public void mo4467a(int i) {
            this.f3192a = i | this.f3192a;
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public void mo4468a(int i, int i2, int i3, int i4) {
            this.f3193b = i;
            this.f3194c = i2;
            this.f3195d = i3;
            this.f3196e = i4;
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: b */
        public boolean mo4469b() {
            if ((this.f3192a & 7) != 0 && (this.f3192a & (mo4465a(this.f3195d, this.f3193b) << 0)) == 0) {
                return false;
            }
            if ((this.f3192a & 112) != 0 && (this.f3192a & (mo4465a(this.f3195d, this.f3194c) << 4)) == 0) {
                return false;
            }
            if ((this.f3192a & 1792) == 0 || (this.f3192a & (mo4465a(this.f3196e, this.f3193b) << 8)) != 0) {
                return (this.f3192a & 28672) == 0 || (this.f3192a & (mo4465a(this.f3196e, this.f3194c) << 12)) != 0;
            }
            return false;
        }
    }

    /* renamed from: android.support.v7.widget.bt$b */
    interface C0881b {
        /* renamed from: a */
        int mo4139a();

        /* renamed from: a */
        int mo4140a(View view);

        /* renamed from: a */
        View mo4141a(int i);

        /* renamed from: b */
        int mo4142b();

        /* renamed from: b */
        int mo4143b(View view);
    }

    C0879bt(C0881b bVar) {
        this.f3190a = bVar;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public View mo4463a(int i, int i2, int i3, int i4) {
        int a = this.f3190a.mo4139a();
        int b = this.f3190a.mo4142b();
        int i5 = i2 > i ? 1 : -1;
        View view = null;
        while (i != i2) {
            View a2 = this.f3190a.mo4141a(i);
            this.f3191b.mo4468a(a, b, this.f3190a.mo4140a(a2), this.f3190a.mo4143b(a2));
            if (i3 != 0) {
                this.f3191b.mo4466a();
                this.f3191b.mo4467a(i3);
                if (this.f3191b.mo4469b()) {
                    return a2;
                }
            }
            if (i4 != 0) {
                this.f3191b.mo4466a();
                this.f3191b.mo4467a(i4);
                if (this.f3191b.mo4469b()) {
                    view = a2;
                }
            }
            i += i5;
        }
        return view;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public boolean mo4464a(View view, int i) {
        this.f3191b.mo4468a(this.f3190a.mo4139a(), this.f3190a.mo4142b(), this.f3190a.mo4140a(view), this.f3190a.mo4143b(view));
        if (i == 0) {
            return false;
        }
        this.f3191b.mo4466a();
        this.f3191b.mo4467a(i);
        return this.f3191b.mo4469b();
    }
}
