package android.support.p031v7.widget;

import android.content.Context;
import android.graphics.Rect;
import android.support.p031v7.widget.C0777ao.C0778a;
import android.util.AttributeSet;
import android.widget.LinearLayout;

/* renamed from: android.support.v7.widget.FitWindowsLinearLayout */
public class FitWindowsLinearLayout extends LinearLayout implements C0777ao {

    /* renamed from: a */
    private C0778a f2349a;

    public FitWindowsLinearLayout(Context context) {
        super(context);
    }

    public FitWindowsLinearLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    /* access modifiers changed from: protected */
    public boolean fitSystemWindows(Rect rect) {
        if (this.f2349a != null) {
            this.f2349a.mo2292a(rect);
        }
        return super.fitSystemWindows(rect);
    }

    public void setOnFitSystemWindowsListener(C0778a aVar) {
        this.f2349a = aVar;
    }
}
