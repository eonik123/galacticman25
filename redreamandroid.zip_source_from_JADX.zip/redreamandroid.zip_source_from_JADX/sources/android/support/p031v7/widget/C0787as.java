package android.support.p031v7.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.support.p018v4.p028h.C0480d;
import android.support.p018v4.p028h.C0495r;
import android.support.p031v7.p032a.C0540a.C0550j;
import android.util.AttributeSet;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewGroup.MarginLayoutParams;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

/* renamed from: android.support.v7.widget.as */
public class C0787as extends ViewGroup {

    /* renamed from: a */
    private boolean f2767a;

    /* renamed from: b */
    private int f2768b;

    /* renamed from: c */
    private int f2769c;

    /* renamed from: d */
    private int f2770d;

    /* renamed from: e */
    private int f2771e;

    /* renamed from: f */
    private int f2772f;

    /* renamed from: g */
    private float f2773g;

    /* renamed from: h */
    private boolean f2774h;

    /* renamed from: i */
    private int[] f2775i;

    /* renamed from: j */
    private int[] f2776j;

    /* renamed from: k */
    private Drawable f2777k;

    /* renamed from: l */
    private int f2778l;

    /* renamed from: m */
    private int f2779m;

    /* renamed from: n */
    private int f2780n;

    /* renamed from: o */
    private int f2781o;

    /* renamed from: android.support.v7.widget.as$a */
    public static class C0788a extends MarginLayoutParams {

        /* renamed from: g */
        public float f2782g;

        /* renamed from: h */
        public int f2783h;

        public C0788a(int i, int i2) {
            super(i, i2);
            this.f2783h = -1;
            this.f2782g = 0.0f;
        }

        public C0788a(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            this.f2783h = -1;
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, C0550j.LinearLayoutCompat_Layout);
            this.f2782g = obtainStyledAttributes.getFloat(C0550j.LinearLayoutCompat_Layout_android_layout_weight, 0.0f);
            this.f2783h = obtainStyledAttributes.getInt(C0550j.LinearLayoutCompat_Layout_android_layout_gravity, -1);
            obtainStyledAttributes.recycle();
        }

        public C0788a(LayoutParams layoutParams) {
            super(layoutParams);
            this.f2783h = -1;
        }
    }

    public C0787as(Context context) {
        this(context, null);
    }

    public C0787as(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public C0787as(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f2767a = true;
        this.f2768b = -1;
        this.f2769c = 0;
        this.f2771e = 8388659;
        C0869bn a = C0869bn.m4638a(context, attributeSet, C0550j.LinearLayoutCompat, i, 0);
        int a2 = a.mo4424a(C0550j.LinearLayoutCompat_android_orientation, -1);
        if (a2 >= 0) {
            setOrientation(a2);
        }
        int a3 = a.mo4424a(C0550j.LinearLayoutCompat_android_gravity, -1);
        if (a3 >= 0) {
            setGravity(a3);
        }
        boolean a4 = a.mo4428a(C0550j.LinearLayoutCompat_android_baselineAligned, true);
        if (!a4) {
            setBaselineAligned(a4);
        }
        this.f2773g = a.mo4423a(C0550j.LinearLayoutCompat_android_weightSum, -1.0f);
        this.f2768b = a.mo4424a(C0550j.LinearLayoutCompat_android_baselineAlignedChildIndex, -1);
        this.f2774h = a.mo4428a(C0550j.LinearLayoutCompat_measureWithLargestChild, false);
        setDividerDrawable(a.mo4426a(C0550j.LinearLayoutCompat_divider));
        this.f2780n = a.mo4424a(C0550j.LinearLayoutCompat_showDividers, 0);
        this.f2781o = a.mo4435e(C0550j.LinearLayoutCompat_dividerPadding, 0);
        a.mo4427a();
    }

    /* renamed from: a */
    private void m3912a(View view, int i, int i2, int i3, int i4) {
        view.layout(i, i2, i3 + i, i4 + i2);
    }

    /* renamed from: c */
    private void m3913c(int i, int i2) {
        int makeMeasureSpec = MeasureSpec.makeMeasureSpec(getMeasuredWidth(), 1073741824);
        for (int i3 = 0; i3 < i; i3++) {
            View b = mo3737b(i3);
            if (b.getVisibility() != 8) {
                C0788a aVar = (C0788a) b.getLayoutParams();
                if (aVar.width == -1) {
                    int i4 = aVar.height;
                    aVar.height = b.getMeasuredHeight();
                    measureChildWithMargins(b, makeMeasureSpec, 0, i2, 0);
                    aVar.height = i4;
                }
            }
        }
    }

    /* renamed from: d */
    private void m3914d(int i, int i2) {
        int makeMeasureSpec = MeasureSpec.makeMeasureSpec(getMeasuredHeight(), 1073741824);
        for (int i3 = 0; i3 < i; i3++) {
            View b = mo3737b(i3);
            if (b.getVisibility() != 8) {
                C0788a aVar = (C0788a) b.getLayoutParams();
                if (aVar.height == -1) {
                    int i4 = aVar.width;
                    aVar.width = b.getMeasuredWidth();
                    measureChildWithMargins(b, i2, 0, makeMeasureSpec, 0);
                    aVar.width = i4;
                }
            }
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public int mo3729a(View view) {
        return 0;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public int mo3730a(View view, int i) {
        return 0;
    }

    /* access modifiers changed from: 0000 */
    /* JADX WARNING: Code restructure failed: missing block: B:126:0x02e1, code lost:
        if (r15 > 0) goto L_0x02ef;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:129:0x02ec, code lost:
        if (r15 < 0) goto L_0x02ee;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:130:0x02ee, code lost:
        r15 = 0;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:131:0x02ef, code lost:
        r13.measure(r2, android.view.View.MeasureSpec.makeMeasureSpec(r15, r10));
        r6 = android.view.View.combineMeasuredStates(r6, r13.getMeasuredState() & -256);
     */
    /* JADX WARNING: Removed duplicated region for block: B:141:0x032b  */
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void mo3731a(int r41, int r42) {
        /*
            r40 = this;
            r7 = r40
            r8 = r41
            r9 = r42
            r10 = 0
            r7.f2772f = r10
            int r11 = r40.getVirtualChildCount()
            int r12 = android.view.View.MeasureSpec.getMode(r41)
            int r13 = android.view.View.MeasureSpec.getMode(r42)
            int r14 = r7.f2768b
            boolean r15 = r7.f2774h
            r16 = 0
            r17 = 1
            r1 = r10
            r2 = r1
            r3 = r2
            r4 = r3
            r5 = r4
            r6 = r5
            r18 = r6
            r20 = r18
            r0 = r16
            r19 = r17
        L_0x002b:
            r10 = 8
            r22 = r4
            if (r6 >= r11) goto L_0x0199
            android.view.View r4 = r7.mo3737b(r6)
            if (r4 != 0) goto L_0x0048
            int r4 = r7.f2772f
            int r10 = r7.mo3743d(r6)
            int r4 = r4 + r10
            r7.f2772f = r4
            r31 = r11
            r28 = r13
            r4 = r22
            goto L_0x018f
        L_0x0048:
            r24 = r1
            int r1 = r4.getVisibility()
            if (r1 != r10) goto L_0x005f
            int r1 = r7.mo3730a(r4, r6)
            int r6 = r6 + r1
            r31 = r11
            r28 = r13
            r4 = r22
            r1 = r24
            goto L_0x018f
        L_0x005f:
            boolean r1 = r7.mo3742c(r6)
            if (r1 == 0) goto L_0x006c
            int r1 = r7.f2772f
            int r10 = r7.f2779m
            int r1 = r1 + r10
            r7.f2772f = r1
        L_0x006c:
            android.view.ViewGroup$LayoutParams r1 = r4.getLayoutParams()
            r10 = r1
            android.support.v7.widget.as$a r10 = (android.support.p031v7.widget.C0787as.C0788a) r10
            float r1 = r10.f2782g
            float r25 = r0 + r1
            r1 = 1073741824(0x40000000, float:2.0)
            if (r13 != r1) goto L_0x00a7
            int r0 = r10.height
            if (r0 != 0) goto L_0x00a7
            float r0 = r10.f2782g
            int r0 = (r0 > r16 ? 1 : (r0 == r16 ? 0 : -1))
            if (r0 <= 0) goto L_0x00a7
            int r0 = r7.f2772f
            int r1 = r10.topMargin
            int r1 = r1 + r0
            r26 = r2
            int r2 = r10.bottomMargin
            int r1 = r1 + r2
            int r0 = java.lang.Math.max(r0, r1)
            r7.f2772f = r0
            r8 = r4
            r34 = r5
            r31 = r11
            r28 = r13
            r18 = r17
            r32 = r22
            r33 = r24
            r30 = r26
            r13 = r6
            goto L_0x0113
        L_0x00a7:
            r26 = r2
            int r0 = r10.height
            if (r0 != 0) goto L_0x00b8
            float r0 = r10.f2782g
            int r0 = (r0 > r16 ? 1 : (r0 == r16 ? 0 : -1))
            if (r0 <= 0) goto L_0x00b8
            r0 = -2
            r10.height = r0
            r2 = 0
            goto L_0x00ba
        L_0x00b8:
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
        L_0x00ba:
            r23 = 0
            int r0 = (r25 > r16 ? 1 : (r25 == r16 ? 0 : -1))
            if (r0 != 0) goto L_0x00c5
            int r0 = r7.f2772f
            r27 = r0
            goto L_0x00c7
        L_0x00c5:
            r27 = 0
        L_0x00c7:
            r0 = r7
            r28 = r13
            r13 = r24
            r24 = 1073741824(0x40000000, float:2.0)
            r1 = r4
            r29 = r2
            r30 = r26
            r2 = r6
            r31 = r11
            r11 = r3
            r3 = r8
            r8 = r4
            r33 = r13
            r32 = r22
            r13 = r24
            r4 = r23
            r34 = r5
            r5 = r9
            r13 = r6
            r6 = r27
            r0.mo3735a(r1, r2, r3, r4, r5, r6)
            r0 = r29
            r1 = -2147483648(0xffffffff80000000, float:-0.0)
            if (r0 == r1) goto L_0x00f2
            r10.height = r0
        L_0x00f2:
            int r0 = r8.getMeasuredHeight()
            int r1 = r7.f2772f
            int r2 = r1 + r0
            int r3 = r10.topMargin
            int r2 = r2 + r3
            int r3 = r10.bottomMargin
            int r2 = r2 + r3
            int r3 = r7.mo3736b(r8)
            int r2 = r2 + r3
            int r1 = java.lang.Math.max(r1, r2)
            r7.f2772f = r1
            if (r15 == 0) goto L_0x0112
            int r3 = java.lang.Math.max(r0, r11)
            goto L_0x0113
        L_0x0112:
            r3 = r11
        L_0x0113:
            if (r14 < 0) goto L_0x011d
            int r6 = r13 + 1
            if (r14 != r6) goto L_0x011d
            int r0 = r7.f2772f
            r7.f2769c = r0
        L_0x011d:
            if (r13 >= r14) goto L_0x012d
            float r0 = r10.f2782g
            int r0 = (r0 > r16 ? 1 : (r0 == r16 ? 0 : -1))
            if (r0 <= 0) goto L_0x012d
            java.lang.RuntimeException r0 = new java.lang.RuntimeException
            java.lang.String r1 = "A child of LinearLayout with index less than mBaselineAlignedChildIndex has weight > 0, which won't work.  Either remove the weight, or don't set mBaselineAlignedChildIndex."
            r0.<init>(r1)
            throw r0
        L_0x012d:
            r0 = 1073741824(0x40000000, float:2.0)
            if (r12 == r0) goto L_0x013b
            int r0 = r10.width
            r1 = -1
            if (r0 != r1) goto L_0x013b
            r0 = r17
            r20 = r0
            goto L_0x013c
        L_0x013b:
            r0 = 0
        L_0x013c:
            int r1 = r10.leftMargin
            int r2 = r10.rightMargin
            int r1 = r1 + r2
            int r2 = r8.getMeasuredWidth()
            int r2 = r2 + r1
            r4 = r30
            int r4 = java.lang.Math.max(r4, r2)
            int r5 = r8.getMeasuredState()
            r6 = r33
            int r5 = android.view.View.combineMeasuredStates(r6, r5)
            if (r19 == 0) goto L_0x0160
            int r6 = r10.width
            r11 = -1
            if (r6 != r11) goto L_0x0160
            r6 = r17
            goto L_0x0161
        L_0x0160:
            r6 = 0
        L_0x0161:
            float r10 = r10.f2782g
            int r10 = (r10 > r16 ? 1 : (r10 == r16 ? 0 : -1))
            if (r10 <= 0) goto L_0x0176
            if (r0 == 0) goto L_0x016c
        L_0x0169:
            r10 = r32
            goto L_0x016e
        L_0x016c:
            r1 = r2
            goto L_0x0169
        L_0x016e:
            int r0 = java.lang.Math.max(r10, r1)
            r10 = r0
            r0 = r34
            goto L_0x0181
        L_0x0176:
            r10 = r32
            if (r0 == 0) goto L_0x017b
            r2 = r1
        L_0x017b:
            r1 = r34
            int r0 = java.lang.Math.max(r1, r2)
        L_0x0181:
            int r1 = r7.mo3730a(r8, r13)
            int r1 = r1 + r13
            r2 = r4
            r19 = r6
            r4 = r10
            r6 = r1
            r1 = r5
            r5 = r0
            r0 = r25
        L_0x018f:
            int r6 = r6 + 1
            r13 = r28
            r11 = r31
            r8 = r41
            goto L_0x002b
        L_0x0199:
            r6 = r1
            r4 = r2
            r1 = r5
            r31 = r11
            r28 = r13
            r2 = r22
            r11 = r3
            int r3 = r7.f2772f
            if (r3 <= 0) goto L_0x01b7
            r3 = r31
            boolean r5 = r7.mo3742c(r3)
            if (r5 == 0) goto L_0x01b9
            int r5 = r7.f2772f
            int r8 = r7.f2779m
            int r5 = r5 + r8
            r7.f2772f = r5
            goto L_0x01b9
        L_0x01b7:
            r3 = r31
        L_0x01b9:
            if (r15 == 0) goto L_0x0212
            r5 = r28
            r8 = -2147483648(0xffffffff80000000, float:-0.0)
            if (r5 == r8) goto L_0x01c7
            if (r5 != 0) goto L_0x01c4
            goto L_0x01c7
        L_0x01c4:
            r35 = r4
            goto L_0x0216
        L_0x01c7:
            r8 = 0
            r7.f2772f = r8
            r8 = 0
        L_0x01cb:
            if (r8 >= r3) goto L_0x01c4
            android.view.View r13 = r7.mo3737b(r8)
            if (r13 != 0) goto L_0x01dd
            int r13 = r7.f2772f
            int r14 = r7.mo3743d(r8)
            int r13 = r13 + r14
            r7.f2772f = r13
            goto L_0x01e8
        L_0x01dd:
            int r14 = r13.getVisibility()
            if (r14 != r10) goto L_0x01eb
            int r13 = r7.mo3730a(r13, r8)
            int r8 = r8 + r13
        L_0x01e8:
            r35 = r4
            goto L_0x020b
        L_0x01eb:
            android.view.ViewGroup$LayoutParams r14 = r13.getLayoutParams()
            android.support.v7.widget.as$a r14 = (android.support.p031v7.widget.C0787as.C0788a) r14
            int r10 = r7.f2772f
            int r21 = r10 + r11
            r35 = r4
            int r4 = r14.topMargin
            int r21 = r21 + r4
            int r4 = r14.bottomMargin
            int r21 = r21 + r4
            int r4 = r7.mo3736b(r13)
            int r4 = r21 + r4
            int r4 = java.lang.Math.max(r10, r4)
            r7.f2772f = r4
        L_0x020b:
            int r8 = r8 + 1
            r4 = r35
            r10 = 8
            goto L_0x01cb
        L_0x0212:
            r35 = r4
            r5 = r28
        L_0x0216:
            int r4 = r7.f2772f
            int r8 = r40.getPaddingTop()
            int r10 = r40.getPaddingBottom()
            int r8 = r8 + r10
            int r4 = r4 + r8
            r7.f2772f = r4
            int r4 = r7.f2772f
            int r8 = r40.getSuggestedMinimumHeight()
            int r4 = java.lang.Math.max(r4, r8)
            r8 = 0
            int r4 = android.view.View.resolveSizeAndState(r4, r9, r8)
            r8 = 16777215(0xffffff, float:2.3509886E-38)
            r8 = r8 & r4
            int r10 = r7.f2772f
            int r8 = r8 - r10
            if (r18 != 0) goto L_0x0285
            if (r8 == 0) goto L_0x0243
            int r10 = (r0 > r16 ? 1 : (r0 == r16 ? 0 : -1))
            if (r10 <= 0) goto L_0x0243
            goto L_0x0285
        L_0x0243:
            int r0 = java.lang.Math.max(r1, r2)
            if (r15 == 0) goto L_0x027f
            r1 = 1073741824(0x40000000, float:2.0)
            if (r5 == r1) goto L_0x027f
            r1 = 0
        L_0x024e:
            if (r1 >= r3) goto L_0x027f
            android.view.View r2 = r7.mo3737b(r1)
            if (r2 == 0) goto L_0x027c
            int r5 = r2.getVisibility()
            r8 = 8
            if (r5 != r8) goto L_0x025f
            goto L_0x027c
        L_0x025f:
            android.view.ViewGroup$LayoutParams r5 = r2.getLayoutParams()
            android.support.v7.widget.as$a r5 = (android.support.p031v7.widget.C0787as.C0788a) r5
            float r5 = r5.f2782g
            int r5 = (r5 > r16 ? 1 : (r5 == r16 ? 0 : -1))
            if (r5 <= 0) goto L_0x027c
            int r5 = r2.getMeasuredWidth()
            r8 = 1073741824(0x40000000, float:2.0)
            int r5 = android.view.View.MeasureSpec.makeMeasureSpec(r5, r8)
            int r10 = android.view.View.MeasureSpec.makeMeasureSpec(r11, r8)
            r2.measure(r5, r10)
        L_0x027c:
            int r1 = r1 + 1
            goto L_0x024e
        L_0x027f:
            r1 = r35
            r11 = r41
            goto L_0x0371
        L_0x0285:
            float r2 = r7.f2773g
            int r2 = (r2 > r16 ? 1 : (r2 == r16 ? 0 : -1))
            if (r2 <= 0) goto L_0x028d
            float r0 = r7.f2773g
        L_0x028d:
            r2 = 0
            r7.f2772f = r2
            r11 = r0
            r0 = r2
            r10 = r8
            r8 = r1
            r1 = r35
        L_0x0296:
            if (r0 >= r3) goto L_0x0360
            android.view.View r13 = r7.mo3737b(r0)
            int r14 = r13.getVisibility()
            r15 = 8
            if (r14 != r15) goto L_0x02aa
            r37 = r11
            r11 = r41
            goto L_0x0359
        L_0x02aa:
            android.view.ViewGroup$LayoutParams r14 = r13.getLayoutParams()
            android.support.v7.widget.as$a r14 = (android.support.p031v7.widget.C0787as.C0788a) r14
            float r2 = r14.f2782g
            int r18 = (r2 > r16 ? 1 : (r2 == r16 ? 0 : -1))
            if (r18 <= 0) goto L_0x0301
            float r15 = (float) r10
            float r15 = r15 * r2
            float r15 = r15 / r11
            int r15 = (int) r15
            float r11 = r11 - r2
            int r10 = r10 - r15
            int r2 = r40.getPaddingLeft()
            int r18 = r40.getPaddingRight()
            int r2 = r2 + r18
            r36 = r10
            int r10 = r14.leftMargin
            int r2 = r2 + r10
            int r10 = r14.rightMargin
            int r2 = r2 + r10
            int r10 = r14.width
            r37 = r11
            r11 = r41
            int r2 = getChildMeasureSpec(r11, r2, r10)
            int r10 = r14.height
            if (r10 != 0) goto L_0x02e4
            r10 = 1073741824(0x40000000, float:2.0)
            if (r5 == r10) goto L_0x02e1
            goto L_0x02e6
        L_0x02e1:
            if (r15 <= 0) goto L_0x02ee
            goto L_0x02ef
        L_0x02e4:
            r10 = 1073741824(0x40000000, float:2.0)
        L_0x02e6:
            int r18 = r13.getMeasuredHeight()
            int r15 = r18 + r15
            if (r15 >= 0) goto L_0x02ef
        L_0x02ee:
            r15 = 0
        L_0x02ef:
            int r15 = android.view.View.MeasureSpec.makeMeasureSpec(r15, r10)
            r13.measure(r2, r15)
            int r2 = r13.getMeasuredState()
            r2 = r2 & -256(0xffffffffffffff00, float:NaN)
            int r6 = android.view.View.combineMeasuredStates(r6, r2)
            goto L_0x0308
        L_0x0301:
            r2 = r11
            r11 = r41
            r37 = r2
            r36 = r10
        L_0x0308:
            int r2 = r14.leftMargin
            int r10 = r14.rightMargin
            int r2 = r2 + r10
            int r10 = r13.getMeasuredWidth()
            int r10 = r10 + r2
            int r1 = java.lang.Math.max(r1, r10)
            r15 = 1073741824(0x40000000, float:2.0)
            if (r12 == r15) goto L_0x0324
            int r15 = r14.width
            r38 = r1
            r1 = -1
            if (r15 != r1) goto L_0x0327
            r15 = r17
            goto L_0x0328
        L_0x0324:
            r38 = r1
            r1 = -1
        L_0x0327:
            r15 = 0
        L_0x0328:
            if (r15 == 0) goto L_0x032b
            goto L_0x032c
        L_0x032b:
            r2 = r10
        L_0x032c:
            int r2 = java.lang.Math.max(r8, r2)
            if (r19 == 0) goto L_0x0339
            int r8 = r14.width
            if (r8 != r1) goto L_0x0339
            r8 = r17
            goto L_0x033a
        L_0x0339:
            r8 = 0
        L_0x033a:
            int r10 = r7.f2772f
            int r15 = r13.getMeasuredHeight()
            int r15 = r15 + r10
            int r1 = r14.topMargin
            int r15 = r15 + r1
            int r1 = r14.bottomMargin
            int r15 = r15 + r1
            int r1 = r7.mo3736b(r13)
            int r15 = r15 + r1
            int r1 = java.lang.Math.max(r10, r15)
            r7.f2772f = r1
            r19 = r8
            r10 = r36
            r1 = r38
            r8 = r2
        L_0x0359:
            int r0 = r0 + 1
            r11 = r37
            r2 = 0
            goto L_0x0296
        L_0x0360:
            r11 = r41
            int r0 = r7.f2772f
            int r2 = r40.getPaddingTop()
            int r5 = r40.getPaddingBottom()
            int r2 = r2 + r5
            int r0 = r0 + r2
            r7.f2772f = r0
            r0 = r8
        L_0x0371:
            if (r19 != 0) goto L_0x0378
            r2 = 1073741824(0x40000000, float:2.0)
            if (r12 == r2) goto L_0x0378
            goto L_0x0379
        L_0x0378:
            r0 = r1
        L_0x0379:
            int r1 = r40.getPaddingLeft()
            int r2 = r40.getPaddingRight()
            int r1 = r1 + r2
            int r0 = r0 + r1
            int r1 = r40.getSuggestedMinimumWidth()
            int r0 = java.lang.Math.max(r0, r1)
            int r0 = android.view.View.resolveSizeAndState(r0, r11, r6)
            r7.setMeasuredDimension(r0, r4)
            if (r20 == 0) goto L_0x0397
            r7.m3913c(r3, r9)
        L_0x0397:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.p031v7.widget.C0787as.mo3731a(int, int):void");
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo3732a(int i, int i2, int i3, int i4) {
        int i5;
        int i6;
        int i7;
        int paddingLeft = getPaddingLeft();
        int i8 = i3 - i;
        int paddingRight = i8 - getPaddingRight();
        int paddingRight2 = (i8 - paddingLeft) - getPaddingRight();
        int virtualChildCount = getVirtualChildCount();
        int i9 = this.f2771e & 112;
        int i10 = this.f2771e & 8388615;
        int i11 = i9 != 16 ? i9 != 80 ? getPaddingTop() : ((getPaddingTop() + i4) - i2) - this.f2772f : (((i4 - i2) - this.f2772f) / 2) + getPaddingTop();
        int i12 = 0;
        while (i12 < virtualChildCount) {
            View b = mo3737b(i12);
            if (b == null) {
                i11 += mo3743d(i12);
            } else if (b.getVisibility() != 8) {
                int measuredWidth = b.getMeasuredWidth();
                int measuredHeight = b.getMeasuredHeight();
                C0788a aVar = (C0788a) b.getLayoutParams();
                int i13 = aVar.f2783h;
                if (i13 < 0) {
                    i13 = i10;
                }
                int a = C0480d.m2070a(i13, C0495r.m2149f(this)) & 7;
                if (a == 1) {
                    i6 = ((paddingRight2 - measuredWidth) / 2) + paddingLeft + aVar.leftMargin;
                    i7 = i6 - aVar.rightMargin;
                } else if (a != 5) {
                    i7 = aVar.leftMargin + paddingLeft;
                } else {
                    i6 = paddingRight - measuredWidth;
                    i7 = i6 - aVar.rightMargin;
                }
                int i14 = i7;
                if (mo3742c(i12)) {
                    i11 += this.f2779m;
                }
                int i15 = i11 + aVar.topMargin;
                C0788a aVar2 = aVar;
                m3912a(b, i14, i15 + mo3729a(b), measuredWidth, measuredHeight);
                i12 += mo3730a(b, i12);
                i11 = i15 + measuredHeight + aVar2.bottomMargin + mo3736b(b);
                i5 = 1;
                i12 += i5;
            }
            i5 = 1;
            i12 += i5;
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo3733a(Canvas canvas) {
        int i;
        int virtualChildCount = getVirtualChildCount();
        for (int i2 = 0; i2 < virtualChildCount; i2++) {
            View b = mo3737b(i2);
            if (!(b == null || b.getVisibility() == 8 || !mo3742c(i2))) {
                mo3734a(canvas, (b.getTop() - ((C0788a) b.getLayoutParams()).topMargin) - this.f2779m);
            }
        }
        if (mo3742c(virtualChildCount)) {
            View b2 = mo3737b(virtualChildCount - 1);
            if (b2 == null) {
                i = (getHeight() - getPaddingBottom()) - this.f2779m;
            } else {
                i = b2.getBottom() + ((C0788a) b2.getLayoutParams()).bottomMargin;
            }
            mo3734a(canvas, i);
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo3734a(Canvas canvas, int i) {
        this.f2777k.setBounds(getPaddingLeft() + this.f2781o, i, (getWidth() - getPaddingRight()) - this.f2781o, this.f2779m + i);
        this.f2777k.draw(canvas);
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo3735a(View view, int i, int i2, int i3, int i4, int i5) {
        measureChildWithMargins(view, i2, i3, i4, i5);
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: b */
    public int mo3736b(View view) {
        return 0;
    }

    /* renamed from: b */
    public C0788a generateLayoutParams(AttributeSet attributeSet) {
        return new C0788a(getContext(), attributeSet);
    }

    /* access modifiers changed from: protected */
    /* renamed from: b */
    public C0788a generateLayoutParams(LayoutParams layoutParams) {
        return new C0788a(layoutParams);
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: b */
    public View mo3737b(int i) {
        return getChildAt(i);
    }

    /* access modifiers changed from: 0000 */
    /* JADX WARNING: Code restructure failed: missing block: B:156:0x039e, code lost:
        if (r4 > 0) goto L_0x03ac;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:159:0x03a9, code lost:
        if (r4 < 0) goto L_0x03ab;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:160:0x03ab, code lost:
        r4 = 0;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:161:0x03ac, code lost:
        r14.measure(android.view.View.MeasureSpec.makeMeasureSpec(r4, r9), r2);
        r6 = android.view.View.combineMeasuredStates(r6, r14.getMeasuredState() & -16777216);
        r2 = r37;
        r4 = r38;
     */
    /* JADX WARNING: Removed duplicated region for block: B:183:0x0433  */
    /* JADX WARNING: Removed duplicated region for block: B:63:0x0185  */
    /* JADX WARNING: Removed duplicated region for block: B:78:0x01c6  */
    /* JADX WARNING: Removed duplicated region for block: B:83:0x01d4  */
    /* renamed from: b */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void mo3738b(int r42, int r43) {
        /*
            r41 = this;
            r7 = r41
            r8 = r42
            r9 = r43
            r10 = 0
            r7.f2772f = r10
            int r11 = r41.getVirtualChildCount()
            int r12 = android.view.View.MeasureSpec.getMode(r42)
            int r13 = android.view.View.MeasureSpec.getMode(r43)
            int[] r0 = r7.f2775i
            r14 = 4
            if (r0 == 0) goto L_0x001e
            int[] r0 = r7.f2776j
            if (r0 != 0) goto L_0x0026
        L_0x001e:
            int[] r0 = new int[r14]
            r7.f2775i = r0
            int[] r0 = new int[r14]
            r7.f2776j = r0
        L_0x0026:
            int[] r15 = r7.f2775i
            int[] r6 = r7.f2776j
            r16 = 3
            r5 = -1
            r15[r16] = r5
            r17 = 2
            r15[r17] = r5
            r18 = 1
            r15[r18] = r5
            r15[r10] = r5
            r6[r16] = r5
            r6[r17] = r5
            r6[r18] = r5
            r6[r10] = r5
            boolean r4 = r7.f2767a
            boolean r3 = r7.f2774h
            r2 = 1073741824(0x40000000, float:2.0)
            if (r12 != r2) goto L_0x004c
            r19 = r18
            goto L_0x004e
        L_0x004c:
            r19 = r10
        L_0x004e:
            r20 = 0
            r1 = r10
            r14 = r1
            r21 = r14
            r22 = r21
            r23 = r22
            r24 = r23
            r25 = r24
            r27 = r25
            r26 = r18
            r0 = r20
        L_0x0062:
            r28 = r6
            r5 = 8
            if (r1 >= r11) goto L_0x0201
            android.view.View r6 = r7.mo3737b(r1)
            if (r6 != 0) goto L_0x0081
            int r5 = r7.f2772f
            int r6 = r7.mo3743d(r1)
            int r5 = r5 + r6
            r7.f2772f = r5
        L_0x0077:
            r30 = r0
            r0 = r1
            r1 = r2
            r31 = r3
            r35 = r4
            goto L_0x01ed
        L_0x0081:
            int r10 = r6.getVisibility()
            if (r10 != r5) goto L_0x008d
            int r5 = r7.mo3730a(r6, r1)
            int r1 = r1 + r5
            goto L_0x0077
        L_0x008d:
            boolean r5 = r7.mo3742c(r1)
            if (r5 == 0) goto L_0x009a
            int r5 = r7.f2772f
            int r10 = r7.f2778l
            int r5 = r5 + r10
            r7.f2772f = r5
        L_0x009a:
            android.view.ViewGroup$LayoutParams r5 = r6.getLayoutParams()
            r10 = r5
            android.support.v7.widget.as$a r10 = (android.support.p031v7.widget.C0787as.C0788a) r10
            float r5 = r10.f2782g
            float r30 = r0 + r5
            if (r12 != r2) goto L_0x00ef
            int r0 = r10.width
            if (r0 != 0) goto L_0x00ef
            float r0 = r10.f2782g
            int r0 = (r0 > r20 ? 1 : (r0 == r20 ? 0 : -1))
            if (r0 <= 0) goto L_0x00ef
            if (r19 == 0) goto L_0x00be
            int r0 = r7.f2772f
            int r5 = r10.leftMargin
            int r2 = r10.rightMargin
            int r5 = r5 + r2
            int r0 = r0 + r5
        L_0x00bb:
            r7.f2772f = r0
            goto L_0x00cb
        L_0x00be:
            int r0 = r7.f2772f
            int r2 = r10.leftMargin
            int r2 = r2 + r0
            int r5 = r10.rightMargin
            int r2 = r2 + r5
            int r0 = java.lang.Math.max(r0, r2)
            goto L_0x00bb
        L_0x00cb:
            if (r4 == 0) goto L_0x00e0
            r0 = 0
            int r2 = android.view.View.MeasureSpec.makeMeasureSpec(r0, r0)
            r6.measure(r2, r2)
            r33 = r1
            r31 = r3
            r35 = r4
            r8 = r6
            r29 = -2
            goto L_0x0160
        L_0x00e0:
            r33 = r1
            r31 = r3
            r35 = r4
            r8 = r6
            r22 = r18
            r1 = 1073741824(0x40000000, float:2.0)
            r29 = -2
            goto L_0x0162
        L_0x00ef:
            int r0 = r10.width
            if (r0 != 0) goto L_0x00fe
            float r0 = r10.f2782g
            int r0 = (r0 > r20 ? 1 : (r0 == r20 ? 0 : -1))
            if (r0 <= 0) goto L_0x00fe
            r5 = -2
            r10.width = r5
            r2 = 0
            goto L_0x0101
        L_0x00fe:
            r5 = -2
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
        L_0x0101:
            int r0 = (r30 > r20 ? 1 : (r30 == r20 ? 0 : -1))
            if (r0 != 0) goto L_0x010a
            int r0 = r7.f2772f
            r29 = r0
            goto L_0x010c
        L_0x010a:
            r29 = 0
        L_0x010c:
            r32 = 0
            r0 = r7
            r33 = r1
            r1 = r6
            r34 = r2
            r2 = r33
            r31 = r3
            r3 = r8
            r35 = r4
            r4 = r29
            r29 = r5
            r8 = -1
            r5 = r9
            r8 = r6
            r9 = -2147483648(0xffffffff80000000, float:-0.0)
            r6 = r32
            r0.mo3735a(r1, r2, r3, r4, r5, r6)
            r0 = r34
            if (r0 == r9) goto L_0x012f
            r10.width = r0
        L_0x012f:
            int r0 = r8.getMeasuredWidth()
            if (r19 == 0) goto L_0x0146
            int r1 = r7.f2772f
            int r2 = r10.leftMargin
            int r2 = r2 + r0
            int r3 = r10.rightMargin
            int r2 = r2 + r3
            int r3 = r7.mo3736b(r8)
            int r2 = r2 + r3
            int r1 = r1 + r2
        L_0x0143:
            r7.f2772f = r1
            goto L_0x015a
        L_0x0146:
            int r1 = r7.f2772f
            int r2 = r1 + r0
            int r3 = r10.leftMargin
            int r2 = r2 + r3
            int r3 = r10.rightMargin
            int r2 = r2 + r3
            int r3 = r7.mo3736b(r8)
            int r2 = r2 + r3
            int r1 = java.lang.Math.max(r1, r2)
            goto L_0x0143
        L_0x015a:
            if (r31 == 0) goto L_0x0160
            int r14 = java.lang.Math.max(r0, r14)
        L_0x0160:
            r1 = 1073741824(0x40000000, float:2.0)
        L_0x0162:
            if (r13 == r1) goto L_0x016e
            int r0 = r10.height
            r2 = -1
            if (r0 != r2) goto L_0x016e
            r0 = r18
            r27 = r0
            goto L_0x016f
        L_0x016e:
            r0 = 0
        L_0x016f:
            int r2 = r10.topMargin
            int r3 = r10.bottomMargin
            int r2 = r2 + r3
            int r3 = r8.getMeasuredHeight()
            int r3 = r3 + r2
            int r4 = r8.getMeasuredState()
            r6 = r25
            int r4 = android.view.View.combineMeasuredStates(r6, r4)
            if (r35 == 0) goto L_0x01af
            int r5 = r8.getBaseline()
            r6 = -1
            if (r5 == r6) goto L_0x01af
            int r6 = r10.f2783h
            if (r6 >= 0) goto L_0x0193
            int r6 = r7.f2771e
            goto L_0x0195
        L_0x0193:
            int r6 = r10.f2783h
        L_0x0195:
            r6 = r6 & 112(0x70, float:1.57E-43)
            r9 = 4
            int r6 = r6 >> r9
            r6 = r6 & -2
            int r6 = r6 >> 1
            r9 = r15[r6]
            int r9 = java.lang.Math.max(r9, r5)
            r15[r6] = r9
            r9 = r28[r6]
            int r5 = r3 - r5
            int r5 = java.lang.Math.max(r9, r5)
            r28[r6] = r5
        L_0x01af:
            r5 = r21
            int r5 = java.lang.Math.max(r5, r3)
            if (r26 == 0) goto L_0x01bf
            int r6 = r10.height
            r9 = -1
            if (r6 != r9) goto L_0x01bf
            r6 = r18
            goto L_0x01c0
        L_0x01bf:
            r6 = 0
        L_0x01c0:
            float r9 = r10.f2782g
            int r9 = (r9 > r20 ? 1 : (r9 == r20 ? 0 : -1))
            if (r9 <= 0) goto L_0x01d4
            if (r0 == 0) goto L_0x01cb
        L_0x01c8:
            r10 = r24
            goto L_0x01cd
        L_0x01cb:
            r2 = r3
            goto L_0x01c8
        L_0x01cd:
            int r24 = java.lang.Math.max(r10, r2)
        L_0x01d1:
            r10 = r33
            goto L_0x01e2
        L_0x01d4:
            r10 = r24
            if (r0 == 0) goto L_0x01d9
            r3 = r2
        L_0x01d9:
            r2 = r23
            int r23 = java.lang.Math.max(r2, r3)
            r24 = r10
            goto L_0x01d1
        L_0x01e2:
            int r0 = r7.mo3730a(r8, r10)
            int r0 = r0 + r10
            r25 = r4
            r21 = r5
            r26 = r6
        L_0x01ed:
            int r0 = r0 + 1
            r2 = r1
            r6 = r28
            r3 = r31
            r4 = r35
            r5 = -1
            r8 = r42
            r9 = r43
            r10 = 0
            r1 = r0
            r0 = r30
            goto L_0x0062
        L_0x0201:
            r1 = r2
            r31 = r3
            r35 = r4
            r3 = r21
            r2 = r23
            r10 = r24
            r6 = r25
            r9 = -2147483648(0xffffffff80000000, float:-0.0)
            r29 = -2
            int r4 = r7.f2772f
            if (r4 <= 0) goto L_0x0223
            boolean r4 = r7.mo3742c(r11)
            if (r4 == 0) goto L_0x0223
            int r4 = r7.f2772f
            int r8 = r7.f2778l
            int r4 = r4 + r8
            r7.f2772f = r4
        L_0x0223:
            r4 = r15[r18]
            r8 = -1
            if (r4 != r8) goto L_0x0235
            r4 = 0
            r1 = r15[r4]
            if (r1 != r8) goto L_0x0235
            r1 = r15[r17]
            if (r1 != r8) goto L_0x0235
            r1 = r15[r16]
            if (r1 == r8) goto L_0x0265
        L_0x0235:
            r1 = r15[r16]
            r4 = 0
            r8 = r15[r4]
            r5 = r15[r18]
            r9 = r15[r17]
            int r5 = java.lang.Math.max(r5, r9)
            int r5 = java.lang.Math.max(r8, r5)
            int r1 = java.lang.Math.max(r1, r5)
            r5 = r28[r16]
            r8 = r28[r4]
            r4 = r28[r18]
            r9 = r28[r17]
            int r4 = java.lang.Math.max(r4, r9)
            int r4 = java.lang.Math.max(r8, r4)
            int r4 = java.lang.Math.max(r5, r4)
            int r1 = r1 + r4
            int r21 = java.lang.Math.max(r3, r1)
            r3 = r21
        L_0x0265:
            if (r31 == 0) goto L_0x02c6
            r1 = -2147483648(0xffffffff80000000, float:-0.0)
            if (r12 == r1) goto L_0x026d
            if (r12 != 0) goto L_0x02c6
        L_0x026d:
            r1 = 0
            r7.f2772f = r1
            r1 = 0
        L_0x0271:
            if (r1 >= r11) goto L_0x02c6
            android.view.View r4 = r7.mo3737b(r1)
            if (r4 != 0) goto L_0x0283
            int r4 = r7.f2772f
            int r5 = r7.mo3743d(r1)
            int r4 = r4 + r5
            r7.f2772f = r4
            goto L_0x0290
        L_0x0283:
            int r5 = r4.getVisibility()
            r8 = 8
            if (r5 != r8) goto L_0x0293
            int r4 = r7.mo3730a(r4, r1)
            int r1 = r1 + r4
        L_0x0290:
            r36 = r1
            goto L_0x02c3
        L_0x0293:
            android.view.ViewGroup$LayoutParams r5 = r4.getLayoutParams()
            android.support.v7.widget.as$a r5 = (android.support.p031v7.widget.C0787as.C0788a) r5
            if (r19 == 0) goto L_0x02ac
            int r8 = r7.f2772f
            int r9 = r5.leftMargin
            int r9 = r9 + r14
            int r5 = r5.rightMargin
            int r9 = r9 + r5
            int r4 = r7.mo3736b(r4)
            int r9 = r9 + r4
            int r8 = r8 + r9
            r7.f2772f = r8
            goto L_0x0290
        L_0x02ac:
            int r8 = r7.f2772f
            int r9 = r8 + r14
            r36 = r1
            int r1 = r5.leftMargin
            int r9 = r9 + r1
            int r1 = r5.rightMargin
            int r9 = r9 + r1
            int r1 = r7.mo3736b(r4)
            int r9 = r9 + r1
            int r1 = java.lang.Math.max(r8, r9)
            r7.f2772f = r1
        L_0x02c3:
            int r1 = r36 + 1
            goto L_0x0271
        L_0x02c6:
            int r1 = r7.f2772f
            int r4 = r41.getPaddingLeft()
            int r5 = r41.getPaddingRight()
            int r4 = r4 + r5
            int r1 = r1 + r4
            r7.f2772f = r1
            int r1 = r7.f2772f
            int r4 = r41.getSuggestedMinimumWidth()
            int r1 = java.lang.Math.max(r1, r4)
            r4 = r42
            r5 = 0
            r8 = -1
            int r1 = android.view.View.resolveSizeAndState(r1, r4, r5)
            r5 = 16777215(0xffffff, float:2.3509886E-38)
            r5 = r5 & r1
            int r9 = r7.f2772f
            int r5 = r5 - r9
            if (r22 != 0) goto L_0x0336
            if (r5 == 0) goto L_0x02f6
            int r21 = (r0 > r20 ? 1 : (r0 == r20 ? 0 : -1))
            if (r21 <= 0) goto L_0x02f6
            goto L_0x0336
        L_0x02f6:
            int r0 = java.lang.Math.max(r2, r10)
            if (r31 == 0) goto L_0x0332
            r2 = 1073741824(0x40000000, float:2.0)
            if (r12 == r2) goto L_0x0332
            r2 = 0
        L_0x0301:
            if (r2 >= r11) goto L_0x0332
            android.view.View r5 = r7.mo3737b(r2)
            if (r5 == 0) goto L_0x032f
            int r8 = r5.getVisibility()
            r10 = 8
            if (r8 != r10) goto L_0x0312
            goto L_0x032f
        L_0x0312:
            android.view.ViewGroup$LayoutParams r8 = r5.getLayoutParams()
            android.support.v7.widget.as$a r8 = (android.support.p031v7.widget.C0787as.C0788a) r8
            float r8 = r8.f2782g
            int r8 = (r8 > r20 ? 1 : (r8 == r20 ? 0 : -1))
            if (r8 <= 0) goto L_0x032f
            r8 = 1073741824(0x40000000, float:2.0)
            int r10 = android.view.View.MeasureSpec.makeMeasureSpec(r14, r8)
            int r12 = r5.getMeasuredHeight()
            int r12 = android.view.View.MeasureSpec.makeMeasureSpec(r12, r8)
            r5.measure(r10, r12)
        L_0x032f:
            int r2 = r2 + 1
            goto L_0x0301
        L_0x0332:
            r5 = r43
            goto L_0x04c7
        L_0x0336:
            float r3 = r7.f2773g
            int r3 = (r3 > r20 ? 1 : (r3 == r20 ? 0 : -1))
            if (r3 <= 0) goto L_0x033e
            float r0 = r7.f2773g
        L_0x033e:
            r15[r16] = r8
            r15[r17] = r8
            r15[r18] = r8
            r3 = 0
            r15[r3] = r8
            r28[r16] = r8
            r28[r17] = r8
            r28[r18] = r8
            r28[r3] = r8
            r7.f2772f = r3
            r10 = r2
            r3 = r8
            r2 = r0
            r0 = 0
        L_0x0355:
            if (r0 >= r11) goto L_0x0475
            android.view.View r14 = r7.mo3737b(r0)
            if (r14 == 0) goto L_0x0468
            int r8 = r14.getVisibility()
            r9 = 8
            if (r8 != r9) goto L_0x0367
            goto L_0x0468
        L_0x0367:
            android.view.ViewGroup$LayoutParams r8 = r14.getLayoutParams()
            android.support.v7.widget.as$a r8 = (android.support.p031v7.widget.C0787as.C0788a) r8
            float r9 = r8.f2782g
            int r21 = (r9 > r20 ? 1 : (r9 == r20 ? 0 : -1))
            if (r21 <= 0) goto L_0x03c3
            float r4 = (float) r5
            float r4 = r4 * r9
            float r4 = r4 / r2
            int r4 = (int) r4
            float r2 = r2 - r9
            int r5 = r5 - r4
            int r9 = r41.getPaddingTop()
            int r21 = r41.getPaddingBottom()
            int r9 = r9 + r21
            r37 = r2
            int r2 = r8.topMargin
            int r9 = r9 + r2
            int r2 = r8.bottomMargin
            int r9 = r9 + r2
            int r2 = r8.height
            r38 = r5
            r5 = r43
            int r2 = getChildMeasureSpec(r5, r9, r2)
            int r9 = r8.width
            if (r9 != 0) goto L_0x03a1
            r9 = 1073741824(0x40000000, float:2.0)
            if (r12 == r9) goto L_0x039e
            goto L_0x03a3
        L_0x039e:
            if (r4 <= 0) goto L_0x03ab
            goto L_0x03ac
        L_0x03a1:
            r9 = 1073741824(0x40000000, float:2.0)
        L_0x03a3:
            int r21 = r14.getMeasuredWidth()
            int r4 = r21 + r4
            if (r4 >= 0) goto L_0x03ac
        L_0x03ab:
            r4 = 0
        L_0x03ac:
            int r4 = android.view.View.MeasureSpec.makeMeasureSpec(r4, r9)
            r14.measure(r4, r2)
            int r2 = r14.getMeasuredState()
            r4 = -16777216(0xffffffffff000000, float:-1.7014118E38)
            r2 = r2 & r4
            int r6 = android.view.View.combineMeasuredStates(r6, r2)
            r2 = r37
            r4 = r38
            goto L_0x03c6
        L_0x03c3:
            r4 = r5
            r5 = r43
        L_0x03c6:
            if (r19 == 0) goto L_0x03e7
            int r9 = r7.f2772f
            int r21 = r14.getMeasuredWidth()
            r39 = r2
            int r2 = r8.leftMargin
            int r21 = r21 + r2
            int r2 = r8.rightMargin
            int r21 = r21 + r2
            int r2 = r7.mo3736b(r14)
            int r21 = r21 + r2
            int r9 = r9 + r21
            r7.f2772f = r9
            r40 = r4
        L_0x03e4:
            r2 = 1073741824(0x40000000, float:2.0)
            goto L_0x0404
        L_0x03e7:
            r39 = r2
            int r2 = r7.f2772f
            int r9 = r14.getMeasuredWidth()
            int r9 = r9 + r2
            r40 = r4
            int r4 = r8.leftMargin
            int r9 = r9 + r4
            int r4 = r8.rightMargin
            int r9 = r9 + r4
            int r4 = r7.mo3736b(r14)
            int r9 = r9 + r4
            int r2 = java.lang.Math.max(r2, r9)
            r7.f2772f = r2
            goto L_0x03e4
        L_0x0404:
            if (r13 == r2) goto L_0x040e
            int r2 = r8.height
            r4 = -1
            if (r2 != r4) goto L_0x040e
            r2 = r18
            goto L_0x040f
        L_0x040e:
            r2 = 0
        L_0x040f:
            int r4 = r8.topMargin
            int r9 = r8.bottomMargin
            int r4 = r4 + r9
            int r9 = r14.getMeasuredHeight()
            int r9 = r9 + r4
            int r3 = java.lang.Math.max(r3, r9)
            if (r2 == 0) goto L_0x0420
            goto L_0x0421
        L_0x0420:
            r4 = r9
        L_0x0421:
            int r2 = java.lang.Math.max(r10, r4)
            if (r26 == 0) goto L_0x042f
            int r4 = r8.height
            r10 = -1
            if (r4 != r10) goto L_0x0430
            r4 = r18
            goto L_0x0431
        L_0x042f:
            r10 = -1
        L_0x0430:
            r4 = 0
        L_0x0431:
            if (r35 == 0) goto L_0x045e
            int r14 = r14.getBaseline()
            if (r14 == r10) goto L_0x045e
            int r10 = r8.f2783h
            if (r10 >= 0) goto L_0x0440
            int r8 = r7.f2771e
            goto L_0x0442
        L_0x0440:
            int r8 = r8.f2783h
        L_0x0442:
            r8 = r8 & 112(0x70, float:1.57E-43)
            r21 = 4
            int r8 = r8 >> 4
            r8 = r8 & -2
            int r8 = r8 >> 1
            r10 = r15[r8]
            int r10 = java.lang.Math.max(r10, r14)
            r15[r8] = r10
            r10 = r28[r8]
            int r9 = r9 - r14
            int r9 = java.lang.Math.max(r10, r9)
            r28[r8] = r9
            goto L_0x0460
        L_0x045e:
            r21 = 4
        L_0x0460:
            r10 = r2
            r26 = r4
            r2 = r39
            r4 = r40
            goto L_0x046d
        L_0x0468:
            r4 = r5
            r5 = r43
            r21 = 4
        L_0x046d:
            int r0 = r0 + 1
            r5 = r4
            r4 = r42
            r8 = -1
            goto L_0x0355
        L_0x0475:
            r5 = r43
            int r0 = r7.f2772f
            int r2 = r41.getPaddingLeft()
            int r4 = r41.getPaddingRight()
            int r2 = r2 + r4
            int r0 = r0 + r2
            r7.f2772f = r0
            r0 = r15[r18]
            r2 = -1
            if (r0 != r2) goto L_0x0497
            r0 = 0
            r4 = r15[r0]
            if (r4 != r2) goto L_0x0497
            r0 = r15[r17]
            if (r0 != r2) goto L_0x0497
            r0 = r15[r16]
            if (r0 == r2) goto L_0x04c6
        L_0x0497:
            r0 = r15[r16]
            r2 = 0
            r4 = r15[r2]
            r8 = r15[r18]
            r9 = r15[r17]
            int r8 = java.lang.Math.max(r8, r9)
            int r4 = java.lang.Math.max(r4, r8)
            int r0 = java.lang.Math.max(r0, r4)
            r4 = r28[r16]
            r2 = r28[r2]
            r8 = r28[r18]
            r9 = r28[r17]
            int r8 = java.lang.Math.max(r8, r9)
            int r2 = java.lang.Math.max(r2, r8)
            int r2 = java.lang.Math.max(r4, r2)
            int r0 = r0 + r2
            int r0 = java.lang.Math.max(r3, r0)
            r3 = r0
        L_0x04c6:
            r0 = r10
        L_0x04c7:
            if (r26 != 0) goto L_0x04ce
            r2 = 1073741824(0x40000000, float:2.0)
            if (r13 == r2) goto L_0x04ce
            goto L_0x04cf
        L_0x04ce:
            r0 = r3
        L_0x04cf:
            int r2 = r41.getPaddingTop()
            int r3 = r41.getPaddingBottom()
            int r2 = r2 + r3
            int r0 = r0 + r2
            int r2 = r41.getSuggestedMinimumHeight()
            int r0 = java.lang.Math.max(r0, r2)
            r2 = -16777216(0xffffffffff000000, float:-1.7014118E38)
            r2 = r2 & r6
            r1 = r1 | r2
            int r2 = r6 << 16
            int r0 = android.view.View.resolveSizeAndState(r0, r5, r2)
            r7.setMeasuredDimension(r1, r0)
            if (r27 == 0) goto L_0x04f5
            r0 = r42
            r7.m3914d(r11, r0)
        L_0x04f5:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.p031v7.widget.C0787as.mo3738b(int, int):void");
    }

    /* access modifiers changed from: 0000 */
    /* JADX WARNING: Removed duplicated region for block: B:28:0x00b6  */
    /* JADX WARNING: Removed duplicated region for block: B:31:0x00bf  */
    /* JADX WARNING: Removed duplicated region for block: B:46:0x00f6  */
    /* JADX WARNING: Removed duplicated region for block: B:49:0x010a  */
    /* renamed from: b */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void mo3739b(int r28, int r29, int r30, int r31) {
        /*
            r27 = this;
            r6 = r27
            boolean r2 = android.support.p031v7.widget.C0885bv.m4757a(r27)
            int r7 = r27.getPaddingTop()
            int r3 = r31 - r29
            int r4 = r27.getPaddingBottom()
            int r8 = r3 - r4
            int r3 = r3 - r7
            int r4 = r27.getPaddingBottom()
            int r9 = r3 - r4
            int r10 = r27.getVirtualChildCount()
            int r3 = r6.f2771e
            r4 = 8388615(0x800007, float:1.1754953E-38)
            r3 = r3 & r4
            int r4 = r6.f2771e
            r11 = r4 & 112(0x70, float:1.57E-43)
            boolean r12 = r6.f2767a
            int[] r13 = r6.f2775i
            int[] r14 = r6.f2776j
            int r4 = android.support.p018v4.p028h.C0495r.m2149f(r27)
            int r3 = android.support.p018v4.p028h.C0480d.m2070a(r3, r4)
            r15 = 2
            r5 = 1
            if (r3 == r5) goto L_0x004e
            r4 = 5
            if (r3 == r4) goto L_0x0041
            int r0 = r27.getPaddingLeft()
            goto L_0x0059
        L_0x0041:
            int r3 = r27.getPaddingLeft()
            int r3 = r3 + r30
            int r3 = r3 - r28
            int r0 = r6.f2772f
            int r0 = r3 - r0
            goto L_0x0059
        L_0x004e:
            int r3 = r27.getPaddingLeft()
            int r0 = r30 - r28
            int r1 = r6.f2772f
            int r0 = r0 - r1
            int r0 = r0 / r15
            int r0 = r0 + r3
        L_0x0059:
            r1 = 0
            if (r2 == 0) goto L_0x0063
            int r2 = r10 + -1
            r16 = r2
            r17 = -1
            goto L_0x0067
        L_0x0063:
            r16 = r1
            r17 = r5
        L_0x0067:
            r3 = r1
        L_0x0068:
            if (r3 >= r10) goto L_0x0153
            int r1 = r17 * r3
            int r2 = r16 + r1
            android.view.View r1 = r6.mo3737b(r2)
            if (r1 != 0) goto L_0x0085
            int r1 = r6.mo3743d(r2)
            int r0 = r0 + r1
            r18 = r5
            r26 = r7
            r23 = r10
            r24 = r11
        L_0x0081:
            r20 = -1
            goto L_0x0146
        L_0x0085:
            int r5 = r1.getVisibility()
            r15 = 8
            if (r5 == r15) goto L_0x013a
            int r15 = r1.getMeasuredWidth()
            int r5 = r1.getMeasuredHeight()
            android.view.ViewGroup$LayoutParams r20 = r1.getLayoutParams()
            r4 = r20
            android.support.v7.widget.as$a r4 = (android.support.p031v7.widget.C0787as.C0788a) r4
            if (r12 == 0) goto L_0x00ad
            r22 = r3
            int r3 = r4.height
            r23 = r10
            r10 = -1
            if (r3 == r10) goto L_0x00b1
            int r3 = r1.getBaseline()
            goto L_0x00b2
        L_0x00ad:
            r22 = r3
            r23 = r10
        L_0x00b1:
            r3 = -1
        L_0x00b2:
            int r10 = r4.f2783h
            if (r10 >= 0) goto L_0x00b7
            r10 = r11
        L_0x00b7:
            r10 = r10 & 112(0x70, float:1.57E-43)
            r24 = r11
            r11 = 16
            if (r10 == r11) goto L_0x00f6
            r11 = 48
            if (r10 == r11) goto L_0x00e3
            r11 = 80
            if (r10 == r11) goto L_0x00cc
            r3 = r7
            r11 = -1
        L_0x00c9:
            r18 = 1
            goto L_0x0104
        L_0x00cc:
            int r10 = r8 - r5
            int r11 = r4.bottomMargin
            int r10 = r10 - r11
            r11 = -1
            if (r3 == r11) goto L_0x00e1
            int r20 = r1.getMeasuredHeight()
            int r20 = r20 - r3
            r3 = 2
            r21 = r14[r3]
            int r21 = r21 - r20
            int r10 = r10 - r21
        L_0x00e1:
            r3 = r10
            goto L_0x00c9
        L_0x00e3:
            r11 = -1
            int r10 = r4.topMargin
            int r10 = r10 + r7
            if (r3 == r11) goto L_0x00f2
            r18 = 1
            r20 = r13[r18]
            int r20 = r20 - r3
            int r10 = r10 + r20
            goto L_0x00f4
        L_0x00f2:
            r18 = 1
        L_0x00f4:
            r3 = r10
            goto L_0x0104
        L_0x00f6:
            r11 = -1
            r18 = 1
            int r3 = r9 - r5
            r10 = 2
            int r3 = r3 / r10
            int r3 = r3 + r7
            int r10 = r4.topMargin
            int r3 = r3 + r10
            int r10 = r4.bottomMargin
            int r3 = r3 - r10
        L_0x0104:
            boolean r10 = r6.mo3742c(r2)
            if (r10 == 0) goto L_0x010d
            int r10 = r6.f2778l
            int r0 = r0 + r10
        L_0x010d:
            int r10 = r4.leftMargin
            int r10 = r10 + r0
            int r0 = r6.mo3729a(r1)
            int r19 = r10 + r0
            r0 = r6
            r25 = r1
            r11 = r2
            r2 = r19
            r19 = r22
            r26 = r7
            r20 = -1
            r7 = r4
            r4 = r15
            r0.m3912a(r1, r2, r3, r4, r5)
            int r0 = r7.rightMargin
            int r15 = r15 + r0
            r0 = r25
            int r1 = r6.mo3736b(r0)
            int r15 = r15 + r1
            int r10 = r10 + r15
            int r0 = r6.mo3730a(r0, r11)
            int r3 = r19 + r0
            r0 = r10
            goto L_0x0146
        L_0x013a:
            r19 = r3
            r26 = r7
            r23 = r10
            r24 = r11
            r18 = 1
            goto L_0x0081
        L_0x0146:
            int r3 = r3 + 1
            r5 = r18
            r10 = r23
            r11 = r24
            r7 = r26
            r15 = 2
            goto L_0x0068
        L_0x0153:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.p031v7.widget.C0787as.mo3739b(int, int, int, int):void");
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: b */
    public void mo3740b(Canvas canvas) {
        int i;
        int left;
        int i2;
        int virtualChildCount = getVirtualChildCount();
        boolean a = C0885bv.m4757a(this);
        for (int i3 = 0; i3 < virtualChildCount; i3++) {
            View b = mo3737b(i3);
            if (!(b == null || b.getVisibility() == 8 || !mo3742c(i3))) {
                C0788a aVar = (C0788a) b.getLayoutParams();
                mo3741b(canvas, a ? b.getRight() + aVar.rightMargin : (b.getLeft() - aVar.leftMargin) - this.f2778l);
            }
        }
        if (mo3742c(virtualChildCount)) {
            View b2 = mo3737b(virtualChildCount - 1);
            if (b2 != null) {
                C0788a aVar2 = (C0788a) b2.getLayoutParams();
                if (a) {
                    left = b2.getLeft();
                    i2 = aVar2.leftMargin;
                } else {
                    i = b2.getRight() + aVar2.rightMargin;
                    mo3741b(canvas, i);
                }
            } else if (a) {
                i = getPaddingLeft();
                mo3741b(canvas, i);
            } else {
                left = getWidth();
                i2 = getPaddingRight();
            }
            i = (left - i2) - this.f2778l;
            mo3741b(canvas, i);
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: b */
    public void mo3741b(Canvas canvas, int i) {
        this.f2777k.setBounds(i, getPaddingTop() + this.f2781o, this.f2778l + i, (getHeight() - getPaddingBottom()) - this.f2781o);
        this.f2777k.draw(canvas);
    }

    /* access modifiers changed from: protected */
    /* renamed from: c */
    public boolean mo3742c(int i) {
        boolean z = false;
        if (i == 0) {
            if ((this.f2780n & 1) != 0) {
                z = true;
            }
            return z;
        } else if (i == getChildCount()) {
            if ((this.f2780n & 4) != 0) {
                z = true;
            }
            return z;
        } else {
            if ((this.f2780n & 2) != 0) {
                for (int i2 = i - 1; i2 >= 0; i2--) {
                    if (getChildAt(i2).getVisibility() != 8) {
                        return true;
                    }
                }
            }
            return false;
        }
    }

    /* access modifiers changed from: protected */
    public boolean checkLayoutParams(LayoutParams layoutParams) {
        return layoutParams instanceof C0788a;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: d */
    public int mo3743d(int i) {
        return 0;
    }

    public int getBaseline() {
        if (this.f2768b < 0) {
            return super.getBaseline();
        }
        if (getChildCount() <= this.f2768b) {
            throw new RuntimeException("mBaselineAlignedChildIndex of LinearLayout set to an index that is out of bounds.");
        }
        View childAt = getChildAt(this.f2768b);
        int baseline = childAt.getBaseline();
        if (baseline != -1) {
            int i = this.f2769c;
            if (this.f2770d == 1) {
                int i2 = this.f2771e & 112;
                if (i2 != 48) {
                    if (i2 == 16) {
                        i += ((((getBottom() - getTop()) - getPaddingTop()) - getPaddingBottom()) - this.f2772f) / 2;
                    } else if (i2 == 80) {
                        i = ((getBottom() - getTop()) - getPaddingBottom()) - this.f2772f;
                    }
                }
            }
            return i + ((C0788a) childAt.getLayoutParams()).topMargin + baseline;
        } else if (this.f2768b == 0) {
            return -1;
        } else {
            throw new RuntimeException("mBaselineAlignedChildIndex of LinearLayout points to a View that doesn't know how to get its baseline.");
        }
    }

    public int getBaselineAlignedChildIndex() {
        return this.f2768b;
    }

    public Drawable getDividerDrawable() {
        return this.f2777k;
    }

    public int getDividerPadding() {
        return this.f2781o;
    }

    public int getDividerWidth() {
        return this.f2778l;
    }

    public int getGravity() {
        return this.f2771e;
    }

    public int getOrientation() {
        return this.f2770d;
    }

    public int getShowDividers() {
        return this.f2780n;
    }

    /* access modifiers changed from: 0000 */
    public int getVirtualChildCount() {
        return getChildCount();
    }

    public float getWeightSum() {
        return this.f2773g;
    }

    /* access modifiers changed from: protected */
    /* renamed from: j */
    public C0788a generateDefaultLayoutParams() {
        if (this.f2770d == 0) {
            return new C0788a(-2, -2);
        }
        if (this.f2770d == 1) {
            return new C0788a(-1, -2);
        }
        return null;
    }

    /* access modifiers changed from: protected */
    public void onDraw(Canvas canvas) {
        if (this.f2777k != null) {
            if (this.f2770d == 1) {
                mo3733a(canvas);
            } else {
                mo3740b(canvas);
            }
        }
    }

    public void onInitializeAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        super.onInitializeAccessibilityEvent(accessibilityEvent);
        accessibilityEvent.setClassName(C0787as.class.getName());
    }

    public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo accessibilityNodeInfo) {
        super.onInitializeAccessibilityNodeInfo(accessibilityNodeInfo);
        accessibilityNodeInfo.setClassName(C0787as.class.getName());
    }

    /* access modifiers changed from: protected */
    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        if (this.f2770d == 1) {
            mo3732a(i, i2, i3, i4);
        } else {
            mo3739b(i, i2, i3, i4);
        }
    }

    /* access modifiers changed from: protected */
    public void onMeasure(int i, int i2) {
        if (this.f2770d == 1) {
            mo3731a(i, i2);
        } else {
            mo3738b(i, i2);
        }
    }

    public void setBaselineAligned(boolean z) {
        this.f2767a = z;
    }

    public void setBaselineAlignedChildIndex(int i) {
        if (i < 0 || i >= getChildCount()) {
            StringBuilder sb = new StringBuilder();
            sb.append("base aligned child index out of range (0, ");
            sb.append(getChildCount());
            sb.append(")");
            throw new IllegalArgumentException(sb.toString());
        }
        this.f2768b = i;
    }

    public void setDividerDrawable(Drawable drawable) {
        if (drawable != this.f2777k) {
            this.f2777k = drawable;
            boolean z = false;
            if (drawable != null) {
                this.f2778l = drawable.getIntrinsicWidth();
                this.f2779m = drawable.getIntrinsicHeight();
            } else {
                this.f2778l = 0;
                this.f2779m = 0;
            }
            if (drawable == null) {
                z = true;
            }
            setWillNotDraw(z);
            requestLayout();
        }
    }

    public void setDividerPadding(int i) {
        this.f2781o = i;
    }

    public void setGravity(int i) {
        if (this.f2771e != i) {
            if ((8388615 & i) == 0) {
                i |= 8388611;
            }
            if ((i & 112) == 0) {
                i |= 48;
            }
            this.f2771e = i;
            requestLayout();
        }
    }

    public void setHorizontalGravity(int i) {
        int i2 = i & 8388615;
        if ((8388615 & this.f2771e) != i2) {
            this.f2771e = i2 | (this.f2771e & -8388616);
            requestLayout();
        }
    }

    public void setMeasureWithLargestChildEnabled(boolean z) {
        this.f2774h = z;
    }

    public void setOrientation(int i) {
        if (this.f2770d != i) {
            this.f2770d = i;
            requestLayout();
        }
    }

    public void setShowDividers(int i) {
        if (i != this.f2780n) {
            requestLayout();
        }
        this.f2780n = i;
    }

    public void setVerticalGravity(int i) {
        int i2 = i & 112;
        if ((this.f2771e & 112) != i2) {
            this.f2771e = i2 | (this.f2771e & -113);
            requestLayout();
        }
    }

    public void setWeightSum(float f) {
        this.f2773g = Math.max(0.0f, f);
    }

    public boolean shouldDelayChildPressedState() {
        return false;
    }
}
