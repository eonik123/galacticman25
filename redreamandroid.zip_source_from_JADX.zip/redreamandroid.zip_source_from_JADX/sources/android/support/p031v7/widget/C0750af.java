package android.support.p031v7.widget;

import android.graphics.drawable.Drawable;
import android.view.View;

/* renamed from: android.support.v7.widget.af */
interface C0750af {
    /* renamed from: a */
    Drawable mo3569a();

    /* renamed from: a */
    void mo3570a(int i, int i2);

    /* renamed from: a */
    void mo3571a(int i, int i2, int i3, int i4);

    /* renamed from: b */
    boolean mo3572b();

    /* renamed from: c */
    boolean mo3573c();

    /* renamed from: d */
    View mo3574d();
}
