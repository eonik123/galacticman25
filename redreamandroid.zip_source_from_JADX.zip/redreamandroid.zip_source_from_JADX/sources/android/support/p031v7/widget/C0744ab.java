package android.support.p031v7.widget;

import android.content.res.ColorStateList;
import android.graphics.Rect;
import android.os.Build.VERSION;
import android.view.View.MeasureSpec;
import android.widget.FrameLayout;

/* renamed from: android.support.v7.widget.ab */
public class C0744ab extends FrameLayout {

    /* renamed from: d */
    private static final int[] f2611d = {16842801};

    /* renamed from: e */
    private static final C0751ag f2612e;

    /* renamed from: a */
    int f2613a;

    /* renamed from: b */
    int f2614b;

    /* renamed from: c */
    final Rect f2615c;

    /* renamed from: f */
    private boolean f2616f;

    /* renamed from: g */
    private boolean f2617g;

    /* renamed from: h */
    private final C0750af f2618h;

    static {
        C0751ag aeVar = VERSION.SDK_INT >= 21 ? new C0747ad() : VERSION.SDK_INT >= 17 ? new C0745ac() : new C0748ae();
        f2612e = aeVar;
        f2612e.mo3553a();
    }

    public ColorStateList getCardBackgroundColor() {
        return f2612e.mo3567i(this.f2618h);
    }

    public float getCardElevation() {
        return f2612e.mo3563e(this.f2618h);
    }

    public int getContentPaddingBottom() {
        return this.f2615c.bottom;
    }

    public int getContentPaddingLeft() {
        return this.f2615c.left;
    }

    public int getContentPaddingRight() {
        return this.f2615c.right;
    }

    public int getContentPaddingTop() {
        return this.f2615c.top;
    }

    public float getMaxCardElevation() {
        return f2612e.mo3555a(this.f2618h);
    }

    public boolean getPreventCornerOverlap() {
        return this.f2617g;
    }

    public float getRadius() {
        return f2612e.mo3562d(this.f2618h);
    }

    public boolean getUseCompatPadding() {
        return this.f2616f;
    }

    /* access modifiers changed from: protected */
    public void onMeasure(int i, int i2) {
        if (!(f2612e instanceof C0747ad)) {
            int mode = MeasureSpec.getMode(i);
            if (mode == Integer.MIN_VALUE || mode == 1073741824) {
                i = MeasureSpec.makeMeasureSpec(Math.max((int) Math.ceil((double) f2612e.mo3558b(this.f2618h)), MeasureSpec.getSize(i)), mode);
            }
            int mode2 = MeasureSpec.getMode(i2);
            if (mode2 == Integer.MIN_VALUE || mode2 == 1073741824) {
                i2 = MeasureSpec.makeMeasureSpec(Math.max((int) Math.ceil((double) f2612e.mo3560c(this.f2618h)), MeasureSpec.getSize(i2)), mode2);
            }
        }
        super.onMeasure(i, i2);
    }

    public void setCardBackgroundColor(int i) {
        f2612e.mo3557a(this.f2618h, ColorStateList.valueOf(i));
    }

    public void setCardBackgroundColor(ColorStateList colorStateList) {
        f2612e.mo3557a(this.f2618h, colorStateList);
    }

    public void setCardElevation(float f) {
        f2612e.mo3561c(this.f2618h, f);
    }

    public void setMaxCardElevation(float f) {
        f2612e.mo3559b(this.f2618h, f);
    }

    public void setMinimumHeight(int i) {
        this.f2614b = i;
        super.setMinimumHeight(i);
    }

    public void setMinimumWidth(int i) {
        this.f2613a = i;
        super.setMinimumWidth(i);
    }

    public void setPadding(int i, int i2, int i3, int i4) {
    }

    public void setPaddingRelative(int i, int i2, int i3, int i4) {
    }

    public void setPreventCornerOverlap(boolean z) {
        if (z != this.f2617g) {
            this.f2617g = z;
            f2612e.mo3566h(this.f2618h);
        }
    }

    public void setRadius(float f) {
        f2612e.mo3556a(this.f2618h, f);
    }

    public void setUseCompatPadding(boolean z) {
        if (this.f2616f != z) {
            this.f2616f = z;
            f2612e.mo3565g(this.f2618h);
        }
    }
}
