package android.support.p031v7.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff.Mode;
import android.graphics.drawable.Drawable;
import android.support.p018v4.p028h.C0494q;
import android.support.p018v4.widget.C0531m;
import android.support.p031v7.p032a.C0540a.C0541a;
import android.support.p031v7.p033b.p034a.C0606a;
import android.util.AttributeSet;
import android.view.ActionMode.Callback;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.widget.AutoCompleteTextView;
import android.widget.TextView;

/* renamed from: android.support.v7.widget.f */
public class C0904f extends AutoCompleteTextView implements C0494q {

    /* renamed from: a */
    private static final int[] f3269a = {16843126};

    /* renamed from: b */
    private final C0905g f3270b;

    /* renamed from: c */
    private final C0934y f3271c;

    public C0904f(Context context) {
        this(context, null);
    }

    public C0904f(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, C0541a.autoCompleteTextViewStyle);
    }

    public C0904f(Context context, AttributeSet attributeSet, int i) {
        super(C0866bk.m4633a(context), attributeSet, i);
        C0869bn a = C0869bn.m4638a(getContext(), attributeSet, f3269a, i, 0);
        if (a.mo4440g(0)) {
            setDropDownBackgroundDrawable(a.mo4426a(0));
        }
        a.mo4427a();
        this.f3270b = new C0905g(this);
        this.f3270b.mo4547a(attributeSet, i);
        this.f3271c = new C0934y(this);
        this.f3271c.mo4679a(attributeSet, i);
        this.f3271c.mo4674a();
    }

    /* access modifiers changed from: protected */
    public void drawableStateChanged() {
        super.drawableStateChanged();
        if (this.f3270b != null) {
            this.f3270b.mo4550c();
        }
        if (this.f3271c != null) {
            this.f3271c.mo4674a();
        }
    }

    public ColorStateList getSupportBackgroundTintList() {
        if (this.f3270b != null) {
            return this.f3270b.mo4542a();
        }
        return null;
    }

    public Mode getSupportBackgroundTintMode() {
        if (this.f3270b != null) {
            return this.f3270b.mo4548b();
        }
        return null;
    }

    public InputConnection onCreateInputConnection(EditorInfo editorInfo) {
        return C0916m.m4905a(super.onCreateInputConnection(editorInfo), editorInfo, this);
    }

    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        if (this.f3270b != null) {
            this.f3270b.mo4546a(drawable);
        }
    }

    public void setBackgroundResource(int i) {
        super.setBackgroundResource(i);
        if (this.f3270b != null) {
            this.f3270b.mo4543a(i);
        }
    }

    public void setCustomSelectionActionModeCallback(Callback callback) {
        super.setCustomSelectionActionModeCallback(C0531m.m2345a((TextView) this, callback));
    }

    public void setDropDownBackgroundResource(int i) {
        setDropDownBackgroundDrawable(C0606a.m2714b(getContext(), i));
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        if (this.f3270b != null) {
            this.f3270b.mo4544a(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(Mode mode) {
        if (this.f3270b != null) {
            this.f3270b.mo4545a(mode);
        }
    }

    public void setTextAppearance(Context context, int i) {
        super.setTextAppearance(context, i);
        if (this.f3271c != null) {
            this.f3271c.mo4678a(context, i);
        }
    }
}
