package android.support.p031v7.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.PorterDuff.Mode;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.support.p018v4.p028h.C0494q;
import android.support.p018v4.widget.C0534o;
import android.util.AttributeSet;
import android.widget.ImageView;

/* renamed from: android.support.v7.widget.p */
public class C0919p extends ImageView implements C0494q, C0534o {

    /* renamed from: a */
    private final C0905g f3310a;

    /* renamed from: b */
    private final C0918o f3311b;

    public C0919p(Context context) {
        this(context, null);
    }

    public C0919p(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public C0919p(Context context, AttributeSet attributeSet, int i) {
        super(C0866bk.m4633a(context), attributeSet, i);
        this.f3310a = new C0905g(this);
        this.f3310a.mo4547a(attributeSet, i);
        this.f3311b = new C0918o(this);
        this.f3311b.mo4595a(attributeSet, i);
    }

    /* access modifiers changed from: protected */
    public void drawableStateChanged() {
        super.drawableStateChanged();
        if (this.f3310a != null) {
            this.f3310a.mo4550c();
        }
        if (this.f3311b != null) {
            this.f3311b.mo4599d();
        }
    }

    public ColorStateList getSupportBackgroundTintList() {
        if (this.f3310a != null) {
            return this.f3310a.mo4542a();
        }
        return null;
    }

    public Mode getSupportBackgroundTintMode() {
        if (this.f3310a != null) {
            return this.f3310a.mo4548b();
        }
        return null;
    }

    public ColorStateList getSupportImageTintList() {
        if (this.f3311b != null) {
            return this.f3311b.mo4597b();
        }
        return null;
    }

    public Mode getSupportImageTintMode() {
        if (this.f3311b != null) {
            return this.f3311b.mo4598c();
        }
        return null;
    }

    public boolean hasOverlappingRendering() {
        return this.f3311b.mo4596a() && super.hasOverlappingRendering();
    }

    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        if (this.f3310a != null) {
            this.f3310a.mo4546a(drawable);
        }
    }

    public void setBackgroundResource(int i) {
        super.setBackgroundResource(i);
        if (this.f3310a != null) {
            this.f3310a.mo4543a(i);
        }
    }

    public void setImageBitmap(Bitmap bitmap) {
        super.setImageBitmap(bitmap);
        if (this.f3311b != null) {
            this.f3311b.mo4599d();
        }
    }

    public void setImageDrawable(Drawable drawable) {
        super.setImageDrawable(drawable);
        if (this.f3311b != null) {
            this.f3311b.mo4599d();
        }
    }

    public void setImageResource(int i) {
        if (this.f3311b != null) {
            this.f3311b.mo4592a(i);
        }
    }

    public void setImageURI(Uri uri) {
        super.setImageURI(uri);
        if (this.f3311b != null) {
            this.f3311b.mo4599d();
        }
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        if (this.f3310a != null) {
            this.f3310a.mo4544a(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(Mode mode) {
        if (this.f3310a != null) {
            this.f3310a.mo4545a(mode);
        }
    }

    public void setSupportImageTintList(ColorStateList colorStateList) {
        if (this.f3311b != null) {
            this.f3311b.mo4593a(colorStateList);
        }
    }

    public void setSupportImageTintMode(Mode mode) {
        if (this.f3311b != null) {
            this.f3311b.mo4594a(mode);
        }
    }
}
