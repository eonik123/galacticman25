package android.support.p031v7.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources.Theme;
import android.database.DataSetObserver;
import android.graphics.PorterDuff.Mode;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.support.p018v4.p028h.C0494q;
import android.support.p018v4.p028h.C0495r;
import android.support.p031v7.p032a.C0540a.C0541a;
import android.support.p031v7.p033b.p034a.C0606a;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewTreeObserver;
import android.view.ViewTreeObserver.OnGlobalLayoutListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListAdapter;
import android.widget.PopupWindow.OnDismissListener;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.ThemedSpinnerAdapter;

/* renamed from: android.support.v7.widget.x */
public class C0927x extends Spinner implements C0494q {

    /* renamed from: d */
    private static final int[] f3330d = {16843505};

    /* renamed from: a */
    C0930b f3331a;

    /* renamed from: b */
    int f3332b;

    /* renamed from: c */
    final Rect f3333c;

    /* renamed from: e */
    private final C0905g f3334e;

    /* renamed from: f */
    private final Context f3335f;

    /* renamed from: g */
    private C0779ap f3336g;

    /* renamed from: h */
    private SpinnerAdapter f3337h;

    /* renamed from: i */
    private final boolean f3338i;

    /* renamed from: android.support.v7.widget.x$a */
    private static class C0929a implements ListAdapter, SpinnerAdapter {

        /* renamed from: a */
        private SpinnerAdapter f3341a;

        /* renamed from: b */
        private ListAdapter f3342b;

        public C0929a(SpinnerAdapter spinnerAdapter, Theme theme) {
            this.f3341a = spinnerAdapter;
            if (spinnerAdapter instanceof ListAdapter) {
                this.f3342b = (ListAdapter) spinnerAdapter;
            }
            if (theme != null) {
                if (VERSION.SDK_INT >= 23 && (spinnerAdapter instanceof ThemedSpinnerAdapter)) {
                    ThemedSpinnerAdapter themedSpinnerAdapter = (ThemedSpinnerAdapter) spinnerAdapter;
                    if (themedSpinnerAdapter.getDropDownViewTheme() != theme) {
                        themedSpinnerAdapter.setDropDownViewTheme(theme);
                    }
                } else if (spinnerAdapter instanceof C0865bj) {
                    C0865bj bjVar = (C0865bj) spinnerAdapter;
                    if (bjVar.mo4416a() == null) {
                        bjVar.mo4417a(theme);
                    }
                }
            }
        }

        public boolean areAllItemsEnabled() {
            ListAdapter listAdapter = this.f3342b;
            if (listAdapter != null) {
                return listAdapter.areAllItemsEnabled();
            }
            return true;
        }

        public int getCount() {
            if (this.f3341a == null) {
                return 0;
            }
            return this.f3341a.getCount();
        }

        public View getDropDownView(int i, View view, ViewGroup viewGroup) {
            if (this.f3341a == null) {
                return null;
            }
            return this.f3341a.getDropDownView(i, view, viewGroup);
        }

        public Object getItem(int i) {
            if (this.f3341a == null) {
                return null;
            }
            return this.f3341a.getItem(i);
        }

        public long getItemId(int i) {
            if (this.f3341a == null) {
                return -1;
            }
            return this.f3341a.getItemId(i);
        }

        public int getItemViewType(int i) {
            return 0;
        }

        public View getView(int i, View view, ViewGroup viewGroup) {
            return getDropDownView(i, view, viewGroup);
        }

        public int getViewTypeCount() {
            return 1;
        }

        public boolean hasStableIds() {
            return this.f3341a != null && this.f3341a.hasStableIds();
        }

        public boolean isEmpty() {
            return getCount() == 0;
        }

        public boolean isEnabled(int i) {
            ListAdapter listAdapter = this.f3342b;
            if (listAdapter != null) {
                return listAdapter.isEnabled(i);
            }
            return true;
        }

        public void registerDataSetObserver(DataSetObserver dataSetObserver) {
            if (this.f3341a != null) {
                this.f3341a.registerDataSetObserver(dataSetObserver);
            }
        }

        public void unregisterDataSetObserver(DataSetObserver dataSetObserver) {
            if (this.f3341a != null) {
                this.f3341a.unregisterDataSetObserver(dataSetObserver);
            }
        }
    }

    /* renamed from: android.support.v7.widget.x$b */
    private class C0930b extends C0789at {

        /* renamed from: a */
        ListAdapter f3343a;

        /* renamed from: h */
        private CharSequence f3345h;

        /* renamed from: i */
        private final Rect f3346i = new Rect();

        public C0930b(Context context, AttributeSet attributeSet, int i) {
            super(context, attributeSet, i);
            mo3778b((View) C0927x.this);
            mo3776a(true);
            mo3770a(0);
            mo3773a((OnItemClickListener) new OnItemClickListener(C0927x.this) {
                public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
                    C0927x.this.setSelection(i);
                    if (C0927x.this.getOnItemClickListener() != null) {
                        C0927x.this.performItemClick(view, i, C0930b.this.f3343a.getItemId(i));
                    }
                    C0930b.this.mo2662c();
                }
            });
        }

        /* renamed from: a */
        public void mo2655a() {
            boolean d = mo2665d();
            mo4670f();
            mo3787h(2);
            super.mo2655a();
            mo2666e().setChoiceMode(1);
            mo3789i(C0927x.this.getSelectedItemPosition());
            if (!d) {
                ViewTreeObserver viewTreeObserver = C0927x.this.getViewTreeObserver();
                if (viewTreeObserver != null) {
                    final C09322 r1 = new OnGlobalLayoutListener() {
                        public void onGlobalLayout() {
                            if (!C0930b.this.mo4668a((View) C0927x.this)) {
                                C0930b.this.mo2662c();
                                return;
                            }
                            C0930b.this.mo4670f();
                            C0930b.super.mo2655a();
                        }
                    };
                    viewTreeObserver.addOnGlobalLayoutListener(r1);
                    mo3775a((OnDismissListener) new OnDismissListener() {
                        public void onDismiss() {
                            ViewTreeObserver viewTreeObserver = C0927x.this.getViewTreeObserver();
                            if (viewTreeObserver != null) {
                                viewTreeObserver.removeGlobalOnLayoutListener(r1);
                            }
                        }
                    });
                }
            }
        }

        /* renamed from: a */
        public void mo3774a(ListAdapter listAdapter) {
            super.mo3774a(listAdapter);
            this.f3343a = listAdapter;
        }

        /* renamed from: a */
        public void mo4667a(CharSequence charSequence) {
            this.f3345h = charSequence;
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public boolean mo4668a(View view) {
            return C0495r.m2171z(view) && view.getGlobalVisibleRect(this.f3346i);
        }

        /* renamed from: b */
        public CharSequence mo4669b() {
            return this.f3345h;
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: f */
        public void mo4670f() {
            int i;
            Drawable h = mo3786h();
            int i2 = 0;
            if (h != null) {
                h.getPadding(C0927x.this.f3333c);
                i2 = C0885bv.m4757a(C0927x.this) ? C0927x.this.f3333c.right : -C0927x.this.f3333c.left;
            } else {
                Rect rect = C0927x.this.f3333c;
                C0927x.this.f3333c.right = 0;
                rect.left = 0;
            }
            int paddingLeft = C0927x.this.getPaddingLeft();
            int paddingRight = C0927x.this.getPaddingRight();
            int width = C0927x.this.getWidth();
            if (C0927x.this.f3332b == -2) {
                int a = C0927x.this.mo4632a((SpinnerAdapter) this.f3343a, mo3786h());
                int i3 = (C0927x.this.getContext().getResources().getDisplayMetrics().widthPixels - C0927x.this.f3333c.left) - C0927x.this.f3333c.right;
                if (a > i3) {
                    a = i3;
                }
                i = Math.max(a, (width - paddingLeft) - paddingRight);
            } else {
                i = C0927x.this.f3332b == -1 ? (width - paddingLeft) - paddingRight : C0927x.this.f3332b;
            }
            mo3784g(i);
            mo3780c(C0885bv.m4757a(C0927x.this) ? i2 + ((width - paddingRight) - mo3792l()) : i2 + paddingLeft);
        }
    }

    public C0927x(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, C0541a.spinnerStyle);
    }

    public C0927x(Context context, AttributeSet attributeSet, int i) {
        this(context, attributeSet, i, -1);
    }

    public C0927x(Context context, AttributeSet attributeSet, int i, int i2) {
        this(context, attributeSet, i, i2, null);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:23:0x0055, code lost:
        if (r12 != null) goto L_0x0057;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:24:0x0057, code lost:
        r12.recycle();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:33:0x0069, code lost:
        if (r12 != null) goto L_0x0057;
     */
    /* JADX WARNING: Removed duplicated region for block: B:14:0x0041  */
    /* JADX WARNING: Removed duplicated region for block: B:36:0x006f  */
    /* JADX WARNING: Removed duplicated region for block: B:42:0x00b3  */
    /* JADX WARNING: Removed duplicated region for block: B:45:0x00cc  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public C0927x(android.content.Context r8, android.util.AttributeSet r9, int r10, int r11, android.content.res.Resources.Theme r12) {
        /*
            r7 = this;
            r7.<init>(r8, r9, r10)
            android.graphics.Rect r0 = new android.graphics.Rect
            r0.<init>()
            r7.f3333c = r0
            int[] r0 = android.support.p031v7.p032a.C0540a.C0550j.Spinner
            r1 = 0
            android.support.v7.widget.bn r0 = android.support.p031v7.widget.C0869bn.m4638a(r8, r9, r0, r10, r1)
            android.support.v7.widget.g r2 = new android.support.v7.widget.g
            r2.<init>(r7)
            r7.f3334e = r2
            r2 = 0
            if (r12 == 0) goto L_0x0023
            android.support.v7.view.d r3 = new android.support.v7.view.d
            r3.<init>(r8, r12)
        L_0x0020:
            r7.f3335f = r3
            goto L_0x003c
        L_0x0023:
            int r12 = android.support.p031v7.p032a.C0540a.C0550j.Spinner_popupTheme
            int r12 = r0.mo4439g(r12, r1)
            if (r12 == 0) goto L_0x0031
            android.support.v7.view.d r3 = new android.support.v7.view.d
            r3.<init>(r8, r12)
            goto L_0x0020
        L_0x0031:
            int r12 = android.os.Build.VERSION.SDK_INT
            r3 = 23
            if (r12 >= r3) goto L_0x0039
            r12 = r8
            goto L_0x003a
        L_0x0039:
            r12 = r2
        L_0x003a:
            r7.f3335f = r12
        L_0x003c:
            android.content.Context r12 = r7.f3335f
            r3 = 1
            if (r12 == 0) goto L_0x00ab
            r12 = -1
            if (r11 != r12) goto L_0x0073
            int[] r12 = f3330d     // Catch:{ Exception -> 0x0060, all -> 0x005d }
            android.content.res.TypedArray r12 = r8.obtainStyledAttributes(r9, r12, r10, r1)     // Catch:{ Exception -> 0x0060, all -> 0x005d }
            boolean r4 = r12.hasValue(r1)     // Catch:{ Exception -> 0x005b }
            if (r4 == 0) goto L_0x0055
            int r4 = r12.getInt(r1, r1)     // Catch:{ Exception -> 0x005b }
            r11 = r4
        L_0x0055:
            if (r12 == 0) goto L_0x0073
        L_0x0057:
            r12.recycle()
            goto L_0x0073
        L_0x005b:
            r4 = move-exception
            goto L_0x0062
        L_0x005d:
            r8 = move-exception
            r12 = r2
            goto L_0x006d
        L_0x0060:
            r4 = move-exception
            r12 = r2
        L_0x0062:
            java.lang.String r5 = "AppCompatSpinner"
            java.lang.String r6 = "Could not read android:spinnerMode"
            android.util.Log.i(r5, r6, r4)     // Catch:{ all -> 0x006c }
            if (r12 == 0) goto L_0x0073
            goto L_0x0057
        L_0x006c:
            r8 = move-exception
        L_0x006d:
            if (r12 == 0) goto L_0x0072
            r12.recycle()
        L_0x0072:
            throw r8
        L_0x0073:
            if (r11 != r3) goto L_0x00ab
            android.support.v7.widget.x$b r11 = new android.support.v7.widget.x$b
            android.content.Context r12 = r7.f3335f
            r11.<init>(r12, r9, r10)
            android.content.Context r12 = r7.f3335f
            int[] r4 = android.support.p031v7.p032a.C0540a.C0550j.Spinner
            android.support.v7.widget.bn r12 = android.support.p031v7.widget.C0869bn.m4638a(r12, r9, r4, r10, r1)
            int r1 = android.support.p031v7.p032a.C0540a.C0550j.Spinner_android_dropDownWidth
            r4 = -2
            int r1 = r12.mo4437f(r1, r4)
            r7.f3332b = r1
            int r1 = android.support.p031v7.p032a.C0540a.C0550j.Spinner_android_popupBackground
            android.graphics.drawable.Drawable r1 = r12.mo4426a(r1)
            r11.mo3772a(r1)
            int r1 = android.support.p031v7.p032a.C0540a.C0550j.Spinner_android_prompt
            java.lang.String r1 = r0.mo4434d(r1)
            r11.mo4667a(r1)
            r12.mo4427a()
            r7.f3331a = r11
            android.support.v7.widget.x$1 r12 = new android.support.v7.widget.x$1
            r12.<init>(r7, r11)
            r7.f3336g = r12
        L_0x00ab:
            int r11 = android.support.p031v7.p032a.C0540a.C0550j.Spinner_android_entries
            java.lang.CharSequence[] r11 = r0.mo4438f(r11)
            if (r11 == 0) goto L_0x00c3
            android.widget.ArrayAdapter r12 = new android.widget.ArrayAdapter
            r1 = 17367048(0x1090008, float:2.5162948E-38)
            r12.<init>(r8, r1, r11)
            int r8 = android.support.p031v7.p032a.C0540a.C0547g.support_simple_spinner_dropdown_item
            r12.setDropDownViewResource(r8)
            r7.setAdapter(r12)
        L_0x00c3:
            r0.mo4427a()
            r7.f3338i = r3
            android.widget.SpinnerAdapter r8 = r7.f3337h
            if (r8 == 0) goto L_0x00d3
            android.widget.SpinnerAdapter r8 = r7.f3337h
            r7.setAdapter(r8)
            r7.f3337h = r2
        L_0x00d3:
            android.support.v7.widget.g r8 = r7.f3334e
            r8.mo4547a(r9, r10)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.p031v7.widget.C0927x.<init>(android.content.Context, android.util.AttributeSet, int, int, android.content.res.Resources$Theme):void");
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public int mo4632a(SpinnerAdapter spinnerAdapter, Drawable drawable) {
        int i = 0;
        if (spinnerAdapter == null) {
            return 0;
        }
        int makeMeasureSpec = MeasureSpec.makeMeasureSpec(getMeasuredWidth(), 0);
        int makeMeasureSpec2 = MeasureSpec.makeMeasureSpec(getMeasuredHeight(), 0);
        int max = Math.max(0, getSelectedItemPosition());
        int min = Math.min(spinnerAdapter.getCount(), max + 15);
        int i2 = 0;
        View view = null;
        for (int max2 = Math.max(0, max - (15 - (min - max))); max2 < min; max2++) {
            int itemViewType = spinnerAdapter.getItemViewType(max2);
            if (itemViewType != i) {
                view = null;
                i = itemViewType;
            }
            view = spinnerAdapter.getView(max2, view, this);
            if (view.getLayoutParams() == null) {
                view.setLayoutParams(new LayoutParams(-2, -2));
            }
            view.measure(makeMeasureSpec, makeMeasureSpec2);
            i2 = Math.max(i2, view.getMeasuredWidth());
        }
        if (drawable != null) {
            drawable.getPadding(this.f3333c);
            i2 += this.f3333c.left + this.f3333c.right;
        }
        return i2;
    }

    /* access modifiers changed from: protected */
    public void drawableStateChanged() {
        super.drawableStateChanged();
        if (this.f3334e != null) {
            this.f3334e.mo4550c();
        }
    }

    public int getDropDownHorizontalOffset() {
        if (this.f3331a != null) {
            return this.f3331a.mo3790j();
        }
        if (VERSION.SDK_INT >= 16) {
            return super.getDropDownHorizontalOffset();
        }
        return 0;
    }

    public int getDropDownVerticalOffset() {
        if (this.f3331a != null) {
            return this.f3331a.mo3791k();
        }
        if (VERSION.SDK_INT >= 16) {
            return super.getDropDownVerticalOffset();
        }
        return 0;
    }

    public int getDropDownWidth() {
        if (this.f3331a != null) {
            return this.f3332b;
        }
        if (VERSION.SDK_INT >= 16) {
            return super.getDropDownWidth();
        }
        return 0;
    }

    public Drawable getPopupBackground() {
        if (this.f3331a != null) {
            return this.f3331a.mo3786h();
        }
        if (VERSION.SDK_INT >= 16) {
            return super.getPopupBackground();
        }
        return null;
    }

    public Context getPopupContext() {
        if (this.f3331a != null) {
            return this.f3335f;
        }
        if (VERSION.SDK_INT >= 23) {
            return super.getPopupContext();
        }
        return null;
    }

    public CharSequence getPrompt() {
        return this.f3331a != null ? this.f3331a.mo4669b() : super.getPrompt();
    }

    public ColorStateList getSupportBackgroundTintList() {
        if (this.f3334e != null) {
            return this.f3334e.mo4542a();
        }
        return null;
    }

    public Mode getSupportBackgroundTintMode() {
        if (this.f3334e != null) {
            return this.f3334e.mo4548b();
        }
        return null;
    }

    /* access modifiers changed from: protected */
    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        if (this.f3331a != null && this.f3331a.mo2665d()) {
            this.f3331a.mo2662c();
        }
    }

    /* access modifiers changed from: protected */
    public void onMeasure(int i, int i2) {
        super.onMeasure(i, i2);
        if (this.f3331a != null && MeasureSpec.getMode(i) == Integer.MIN_VALUE) {
            setMeasuredDimension(Math.min(Math.max(getMeasuredWidth(), mo4632a(getAdapter(), getBackground())), MeasureSpec.getSize(i)), getMeasuredHeight());
        }
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        if (this.f3336g == null || !this.f3336g.onTouch(this, motionEvent)) {
            return super.onTouchEvent(motionEvent);
        }
        return true;
    }

    public boolean performClick() {
        if (this.f3331a == null) {
            return super.performClick();
        }
        if (!this.f3331a.mo2665d()) {
            this.f3331a.mo2655a();
        }
        return true;
    }

    public void setAdapter(SpinnerAdapter spinnerAdapter) {
        if (!this.f3338i) {
            this.f3337h = spinnerAdapter;
            return;
        }
        super.setAdapter(spinnerAdapter);
        if (this.f3331a != null) {
            this.f3331a.mo3774a((ListAdapter) new C0929a(spinnerAdapter, (this.f3335f == null ? getContext() : this.f3335f).getTheme()));
        }
    }

    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        if (this.f3334e != null) {
            this.f3334e.mo4546a(drawable);
        }
    }

    public void setBackgroundResource(int i) {
        super.setBackgroundResource(i);
        if (this.f3334e != null) {
            this.f3334e.mo4543a(i);
        }
    }

    public void setDropDownHorizontalOffset(int i) {
        if (this.f3331a != null) {
            this.f3331a.mo3780c(i);
            return;
        }
        if (VERSION.SDK_INT >= 16) {
            super.setDropDownHorizontalOffset(i);
        }
    }

    public void setDropDownVerticalOffset(int i) {
        if (this.f3331a != null) {
            this.f3331a.mo3781d(i);
            return;
        }
        if (VERSION.SDK_INT >= 16) {
            super.setDropDownVerticalOffset(i);
        }
    }

    public void setDropDownWidth(int i) {
        if (this.f3331a != null) {
            this.f3332b = i;
            return;
        }
        if (VERSION.SDK_INT >= 16) {
            super.setDropDownWidth(i);
        }
    }

    public void setPopupBackgroundDrawable(Drawable drawable) {
        if (this.f3331a != null) {
            this.f3331a.mo3772a(drawable);
            return;
        }
        if (VERSION.SDK_INT >= 16) {
            super.setPopupBackgroundDrawable(drawable);
        }
    }

    public void setPopupBackgroundResource(int i) {
        setPopupBackgroundDrawable(C0606a.m2714b(getPopupContext(), i));
    }

    public void setPrompt(CharSequence charSequence) {
        if (this.f3331a != null) {
            this.f3331a.mo4667a(charSequence);
        } else {
            super.setPrompt(charSequence);
        }
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        if (this.f3334e != null) {
            this.f3334e.mo4544a(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(Mode mode) {
        if (this.f3334e != null) {
            this.f3334e.mo4545a(mode);
        }
    }
}
