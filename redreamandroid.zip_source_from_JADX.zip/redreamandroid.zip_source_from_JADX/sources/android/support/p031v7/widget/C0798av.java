package android.support.p031v7.widget;

import android.content.Context;
import android.content.res.Configuration;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.support.p031v7.view.menu.C0654g;
import android.support.p031v7.view.menu.C0655h;
import android.support.p031v7.view.menu.C0659j;
import android.support.p031v7.view.menu.ListMenuItemView;
import android.transition.Transition;
import android.util.AttributeSet;
import android.util.Log;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.widget.HeaderViewListAdapter;
import android.widget.ListAdapter;
import android.widget.PopupWindow;
import java.lang.reflect.Method;

/* renamed from: android.support.v7.widget.av */
public class C0798av extends C0789at implements C0797au {

    /* renamed from: a */
    private static Method f2827a;

    /* renamed from: b */
    private C0797au f2828b;

    /* renamed from: android.support.v7.widget.av$a */
    public static class C0799a extends C0769am {

        /* renamed from: b */
        final int f2829b;

        /* renamed from: c */
        final int f2830c;

        /* renamed from: d */
        private C0797au f2831d;

        /* renamed from: e */
        private MenuItem f2832e;

        public C0799a(Context context, boolean z) {
            super(context, z);
            Configuration configuration = context.getResources().getConfiguration();
            if (VERSION.SDK_INT < 17 || 1 != configuration.getLayoutDirection()) {
                this.f2829b = 22;
                this.f2830c = 21;
                return;
            }
            this.f2829b = 21;
            this.f2830c = 22;
        }

        /* renamed from: a */
        public /* bridge */ /* synthetic */ int mo3672a(int i, int i2, int i3, int i4, int i5) {
            return super.mo3672a(i, i2, i3, i4, i5);
        }

        /* renamed from: a */
        public /* bridge */ /* synthetic */ boolean mo3673a(MotionEvent motionEvent, int i) {
            return super.mo3673a(motionEvent, i);
        }

        public /* bridge */ /* synthetic */ boolean hasFocus() {
            return super.hasFocus();
        }

        public /* bridge */ /* synthetic */ boolean hasWindowFocus() {
            return super.hasWindowFocus();
        }

        public /* bridge */ /* synthetic */ boolean isFocused() {
            return super.isFocused();
        }

        public /* bridge */ /* synthetic */ boolean isInTouchMode() {
            return super.isInTouchMode();
        }

        public boolean onHoverEvent(MotionEvent motionEvent) {
            int i;
            if (this.f2831d != null) {
                ListAdapter adapter = getAdapter();
                if (adapter instanceof HeaderViewListAdapter) {
                    HeaderViewListAdapter headerViewListAdapter = (HeaderViewListAdapter) adapter;
                    i = headerViewListAdapter.getHeadersCount();
                    adapter = headerViewListAdapter.getWrappedAdapter();
                } else {
                    i = 0;
                }
                C0654g gVar = (C0654g) adapter;
                C0659j jVar = null;
                if (motionEvent.getAction() != 10) {
                    int pointToPosition = pointToPosition((int) motionEvent.getX(), (int) motionEvent.getY());
                    if (pointToPosition != -1) {
                        int i2 = pointToPosition - i;
                        if (i2 >= 0 && i2 < gVar.getCount()) {
                            jVar = gVar.getItem(i2);
                        }
                    }
                }
                MenuItem menuItem = this.f2832e;
                if (menuItem != jVar) {
                    C0655h a = gVar.mo2687a();
                    if (menuItem != null) {
                        this.f2831d.mo2673a(a, menuItem);
                    }
                    this.f2832e = jVar;
                    if (jVar != null) {
                        this.f2831d.mo2674b(a, jVar);
                    }
                }
            }
            return super.onHoverEvent(motionEvent);
        }

        public boolean onKeyDown(int i, KeyEvent keyEvent) {
            ListMenuItemView listMenuItemView = (ListMenuItemView) getSelectedView();
            if (listMenuItemView != null && i == this.f2829b) {
                if (listMenuItemView.isEnabled() && listMenuItemView.getItemData().hasSubMenu()) {
                    performItemClick(listMenuItemView, getSelectedItemPosition(), getSelectedItemId());
                }
                return true;
            } else if (listMenuItemView == null || i != this.f2830c) {
                return super.onKeyDown(i, keyEvent);
            } else {
                setSelection(-1);
                ((C0654g) getAdapter()).mo2687a().mo2711a(false);
                return true;
            }
        }

        public /* bridge */ /* synthetic */ boolean onTouchEvent(MotionEvent motionEvent) {
            return super.onTouchEvent(motionEvent);
        }

        public void setHoverListener(C0797au auVar) {
            this.f2831d = auVar;
        }

        public /* bridge */ /* synthetic */ void setSelector(Drawable drawable) {
            super.setSelector(drawable);
        }
    }

    static {
        try {
            f2827a = PopupWindow.class.getDeclaredMethod("setTouchModal", new Class[]{Boolean.TYPE});
        } catch (NoSuchMethodException unused) {
            Log.i("MenuPopupWindow", "Could not find method setTouchModal() on PopupWindow. Oh well.");
        }
    }

    public C0798av(Context context, AttributeSet attributeSet, int i, int i2) {
        super(context, attributeSet, i, i2);
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public C0769am mo3769a(Context context, boolean z) {
        C0799a aVar = new C0799a(context, z);
        aVar.setHoverListener(this);
        return aVar;
    }

    /* renamed from: a */
    public void mo2673a(C0655h hVar, MenuItem menuItem) {
        if (this.f2828b != null) {
            this.f2828b.mo2673a(hVar, menuItem);
        }
    }

    /* renamed from: a */
    public void mo3805a(C0797au auVar) {
        this.f2828b = auVar;
    }

    /* renamed from: a */
    public void mo3806a(Object obj) {
        if (VERSION.SDK_INT >= 23) {
            this.f2801g.setEnterTransition((Transition) obj);
        }
    }

    /* renamed from: b */
    public void mo2674b(C0655h hVar, MenuItem menuItem) {
        if (this.f2828b != null) {
            this.f2828b.mo2674b(hVar, menuItem);
        }
    }

    /* renamed from: b */
    public void mo3807b(Object obj) {
        if (VERSION.SDK_INT >= 23) {
            this.f2801g.setExitTransition((Transition) obj);
        }
    }

    /* renamed from: c */
    public void mo3808c(boolean z) {
        if (f2827a != null) {
            try {
                f2827a.invoke(this.f2801g, new Object[]{Boolean.valueOf(z)});
            } catch (Exception unused) {
                Log.i("MenuPopupWindow", "Could not invoke setTouchModal() on PopupWindow. Oh well.");
            }
        }
    }
}
