package android.support.p031v7.widget;

import android.support.p018v4.p027g.C0428j.C0429a;
import android.support.p018v4.p027g.C0428j.C0430b;
import android.support.p031v7.widget.C0805ay.C0846x;
import java.util.ArrayList;
import java.util.List;

/* renamed from: android.support.v7.widget.e */
class C0901e implements C0801a {

    /* renamed from: a */
    final ArrayList<C0903b> f3257a;

    /* renamed from: b */
    final ArrayList<C0903b> f3258b;

    /* renamed from: c */
    final C0902a f3259c;

    /* renamed from: d */
    Runnable f3260d;

    /* renamed from: e */
    final boolean f3261e;

    /* renamed from: f */
    final C0800aw f3262f;

    /* renamed from: g */
    private C0429a<C0903b> f3263g;

    /* renamed from: h */
    private int f3264h;

    /* renamed from: android.support.v7.widget.e$a */
    interface C0902a {
        /* renamed from: a */
        C0846x mo3998a(int i);

        /* renamed from: a */
        void mo3999a(int i, int i2);

        /* renamed from: a */
        void mo4000a(int i, int i2, Object obj);

        /* renamed from: a */
        void mo4001a(C0903b bVar);

        /* renamed from: b */
        void mo4002b(int i, int i2);

        /* renamed from: b */
        void mo4003b(C0903b bVar);

        /* renamed from: c */
        void mo4004c(int i, int i2);

        /* renamed from: d */
        void mo4006d(int i, int i2);
    }

    /* renamed from: android.support.v7.widget.e$b */
    static class C0903b {

        /* renamed from: a */
        int f3265a;

        /* renamed from: b */
        int f3266b;

        /* renamed from: c */
        Object f3267c;

        /* renamed from: d */
        int f3268d;

        C0903b(int i, int i2, int i3, Object obj) {
            this.f3265a = i;
            this.f3266b = i2;
            this.f3268d = i3;
            this.f3267c = obj;
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public String mo4532a() {
            int i = this.f3265a;
            if (i == 4) {
                return "up";
            }
            if (i == 8) {
                return "mv";
            }
            switch (i) {
                case 1:
                    return "add";
                case 2:
                    return "rm";
                default:
                    return "??";
            }
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (obj == null || getClass() != obj.getClass()) {
                return false;
            }
            C0903b bVar = (C0903b) obj;
            if (this.f3265a != bVar.f3265a) {
                return false;
            }
            if (this.f3265a == 8 && Math.abs(this.f3268d - this.f3266b) == 1 && this.f3268d == bVar.f3266b && this.f3266b == bVar.f3268d) {
                return true;
            }
            if (this.f3268d != bVar.f3268d || this.f3266b != bVar.f3266b) {
                return false;
            }
            if (this.f3267c != null) {
                if (!this.f3267c.equals(bVar.f3267c)) {
                    return false;
                }
            } else if (bVar.f3267c != null) {
                return false;
            }
            return true;
        }

        public int hashCode() {
            return (31 * ((this.f3265a * 31) + this.f3266b)) + this.f3268d;
        }

        public String toString() {
            StringBuilder sb = new StringBuilder();
            sb.append(Integer.toHexString(System.identityHashCode(this)));
            sb.append("[");
            sb.append(mo4532a());
            sb.append(",s:");
            sb.append(this.f3266b);
            sb.append("c:");
            sb.append(this.f3268d);
            sb.append(",p:");
            sb.append(this.f3267c);
            sb.append("]");
            return sb.toString();
        }
    }

    C0901e(C0902a aVar) {
        this(aVar, false);
    }

    C0901e(C0902a aVar, boolean z) {
        this.f3263g = new C0430b(30);
        this.f3257a = new ArrayList<>();
        this.f3258b = new ArrayList<>();
        this.f3264h = 0;
        this.f3259c = aVar;
        this.f3261e = z;
        this.f3262f = new C0800aw(this);
    }

    /* renamed from: b */
    private int m4818b(int i, int i2) {
        int i3;
        int i4;
        int i5;
        int i6;
        int i7;
        int i8;
        for (int size = this.f3258b.size() - 1; size >= 0; size--) {
            C0903b bVar = (C0903b) this.f3258b.get(size);
            if (bVar.f3265a == 8) {
                if (bVar.f3266b < bVar.f3268d) {
                    i5 = bVar.f3266b;
                    i4 = bVar.f3268d;
                } else {
                    i5 = bVar.f3268d;
                    i4 = bVar.f3266b;
                }
                if (i < i5 || i > i4) {
                    if (i < bVar.f3266b) {
                        if (i2 == 1) {
                            bVar.f3266b++;
                            i6 = bVar.f3268d + 1;
                        } else if (i2 == 2) {
                            bVar.f3266b--;
                            i6 = bVar.f3268d - 1;
                        }
                        bVar.f3268d = i6;
                    }
                } else if (i5 == bVar.f3266b) {
                    if (i2 == 1) {
                        i8 = bVar.f3268d + 1;
                    } else {
                        if (i2 == 2) {
                            i8 = bVar.f3268d - 1;
                        }
                        i++;
                    }
                    bVar.f3268d = i8;
                    i++;
                } else {
                    if (i2 == 1) {
                        i7 = bVar.f3266b + 1;
                    } else {
                        if (i2 == 2) {
                            i7 = bVar.f3266b - 1;
                        }
                        i--;
                    }
                    bVar.f3266b = i7;
                    i--;
                }
            } else if (bVar.f3266b > i) {
                if (i2 == 1) {
                    i3 = bVar.f3266b + 1;
                } else if (i2 == 2) {
                    i3 = bVar.f3266b - 1;
                }
                bVar.f3266b = i3;
            } else if (bVar.f3265a == 1) {
                i -= bVar.f3268d;
            } else if (bVar.f3265a == 2) {
                i += bVar.f3268d;
            }
        }
        for (int size2 = this.f3258b.size() - 1; size2 >= 0; size2--) {
            C0903b bVar2 = (C0903b) this.f3258b.get(size2);
            if (bVar2.f3265a == 8) {
                if (bVar2.f3268d != bVar2.f3266b && bVar2.f3268d >= 0) {
                }
            } else if (bVar2.f3268d > 0) {
            }
            this.f3258b.remove(size2);
            mo3815a(bVar2);
        }
        return i;
    }

    /* renamed from: b */
    private void m4819b(C0903b bVar) {
        m4825g(bVar);
    }

    /* renamed from: c */
    private void m4820c(C0903b bVar) {
        boolean z;
        boolean z2;
        boolean z3;
        int i = bVar.f3266b;
        int i2 = bVar.f3266b + bVar.f3268d;
        int i3 = bVar.f3266b;
        boolean z4 = true;
        int i4 = 0;
        while (i3 < i2) {
            if (this.f3259c.mo3998a(i3) != null || m4822d(i3)) {
                if (!z4) {
                    m4823e(mo3814a(2, i, i4, null));
                    z3 = true;
                } else {
                    z3 = false;
                }
                z = true;
            } else {
                if (z4) {
                    m4825g(mo3814a(2, i, i4, null));
                    z2 = true;
                } else {
                    z2 = false;
                }
                z = false;
            }
            if (z2) {
                i3 -= i4;
                i2 -= i4;
                i4 = 1;
            } else {
                i4++;
            }
            i3++;
            z4 = z;
        }
        if (i4 != bVar.f3268d) {
            mo3815a(bVar);
            bVar = mo3814a(2, i, i4, null);
        }
        if (!z4) {
            m4823e(bVar);
        } else {
            m4825g(bVar);
        }
    }

    /* renamed from: d */
    private void m4821d(C0903b bVar) {
        int i = bVar.f3266b;
        int i2 = bVar.f3266b + bVar.f3268d;
        char c = 65535;
        int i3 = i;
        int i4 = 0;
        for (int i5 = bVar.f3266b; i5 < i2; i5++) {
            if (this.f3259c.mo3998a(i5) != null || m4822d(i5)) {
                if (c == 0) {
                    m4823e(mo3814a(4, i3, i4, bVar.f3267c));
                    i3 = i5;
                    i4 = 0;
                }
                c = 1;
            } else {
                if (c == 1) {
                    m4825g(mo3814a(4, i3, i4, bVar.f3267c));
                    i3 = i5;
                    i4 = 0;
                }
                c = 0;
            }
            i4++;
        }
        if (i4 != bVar.f3268d) {
            Object obj = bVar.f3267c;
            mo3815a(bVar);
            bVar = mo3814a(4, i3, i4, obj);
        }
        if (c == 0) {
            m4823e(bVar);
        } else {
            m4825g(bVar);
        }
    }

    /* renamed from: d */
    private boolean m4822d(int i) {
        int size = this.f3258b.size();
        for (int i2 = 0; i2 < size; i2++) {
            C0903b bVar = (C0903b) this.f3258b.get(i2);
            if (bVar.f3265a == 8) {
                if (mo4520a(bVar.f3268d, i2 + 1) == i) {
                    return true;
                }
            } else if (bVar.f3265a == 1) {
                int i3 = bVar.f3266b + bVar.f3268d;
                for (int i4 = bVar.f3266b; i4 < i3; i4++) {
                    if (mo4520a(i4, i2 + 1) == i) {
                        return true;
                    }
                }
                continue;
            } else {
                continue;
            }
        }
        return false;
    }

    /* renamed from: e */
    private void m4823e(C0903b bVar) {
        int i;
        if (bVar.f3265a == 1 || bVar.f3265a == 8) {
            throw new IllegalArgumentException("should not dispatch add or move for pre layout");
        }
        int b = m4818b(bVar.f3266b, bVar.f3265a);
        int i2 = bVar.f3266b;
        int i3 = bVar.f3265a;
        if (i3 == 2) {
            i = 0;
        } else if (i3 != 4) {
            StringBuilder sb = new StringBuilder();
            sb.append("op should be remove or update.");
            sb.append(bVar);
            throw new IllegalArgumentException(sb.toString());
        } else {
            i = 1;
        }
        int i4 = b;
        int i5 = i2;
        int i6 = 1;
        for (int i7 = 1; i7 < bVar.f3268d; i7++) {
            int b2 = m4818b(bVar.f3266b + (i * i7), bVar.f3265a);
            int i8 = bVar.f3265a;
            if (i8 == 2 ? b2 == i4 : i8 == 4 && b2 == i4 + 1) {
                i6++;
            } else {
                C0903b a = mo3814a(bVar.f3265a, i4, i6, bVar.f3267c);
                mo4522a(a, i5);
                mo3815a(a);
                if (bVar.f3265a == 4) {
                    i5 += i6;
                }
                i6 = 1;
                i4 = b2;
            }
        }
        Object obj = bVar.f3267c;
        mo3815a(bVar);
        if (i6 > 0) {
            C0903b a2 = mo3814a(bVar.f3265a, i4, i6, obj);
            mo4522a(a2, i5);
            mo3815a(a2);
        }
    }

    /* renamed from: f */
    private void m4824f(C0903b bVar) {
        m4825g(bVar);
    }

    /* renamed from: g */
    private void m4825g(C0903b bVar) {
        this.f3258b.add(bVar);
        int i = bVar.f3265a;
        if (i == 4) {
            this.f3259c.mo4000a(bVar.f3266b, bVar.f3268d, bVar.f3267c);
        } else if (i != 8) {
            switch (i) {
                case 1:
                    this.f3259c.mo4004c(bVar.f3266b, bVar.f3268d);
                    return;
                case 2:
                    this.f3259c.mo4002b(bVar.f3266b, bVar.f3268d);
                    return;
                default:
                    StringBuilder sb = new StringBuilder();
                    sb.append("Unknown update op type for ");
                    sb.append(bVar);
                    throw new IllegalArgumentException(sb.toString());
            }
        } else {
            this.f3259c.mo4006d(bVar.f3266b, bVar.f3268d);
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public int mo4520a(int i, int i2) {
        int size = this.f3258b.size();
        while (i2 < size) {
            C0903b bVar = (C0903b) this.f3258b.get(i2);
            if (bVar.f3265a == 8) {
                if (bVar.f3266b == i) {
                    i = bVar.f3268d;
                } else {
                    if (bVar.f3266b < i) {
                        i--;
                    }
                    if (bVar.f3268d <= i) {
                        i++;
                    }
                }
            } else if (bVar.f3266b > i) {
                continue;
            } else if (bVar.f3265a == 2) {
                if (i < bVar.f3266b + bVar.f3268d) {
                    return -1;
                }
                i -= bVar.f3268d;
            } else if (bVar.f3265a == 1) {
                i += bVar.f3268d;
            }
            i2++;
        }
        return i;
    }

    /* renamed from: a */
    public C0903b mo3814a(int i, int i2, int i3, Object obj) {
        C0903b bVar = (C0903b) this.f3263g.mo1743a();
        if (bVar == null) {
            return new C0903b(i, i2, i3, obj);
        }
        bVar.f3265a = i;
        bVar.f3266b = i2;
        bVar.f3268d = i3;
        bVar.f3267c = obj;
        return bVar;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo4521a() {
        mo4523a((List<C0903b>) this.f3257a);
        mo4523a((List<C0903b>) this.f3258b);
        this.f3264h = 0;
    }

    /* renamed from: a */
    public void mo3815a(C0903b bVar) {
        if (!this.f3261e) {
            bVar.f3267c = null;
            this.f3263g.mo1744a(bVar);
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo4522a(C0903b bVar, int i) {
        this.f3259c.mo4001a(bVar);
        int i2 = bVar.f3265a;
        if (i2 == 2) {
            this.f3259c.mo3999a(i, bVar.f3268d);
        } else if (i2 != 4) {
            throw new IllegalArgumentException("only remove and update ops can be dispatched in first pass");
        } else {
            this.f3259c.mo4000a(i, bVar.f3268d, bVar.f3267c);
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo4523a(List<C0903b> list) {
        int size = list.size();
        for (int i = 0; i < size; i++) {
            mo3815a((C0903b) list.get(i));
        }
        list.clear();
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public boolean mo4524a(int i) {
        return (i & this.f3264h) != 0;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: b */
    public int mo4525b(int i) {
        return mo4520a(i, 0);
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: b */
    public void mo4526b() {
        this.f3262f.mo3811a(this.f3257a);
        int size = this.f3257a.size();
        for (int i = 0; i < size; i++) {
            C0903b bVar = (C0903b) this.f3257a.get(i);
            int i2 = bVar.f3265a;
            if (i2 == 4) {
                m4821d(bVar);
            } else if (i2 != 8) {
                switch (i2) {
                    case 1:
                        m4824f(bVar);
                        break;
                    case 2:
                        m4820c(bVar);
                        break;
                }
            } else {
                m4819b(bVar);
            }
            if (this.f3260d != null) {
                this.f3260d.run();
            }
        }
        this.f3257a.clear();
    }

    /* JADX WARNING: Code restructure failed: missing block: B:35:0x0047, code lost:
        continue;
     */
    /* renamed from: c */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public int mo4527c(int r6) {
        /*
            r5 = this;
            java.util.ArrayList<android.support.v7.widget.e$b> r0 = r5.f3257a
            int r0 = r0.size()
            r1 = 0
        L_0x0007:
            if (r1 >= r0) goto L_0x004a
            java.util.ArrayList<android.support.v7.widget.e$b> r2 = r5.f3257a
            java.lang.Object r2 = r2.get(r1)
            android.support.v7.widget.e$b r2 = (android.support.p031v7.widget.C0901e.C0903b) r2
            int r3 = r2.f3265a
            r4 = 8
            if (r3 == r4) goto L_0x0034
            switch(r3) {
                case 1: goto L_0x002c;
                case 2: goto L_0x001b;
                default: goto L_0x001a;
            }
        L_0x001a:
            goto L_0x0047
        L_0x001b:
            int r3 = r2.f3266b
            if (r3 > r6) goto L_0x0047
            int r3 = r2.f3266b
            int r4 = r2.f3268d
            int r3 = r3 + r4
            if (r3 <= r6) goto L_0x0028
            r6 = -1
            return r6
        L_0x0028:
            int r2 = r2.f3268d
            int r6 = r6 - r2
            goto L_0x0047
        L_0x002c:
            int r3 = r2.f3266b
            if (r3 > r6) goto L_0x0047
            int r2 = r2.f3268d
            int r6 = r6 + r2
            goto L_0x0047
        L_0x0034:
            int r3 = r2.f3266b
            if (r3 != r6) goto L_0x003b
            int r6 = r2.f3268d
            goto L_0x0047
        L_0x003b:
            int r3 = r2.f3266b
            if (r3 >= r6) goto L_0x0041
            int r6 = r6 + -1
        L_0x0041:
            int r2 = r2.f3268d
            if (r2 > r6) goto L_0x0047
            int r6 = r6 + 1
        L_0x0047:
            int r1 = r1 + 1
            goto L_0x0007
        L_0x004a:
            return r6
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.p031v7.widget.C0901e.mo4527c(int):int");
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: c */
    public void mo4528c() {
        int size = this.f3258b.size();
        for (int i = 0; i < size; i++) {
            this.f3259c.mo4003b((C0903b) this.f3258b.get(i));
        }
        mo4523a((List<C0903b>) this.f3258b);
        this.f3264h = 0;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: d */
    public boolean mo4529d() {
        return this.f3257a.size() > 0;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: e */
    public void mo4530e() {
        mo4528c();
        int size = this.f3257a.size();
        for (int i = 0; i < size; i++) {
            C0903b bVar = (C0903b) this.f3257a.get(i);
            int i2 = bVar.f3265a;
            if (i2 == 4) {
                this.f3259c.mo4003b(bVar);
                this.f3259c.mo4000a(bVar.f3266b, bVar.f3268d, bVar.f3267c);
            } else if (i2 != 8) {
                switch (i2) {
                    case 1:
                        this.f3259c.mo4003b(bVar);
                        this.f3259c.mo4004c(bVar.f3266b, bVar.f3268d);
                        break;
                    case 2:
                        this.f3259c.mo4003b(bVar);
                        this.f3259c.mo3999a(bVar.f3266b, bVar.f3268d);
                        break;
                }
            } else {
                this.f3259c.mo4003b(bVar);
                this.f3259c.mo4006d(bVar.f3266b, bVar.f3268d);
            }
            if (this.f3260d != null) {
                this.f3260d.run();
            }
        }
        mo4523a((List<C0903b>) this.f3257a);
        this.f3264h = 0;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: f */
    public boolean mo4531f() {
        return !this.f3258b.isEmpty() && !this.f3257a.isEmpty();
    }
}
