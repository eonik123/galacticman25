package android.support.p031v7.widget;

import android.content.Context;
import android.graphics.PointF;
import android.graphics.Rect;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.support.p018v4.p028h.p029a.C0464c;
import android.support.p018v4.p028h.p029a.C0464c.C0466b;
import android.support.p031v7.widget.C0805ay.C0823i;
import android.support.p031v7.widget.C0805ay.C0823i.C0826a;
import android.support.p031v7.widget.C0805ay.C0823i.C0827b;
import android.support.p031v7.widget.C0805ay.C0828j;
import android.support.p031v7.widget.C0805ay.C0835p;
import android.support.p031v7.widget.C0805ay.C0840t.C0842b;
import android.support.p031v7.widget.C0805ay.C0843u;
import android.util.AttributeSet;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewGroup.MarginLayoutParams;
import android.view.accessibility.AccessibilityEvent;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.BitSet;
import java.util.List;

/* renamed from: android.support.v7.widget.StaggeredGridLayoutManager */
public class StaggeredGridLayoutManager extends C0823i implements C0842b {

    /* renamed from: A */
    private C0729d f2477A;

    /* renamed from: B */
    private int f2478B;

    /* renamed from: C */
    private final Rect f2479C = new Rect();

    /* renamed from: D */
    private final C0724a f2480D = new C0724a();

    /* renamed from: E */
    private boolean f2481E = false;

    /* renamed from: F */
    private boolean f2482F = true;

    /* renamed from: G */
    private int[] f2483G;

    /* renamed from: H */
    private final Runnable f2484H = new Runnable() {
        public void run() {
            StaggeredGridLayoutManager.this.mo3348g();
        }
    };

    /* renamed from: a */
    C0731e[] f2485a;

    /* renamed from: b */
    C0802ax f2486b;

    /* renamed from: c */
    C0802ax f2487c;

    /* renamed from: d */
    boolean f2488d = false;

    /* renamed from: e */
    boolean f2489e = false;

    /* renamed from: f */
    int f2490f = -1;

    /* renamed from: g */
    int f2491g = Integer.MIN_VALUE;

    /* renamed from: h */
    C0726c f2492h = new C0726c();

    /* renamed from: i */
    private int f2493i = -1;

    /* renamed from: j */
    private int f2494j;

    /* renamed from: k */
    private int f2495k;

    /* renamed from: l */
    private final C0786ar f2496l;

    /* renamed from: m */
    private BitSet f2497m;

    /* renamed from: n */
    private int f2498n = 2;

    /* renamed from: o */
    private boolean f2499o;

    /* renamed from: z */
    private boolean f2500z;

    /* renamed from: android.support.v7.widget.StaggeredGridLayoutManager$a */
    class C0724a {

        /* renamed from: a */
        int f2502a;

        /* renamed from: b */
        int f2503b;

        /* renamed from: c */
        boolean f2504c;

        /* renamed from: d */
        boolean f2505d;

        /* renamed from: e */
        boolean f2506e;

        /* renamed from: f */
        int[] f2507f;

        C0724a() {
            mo3359a();
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public void mo3359a() {
            this.f2502a = -1;
            this.f2503b = Integer.MIN_VALUE;
            this.f2504c = false;
            this.f2505d = false;
            this.f2506e = false;
            if (this.f2507f != null) {
                Arrays.fill(this.f2507f, -1);
            }
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public void mo3360a(int i) {
            this.f2503b = this.f2504c ? StaggeredGridLayoutManager.this.f2486b.mo3823d() - i : StaggeredGridLayoutManager.this.f2486b.mo3821c() + i;
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public void mo3361a(C0731e[] eVarArr) {
            int length = eVarArr.length;
            if (this.f2507f == null || this.f2507f.length < length) {
                this.f2507f = new int[StaggeredGridLayoutManager.this.f2485a.length];
            }
            for (int i = 0; i < length; i++) {
                this.f2507f[i] = eVarArr[i].mo3393a(Integer.MIN_VALUE);
            }
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: b */
        public void mo3362b() {
            this.f2503b = this.f2504c ? StaggeredGridLayoutManager.this.f2486b.mo3823d() : StaggeredGridLayoutManager.this.f2486b.mo3821c();
        }
    }

    /* renamed from: android.support.v7.widget.StaggeredGridLayoutManager$b */
    public static class C0725b extends C0828j {

        /* renamed from: a */
        C0731e f2509a;

        /* renamed from: b */
        boolean f2510b;

        public C0725b(int i, int i2) {
            super(i, i2);
        }

        public C0725b(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
        }

        public C0725b(LayoutParams layoutParams) {
            super(layoutParams);
        }

        public C0725b(MarginLayoutParams marginLayoutParams) {
            super(marginLayoutParams);
        }

        /* renamed from: a */
        public boolean mo3363a() {
            return this.f2510b;
        }

        /* renamed from: b */
        public final int mo3364b() {
            if (this.f2509a == null) {
                return -1;
            }
            return this.f2509a.f2531e;
        }
    }

    /* renamed from: android.support.v7.widget.StaggeredGridLayoutManager$c */
    static class C0726c {

        /* renamed from: a */
        int[] f2511a;

        /* renamed from: b */
        List<C0727a> f2512b;

        /* renamed from: android.support.v7.widget.StaggeredGridLayoutManager$c$a */
        static class C0727a implements Parcelable {
            public static final Creator<C0727a> CREATOR = new Creator<C0727a>() {
                /* renamed from: a */
                public C0727a createFromParcel(Parcel parcel) {
                    return new C0727a(parcel);
                }

                /* renamed from: a */
                public C0727a[] newArray(int i) {
                    return new C0727a[i];
                }
            };

            /* renamed from: a */
            int f2513a;

            /* renamed from: b */
            int f2514b;

            /* renamed from: c */
            int[] f2515c;

            /* renamed from: d */
            boolean f2516d;

            C0727a() {
            }

            C0727a(Parcel parcel) {
                this.f2513a = parcel.readInt();
                this.f2514b = parcel.readInt();
                boolean z = true;
                if (parcel.readInt() != 1) {
                    z = false;
                }
                this.f2516d = z;
                int readInt = parcel.readInt();
                if (readInt > 0) {
                    this.f2515c = new int[readInt];
                    parcel.readIntArray(this.f2515c);
                }
            }

            /* access modifiers changed from: 0000 */
            /* renamed from: a */
            public int mo3377a(int i) {
                if (this.f2515c == null) {
                    return 0;
                }
                return this.f2515c[i];
            }

            public int describeContents() {
                return 0;
            }

            public String toString() {
                StringBuilder sb = new StringBuilder();
                sb.append("FullSpanItem{mPosition=");
                sb.append(this.f2513a);
                sb.append(", mGapDir=");
                sb.append(this.f2514b);
                sb.append(", mHasUnwantedGapAfter=");
                sb.append(this.f2516d);
                sb.append(", mGapPerSpan=");
                sb.append(Arrays.toString(this.f2515c));
                sb.append('}');
                return sb.toString();
            }

            public void writeToParcel(Parcel parcel, int i) {
                parcel.writeInt(this.f2513a);
                parcel.writeInt(this.f2514b);
                parcel.writeInt(this.f2516d ? 1 : 0);
                if (this.f2515c == null || this.f2515c.length <= 0) {
                    parcel.writeInt(0);
                    return;
                }
                parcel.writeInt(this.f2515c.length);
                parcel.writeIntArray(this.f2515c);
            }
        }

        C0726c() {
        }

        /* renamed from: c */
        private void m3553c(int i, int i2) {
            if (this.f2512b != null) {
                int i3 = i + i2;
                for (int size = this.f2512b.size() - 1; size >= 0; size--) {
                    C0727a aVar = (C0727a) this.f2512b.get(size);
                    if (aVar.f2513a >= i) {
                        if (aVar.f2513a < i3) {
                            this.f2512b.remove(size);
                        } else {
                            aVar.f2513a -= i2;
                        }
                    }
                }
            }
        }

        /* renamed from: d */
        private void m3554d(int i, int i2) {
            if (this.f2512b != null) {
                for (int size = this.f2512b.size() - 1; size >= 0; size--) {
                    C0727a aVar = (C0727a) this.f2512b.get(size);
                    if (aVar.f2513a >= i) {
                        aVar.f2513a += i2;
                    }
                }
            }
        }

        /* renamed from: g */
        private int m3555g(int i) {
            if (this.f2512b == null) {
                return -1;
            }
            C0727a f = mo3376f(i);
            if (f != null) {
                this.f2512b.remove(f);
            }
            int size = this.f2512b.size();
            int i2 = 0;
            while (true) {
                if (i2 >= size) {
                    i2 = -1;
                    break;
                } else if (((C0727a) this.f2512b.get(i2)).f2513a >= i) {
                    break;
                } else {
                    i2++;
                }
            }
            if (i2 == -1) {
                return -1;
            }
            C0727a aVar = (C0727a) this.f2512b.get(i2);
            this.f2512b.remove(i2);
            return aVar.f2513a;
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public int mo3365a(int i) {
            if (this.f2512b != null) {
                for (int size = this.f2512b.size() - 1; size >= 0; size--) {
                    if (((C0727a) this.f2512b.get(size)).f2513a >= i) {
                        this.f2512b.remove(size);
                    }
                }
            }
            return mo3371b(i);
        }

        /* renamed from: a */
        public C0727a mo3366a(int i, int i2, int i3, boolean z) {
            if (this.f2512b == null) {
                return null;
            }
            int size = this.f2512b.size();
            for (int i4 = 0; i4 < size; i4++) {
                C0727a aVar = (C0727a) this.f2512b.get(i4);
                if (aVar.f2513a >= i2) {
                    return null;
                }
                if (aVar.f2513a >= i && (i3 == 0 || aVar.f2514b == i3 || (z && aVar.f2516d))) {
                    return aVar;
                }
            }
            return null;
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public void mo3367a() {
            if (this.f2511a != null) {
                Arrays.fill(this.f2511a, -1);
            }
            this.f2512b = null;
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public void mo3368a(int i, int i2) {
            if (this.f2511a != null && i < this.f2511a.length) {
                int i3 = i + i2;
                mo3375e(i3);
                System.arraycopy(this.f2511a, i3, this.f2511a, i, (this.f2511a.length - i) - i2);
                Arrays.fill(this.f2511a, this.f2511a.length - i2, this.f2511a.length, -1);
                m3553c(i, i2);
            }
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public void mo3369a(int i, C0731e eVar) {
            mo3375e(i);
            this.f2511a[i] = eVar.f2531e;
        }

        /* renamed from: a */
        public void mo3370a(C0727a aVar) {
            if (this.f2512b == null) {
                this.f2512b = new ArrayList();
            }
            int size = this.f2512b.size();
            for (int i = 0; i < size; i++) {
                C0727a aVar2 = (C0727a) this.f2512b.get(i);
                if (aVar2.f2513a == aVar.f2513a) {
                    this.f2512b.remove(i);
                }
                if (aVar2.f2513a >= aVar.f2513a) {
                    this.f2512b.add(i, aVar);
                    return;
                }
            }
            this.f2512b.add(aVar);
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: b */
        public int mo3371b(int i) {
            if (this.f2511a == null || i >= this.f2511a.length) {
                return -1;
            }
            int g = m3555g(i);
            if (g == -1) {
                Arrays.fill(this.f2511a, i, this.f2511a.length, -1);
                return this.f2511a.length;
            }
            int i2 = g + 1;
            Arrays.fill(this.f2511a, i, i2, -1);
            return i2;
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: b */
        public void mo3372b(int i, int i2) {
            if (this.f2511a != null && i < this.f2511a.length) {
                int i3 = i + i2;
                mo3375e(i3);
                System.arraycopy(this.f2511a, i, this.f2511a, i3, (this.f2511a.length - i) - i2);
                Arrays.fill(this.f2511a, i, i3, -1);
                m3554d(i, i2);
            }
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: c */
        public int mo3373c(int i) {
            if (this.f2511a == null || i >= this.f2511a.length) {
                return -1;
            }
            return this.f2511a[i];
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: d */
        public int mo3374d(int i) {
            int length = this.f2511a.length;
            while (length <= i) {
                length *= 2;
            }
            return length;
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: e */
        public void mo3375e(int i) {
            if (this.f2511a == null) {
                this.f2511a = new int[(Math.max(i, 10) + 1)];
                Arrays.fill(this.f2511a, -1);
                return;
            }
            if (i >= this.f2511a.length) {
                int[] iArr = this.f2511a;
                this.f2511a = new int[mo3374d(i)];
                System.arraycopy(iArr, 0, this.f2511a, 0, iArr.length);
                Arrays.fill(this.f2511a, iArr.length, this.f2511a.length, -1);
            }
        }

        /* renamed from: f */
        public C0727a mo3376f(int i) {
            if (this.f2512b == null) {
                return null;
            }
            for (int size = this.f2512b.size() - 1; size >= 0; size--) {
                C0727a aVar = (C0727a) this.f2512b.get(size);
                if (aVar.f2513a == i) {
                    return aVar;
                }
            }
            return null;
        }
    }

    /* renamed from: android.support.v7.widget.StaggeredGridLayoutManager$d */
    public static class C0729d implements Parcelable {
        public static final Creator<C0729d> CREATOR = new Creator<C0729d>() {
            /* renamed from: a */
            public C0729d createFromParcel(Parcel parcel) {
                return new C0729d(parcel);
            }

            /* renamed from: a */
            public C0729d[] newArray(int i) {
                return new C0729d[i];
            }
        };

        /* renamed from: a */
        int f2517a;

        /* renamed from: b */
        int f2518b;

        /* renamed from: c */
        int f2519c;

        /* renamed from: d */
        int[] f2520d;

        /* renamed from: e */
        int f2521e;

        /* renamed from: f */
        int[] f2522f;

        /* renamed from: g */
        List<C0727a> f2523g;

        /* renamed from: h */
        boolean f2524h;

        /* renamed from: i */
        boolean f2525i;

        /* renamed from: j */
        boolean f2526j;

        public C0729d() {
        }

        C0729d(Parcel parcel) {
            this.f2517a = parcel.readInt();
            this.f2518b = parcel.readInt();
            this.f2519c = parcel.readInt();
            if (this.f2519c > 0) {
                this.f2520d = new int[this.f2519c];
                parcel.readIntArray(this.f2520d);
            }
            this.f2521e = parcel.readInt();
            if (this.f2521e > 0) {
                this.f2522f = new int[this.f2521e];
                parcel.readIntArray(this.f2522f);
            }
            boolean z = false;
            this.f2524h = parcel.readInt() == 1;
            this.f2525i = parcel.readInt() == 1;
            if (parcel.readInt() == 1) {
                z = true;
            }
            this.f2526j = z;
            this.f2523g = parcel.readArrayList(C0727a.class.getClassLoader());
        }

        public C0729d(C0729d dVar) {
            this.f2519c = dVar.f2519c;
            this.f2517a = dVar.f2517a;
            this.f2518b = dVar.f2518b;
            this.f2520d = dVar.f2520d;
            this.f2521e = dVar.f2521e;
            this.f2522f = dVar.f2522f;
            this.f2524h = dVar.f2524h;
            this.f2525i = dVar.f2525i;
            this.f2526j = dVar.f2526j;
            this.f2523g = dVar.f2523g;
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public void mo3385a() {
            this.f2520d = null;
            this.f2519c = 0;
            this.f2521e = 0;
            this.f2522f = null;
            this.f2523g = null;
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: b */
        public void mo3386b() {
            this.f2520d = null;
            this.f2519c = 0;
            this.f2517a = -1;
            this.f2518b = -1;
        }

        public int describeContents() {
            return 0;
        }

        public void writeToParcel(Parcel parcel, int i) {
            parcel.writeInt(this.f2517a);
            parcel.writeInt(this.f2518b);
            parcel.writeInt(this.f2519c);
            if (this.f2519c > 0) {
                parcel.writeIntArray(this.f2520d);
            }
            parcel.writeInt(this.f2521e);
            if (this.f2521e > 0) {
                parcel.writeIntArray(this.f2522f);
            }
            parcel.writeInt(this.f2524h ? 1 : 0);
            parcel.writeInt(this.f2525i ? 1 : 0);
            parcel.writeInt(this.f2526j ? 1 : 0);
            parcel.writeList(this.f2523g);
        }
    }

    /* renamed from: android.support.v7.widget.StaggeredGridLayoutManager$e */
    class C0731e {

        /* renamed from: a */
        ArrayList<View> f2527a = new ArrayList<>();

        /* renamed from: b */
        int f2528b = Integer.MIN_VALUE;

        /* renamed from: c */
        int f2529c = Integer.MIN_VALUE;

        /* renamed from: d */
        int f2530d = 0;

        /* renamed from: e */
        final int f2531e;

        C0731e(int i) {
            this.f2531e = i;
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public int mo3393a(int i) {
            if (this.f2528b != Integer.MIN_VALUE) {
                return this.f2528b;
            }
            if (this.f2527a.size() == 0) {
                return i;
            }
            mo3397a();
            return this.f2528b;
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public int mo3394a(int i, int i2, boolean z) {
            return mo3395a(i, i2, false, false, z);
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public int mo3395a(int i, int i2, boolean z, boolean z2, boolean z3) {
            int c = StaggeredGridLayoutManager.this.f2486b.mo3821c();
            int d = StaggeredGridLayoutManager.this.f2486b.mo3823d();
            int i3 = i2 > i ? 1 : -1;
            while (i != i2) {
                View view = (View) this.f2527a.get(i);
                int a = StaggeredGridLayoutManager.this.f2486b.mo3816a(view);
                int b = StaggeredGridLayoutManager.this.f2486b.mo3820b(view);
                boolean z4 = false;
                boolean z5 = !z3 ? a < d : a <= d;
                if (!z3 ? b > c : b >= c) {
                    z4 = true;
                }
                if (z5 && z4) {
                    if (!z || !z2) {
                        if (!z2 && a >= c && b <= d) {
                        }
                    } else if (a >= c && b <= d) {
                    }
                    return StaggeredGridLayoutManager.this.mo4104d(view);
                }
                i += i3;
            }
            return -1;
        }

        /* renamed from: a */
        public View mo3396a(int i, int i2) {
            View view = null;
            if (i2 != -1) {
                int size = this.f2527a.size() - 1;
                while (size >= 0) {
                    View view2 = (View) this.f2527a.get(size);
                    if (StaggeredGridLayoutManager.this.f2488d && StaggeredGridLayoutManager.this.mo4104d(view2) >= i) {
                        break;
                    } else if (StaggeredGridLayoutManager.this.f2488d || StaggeredGridLayoutManager.this.mo4104d(view2) > i) {
                        if (!view2.hasFocusable()) {
                            break;
                        }
                        size--;
                        view = view2;
                    } else {
                        return view;
                    }
                }
            } else {
                int size2 = this.f2527a.size();
                int i3 = 0;
                while (i3 < size2) {
                    View view3 = (View) this.f2527a.get(i3);
                    if (StaggeredGridLayoutManager.this.f2488d && StaggeredGridLayoutManager.this.mo4104d(view3) <= i) {
                        break;
                    } else if (StaggeredGridLayoutManager.this.f2488d || StaggeredGridLayoutManager.this.mo4104d(view3) < i) {
                        if (!view3.hasFocusable()) {
                            break;
                        }
                        i3++;
                        view = view3;
                    } else {
                        return view;
                    }
                }
            }
            return view;
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public void mo3397a() {
            View view = (View) this.f2527a.get(0);
            C0725b c = mo3403c(view);
            this.f2528b = StaggeredGridLayoutManager.this.f2486b.mo3816a(view);
            if (c.f2510b) {
                C0727a f = StaggeredGridLayoutManager.this.f2492h.mo3376f(c.mo4147f());
                if (f != null && f.f2514b == -1) {
                    this.f2528b -= f.mo3377a(this.f2531e);
                }
            }
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public void mo3398a(View view) {
            C0725b c = mo3403c(view);
            c.f2509a = this;
            this.f2527a.add(0, view);
            this.f2528b = Integer.MIN_VALUE;
            if (this.f2527a.size() == 1) {
                this.f2529c = Integer.MIN_VALUE;
            }
            if (c.mo4145d() || c.mo4146e()) {
                this.f2530d += StaggeredGridLayoutManager.this.f2486b.mo3826e(view);
            }
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public void mo3399a(boolean z, int i) {
            int b = z ? mo3401b(Integer.MIN_VALUE) : mo3393a(Integer.MIN_VALUE);
            mo3408e();
            if (b != Integer.MIN_VALUE) {
                if ((!z || b >= StaggeredGridLayoutManager.this.f2486b.mo3823d()) && (z || b <= StaggeredGridLayoutManager.this.f2486b.mo3821c())) {
                    if (i != Integer.MIN_VALUE) {
                        b += i;
                    }
                    this.f2529c = b;
                    this.f2528b = b;
                }
            }
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: b */
        public int mo3400b() {
            if (this.f2528b != Integer.MIN_VALUE) {
                return this.f2528b;
            }
            mo3397a();
            return this.f2528b;
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: b */
        public int mo3401b(int i) {
            if (this.f2529c != Integer.MIN_VALUE) {
                return this.f2529c;
            }
            if (this.f2527a.size() == 0) {
                return i;
            }
            mo3404c();
            return this.f2529c;
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: b */
        public void mo3402b(View view) {
            C0725b c = mo3403c(view);
            c.f2509a = this;
            this.f2527a.add(view);
            this.f2529c = Integer.MIN_VALUE;
            if (this.f2527a.size() == 1) {
                this.f2528b = Integer.MIN_VALUE;
            }
            if (c.mo4145d() || c.mo4146e()) {
                this.f2530d += StaggeredGridLayoutManager.this.f2486b.mo3826e(view);
            }
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: c */
        public C0725b mo3403c(View view) {
            return (C0725b) view.getLayoutParams();
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: c */
        public void mo3404c() {
            View view = (View) this.f2527a.get(this.f2527a.size() - 1);
            C0725b c = mo3403c(view);
            this.f2529c = StaggeredGridLayoutManager.this.f2486b.mo3820b(view);
            if (c.f2510b) {
                C0727a f = StaggeredGridLayoutManager.this.f2492h.mo3376f(c.mo4147f());
                if (f != null && f.f2514b == 1) {
                    this.f2529c += f.mo3377a(this.f2531e);
                }
            }
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: c */
        public void mo3405c(int i) {
            this.f2528b = i;
            this.f2529c = i;
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: d */
        public int mo3406d() {
            if (this.f2529c != Integer.MIN_VALUE) {
                return this.f2529c;
            }
            mo3404c();
            return this.f2529c;
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: d */
        public void mo3407d(int i) {
            if (this.f2528b != Integer.MIN_VALUE) {
                this.f2528b += i;
            }
            if (this.f2529c != Integer.MIN_VALUE) {
                this.f2529c += i;
            }
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: e */
        public void mo3408e() {
            this.f2527a.clear();
            mo3409f();
            this.f2530d = 0;
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: f */
        public void mo3409f() {
            this.f2528b = Integer.MIN_VALUE;
            this.f2529c = Integer.MIN_VALUE;
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: g */
        public void mo3410g() {
            int size = this.f2527a.size();
            View view = (View) this.f2527a.remove(size - 1);
            C0725b c = mo3403c(view);
            c.f2509a = null;
            if (c.mo4145d() || c.mo4146e()) {
                this.f2530d -= StaggeredGridLayoutManager.this.f2486b.mo3826e(view);
            }
            if (size == 1) {
                this.f2528b = Integer.MIN_VALUE;
            }
            this.f2529c = Integer.MIN_VALUE;
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: h */
        public void mo3411h() {
            View view = (View) this.f2527a.remove(0);
            C0725b c = mo3403c(view);
            c.f2509a = null;
            if (this.f2527a.size() == 0) {
                this.f2529c = Integer.MIN_VALUE;
            }
            if (c.mo4145d() || c.mo4146e()) {
                this.f2530d -= StaggeredGridLayoutManager.this.f2486b.mo3826e(view);
            }
            this.f2528b = Integer.MIN_VALUE;
        }

        /* renamed from: i */
        public int mo3412i() {
            return this.f2530d;
        }

        /* renamed from: j */
        public int mo3413j() {
            int i;
            int size;
            if (StaggeredGridLayoutManager.this.f2488d) {
                i = this.f2527a.size() - 1;
                size = -1;
            } else {
                i = 0;
                size = this.f2527a.size();
            }
            return mo3394a(i, size, true);
        }

        /* renamed from: k */
        public int mo3414k() {
            int size;
            int i;
            if (StaggeredGridLayoutManager.this.f2488d) {
                size = 0;
                i = this.f2527a.size();
            } else {
                size = this.f2527a.size() - 1;
                i = -1;
            }
            return mo3394a(size, i, true);
        }
    }

    public StaggeredGridLayoutManager(Context context, AttributeSet attributeSet, int i, int i2) {
        C0827b a = m4233a(context, attributeSet, i, i2);
        mo3343b(a.f2959a);
        mo3338a(a.f2960b);
        mo3341a(a.f2961c);
        this.f2496l = new C0786ar();
        m3450M();
    }

    /* renamed from: M */
    private void m3450M() {
        this.f2486b = C0802ax.m3987a(this, this.f2494j);
        this.f2487c = C0802ax.m3987a(this, 1 - this.f2494j);
    }

    /* renamed from: N */
    private void m3451N() {
        this.f2489e = (this.f2494j == 1 || !mo3352j()) ? this.f2488d : !this.f2488d;
    }

    /* renamed from: O */
    private void m3452O() {
        int i;
        int i2;
        if (this.f2487c.mo3830h() != 1073741824) {
            int v = mo4134v();
            float f = 0.0f;
            for (int i3 = 0; i3 < v; i3++) {
                View i4 = mo4120i(i3);
                float e = (float) this.f2487c.mo3826e(i4);
                if (e >= f) {
                    if (((C0725b) i4.getLayoutParams()).mo3363a()) {
                        e = (1.0f * e) / ((float) this.f2493i);
                    }
                    f = Math.max(f, e);
                }
            }
            int i5 = this.f2495k;
            int round = Math.round(f * ((float) this.f2493i));
            if (this.f2487c.mo3830h() == Integer.MIN_VALUE) {
                round = Math.min(round, this.f2487c.mo3827f());
            }
            mo3347f(round);
            if (this.f2495k != i5) {
                for (int i6 = 0; i6 < v; i6++) {
                    View i7 = mo4120i(i6);
                    C0725b bVar = (C0725b) i7.getLayoutParams();
                    if (!bVar.f2510b) {
                        if (!mo3352j() || this.f2494j != 1) {
                            i = bVar.f2509a.f2531e * this.f2495k;
                            i2 = bVar.f2509a.f2531e * i5;
                            if (this.f2494j != 1) {
                                i7.offsetTopAndBottom(i - i2);
                            }
                        } else {
                            i = (-((this.f2493i - 1) - bVar.f2509a.f2531e)) * this.f2495k;
                            i2 = (-((this.f2493i - 1) - bVar.f2509a.f2531e)) * i5;
                        }
                        i7.offsetLeftAndRight(i - i2);
                    }
                }
            }
        }
    }

    /* JADX WARNING: type inference failed for: r9v0 */
    /* JADX WARNING: type inference failed for: r9v1, types: [int, boolean] */
    /* JADX WARNING: type inference failed for: r3v0, types: [int] */
    /* JADX WARNING: type inference failed for: r3v2 */
    /* JADX WARNING: type inference failed for: r3v5 */
    /* JADX WARNING: type inference failed for: r9v4 */
    /* JADX WARNING: type inference failed for: r3v6 */
    /* JADX WARNING: type inference failed for: r3v7 */
    /* JADX WARNING: type inference failed for: r3v11 */
    /* JADX WARNING: type inference failed for: r3v12 */
    /* JADX WARNING: type inference failed for: r9v9 */
    /* JADX WARNING: type inference failed for: r3v13 */
    /* JADX WARNING: type inference failed for: r3v14 */
    /* JADX WARNING: Multi-variable type inference failed. Error: jadx.core.utils.exceptions.JadxRuntimeException: No candidate types for var: r9v1, types: [int, boolean]
      assigns: []
      uses: [?[int, float, boolean, short, byte, char, OBJECT, ARRAY], boolean, int, ?[int, short, byte, char]]
      mth insns count: 224
    	at jadx.core.dex.visitors.typeinference.TypeSearch.fillTypeCandidates(TypeSearch.java:237)
    	at java.base/java.util.ArrayList.forEach(ArrayList.java:1540)
    	at jadx.core.dex.visitors.typeinference.TypeSearch.run(TypeSearch.java:53)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.runMultiVariableSearch(TypeInferenceVisitor.java:99)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.visit(TypeInferenceVisitor.java:92)
    	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:27)
    	at jadx.core.dex.visitors.DepthTraversal.lambda$visit$1(DepthTraversal.java:14)
    	at java.base/java.util.ArrayList.forEach(ArrayList.java:1540)
    	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:14)
    	at jadx.core.ProcessClass.process(ProcessClass.java:30)
    	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:311)
    	at jadx.api.JavaClass.decompile(JavaClass.java:62)
    	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:217)
     */
    /* JADX WARNING: Unknown variable types count: 7 */
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private int m3453a(android.support.p031v7.widget.C0805ay.C0835p r18, android.support.p031v7.widget.C0786ar r19, android.support.p031v7.widget.C0805ay.C0843u r20) {
        /*
            r17 = this;
            r6 = r17
            r7 = r18
            r8 = r19
            java.util.BitSet r0 = r6.f2497m
            int r1 = r6.f2493i
            r9 = 0
            r10 = 1
            r0.set(r9, r1, r10)
            android.support.v7.widget.ar r0 = r6.f2496l
            boolean r0 = r0.f2766i
            if (r0 == 0) goto L_0x0021
            int r0 = r8.f2762e
            if (r0 != r10) goto L_0x001e
            r0 = 2147483647(0x7fffffff, float:NaN)
        L_0x001c:
            r11 = r0
            goto L_0x0031
        L_0x001e:
            r0 = -2147483648(0xffffffff80000000, float:-0.0)
            goto L_0x001c
        L_0x0021:
            int r0 = r8.f2762e
            if (r0 != r10) goto L_0x002b
            int r0 = r8.f2764g
            int r1 = r8.f2759b
            int r0 = r0 + r1
            goto L_0x001c
        L_0x002b:
            int r0 = r8.f2763f
            int r1 = r8.f2759b
            int r0 = r0 - r1
            goto L_0x001c
        L_0x0031:
            int r0 = r8.f2762e
            r6.m3455a(r0, r11)
            boolean r0 = r6.f2489e
            if (r0 == 0) goto L_0x0042
            android.support.v7.widget.ax r0 = r6.f2486b
            int r0 = r0.mo3823d()
        L_0x0040:
            r12 = r0
            goto L_0x0049
        L_0x0042:
            android.support.v7.widget.ax r0 = r6.f2486b
            int r0 = r0.mo3821c()
            goto L_0x0040
        L_0x0049:
            r0 = r9
        L_0x004a:
            boolean r1 = r19.mo3727a(r20)
            r2 = -1
            if (r1 == 0) goto L_0x01c5
            android.support.v7.widget.ar r1 = r6.f2496l
            boolean r1 = r1.f2766i
            if (r1 != 0) goto L_0x005f
            java.util.BitSet r1 = r6.f2497m
            boolean r1 = r1.isEmpty()
            if (r1 != 0) goto L_0x01c5
        L_0x005f:
            android.view.View r13 = r8.mo3726a(r7)
            android.view.ViewGroup$LayoutParams r0 = r13.getLayoutParams()
            r14 = r0
            android.support.v7.widget.StaggeredGridLayoutManager$b r14 = (android.support.p031v7.widget.StaggeredGridLayoutManager.C0725b) r14
            int r0 = r14.mo4147f()
            android.support.v7.widget.StaggeredGridLayoutManager$c r1 = r6.f2492h
            int r1 = r1.mo3373c(r0)
            if (r1 != r2) goto L_0x0078
            r3 = r10
            goto L_0x0079
        L_0x0078:
            r3 = r9
        L_0x0079:
            if (r3 == 0) goto L_0x008e
            boolean r1 = r14.f2510b
            if (r1 == 0) goto L_0x0084
            android.support.v7.widget.StaggeredGridLayoutManager$e[] r1 = r6.f2485a
            r1 = r1[r9]
            goto L_0x0088
        L_0x0084:
            android.support.v7.widget.StaggeredGridLayoutManager$e r1 = r6.m3454a(r8)
        L_0x0088:
            android.support.v7.widget.StaggeredGridLayoutManager$c r4 = r6.f2492h
            r4.mo3369a(r0, r1)
            goto L_0x0092
        L_0x008e:
            android.support.v7.widget.StaggeredGridLayoutManager$e[] r4 = r6.f2485a
            r1 = r4[r1]
        L_0x0092:
            r15 = r1
            r14.f2509a = r15
            int r1 = r8.f2762e
            if (r1 != r10) goto L_0x009d
            r6.mo4093b(r13)
            goto L_0x00a0
        L_0x009d:
            r6.mo4094b(r13, r9)
        L_0x00a0:
            r6.m3463a(r13, r14, r9)
            int r1 = r8.f2762e
            if (r1 != r10) goto L_0x00d1
            boolean r1 = r14.f2510b
            if (r1 == 0) goto L_0x00b0
            int r1 = r6.m3482r(r12)
            goto L_0x00b4
        L_0x00b0:
            int r1 = r15.mo3401b(r12)
        L_0x00b4:
            android.support.v7.widget.ax r4 = r6.f2486b
            int r4 = r4.mo3826e(r13)
            int r4 = r4 + r1
            if (r3 == 0) goto L_0x00ce
            boolean r5 = r14.f2510b
            if (r5 == 0) goto L_0x00ce
            android.support.v7.widget.StaggeredGridLayoutManager$c$a r5 = r6.m3476n(r1)
            r5.f2514b = r2
            r5.f2513a = r0
            android.support.v7.widget.StaggeredGridLayoutManager$c r9 = r6.f2492h
            r9.mo3370a(r5)
        L_0x00ce:
            r5 = r4
            r4 = r1
            goto L_0x00fa
        L_0x00d1:
            boolean r1 = r14.f2510b
            if (r1 == 0) goto L_0x00da
            int r1 = r6.m3480q(r12)
            goto L_0x00de
        L_0x00da:
            int r1 = r15.mo3393a(r12)
        L_0x00de:
            android.support.v7.widget.ax r4 = r6.f2486b
            int r4 = r4.mo3826e(r13)
            int r4 = r1 - r4
            if (r3 == 0) goto L_0x00f9
            boolean r5 = r14.f2510b
            if (r5 == 0) goto L_0x00f9
            android.support.v7.widget.StaggeredGridLayoutManager$c$a r5 = r6.m3477o(r1)
            r5.f2514b = r10
            r5.f2513a = r0
            android.support.v7.widget.StaggeredGridLayoutManager$c r9 = r6.f2492h
            r9.mo3370a(r5)
        L_0x00f9:
            r5 = r1
        L_0x00fa:
            boolean r1 = r14.f2510b
            if (r1 == 0) goto L_0x0123
            int r1 = r8.f2761d
            if (r1 != r2) goto L_0x0123
            if (r3 == 0) goto L_0x0107
        L_0x0104:
            r6.f2481E = r10
            goto L_0x0123
        L_0x0107:
            int r1 = r8.f2762e
            if (r1 != r10) goto L_0x0111
            boolean r1 = r17.mo3356m()
        L_0x010f:
            r1 = r1 ^ r10
            goto L_0x0116
        L_0x0111:
            boolean r1 = r17.mo3357n()
            goto L_0x010f
        L_0x0116:
            if (r1 == 0) goto L_0x0123
            android.support.v7.widget.StaggeredGridLayoutManager$c r1 = r6.f2492h
            android.support.v7.widget.StaggeredGridLayoutManager$c$a r0 = r1.mo3376f(r0)
            if (r0 == 0) goto L_0x0104
            r0.f2516d = r10
            goto L_0x0104
        L_0x0123:
            r6.m3462a(r13, r14, r8)
            boolean r0 = r17.mo3352j()
            if (r0 == 0) goto L_0x0156
            int r0 = r6.f2494j
            if (r0 != r10) goto L_0x0156
            boolean r0 = r14.f2510b
            if (r0 == 0) goto L_0x013b
            android.support.v7.widget.ax r0 = r6.f2487c
            int r0 = r0.mo3823d()
            goto L_0x014b
        L_0x013b:
            android.support.v7.widget.ax r0 = r6.f2487c
            int r0 = r0.mo3823d()
            int r1 = r6.f2493i
            int r1 = r1 - r10
            int r2 = r15.f2531e
            int r1 = r1 - r2
            int r2 = r6.f2495k
            int r1 = r1 * r2
            int r0 = r0 - r1
        L_0x014b:
            android.support.v7.widget.ax r1 = r6.f2487c
            int r1 = r1.mo3826e(r13)
            int r1 = r0 - r1
            r9 = r0
            r3 = r1
            goto L_0x0176
        L_0x0156:
            boolean r0 = r14.f2510b
            if (r0 == 0) goto L_0x0161
            android.support.v7.widget.ax r0 = r6.f2487c
            int r0 = r0.mo3821c()
            goto L_0x016d
        L_0x0161:
            int r0 = r15.f2531e
            int r1 = r6.f2495k
            int r0 = r0 * r1
            android.support.v7.widget.ax r1 = r6.f2487c
            int r1 = r1.mo3821c()
            int r0 = r0 + r1
        L_0x016d:
            android.support.v7.widget.ax r1 = r6.f2487c
            int r1 = r1.mo3826e(r13)
            int r1 = r1 + r0
            r3 = r0
            r9 = r1
        L_0x0176:
            int r0 = r6.f2494j
            if (r0 != r10) goto L_0x0183
            r0 = r6
            r1 = r13
            r2 = r3
            r3 = r4
            r4 = r9
        L_0x017f:
            r0.mo4072a(r1, r2, r3, r4, r5)
            goto L_0x0189
        L_0x0183:
            r0 = r6
            r1 = r13
            r2 = r4
            r4 = r5
            r5 = r9
            goto L_0x017f
        L_0x0189:
            boolean r0 = r14.f2510b
            if (r0 == 0) goto L_0x0195
            android.support.v7.widget.ar r0 = r6.f2496l
            int r0 = r0.f2762e
            r6.m3455a(r0, r11)
            goto L_0x019c
        L_0x0195:
            android.support.v7.widget.ar r0 = r6.f2496l
            int r0 = r0.f2762e
            r6.m3457a(r15, r0, r11)
        L_0x019c:
            android.support.v7.widget.ar r0 = r6.f2496l
            r6.m3459a(r7, r0)
            android.support.v7.widget.ar r0 = r6.f2496l
            boolean r0 = r0.f2765h
            if (r0 == 0) goto L_0x01c0
            boolean r0 = r13.hasFocusable()
            if (r0 == 0) goto L_0x01c0
            boolean r0 = r14.f2510b
            if (r0 == 0) goto L_0x01b7
            java.util.BitSet r0 = r6.f2497m
            r0.clear()
            goto L_0x01c0
        L_0x01b7:
            java.util.BitSet r0 = r6.f2497m
            int r1 = r15.f2531e
            r3 = 0
            r0.set(r1, r3)
            goto L_0x01c1
        L_0x01c0:
            r3 = 0
        L_0x01c1:
            r9 = r3
            r0 = r10
            goto L_0x004a
        L_0x01c5:
            r3 = r9
            if (r0 != 0) goto L_0x01cd
            android.support.v7.widget.ar r0 = r6.f2496l
            r6.m3459a(r7, r0)
        L_0x01cd:
            android.support.v7.widget.ar r0 = r6.f2496l
            int r0 = r0.f2762e
            if (r0 != r2) goto L_0x01e5
            android.support.v7.widget.ax r0 = r6.f2486b
            int r0 = r0.mo3821c()
            int r0 = r6.m3480q(r0)
            android.support.v7.widget.ax r1 = r6.f2486b
            int r1 = r1.mo3821c()
            int r1 = r1 - r0
            goto L_0x01f7
        L_0x01e5:
            android.support.v7.widget.ax r0 = r6.f2486b
            int r0 = r0.mo3823d()
            int r0 = r6.m3482r(r0)
            android.support.v7.widget.ax r1 = r6.f2486b
            int r1 = r1.mo3823d()
            int r1 = r0 - r1
        L_0x01f7:
            if (r1 <= 0) goto L_0x0200
            int r0 = r8.f2759b
            int r9 = java.lang.Math.min(r0, r1)
            r3 = r9
        L_0x0200:
            return r3
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.p031v7.widget.StaggeredGridLayoutManager.m3453a(android.support.v7.widget.ay$p, android.support.v7.widget.ar, android.support.v7.widget.ay$u):int");
    }

    /* renamed from: a */
    private C0731e m3454a(C0786ar arVar) {
        int i;
        int i2;
        int i3 = -1;
        if (m3484t(arVar.f2762e)) {
            i2 = this.f2493i - 1;
            i = -1;
        } else {
            i2 = 0;
            i3 = this.f2493i;
            i = 1;
        }
        C0731e eVar = null;
        if (arVar.f2762e == 1) {
            int i4 = Integer.MAX_VALUE;
            int c = this.f2486b.mo3821c();
            while (i2 != i3) {
                C0731e eVar2 = this.f2485a[i2];
                int b = eVar2.mo3401b(c);
                if (b < i4) {
                    eVar = eVar2;
                    i4 = b;
                }
                i2 += i;
            }
            return eVar;
        }
        int i5 = Integer.MIN_VALUE;
        int d = this.f2486b.mo3823d();
        while (i2 != i3) {
            C0731e eVar3 = this.f2485a[i2];
            int a = eVar3.mo3393a(d);
            if (a > i5) {
                eVar = eVar3;
                i5 = a;
            }
            i2 += i;
        }
        return eVar;
    }

    /* renamed from: a */
    private void m3455a(int i, int i2) {
        for (int i3 = 0; i3 < this.f2493i; i3++) {
            if (!this.f2485a[i3].f2527a.isEmpty()) {
                m3457a(this.f2485a[i3], i, i2);
            }
        }
    }

    /* renamed from: a */
    private void m3456a(C0724a aVar) {
        boolean z;
        if (this.f2477A.f2519c > 0) {
            if (this.f2477A.f2519c == this.f2493i) {
                for (int i = 0; i < this.f2493i; i++) {
                    this.f2485a[i].mo3408e();
                    int i2 = this.f2477A.f2520d[i];
                    if (i2 != Integer.MIN_VALUE) {
                        i2 += this.f2477A.f2525i ? this.f2486b.mo3823d() : this.f2486b.mo3821c();
                    }
                    this.f2485a[i].mo3405c(i2);
                }
            } else {
                this.f2477A.mo3385a();
                this.f2477A.f2517a = this.f2477A.f2518b;
            }
        }
        this.f2500z = this.f2477A.f2526j;
        mo3341a(this.f2477A.f2524h);
        m3451N();
        if (this.f2477A.f2517a != -1) {
            this.f2490f = this.f2477A.f2517a;
            z = this.f2477A.f2525i;
        } else {
            z = this.f2489e;
        }
        aVar.f2504c = z;
        if (this.f2477A.f2521e > 1) {
            this.f2492h.f2511a = this.f2477A.f2522f;
            this.f2492h.f2512b = this.f2477A.f2523g;
        }
    }

    /* renamed from: a */
    private void m3457a(C0731e eVar, int i, int i2) {
        int i3 = eVar.mo3412i();
        if (i == -1) {
            if (eVar.mo3400b() + i3 > i2) {
                return;
            }
        } else if (eVar.mo3406d() - i3 < i2) {
            return;
        }
        this.f2497m.set(eVar.f2531e, false);
    }

    /* renamed from: a */
    private void m3458a(C0835p pVar, int i) {
        while (mo4134v() > 0) {
            View i2 = mo4120i(0);
            if (this.f2486b.mo3820b(i2) > i || this.f2486b.mo3822c(i2) > i) {
                break;
            }
            C0725b bVar = (C0725b) i2.getLayoutParams();
            if (bVar.f2510b) {
                int i3 = 0;
                while (i3 < this.f2493i) {
                    if (this.f2485a[i3].f2527a.size() != 1) {
                        i3++;
                    } else {
                        return;
                    }
                }
                for (int i4 = 0; i4 < this.f2493i; i4++) {
                    this.f2485a[i4].mo3411h();
                }
            } else if (bVar.f2509a.f2527a.size() != 1) {
                bVar.f2509a.mo3411h();
            } else {
                return;
            }
            mo4076a(i2, pVar);
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:8:0x0010, code lost:
        if (r4.f2762e == -1) goto L_0x0012;
     */
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private void m3459a(android.support.p031v7.widget.C0805ay.C0835p r3, android.support.p031v7.widget.C0786ar r4) {
        /*
            r2 = this;
            boolean r0 = r4.f2758a
            if (r0 == 0) goto L_0x004f
            boolean r0 = r4.f2766i
            if (r0 == 0) goto L_0x0009
            return
        L_0x0009:
            int r0 = r4.f2759b
            r1 = -1
            if (r0 != 0) goto L_0x001e
            int r0 = r4.f2762e
            if (r0 != r1) goto L_0x0018
        L_0x0012:
            int r4 = r4.f2764g
        L_0x0014:
            r2.m3468b(r3, r4)
            return
        L_0x0018:
            int r4 = r4.f2763f
        L_0x001a:
            r2.m3458a(r3, r4)
            return
        L_0x001e:
            int r0 = r4.f2762e
            if (r0 != r1) goto L_0x0039
            int r0 = r4.f2763f
            int r1 = r4.f2763f
            int r1 = r2.m3478p(r1)
            int r0 = r0 - r1
            if (r0 >= 0) goto L_0x002e
            goto L_0x0012
        L_0x002e:
            int r1 = r4.f2764g
            int r4 = r4.f2759b
            int r4 = java.lang.Math.min(r0, r4)
            int r4 = r1 - r4
            goto L_0x0014
        L_0x0039:
            int r0 = r4.f2764g
            int r0 = r2.m3483s(r0)
            int r1 = r4.f2764g
            int r0 = r0 - r1
            if (r0 >= 0) goto L_0x0045
            goto L_0x0018
        L_0x0045:
            int r1 = r4.f2763f
            int r4 = r4.f2759b
            int r4 = java.lang.Math.min(r0, r4)
            int r4 = r4 + r1
            goto L_0x001a
        L_0x004f:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.p031v7.widget.StaggeredGridLayoutManager.m3459a(android.support.v7.widget.ay$p, android.support.v7.widget.ar):void");
    }

    /* JADX WARNING: Code restructure failed: missing block: B:84:0x0154, code lost:
        if (mo3348g() != false) goto L_0x0158;
     */
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private void m3460a(android.support.p031v7.widget.C0805ay.C0835p r9, android.support.p031v7.widget.C0805ay.C0843u r10, boolean r11) {
        /*
            r8 = this;
            android.support.v7.widget.StaggeredGridLayoutManager$a r0 = r8.f2480D
            android.support.v7.widget.StaggeredGridLayoutManager$d r1 = r8.f2477A
            r2 = -1
            if (r1 != 0) goto L_0x000b
            int r1 = r8.f2490f
            if (r1 == r2) goto L_0x0018
        L_0x000b:
            int r1 = r10.mo4227e()
            if (r1 != 0) goto L_0x0018
            r8.mo4098c(r9)
            r0.mo3359a()
            return
        L_0x0018:
            boolean r1 = r0.f2506e
            r3 = 0
            r4 = 1
            if (r1 == 0) goto L_0x0029
            int r1 = r8.f2490f
            if (r1 != r2) goto L_0x0029
            android.support.v7.widget.StaggeredGridLayoutManager$d r1 = r8.f2477A
            if (r1 == 0) goto L_0x0027
            goto L_0x0029
        L_0x0027:
            r1 = r3
            goto L_0x002a
        L_0x0029:
            r1 = r4
        L_0x002a:
            if (r1 == 0) goto L_0x0043
            r0.mo3359a()
            android.support.v7.widget.StaggeredGridLayoutManager$d r5 = r8.f2477A
            if (r5 == 0) goto L_0x0037
            r8.m3456a(r0)
            goto L_0x003e
        L_0x0037:
            r8.m3451N()
            boolean r5 = r8.f2489e
            r0.f2504c = r5
        L_0x003e:
            r8.mo3340a(r10, r0)
            r0.f2506e = r4
        L_0x0043:
            android.support.v7.widget.StaggeredGridLayoutManager$d r5 = r8.f2477A
            if (r5 != 0) goto L_0x0060
            int r5 = r8.f2490f
            if (r5 != r2) goto L_0x0060
            boolean r5 = r0.f2504c
            boolean r6 = r8.f2499o
            if (r5 != r6) goto L_0x0059
            boolean r5 = r8.mo3352j()
            boolean r6 = r8.f2500z
            if (r5 == r6) goto L_0x0060
        L_0x0059:
            android.support.v7.widget.StaggeredGridLayoutManager$c r5 = r8.f2492h
            r5.mo3367a()
            r0.f2505d = r4
        L_0x0060:
            int r5 = r8.mo4134v()
            if (r5 <= 0) goto L_0x00cd
            android.support.v7.widget.StaggeredGridLayoutManager$d r5 = r8.f2477A
            if (r5 == 0) goto L_0x0070
            android.support.v7.widget.StaggeredGridLayoutManager$d r5 = r8.f2477A
            int r5 = r5.f2519c
            if (r5 >= r4) goto L_0x00cd
        L_0x0070:
            boolean r5 = r0.f2505d
            if (r5 == 0) goto L_0x0092
            r1 = r3
        L_0x0075:
            int r5 = r8.f2493i
            if (r1 >= r5) goto L_0x00cd
            android.support.v7.widget.StaggeredGridLayoutManager$e[] r5 = r8.f2485a
            r5 = r5[r1]
            r5.mo3408e()
            int r5 = r0.f2503b
            r6 = -2147483648(0xffffffff80000000, float:-0.0)
            if (r5 == r6) goto L_0x008f
            android.support.v7.widget.StaggeredGridLayoutManager$e[] r5 = r8.f2485a
            r5 = r5[r1]
            int r6 = r0.f2503b
            r5.mo3405c(r6)
        L_0x008f:
            int r1 = r1 + 1
            goto L_0x0075
        L_0x0092:
            if (r1 != 0) goto L_0x00b3
            android.support.v7.widget.StaggeredGridLayoutManager$a r1 = r8.f2480D
            int[] r1 = r1.f2507f
            if (r1 != 0) goto L_0x009b
            goto L_0x00b3
        L_0x009b:
            r1 = r3
        L_0x009c:
            int r5 = r8.f2493i
            if (r1 >= r5) goto L_0x00cd
            android.support.v7.widget.StaggeredGridLayoutManager$e[] r5 = r8.f2485a
            r5 = r5[r1]
            r5.mo3408e()
            android.support.v7.widget.StaggeredGridLayoutManager$a r6 = r8.f2480D
            int[] r6 = r6.f2507f
            r6 = r6[r1]
            r5.mo3405c(r6)
            int r1 = r1 + 1
            goto L_0x009c
        L_0x00b3:
            r1 = r3
        L_0x00b4:
            int r5 = r8.f2493i
            if (r1 >= r5) goto L_0x00c6
            android.support.v7.widget.StaggeredGridLayoutManager$e[] r5 = r8.f2485a
            r5 = r5[r1]
            boolean r6 = r8.f2489e
            int r7 = r0.f2503b
            r5.mo3399a(r6, r7)
            int r1 = r1 + 1
            goto L_0x00b4
        L_0x00c6:
            android.support.v7.widget.StaggeredGridLayoutManager$a r1 = r8.f2480D
            android.support.v7.widget.StaggeredGridLayoutManager$e[] r5 = r8.f2485a
            r1.mo3361a(r5)
        L_0x00cd:
            r8.mo4064a(r9)
            android.support.v7.widget.ar r1 = r8.f2496l
            r1.f2758a = r3
            r8.f2481E = r3
            android.support.v7.widget.ax r1 = r8.f2487c
            int r1 = r1.mo3827f()
            r8.mo3347f(r1)
            int r1 = r0.f2502a
            r8.m3467b(r1, r10)
            boolean r1 = r0.f2504c
            if (r1 == 0) goto L_0x0104
            r8.m3475m(r2)
            android.support.v7.widget.ar r1 = r8.f2496l
            r8.m3453a(r9, r1, r10)
            r8.m3475m(r4)
        L_0x00f3:
            android.support.v7.widget.ar r1 = r8.f2496l
            int r2 = r0.f2502a
            android.support.v7.widget.ar r5 = r8.f2496l
            int r5 = r5.f2761d
            int r2 = r2 + r5
            r1.f2760c = r2
            android.support.v7.widget.ar r1 = r8.f2496l
            r8.m3453a(r9, r1, r10)
            goto L_0x0110
        L_0x0104:
            r8.m3475m(r4)
            android.support.v7.widget.ar r1 = r8.f2496l
            r8.m3453a(r9, r1, r10)
            r8.m3475m(r2)
            goto L_0x00f3
        L_0x0110:
            r8.m3452O()
            int r1 = r8.mo4134v()
            if (r1 <= 0) goto L_0x012a
            boolean r1 = r8.f2489e
            if (r1 == 0) goto L_0x0124
            r8.m3469b(r9, r10, r4)
            r8.m3471c(r9, r10, r3)
            goto L_0x012a
        L_0x0124:
            r8.m3471c(r9, r10, r4)
            r8.m3469b(r9, r10, r3)
        L_0x012a:
            if (r11 == 0) goto L_0x0157
            boolean r11 = r10.mo4223a()
            if (r11 != 0) goto L_0x0157
            int r11 = r8.f2498n
            if (r11 == 0) goto L_0x0148
            int r11 = r8.mo4134v()
            if (r11 <= 0) goto L_0x0148
            boolean r11 = r8.f2481E
            if (r11 != 0) goto L_0x0146
            android.view.View r11 = r8.mo3349h()
            if (r11 == 0) goto L_0x0148
        L_0x0146:
            r11 = r4
            goto L_0x0149
        L_0x0148:
            r11 = r3
        L_0x0149:
            if (r11 == 0) goto L_0x0157
            java.lang.Runnable r11 = r8.f2484H
            r8.mo4089a(r11)
            boolean r11 = r8.mo3348g()
            if (r11 == 0) goto L_0x0157
            goto L_0x0158
        L_0x0157:
            r4 = r3
        L_0x0158:
            boolean r11 = r10.mo4223a()
            if (r11 == 0) goto L_0x0163
            android.support.v7.widget.StaggeredGridLayoutManager$a r11 = r8.f2480D
            r11.mo3359a()
        L_0x0163:
            boolean r11 = r0.f2504c
            r8.f2499o = r11
            boolean r11 = r8.mo3352j()
            r8.f2500z = r11
            if (r4 == 0) goto L_0x0177
            android.support.v7.widget.StaggeredGridLayoutManager$a r11 = r8.f2480D
            r11.mo3359a()
            r8.m3460a(r9, r10, r3)
        L_0x0177:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.p031v7.widget.StaggeredGridLayoutManager.m3460a(android.support.v7.widget.ay$p, android.support.v7.widget.ay$u, boolean):void");
    }

    /* renamed from: a */
    private void m3461a(View view, int i, int i2, boolean z) {
        mo4095b(view, this.f2479C);
        C0725b bVar = (C0725b) view.getLayoutParams();
        int b = m3465b(i, bVar.leftMargin + this.f2479C.left, bVar.rightMargin + this.f2479C.right);
        int b2 = m3465b(i2, bVar.topMargin + this.f2479C.top, bVar.bottomMargin + this.f2479C.bottom);
        if (z ? mo4086a(view, b, b2, (C0828j) bVar) : mo4096b(view, b, b2, (C0828j) bVar)) {
            view.measure(b, b2);
        }
    }

    /* renamed from: a */
    private void m3462a(View view, C0725b bVar, C0786ar arVar) {
        if (arVar.f2762e == 1) {
            if (bVar.f2510b) {
                m3479p(view);
            } else {
                bVar.f2509a.mo3402b(view);
            }
        } else if (bVar.f2510b) {
            m3481q(view);
        } else {
            bVar.f2509a.mo3398a(view);
        }
    }

    /* renamed from: a */
    private void m3463a(View view, C0725b bVar, boolean z) {
        int a;
        int a2;
        if (bVar.f2510b) {
            if (this.f2494j == 1) {
                a = this.f2478B;
            } else {
                m3461a(view, m4232a(mo4137y(), mo4135w(), mo4051A() + mo4053C(), bVar.width, true), this.f2478B, z);
                return;
            }
        } else if (this.f2494j == 1) {
            a = m4232a(this.f2495k, mo4135w(), 0, bVar.width, false);
        } else {
            a = m4232a(mo4137y(), mo4135w(), mo4051A() + mo4053C(), bVar.width, true);
            a2 = m4232a(this.f2495k, mo4136x(), 0, bVar.height, false);
            m3461a(view, a, a2, z);
        }
        a2 = m4232a(mo4138z(), mo4136x(), mo4052B() + mo4054D(), bVar.height, true);
        m3461a(view, a, a2, z);
    }

    /* renamed from: a */
    private boolean m3464a(C0731e eVar) {
        if (this.f2489e) {
            if (eVar.mo3406d() < this.f2486b.mo3823d()) {
                return !eVar.mo3403c((View) eVar.f2527a.get(eVar.f2527a.size() - 1)).f2510b;
            }
        } else if (eVar.mo3400b() > this.f2486b.mo3821c()) {
            return !eVar.mo3403c((View) eVar.f2527a.get(0)).f2510b;
        }
        return false;
    }

    /* renamed from: b */
    private int m3465b(int i, int i2, int i3) {
        if (i2 == 0 && i3 == 0) {
            return i;
        }
        int mode = MeasureSpec.getMode(i);
        return (mode == Integer.MIN_VALUE || mode == 1073741824) ? MeasureSpec.makeMeasureSpec(Math.max(0, (MeasureSpec.getSize(i) - i2) - i3), mode) : i;
    }

    /* renamed from: b */
    private int m3466b(C0843u uVar) {
        if (mo4134v() == 0) {
            return 0;
        }
        return C0855be.m4567a(uVar, this.f2486b, mo3342b(!this.f2482F), mo3346c(!this.f2482F), this, this.f2482F, this.f2489e);
    }

    /* JADX WARNING: Removed duplicated region for block: B:14:0x0039  */
    /* JADX WARNING: Removed duplicated region for block: B:15:0x0050  */
    /* renamed from: b */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private void m3467b(int r5, android.support.p031v7.widget.C0805ay.C0843u r6) {
        /*
            r4 = this;
            android.support.v7.widget.ar r0 = r4.f2496l
            r1 = 0
            r0.f2759b = r1
            android.support.v7.widget.ar r0 = r4.f2496l
            r0.f2760c = r5
            boolean r0 = r4.mo4131s()
            r2 = 1
            if (r0 == 0) goto L_0x0031
            int r6 = r6.mo4225c()
            r0 = -1
            if (r6 == r0) goto L_0x0031
            boolean r0 = r4.f2489e
            if (r6 >= r5) goto L_0x001d
            r5 = r2
            goto L_0x001e
        L_0x001d:
            r5 = r1
        L_0x001e:
            if (r0 != r5) goto L_0x0029
            android.support.v7.widget.ax r5 = r4.f2486b
            int r5 = r5.mo3827f()
            r6 = r5
            r5 = r1
            goto L_0x0033
        L_0x0029:
            android.support.v7.widget.ax r5 = r4.f2486b
            int r5 = r5.mo3827f()
            r6 = r1
            goto L_0x0033
        L_0x0031:
            r5 = r1
            r6 = r5
        L_0x0033:
            boolean r0 = r4.mo4130r()
            if (r0 == 0) goto L_0x0050
            android.support.v7.widget.ar r0 = r4.f2496l
            android.support.v7.widget.ax r3 = r4.f2486b
            int r3 = r3.mo3821c()
            int r3 = r3 - r5
            r0.f2763f = r3
            android.support.v7.widget.ar r5 = r4.f2496l
            android.support.v7.widget.ax r0 = r4.f2486b
            int r0 = r0.mo3823d()
            int r0 = r0 + r6
            r5.f2764g = r0
            goto L_0x0060
        L_0x0050:
            android.support.v7.widget.ar r0 = r4.f2496l
            android.support.v7.widget.ax r3 = r4.f2486b
            int r3 = r3.mo3825e()
            int r3 = r3 + r6
            r0.f2764g = r3
            android.support.v7.widget.ar r6 = r4.f2496l
            int r5 = -r5
            r6.f2763f = r5
        L_0x0060:
            android.support.v7.widget.ar r5 = r4.f2496l
            r5.f2765h = r1
            android.support.v7.widget.ar r5 = r4.f2496l
            r5.f2758a = r2
            android.support.v7.widget.ar r5 = r4.f2496l
            android.support.v7.widget.ax r6 = r4.f2486b
            int r6 = r6.mo3830h()
            if (r6 != 0) goto L_0x007b
            android.support.v7.widget.ax r6 = r4.f2486b
            int r6 = r6.mo3825e()
            if (r6 != 0) goto L_0x007b
            r1 = r2
        L_0x007b:
            r5.f2766i = r1
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.p031v7.widget.StaggeredGridLayoutManager.m3467b(int, android.support.v7.widget.ay$u):void");
    }

    /* renamed from: b */
    private void m3468b(C0835p pVar, int i) {
        for (int v = mo4134v() - 1; v >= 0; v--) {
            View i2 = mo4120i(v);
            if (this.f2486b.mo3816a(i2) < i || this.f2486b.mo3824d(i2) < i) {
                break;
            }
            C0725b bVar = (C0725b) i2.getLayoutParams();
            if (bVar.f2510b) {
                int i3 = 0;
                while (i3 < this.f2493i) {
                    if (this.f2485a[i3].f2527a.size() != 1) {
                        i3++;
                    } else {
                        return;
                    }
                }
                for (int i4 = 0; i4 < this.f2493i; i4++) {
                    this.f2485a[i4].mo3410g();
                }
            } else if (bVar.f2509a.f2527a.size() != 1) {
                bVar.f2509a.mo3410g();
            } else {
                return;
            }
            mo4076a(i2, pVar);
        }
    }

    /* renamed from: b */
    private void m3469b(C0835p pVar, C0843u uVar, boolean z) {
        int r = m3482r(Integer.MIN_VALUE);
        if (r != Integer.MIN_VALUE) {
            int d = this.f2486b.mo3823d() - r;
            if (d > 0) {
                int i = d - (-mo3345c(-d, pVar, uVar));
                if (z && i > 0) {
                    this.f2486b.mo3818a(i);
                }
            }
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:13:0x0026  */
    /* JADX WARNING: Removed duplicated region for block: B:16:0x0036  */
    /* JADX WARNING: Removed duplicated region for block: B:18:0x0043 A[RETURN] */
    /* JADX WARNING: Removed duplicated region for block: B:19:0x0044  */
    /* renamed from: c */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private void m3470c(int r6, int r7, int r8) {
        /*
            r5 = this;
            boolean r0 = r5.f2489e
            if (r0 == 0) goto L_0x0009
            int r0 = r5.mo3336K()
            goto L_0x000d
        L_0x0009:
            int r0 = r5.mo3337L()
        L_0x000d:
            r1 = 8
            if (r8 != r1) goto L_0x001b
            if (r6 >= r7) goto L_0x0016
            int r2 = r7 + 1
            goto L_0x001d
        L_0x0016:
            int r2 = r6 + 1
            r3 = r2
            r2 = r7
            goto L_0x001f
        L_0x001b:
            int r2 = r6 + r7
        L_0x001d:
            r3 = r2
            r2 = r6
        L_0x001f:
            android.support.v7.widget.StaggeredGridLayoutManager$c r4 = r5.f2492h
            r4.mo3371b(r2)
            if (r8 == r1) goto L_0x0036
            switch(r8) {
                case 1: goto L_0x0030;
                case 2: goto L_0x002a;
                default: goto L_0x0029;
            }
        L_0x0029:
            goto L_0x0041
        L_0x002a:
            android.support.v7.widget.StaggeredGridLayoutManager$c r8 = r5.f2492h
            r8.mo3368a(r6, r7)
            goto L_0x0041
        L_0x0030:
            android.support.v7.widget.StaggeredGridLayoutManager$c r8 = r5.f2492h
            r8.mo3372b(r6, r7)
            goto L_0x0041
        L_0x0036:
            android.support.v7.widget.StaggeredGridLayoutManager$c r8 = r5.f2492h
            r1 = 1
            r8.mo3368a(r6, r1)
            android.support.v7.widget.StaggeredGridLayoutManager$c r6 = r5.f2492h
            r6.mo3372b(r7, r1)
        L_0x0041:
            if (r3 > r0) goto L_0x0044
            return
        L_0x0044:
            boolean r6 = r5.f2489e
            if (r6 == 0) goto L_0x004d
            int r6 = r5.mo3337L()
            goto L_0x0051
        L_0x004d:
            int r6 = r5.mo3336K()
        L_0x0051:
            if (r2 > r6) goto L_0x0056
            r5.mo4127o()
        L_0x0056:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.p031v7.widget.StaggeredGridLayoutManager.m3470c(int, int, int):void");
    }

    /* renamed from: c */
    private void m3471c(C0835p pVar, C0843u uVar, boolean z) {
        int q = m3480q(Integer.MAX_VALUE);
        if (q != Integer.MAX_VALUE) {
            int c = q - this.f2486b.mo3821c();
            if (c > 0) {
                int c2 = c - mo3345c(c, pVar, uVar);
                if (z && c2 > 0) {
                    this.f2486b.mo3818a(-c2);
                }
            }
        }
    }

    /* renamed from: c */
    private boolean m3472c(C0843u uVar, C0724a aVar) {
        aVar.f2502a = this.f2499o ? m3487w(uVar.mo4227e()) : m3486v(uVar.mo4227e());
        aVar.f2503b = Integer.MIN_VALUE;
        return true;
    }

    /* renamed from: i */
    private int m3473i(C0843u uVar) {
        if (mo4134v() == 0) {
            return 0;
        }
        return C0855be.m4566a(uVar, this.f2486b, mo3342b(!this.f2482F), mo3346c(!this.f2482F), this, this.f2482F);
    }

    /* renamed from: j */
    private int m3474j(C0843u uVar) {
        if (mo4134v() == 0) {
            return 0;
        }
        return C0855be.m4568b(uVar, this.f2486b, mo3342b(!this.f2482F), mo3346c(!this.f2482F), this, this.f2482F);
    }

    /* renamed from: m */
    private void m3475m(int i) {
        this.f2496l.f2762e = i;
        C0786ar arVar = this.f2496l;
        int i2 = 1;
        if (this.f2489e != (i == -1)) {
            i2 = -1;
        }
        arVar.f2761d = i2;
    }

    /* renamed from: n */
    private C0727a m3476n(int i) {
        C0727a aVar = new C0727a();
        aVar.f2515c = new int[this.f2493i];
        for (int i2 = 0; i2 < this.f2493i; i2++) {
            aVar.f2515c[i2] = i - this.f2485a[i2].mo3401b(i);
        }
        return aVar;
    }

    /* renamed from: o */
    private C0727a m3477o(int i) {
        C0727a aVar = new C0727a();
        aVar.f2515c = new int[this.f2493i];
        for (int i2 = 0; i2 < this.f2493i; i2++) {
            aVar.f2515c[i2] = this.f2485a[i2].mo3393a(i) - i;
        }
        return aVar;
    }

    /* renamed from: p */
    private int m3478p(int i) {
        int a = this.f2485a[0].mo3393a(i);
        for (int i2 = 1; i2 < this.f2493i; i2++) {
            int a2 = this.f2485a[i2].mo3393a(i);
            if (a2 > a) {
                a = a2;
            }
        }
        return a;
    }

    /* renamed from: p */
    private void m3479p(View view) {
        for (int i = this.f2493i - 1; i >= 0; i--) {
            this.f2485a[i].mo3402b(view);
        }
    }

    /* renamed from: q */
    private int m3480q(int i) {
        int a = this.f2485a[0].mo3393a(i);
        for (int i2 = 1; i2 < this.f2493i; i2++) {
            int a2 = this.f2485a[i2].mo3393a(i);
            if (a2 < a) {
                a = a2;
            }
        }
        return a;
    }

    /* renamed from: q */
    private void m3481q(View view) {
        for (int i = this.f2493i - 1; i >= 0; i--) {
            this.f2485a[i].mo3398a(view);
        }
    }

    /* renamed from: r */
    private int m3482r(int i) {
        int b = this.f2485a[0].mo3401b(i);
        for (int i2 = 1; i2 < this.f2493i; i2++) {
            int b2 = this.f2485a[i2].mo3401b(i);
            if (b2 > b) {
                b = b2;
            }
        }
        return b;
    }

    /* renamed from: s */
    private int m3483s(int i) {
        int b = this.f2485a[0].mo3401b(i);
        for (int i2 = 1; i2 < this.f2493i; i2++) {
            int b2 = this.f2485a[i2].mo3401b(i);
            if (b2 < b) {
                b = b2;
            }
        }
        return b;
    }

    /* renamed from: t */
    private boolean m3484t(int i) {
        boolean z = false;
        if (this.f2494j == 0) {
            if ((i == -1) != this.f2489e) {
                z = true;
            }
            return z;
        }
        if (((i == -1) == this.f2489e) == mo3352j()) {
            z = true;
        }
        return z;
    }

    /* renamed from: u */
    private int m3485u(int i) {
        int i2 = -1;
        if (mo4134v() == 0) {
            if (this.f2489e) {
                i2 = 1;
            }
            return i2;
        }
        return (i < mo3337L()) != this.f2489e ? -1 : 1;
    }

    /* renamed from: v */
    private int m3486v(int i) {
        int v = mo4134v();
        for (int i2 = 0; i2 < v; i2++) {
            int d = mo4104d(mo4120i(i2));
            if (d >= 0 && d < i) {
                return d;
            }
        }
        return 0;
    }

    /* renamed from: w */
    private int m3487w(int i) {
        for (int v = mo4134v() - 1; v >= 0; v--) {
            int d = mo4104d(mo4120i(v));
            if (d >= 0 && d < i) {
                return d;
            }
        }
        return 0;
    }

    /* renamed from: x */
    private int m3488x(int i) {
        int i2 = Integer.MIN_VALUE;
        if (i == 17) {
            return this.f2494j == 0 ? -1 : Integer.MIN_VALUE;
        }
        if (i == 33) {
            return this.f2494j == 1 ? -1 : Integer.MIN_VALUE;
        }
        if (i == 66) {
            if (this.f2494j == 0) {
                i2 = 1;
            }
            return i2;
        } else if (i != 130) {
            switch (i) {
                case 1:
                    return (this.f2494j != 1 && mo3352j()) ? 1 : -1;
                case 2:
                    return (this.f2494j != 1 && mo3352j()) ? -1 : 1;
                default:
                    return Integer.MIN_VALUE;
            }
        } else {
            if (this.f2494j == 1) {
                i2 = 1;
            }
            return i2;
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: K */
    public int mo3336K() {
        int v = mo4134v();
        if (v == 0) {
            return 0;
        }
        return mo4104d(mo4120i(v - 1));
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: L */
    public int mo3337L() {
        if (mo4134v() == 0) {
            return 0;
        }
        return mo4104d(mo4120i(0));
    }

    /* renamed from: a */
    public int mo3158a(int i, C0835p pVar, C0843u uVar) {
        return mo3345c(i, pVar, uVar);
    }

    /* renamed from: a */
    public int mo3159a(C0835p pVar, C0843u uVar) {
        return this.f2494j == 0 ? this.f2493i : super.mo3159a(pVar, uVar);
    }

    /* renamed from: a */
    public C0828j mo3160a() {
        return this.f2494j == 0 ? new C0725b(-2, -1) : new C0725b(-1, -2);
    }

    /* renamed from: a */
    public C0828j mo3161a(Context context, AttributeSet attributeSet) {
        return new C0725b(context, attributeSet);
    }

    /* renamed from: a */
    public C0828j mo3162a(LayoutParams layoutParams) {
        return layoutParams instanceof MarginLayoutParams ? new C0725b((MarginLayoutParams) layoutParams) : new C0725b(layoutParams);
    }

    /* renamed from: a */
    public View mo3164a(View view, int i, C0835p pVar, C0843u uVar) {
        if (mo4134v() == 0) {
            return null;
        }
        View e = mo4108e(view);
        if (e == null) {
            return null;
        }
        m3451N();
        int x = m3488x(i);
        if (x == Integer.MIN_VALUE) {
            return null;
        }
        C0725b bVar = (C0725b) e.getLayoutParams();
        boolean z = bVar.f2510b;
        C0731e eVar = bVar.f2509a;
        int K = x == 1 ? mo3336K() : mo3337L();
        m3467b(K, uVar);
        m3475m(x);
        this.f2496l.f2760c = this.f2496l.f2761d + K;
        this.f2496l.f2759b = (int) (0.33333334f * ((float) this.f2486b.mo3827f()));
        this.f2496l.f2765h = true;
        this.f2496l.f2758a = false;
        m3453a(pVar, this.f2496l, uVar);
        this.f2499o = this.f2489e;
        if (!z) {
            View a = eVar.mo3396a(K, x);
            if (!(a == null || a == e)) {
                return a;
            }
        }
        if (m3484t(x)) {
            for (int i2 = this.f2493i - 1; i2 >= 0; i2--) {
                View a2 = this.f2485a[i2].mo3396a(K, x);
                if (a2 != null && a2 != e) {
                    return a2;
                }
            }
        } else {
            for (int i3 = 0; i3 < this.f2493i; i3++) {
                View a3 = this.f2485a[i3].mo3396a(K, x);
                if (a3 != null && a3 != e) {
                    return a3;
                }
            }
        }
        boolean z2 = (this.f2488d ^ true) == (x == -1);
        if (!z) {
            View c = mo3205c(z2 ? eVar.mo3413j() : eVar.mo3414k());
            if (!(c == null || c == e)) {
                return c;
            }
        }
        if (m3484t(x)) {
            for (int i4 = this.f2493i - 1; i4 >= 0; i4--) {
                if (i4 != eVar.f2531e) {
                    View c2 = mo3205c(z2 ? this.f2485a[i4].mo3413j() : this.f2485a[i4].mo3414k());
                    if (!(c2 == null || c2 == e)) {
                        return c2;
                    }
                }
            }
        } else {
            for (int i5 = 0; i5 < this.f2493i; i5++) {
                View c3 = mo3205c(z2 ? this.f2485a[i5].mo3413j() : this.f2485a[i5].mo3414k());
                if (c3 != null && c3 != e) {
                    return c3;
                }
            }
        }
        return null;
    }

    /* renamed from: a */
    public void mo3338a(int i) {
        mo3198a((String) null);
        if (i != this.f2493i) {
            mo3350i();
            this.f2493i = i;
            this.f2497m = new BitSet(this.f2493i);
            this.f2485a = new C0731e[this.f2493i];
            for (int i2 = 0; i2 < this.f2493i; i2++) {
                this.f2485a[i2] = new C0731e(i2);
            }
            mo4127o();
        }
    }

    /* renamed from: a */
    public void mo3193a(int i, int i2, C0843u uVar, C0826a aVar) {
        int b;
        int i3;
        if (this.f2494j != 0) {
            i = i2;
        }
        if (mo4134v() != 0 && i != 0) {
            mo3339a(i, uVar);
            if (this.f2483G == null || this.f2483G.length < this.f2493i) {
                this.f2483G = new int[this.f2493i];
            }
            int i4 = 0;
            for (int i5 = 0; i5 < this.f2493i; i5++) {
                if (this.f2496l.f2761d == -1) {
                    b = this.f2496l.f2763f;
                    i3 = this.f2485a[i5].mo3393a(this.f2496l.f2763f);
                } else {
                    b = this.f2485a[i5].mo3401b(this.f2496l.f2764g);
                    i3 = this.f2496l.f2764g;
                }
                int i6 = b - i3;
                if (i6 >= 0) {
                    this.f2483G[i4] = i6;
                    i4++;
                }
            }
            Arrays.sort(this.f2483G, 0, i4);
            for (int i7 = 0; i7 < i4 && this.f2496l.mo3727a(uVar); i7++) {
                aVar.mo3724b(this.f2496l.f2760c, this.f2483G[i7]);
                this.f2496l.f2760c += this.f2496l.f2761d;
            }
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo3339a(int i, C0843u uVar) {
        int i2;
        int i3;
        if (i > 0) {
            i3 = mo3336K();
            i2 = 1;
        } else {
            i2 = -1;
            i3 = mo3337L();
        }
        this.f2496l.f2758a = true;
        m3467b(i3, uVar);
        m3475m(i2);
        this.f2496l.f2760c = i3 + this.f2496l.f2761d;
        this.f2496l.f2759b = Math.abs(i);
    }

    /* renamed from: a */
    public void mo3166a(Rect rect, int i, int i2) {
        int i3;
        int i4;
        int A = mo4051A() + mo4053C();
        int B = mo4052B() + mo4054D();
        if (this.f2494j == 1) {
            i4 = m4231a(i2, rect.height() + B, mo4057G());
            i3 = m4231a(i, (this.f2495k * this.f2493i) + A, mo4056F());
        } else {
            i3 = m4231a(i, rect.width() + A, mo4056F());
            i4 = m4231a(i2, (this.f2495k * this.f2493i) + B, mo4057G());
        }
        mo4113f(i3, i4);
    }

    /* renamed from: a */
    public void mo3195a(Parcelable parcelable) {
        if (parcelable instanceof C0729d) {
            this.f2477A = (C0729d) parcelable;
            mo4127o();
        }
    }

    /* renamed from: a */
    public void mo3169a(C0835p pVar, C0843u uVar, View view, C0464c cVar) {
        int i;
        int i2;
        int b;
        int i3;
        LayoutParams layoutParams = view.getLayoutParams();
        if (!(layoutParams instanceof C0725b)) {
            super.mo4075a(view, cVar);
            return;
        }
        C0725b bVar = (C0725b) layoutParams;
        int i4 = 1;
        if (this.f2494j == 0) {
            i = bVar.mo3364b();
            if (bVar.f2510b) {
                i4 = this.f2493i;
            }
            i2 = i4;
            b = -1;
            i3 = -1;
        } else {
            i = -1;
            i2 = -1;
            b = bVar.mo3364b();
            if (bVar.f2510b) {
                i4 = this.f2493i;
            }
            i3 = i4;
        }
        cVar.mo1864b((Object) C0466b.m2039a(i, i2, b, i3, bVar.f2510b, false));
    }

    /* renamed from: a */
    public void mo3170a(C0843u uVar) {
        super.mo3170a(uVar);
        this.f2490f = -1;
        this.f2491g = Integer.MIN_VALUE;
        this.f2477A = null;
        this.f2480D.mo3359a();
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo3340a(C0843u uVar, C0724a aVar) {
        if (!mo3344b(uVar, aVar) && !m3472c(uVar, aVar)) {
            aVar.mo3362b();
            aVar.f2502a = 0;
        }
    }

    /* renamed from: a */
    public void mo3172a(C0805ay ayVar) {
        this.f2492h.mo3367a();
        mo4127o();
    }

    /* renamed from: a */
    public void mo3173a(C0805ay ayVar, int i, int i2) {
        m3470c(i, i2, 1);
    }

    /* renamed from: a */
    public void mo3174a(C0805ay ayVar, int i, int i2, int i3) {
        m3470c(i, i2, 8);
    }

    /* renamed from: a */
    public void mo3175a(C0805ay ayVar, int i, int i2, Object obj) {
        m3470c(i, i2, 4);
    }

    /* renamed from: a */
    public void mo3196a(C0805ay ayVar, C0835p pVar) {
        super.mo3196a(ayVar, pVar);
        mo4089a(this.f2484H);
        for (int i = 0; i < this.f2493i; i++) {
            this.f2485a[i].mo3408e();
        }
        ayVar.requestLayout();
    }

    /* renamed from: a */
    public void mo3197a(AccessibilityEvent accessibilityEvent) {
        super.mo3197a(accessibilityEvent);
        if (mo4134v() > 0) {
            View b = mo3342b(false);
            View c = mo3346c(false);
            if (b != null && c != null) {
                int d = mo4104d(b);
                int d2 = mo4104d(c);
                if (d < d2) {
                    accessibilityEvent.setFromIndex(d);
                    accessibilityEvent.setToIndex(d2);
                    return;
                }
                accessibilityEvent.setFromIndex(d2);
                accessibilityEvent.setToIndex(d);
            }
        }
    }

    /* renamed from: a */
    public void mo3198a(String str) {
        if (this.f2477A == null) {
            super.mo3198a(str);
        }
    }

    /* renamed from: a */
    public void mo3341a(boolean z) {
        mo3198a((String) null);
        if (!(this.f2477A == null || this.f2477A.f2524h == z)) {
            this.f2477A.f2524h = z;
        }
        this.f2488d = z;
        mo4127o();
    }

    /* renamed from: a */
    public boolean mo3177a(C0828j jVar) {
        return jVar instanceof C0725b;
    }

    /* renamed from: b */
    public int mo3178b(int i, C0835p pVar, C0843u uVar) {
        return mo3345c(i, pVar, uVar);
    }

    /* renamed from: b */
    public int mo3179b(C0835p pVar, C0843u uVar) {
        return this.f2494j == 1 ? this.f2493i : super.mo3179b(pVar, uVar);
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: b */
    public View mo3342b(boolean z) {
        int c = this.f2486b.mo3821c();
        int d = this.f2486b.mo3823d();
        int v = mo4134v();
        View view = null;
        for (int i = 0; i < v; i++) {
            View i2 = mo4120i(i);
            int a = this.f2486b.mo3816a(i2);
            if (this.f2486b.mo3820b(i2) > c && a < d) {
                if (a >= c || !z) {
                    return i2;
                }
                if (view == null) {
                    view = i2;
                }
            }
        }
        return view;
    }

    /* renamed from: b */
    public void mo3343b(int i) {
        if (i == 0 || i == 1) {
            mo3198a((String) null);
            if (i != this.f2494j) {
                this.f2494j = i;
                C0802ax axVar = this.f2486b;
                this.f2486b = this.f2487c;
                this.f2487c = axVar;
                mo4127o();
                return;
            }
            return;
        }
        throw new IllegalArgumentException("invalid orientation.");
    }

    /* renamed from: b */
    public void mo3180b(C0805ay ayVar, int i, int i2) {
        m3470c(i, i2, 2);
    }

    /* renamed from: b */
    public boolean mo3181b() {
        return this.f2477A == null;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: b */
    public boolean mo3344b(C0843u uVar, C0724a aVar) {
        int c;
        int a;
        boolean z = false;
        if (uVar.mo4223a() || this.f2490f == -1) {
            return false;
        }
        if (this.f2490f < 0 || this.f2490f >= uVar.mo4227e()) {
            this.f2490f = -1;
            this.f2491g = Integer.MIN_VALUE;
            return false;
        } else if (this.f2477A == null || this.f2477A.f2517a == -1 || this.f2477A.f2519c < 1) {
            View c2 = mo3205c(this.f2490f);
            if (c2 != null) {
                aVar.f2502a = this.f2489e ? mo3336K() : mo3337L();
                if (this.f2491g != Integer.MIN_VALUE) {
                    if (aVar.f2504c) {
                        c = this.f2486b.mo3823d() - this.f2491g;
                        a = this.f2486b.mo3820b(c2);
                    } else {
                        c = this.f2486b.mo3821c() + this.f2491g;
                        a = this.f2486b.mo3816a(c2);
                    }
                    aVar.f2503b = c - a;
                    return true;
                } else if (this.f2486b.mo3826e(c2) > this.f2486b.mo3827f()) {
                    aVar.f2503b = aVar.f2504c ? this.f2486b.mo3823d() : this.f2486b.mo3821c();
                    return true;
                } else {
                    int a2 = this.f2486b.mo3816a(c2) - this.f2486b.mo3821c();
                    if (a2 < 0) {
                        aVar.f2503b = -a2;
                        return true;
                    }
                    int d = this.f2486b.mo3823d() - this.f2486b.mo3820b(c2);
                    if (d < 0) {
                        aVar.f2503b = d;
                        return true;
                    }
                    aVar.f2503b = Integer.MIN_VALUE;
                    return true;
                }
            } else {
                aVar.f2502a = this.f2490f;
                if (this.f2491g == Integer.MIN_VALUE) {
                    if (m3485u(aVar.f2502a) == 1) {
                        z = true;
                    }
                    aVar.f2504c = z;
                    aVar.mo3362b();
                } else {
                    aVar.mo3360a(this.f2491g);
                }
                aVar.f2505d = true;
                return true;
            }
        } else {
            aVar.f2503b = Integer.MIN_VALUE;
            aVar.f2502a = this.f2490f;
            return true;
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: c */
    public int mo3345c(int i, C0835p pVar, C0843u uVar) {
        if (mo4134v() == 0 || i == 0) {
            return 0;
        }
        mo3339a(i, uVar);
        int a = m3453a(pVar, this.f2496l, uVar);
        if (this.f2496l.f2759b >= a) {
            i = i < 0 ? -a : a;
        }
        this.f2486b.mo3818a(-i);
        this.f2499o = this.f2489e;
        this.f2496l.f2759b = 0;
        m3459a(pVar, this.f2496l);
        return i;
    }

    /* renamed from: c */
    public int mo3204c(C0843u uVar) {
        return m3466b(uVar);
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: c */
    public View mo3346c(boolean z) {
        int c = this.f2486b.mo3821c();
        int d = this.f2486b.mo3823d();
        View view = null;
        for (int v = mo4134v() - 1; v >= 0; v--) {
            View i = mo4120i(v);
            int a = this.f2486b.mo3816a(i);
            int b = this.f2486b.mo3820b(i);
            if (b > c && a < d) {
                if (b <= d || !z) {
                    return i;
                }
                if (view == null) {
                    view = i;
                }
            }
        }
        return view;
    }

    /* renamed from: c */
    public void mo3182c(C0835p pVar, C0843u uVar) {
        m3460a(pVar, uVar, true);
    }

    /* renamed from: c */
    public boolean mo3206c() {
        return this.f2498n != 0;
    }

    /* renamed from: d */
    public int mo3207d(C0843u uVar) {
        return m3466b(uVar);
    }

    /* renamed from: d */
    public PointF mo3208d(int i) {
        int u = m3485u(i);
        PointF pointF = new PointF();
        if (u == 0) {
            return null;
        }
        if (this.f2494j == 0) {
            pointF.x = (float) u;
            pointF.y = 0.0f;
            return pointF;
        }
        pointF.x = 0.0f;
        pointF.y = (float) u;
        return pointF;
    }

    /* renamed from: d */
    public Parcelable mo3209d() {
        int i;
        int c;
        if (this.f2477A != null) {
            return new C0729d(this.f2477A);
        }
        C0729d dVar = new C0729d();
        dVar.f2524h = this.f2488d;
        dVar.f2525i = this.f2499o;
        dVar.f2526j = this.f2500z;
        if (this.f2492h == null || this.f2492h.f2511a == null) {
            dVar.f2521e = 0;
        } else {
            dVar.f2522f = this.f2492h.f2511a;
            dVar.f2521e = dVar.f2522f.length;
            dVar.f2523g = this.f2492h.f2512b;
        }
        if (mo4134v() > 0) {
            dVar.f2517a = this.f2499o ? mo3336K() : mo3337L();
            dVar.f2518b = mo3353k();
            dVar.f2519c = this.f2493i;
            dVar.f2520d = new int[this.f2493i];
            for (int i2 = 0; i2 < this.f2493i; i2++) {
                if (this.f2499o) {
                    i = this.f2485a[i2].mo3401b(Integer.MIN_VALUE);
                    if (i != Integer.MIN_VALUE) {
                        c = this.f2486b.mo3823d();
                    } else {
                        dVar.f2520d[i2] = i;
                    }
                } else {
                    i = this.f2485a[i2].mo3393a(Integer.MIN_VALUE);
                    if (i != Integer.MIN_VALUE) {
                        c = this.f2486b.mo3821c();
                    } else {
                        dVar.f2520d[i2] = i;
                    }
                }
                i -= c;
                dVar.f2520d[i2] = i;
            }
        } else {
            dVar.f2517a = -1;
            dVar.f2518b = -1;
            dVar.f2519c = 0;
        }
        return dVar;
    }

    /* renamed from: e */
    public int mo3210e(C0843u uVar) {
        return m3473i(uVar);
    }

    /* renamed from: e */
    public void mo3211e(int i) {
        if (!(this.f2477A == null || this.f2477A.f2517a == i)) {
            this.f2477A.mo3386b();
        }
        this.f2490f = i;
        this.f2491g = Integer.MIN_VALUE;
        mo4127o();
    }

    /* renamed from: e */
    public boolean mo3212e() {
        return this.f2494j == 0;
    }

    /* renamed from: f */
    public int mo3214f(C0843u uVar) {
        return m3473i(uVar);
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: f */
    public void mo3347f(int i) {
        this.f2495k = i / this.f2493i;
        this.f2478B = MeasureSpec.makeMeasureSpec(i, this.f2487c.mo3830h());
    }

    /* renamed from: f */
    public boolean mo3215f() {
        return this.f2494j == 1;
    }

    /* renamed from: g */
    public int mo3217g(C0843u uVar) {
        return m3474j(uVar);
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: g */
    public boolean mo3348g() {
        int i;
        int i2;
        if (mo4134v() == 0 || this.f2498n == 0 || !mo4129q()) {
            return false;
        }
        if (this.f2489e) {
            i2 = mo3336K();
            i = mo3337L();
        } else {
            i2 = mo3337L();
            i = mo3336K();
        }
        if (i2 == 0 && mo3349h() != null) {
            this.f2492h.mo3367a();
        } else if (!this.f2481E) {
            return false;
        } else {
            int i3 = this.f2489e ? -1 : 1;
            int i4 = i + 1;
            C0727a a = this.f2492h.mo3366a(i2, i4, i3, true);
            if (a == null) {
                this.f2481E = false;
                this.f2492h.mo3365a(i4);
                return false;
            }
            C0727a a2 = this.f2492h.mo3366a(i2, a.f2513a, i3 * -1, true);
            if (a2 == null) {
                this.f2492h.mo3365a(a.f2513a);
            } else {
                this.f2492h.mo3365a(a2.f2513a + 1);
            }
        }
        mo4059I();
        mo4127o();
        return true;
    }

    /* renamed from: h */
    public int mo3218h(C0843u uVar) {
        return m3474j(uVar);
    }

    /* access modifiers changed from: 0000 */
    /* JADX WARNING: Code restructure failed: missing block: B:28:0x0074, code lost:
        if (r10 == r11) goto L_0x0088;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:32:0x0086, code lost:
        if (r10 == r11) goto L_0x0088;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:34:0x008a, code lost:
        r10 = false;
     */
    /* renamed from: h */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public android.view.View mo3349h() {
        /*
            r12 = this;
            int r0 = r12.mo4134v()
            r1 = 1
            int r0 = r0 - r1
            java.util.BitSet r2 = new java.util.BitSet
            int r3 = r12.f2493i
            r2.<init>(r3)
            int r3 = r12.f2493i
            r4 = 0
            r2.set(r4, r3, r1)
            int r3 = r12.f2494j
            r5 = -1
            if (r3 != r1) goto L_0x0020
            boolean r3 = r12.mo3352j()
            if (r3 == 0) goto L_0x0020
            r3 = r1
            goto L_0x0021
        L_0x0020:
            r3 = r5
        L_0x0021:
            boolean r6 = r12.f2489e
            if (r6 == 0) goto L_0x0027
            r6 = r5
            goto L_0x002b
        L_0x0027:
            int r0 = r0 + 1
            r6 = r0
            r0 = r4
        L_0x002b:
            if (r0 >= r6) goto L_0x002e
            r5 = r1
        L_0x002e:
            if (r0 == r6) goto L_0x00ab
            android.view.View r7 = r12.mo4120i(r0)
            android.view.ViewGroup$LayoutParams r8 = r7.getLayoutParams()
            android.support.v7.widget.StaggeredGridLayoutManager$b r8 = (android.support.p031v7.widget.StaggeredGridLayoutManager.C0725b) r8
            android.support.v7.widget.StaggeredGridLayoutManager$e r9 = r8.f2509a
            int r9 = r9.f2531e
            boolean r9 = r2.get(r9)
            if (r9 == 0) goto L_0x0054
            android.support.v7.widget.StaggeredGridLayoutManager$e r9 = r8.f2509a
            boolean r9 = r12.m3464a(r9)
            if (r9 == 0) goto L_0x004d
            return r7
        L_0x004d:
            android.support.v7.widget.StaggeredGridLayoutManager$e r9 = r8.f2509a
            int r9 = r9.f2531e
            r2.clear(r9)
        L_0x0054:
            boolean r9 = r8.f2510b
            if (r9 == 0) goto L_0x0059
            goto L_0x00a9
        L_0x0059:
            int r9 = r0 + r5
            if (r9 == r6) goto L_0x00a9
            android.view.View r9 = r12.mo4120i(r9)
            boolean r10 = r12.f2489e
            if (r10 == 0) goto L_0x0077
            android.support.v7.widget.ax r10 = r12.f2486b
            int r10 = r10.mo3820b(r7)
            android.support.v7.widget.ax r11 = r12.f2486b
            int r11 = r11.mo3820b(r9)
            if (r10 >= r11) goto L_0x0074
            return r7
        L_0x0074:
            if (r10 != r11) goto L_0x008a
            goto L_0x0088
        L_0x0077:
            android.support.v7.widget.ax r10 = r12.f2486b
            int r10 = r10.mo3816a(r7)
            android.support.v7.widget.ax r11 = r12.f2486b
            int r11 = r11.mo3816a(r9)
            if (r10 <= r11) goto L_0x0086
            return r7
        L_0x0086:
            if (r10 != r11) goto L_0x008a
        L_0x0088:
            r10 = r1
            goto L_0x008b
        L_0x008a:
            r10 = r4
        L_0x008b:
            if (r10 == 0) goto L_0x00a9
            android.view.ViewGroup$LayoutParams r9 = r9.getLayoutParams()
            android.support.v7.widget.StaggeredGridLayoutManager$b r9 = (android.support.p031v7.widget.StaggeredGridLayoutManager.C0725b) r9
            android.support.v7.widget.StaggeredGridLayoutManager$e r8 = r8.f2509a
            int r8 = r8.f2531e
            android.support.v7.widget.StaggeredGridLayoutManager$e r9 = r9.f2509a
            int r9 = r9.f2531e
            int r8 = r8 - r9
            if (r8 >= 0) goto L_0x00a0
            r8 = r1
            goto L_0x00a1
        L_0x00a0:
            r8 = r4
        L_0x00a1:
            if (r3 >= 0) goto L_0x00a5
            r9 = r1
            goto L_0x00a6
        L_0x00a5:
            r9 = r4
        L_0x00a6:
            if (r8 == r9) goto L_0x00a9
            return r7
        L_0x00a9:
            int r0 = r0 + r5
            goto L_0x002e
        L_0x00ab:
            r0 = 0
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.p031v7.widget.StaggeredGridLayoutManager.mo3349h():android.view.View");
    }

    /* renamed from: i */
    public void mo3350i() {
        this.f2492h.mo3367a();
        mo4127o();
    }

    /* renamed from: j */
    public void mo3351j(int i) {
        super.mo3351j(i);
        for (int i2 = 0; i2 < this.f2493i; i2++) {
            this.f2485a[i2].mo3407d(i);
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: j */
    public boolean mo3352j() {
        return mo4132t() == 1;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: k */
    public int mo3353k() {
        View c = this.f2489e ? mo3346c(true) : mo3342b(true);
        if (c == null) {
            return -1;
        }
        return mo4104d(c);
    }

    /* renamed from: k */
    public void mo3354k(int i) {
        super.mo3354k(i);
        for (int i2 = 0; i2 < this.f2493i; i2++) {
            this.f2485a[i2].mo3407d(i);
        }
    }

    /* renamed from: l */
    public void mo3355l(int i) {
        if (i == 0) {
            mo3348g();
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: m */
    public boolean mo3356m() {
        int b = this.f2485a[0].mo3401b(Integer.MIN_VALUE);
        for (int i = 1; i < this.f2493i; i++) {
            if (this.f2485a[i].mo3401b(Integer.MIN_VALUE) != b) {
                return false;
            }
        }
        return true;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: n */
    public boolean mo3357n() {
        int a = this.f2485a[0].mo3393a(Integer.MIN_VALUE);
        for (int i = 1; i < this.f2493i; i++) {
            if (this.f2485a[i].mo3393a(Integer.MIN_VALUE) != a) {
                return false;
            }
        }
        return true;
    }
}
