package android.support.p031v7.widget;

import android.support.p031v7.widget.C0805ay.C0823i;
import android.support.p031v7.widget.C0805ay.C0843u;
import android.view.View;

/* renamed from: android.support.v7.widget.be */
class C0855be {
    /* renamed from: a */
    static int m4566a(C0843u uVar, C0802ax axVar, View view, View view2, C0823i iVar, boolean z) {
        if (iVar.mo4134v() == 0 || uVar.mo4227e() == 0 || view == null || view2 == null) {
            return 0;
        }
        if (!z) {
            return Math.abs(iVar.mo4104d(view) - iVar.mo4104d(view2)) + 1;
        }
        return Math.min(axVar.mo3827f(), axVar.mo3820b(view2) - axVar.mo3816a(view));
    }

    /* renamed from: a */
    static int m4567a(C0843u uVar, C0802ax axVar, View view, View view2, C0823i iVar, boolean z, boolean z2) {
        if (iVar.mo4134v() == 0 || uVar.mo4227e() == 0 || view == null || view2 == null) {
            return 0;
        }
        int max = z2 ? Math.max(0, (uVar.mo4227e() - Math.max(iVar.mo4104d(view), iVar.mo4104d(view2))) - 1) : Math.max(0, Math.min(iVar.mo4104d(view), iVar.mo4104d(view2)));
        if (!z) {
            return max;
        }
        return Math.round((((float) max) * (((float) Math.abs(axVar.mo3820b(view2) - axVar.mo3816a(view))) / ((float) (Math.abs(iVar.mo4104d(view) - iVar.mo4104d(view2)) + 1)))) + ((float) (axVar.mo3821c() - axVar.mo3816a(view))));
    }

    /* renamed from: b */
    static int m4568b(C0843u uVar, C0802ax axVar, View view, View view2, C0823i iVar, boolean z) {
        if (iVar.mo4134v() == 0 || uVar.mo4227e() == 0 || view == null || view2 == null) {
            return 0;
        }
        if (!z) {
            return uVar.mo4227e();
        }
        return (int) ((((float) (axVar.mo3820b(view2) - axVar.mo3816a(view))) / ((float) (Math.abs(iVar.mo4104d(view) - iVar.mo4104d(view2)) + 1))) * ((float) uVar.mo4227e()));
    }
}
