package android.support.p031v7.widget;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.support.p018v4.p028h.C0495r;
import android.support.p018v4.p028h.C0502v;
import android.support.p018v4.p028h.C0506w;
import android.support.p018v4.p028h.C0507x;
import android.support.p031v7.p032a.C0540a.C0541a;
import android.support.p031v7.p032a.C0540a.C0545e;
import android.support.p031v7.p032a.C0540a.C0546f;
import android.support.p031v7.p032a.C0540a.C0548h;
import android.support.p031v7.p032a.C0540a.C0550j;
import android.support.p031v7.p033b.p034a.C0606a;
import android.support.p031v7.view.menu.C0642a;
import android.support.p031v7.view.menu.C0655h;
import android.support.p031v7.view.menu.C0655h.C0656a;
import android.support.p031v7.view.menu.C0671o.C0672a;
import android.support.p031v7.widget.Toolbar.C0736b;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.Window.Callback;

/* renamed from: android.support.v7.widget.bo */
public class C0870bo implements C0756aj {

    /* renamed from: a */
    Toolbar f3146a;

    /* renamed from: b */
    CharSequence f3147b;

    /* renamed from: c */
    Callback f3148c;

    /* renamed from: d */
    boolean f3149d;

    /* renamed from: e */
    private int f3150e;

    /* renamed from: f */
    private View f3151f;

    /* renamed from: g */
    private View f3152g;

    /* renamed from: h */
    private Drawable f3153h;

    /* renamed from: i */
    private Drawable f3154i;

    /* renamed from: j */
    private Drawable f3155j;

    /* renamed from: k */
    private boolean f3156k;

    /* renamed from: l */
    private CharSequence f3157l;

    /* renamed from: m */
    private CharSequence f3158m;

    /* renamed from: n */
    private C0887c f3159n;

    /* renamed from: o */
    private int f3160o;

    /* renamed from: p */
    private int f3161p;

    /* renamed from: q */
    private Drawable f3162q;

    public C0870bo(Toolbar toolbar, boolean z) {
        this(toolbar, z, C0548h.abc_action_bar_up_description, C0545e.abc_ic_ab_back_material);
    }

    public C0870bo(Toolbar toolbar, boolean z, int i, int i2) {
        this.f3160o = 0;
        this.f3161p = 0;
        this.f3146a = toolbar;
        this.f3147b = toolbar.getTitle();
        this.f3157l = toolbar.getSubtitle();
        this.f3156k = this.f3147b != null;
        this.f3155j = toolbar.getNavigationIcon();
        C0869bn a = C0869bn.m4638a(toolbar.getContext(), null, C0550j.ActionBar, C0541a.actionBarStyle, 0);
        this.f3162q = a.mo4426a(C0550j.ActionBar_homeAsUpIndicator);
        if (z) {
            CharSequence c = a.mo4432c(C0550j.ActionBar_title);
            if (!TextUtils.isEmpty(c)) {
                mo4443b(c);
            }
            CharSequence c2 = a.mo4432c(C0550j.ActionBar_subtitle);
            if (!TextUtils.isEmpty(c2)) {
                mo4445c(c2);
            }
            Drawable a2 = a.mo4426a(C0550j.ActionBar_logo);
            if (a2 != null) {
                mo4442b(a2);
            }
            Drawable a3 = a.mo4426a(C0550j.ActionBar_icon);
            if (a3 != null) {
                mo3615a(a3);
            }
            if (this.f3155j == null && this.f3162q != null) {
                mo4444c(this.f3162q);
            }
            mo3625c(a.mo4424a(C0550j.ActionBar_displayOptions, 0));
            int g = a.mo4439g(C0550j.ActionBar_customNavigationLayout, 0);
            if (g != 0) {
                mo4441a(LayoutInflater.from(this.f3146a.getContext()).inflate(g, this.f3146a, false));
                mo3625c(this.f3150e | 16);
            }
            int f = a.mo4437f(C0550j.ActionBar_height, 0);
            if (f > 0) {
                LayoutParams layoutParams = this.f3146a.getLayoutParams();
                layoutParams.height = f;
                this.f3146a.setLayoutParams(layoutParams);
            }
            int d = a.mo4433d(C0550j.ActionBar_contentInsetStart, -1);
            int d2 = a.mo4433d(C0550j.ActionBar_contentInsetEnd, -1);
            if (d >= 0 || d2 >= 0) {
                this.f3146a.mo3417a(Math.max(d, 0), Math.max(d2, 0));
            }
            int g2 = a.mo4439g(C0550j.ActionBar_titleTextStyle, 0);
            if (g2 != 0) {
                this.f3146a.mo3418a(this.f3146a.getContext(), g2);
            }
            int g3 = a.mo4439g(C0550j.ActionBar_subtitleTextStyle, 0);
            if (g3 != 0) {
                this.f3146a.mo3422b(this.f3146a.getContext(), g3);
            }
            int g4 = a.mo4439g(C0550j.ActionBar_popupTheme, 0);
            if (g4 != 0) {
                this.f3146a.setPopupTheme(g4);
            }
        } else {
            this.f3150e = m4658r();
        }
        a.mo4427a();
        mo4447e(i);
        this.f3158m = this.f3146a.getNavigationContentDescription();
        this.f3146a.setNavigationOnClickListener(new OnClickListener() {

            /* renamed from: a */
            final C0642a f3163a;

            {
                C0642a aVar = new C0642a(C0870bo.this.f3146a.getContext(), 0, 16908332, 0, 0, C0870bo.this.f3147b);
                this.f3163a = aVar;
            }

            public void onClick(View view) {
                if (C0870bo.this.f3148c != null && C0870bo.this.f3149d) {
                    C0870bo.this.f3148c.onMenuItemSelected(0, this.f3163a);
                }
            }
        });
    }

    /* renamed from: e */
    private void m4657e(CharSequence charSequence) {
        this.f3147b = charSequence;
        if ((this.f3150e & 8) != 0) {
            this.f3146a.setTitle(charSequence);
        }
    }

    /* renamed from: r */
    private int m4658r() {
        if (this.f3146a.getNavigationIcon() == null) {
            return 11;
        }
        this.f3162q = this.f3146a.getNavigationIcon();
        return 15;
    }

    /* renamed from: s */
    private void m4659s() {
        Drawable drawable = (this.f3150e & 2) != 0 ? ((this.f3150e & 1) == 0 || this.f3154i == null) ? this.f3153h : this.f3154i : null;
        this.f3146a.setLogo(drawable);
    }

    /* renamed from: t */
    private void m4660t() {
        Drawable drawable;
        Toolbar toolbar;
        if ((this.f3150e & 4) != 0) {
            toolbar = this.f3146a;
            drawable = this.f3155j != null ? this.f3155j : this.f3162q;
        } else {
            toolbar = this.f3146a;
            drawable = null;
        }
        toolbar.setNavigationIcon(drawable);
    }

    /* renamed from: u */
    private void m4661u() {
        if ((this.f3150e & 4) != 0) {
            if (TextUtils.isEmpty(this.f3158m)) {
                this.f3146a.setNavigationContentDescription(this.f3161p);
                return;
            }
            this.f3146a.setNavigationContentDescription(this.f3158m);
        }
    }

    /* renamed from: a */
    public C0502v mo3612a(final int i, long j) {
        return C0495r.m2156k(this.f3146a).mo1953a(i == 0 ? 1.0f : 0.0f).mo1954a(j).mo1955a((C0506w) new C0507x() {

            /* renamed from: c */
            private boolean f3167c = false;

            /* renamed from: a */
            public void mo1966a(View view) {
                C0870bo.this.f3146a.setVisibility(0);
            }

            /* renamed from: b */
            public void mo1967b(View view) {
                if (!this.f3167c) {
                    C0870bo.this.f3146a.setVisibility(i);
                }
            }

            /* renamed from: c */
            public void mo1968c(View view) {
                this.f3167c = true;
            }
        });
    }

    /* renamed from: a */
    public ViewGroup mo3613a() {
        return this.f3146a;
    }

    /* renamed from: a */
    public void mo3614a(int i) {
        mo3615a(i != 0 ? C0606a.m2714b(mo3622b(), i) : null);
    }

    /* renamed from: a */
    public void mo3615a(Drawable drawable) {
        this.f3153h = drawable;
        m4659s();
    }

    /* renamed from: a */
    public void mo3616a(C0672a aVar, C0656a aVar2) {
        this.f3146a.mo3420a(aVar, aVar2);
    }

    /* renamed from: a */
    public void mo3617a(C0856bf bfVar) {
        if (this.f3151f != null && this.f3151f.getParent() == this.f3146a) {
            this.f3146a.removeView(this.f3151f);
        }
        this.f3151f = bfVar;
        if (bfVar != null && this.f3160o == 2) {
            this.f3146a.addView(this.f3151f, 0);
            C0736b bVar = (C0736b) this.f3151f.getLayoutParams();
            bVar.width = -2;
            bVar.height = -2;
            bVar.f1689a = 8388691;
            bfVar.setAllowCollapse(true);
        }
    }

    /* renamed from: a */
    public void mo3618a(Menu menu, C0672a aVar) {
        if (this.f3159n == null) {
            this.f3159n = new C0887c(this.f3146a.getContext());
            this.f3159n.mo2636a(C0546f.action_menu_presenter);
        }
        this.f3159n.mo2640a(aVar);
        this.f3146a.mo3419a((C0655h) menu, this.f3159n);
    }

    /* renamed from: a */
    public void mo4441a(View view) {
        if (!(this.f3152g == null || (this.f3150e & 16) == 0)) {
            this.f3146a.removeView(this.f3152g);
        }
        this.f3152g = view;
        if (view != null && (this.f3150e & 16) != 0) {
            this.f3146a.addView(this.f3152g);
        }
    }

    /* renamed from: a */
    public void mo3619a(Callback callback) {
        this.f3148c = callback;
    }

    /* renamed from: a */
    public void mo3620a(CharSequence charSequence) {
        if (!this.f3156k) {
            m4657e(charSequence);
        }
    }

    /* renamed from: a */
    public void mo3621a(boolean z) {
        this.f3146a.setCollapsible(z);
    }

    /* renamed from: b */
    public Context mo3622b() {
        return this.f3146a.getContext();
    }

    /* renamed from: b */
    public void mo3623b(int i) {
        mo4442b(i != 0 ? C0606a.m2714b(mo3622b(), i) : null);
    }

    /* renamed from: b */
    public void mo4442b(Drawable drawable) {
        this.f3154i = drawable;
        m4659s();
    }

    /* renamed from: b */
    public void mo4443b(CharSequence charSequence) {
        this.f3156k = true;
        m4657e(charSequence);
    }

    /* renamed from: b */
    public void mo3624b(boolean z) {
    }

    /* renamed from: c */
    public void mo3625c(int i) {
        CharSequence charSequence;
        Toolbar toolbar;
        int i2 = this.f3150e ^ i;
        this.f3150e = i;
        if (i2 != 0) {
            if ((i2 & 4) != 0) {
                if ((i & 4) != 0) {
                    m4661u();
                }
                m4660t();
            }
            if ((i2 & 3) != 0) {
                m4659s();
            }
            if ((i2 & 8) != 0) {
                if ((i & 8) != 0) {
                    this.f3146a.setTitle(this.f3147b);
                    toolbar = this.f3146a;
                    charSequence = this.f3157l;
                } else {
                    charSequence = null;
                    this.f3146a.setTitle((CharSequence) null);
                    toolbar = this.f3146a;
                }
                toolbar.setSubtitle(charSequence);
            }
            if (!((i2 & 16) == 0 || this.f3152g == null)) {
                if ((i & 16) != 0) {
                    this.f3146a.addView(this.f3152g);
                    return;
                }
                this.f3146a.removeView(this.f3152g);
            }
        }
    }

    /* renamed from: c */
    public void mo4444c(Drawable drawable) {
        this.f3155j = drawable;
        m4660t();
    }

    /* renamed from: c */
    public void mo4445c(CharSequence charSequence) {
        this.f3157l = charSequence;
        if ((this.f3150e & 8) != 0) {
            this.f3146a.setSubtitle(charSequence);
        }
    }

    /* renamed from: c */
    public boolean mo3626c() {
        return this.f3146a.mo3429g();
    }

    /* renamed from: d */
    public void mo3627d() {
        this.f3146a.mo3459h();
    }

    /* renamed from: d */
    public void mo3628d(int i) {
        this.f3146a.setVisibility(i);
    }

    /* renamed from: d */
    public void mo4446d(CharSequence charSequence) {
        this.f3158m = charSequence;
        m4661u();
    }

    /* renamed from: e */
    public CharSequence mo3629e() {
        return this.f3146a.getTitle();
    }

    /* renamed from: e */
    public void mo4447e(int i) {
        if (i != this.f3161p) {
            this.f3161p = i;
            if (TextUtils.isEmpty(this.f3146a.getNavigationContentDescription())) {
                mo4448f(this.f3161p);
            }
        }
    }

    /* renamed from: f */
    public void mo3630f() {
        Log.i("ToolbarWidgetWrapper", "Progress display unsupported");
    }

    /* renamed from: f */
    public void mo4448f(int i) {
        mo4446d((CharSequence) i == 0 ? null : mo3622b().getString(i));
    }

    /* renamed from: g */
    public void mo3631g() {
        Log.i("ToolbarWidgetWrapper", "Progress display unsupported");
    }

    /* renamed from: h */
    public boolean mo3632h() {
        return this.f3146a.mo3421a();
    }

    /* renamed from: i */
    public boolean mo3633i() {
        return this.f3146a.mo3423b();
    }

    /* renamed from: j */
    public boolean mo3634j() {
        return this.f3146a.mo3424c();
    }

    /* renamed from: k */
    public boolean mo3635k() {
        return this.f3146a.mo3426d();
    }

    /* renamed from: l */
    public boolean mo3636l() {
        return this.f3146a.mo3427e();
    }

    /* renamed from: m */
    public void mo3637m() {
        this.f3149d = true;
    }

    /* renamed from: n */
    public void mo3638n() {
        this.f3146a.mo3428f();
    }

    /* renamed from: o */
    public int mo3639o() {
        return this.f3150e;
    }

    /* renamed from: p */
    public int mo3640p() {
        return this.f3160o;
    }

    /* renamed from: q */
    public Menu mo3641q() {
        return this.f3146a.getMenu();
    }
}
