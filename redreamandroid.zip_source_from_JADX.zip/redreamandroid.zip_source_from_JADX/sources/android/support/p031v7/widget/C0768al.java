package android.support.p031v7.widget;

import android.graphics.PorterDuff.Mode;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.Drawable.ConstantState;
import android.graphics.drawable.DrawableContainer;
import android.graphics.drawable.DrawableContainer.DrawableContainerState;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.InsetDrawable;
import android.graphics.drawable.LayerDrawable;
import android.graphics.drawable.ScaleDrawable;
import android.os.Build.VERSION;
import android.support.p018v4.graphics.drawable.C0443c;
import android.support.p031v7.p035c.p036a.C0620c;

/* renamed from: android.support.v7.widget.al */
public class C0768al {

    /* renamed from: a */
    public static final Rect f2678a = new Rect();

    /* renamed from: b */
    private static Class<?> f2679b;

    static {
        if (VERSION.SDK_INT >= 18) {
            try {
                f2679b = Class.forName("android.graphics.Insets");
            } catch (ClassNotFoundException unused) {
            }
        }
    }

    /* renamed from: a */
    public static Mode m3839a(int i, Mode mode) {
        if (i == 3) {
            return Mode.SRC_OVER;
        }
        if (i == 5) {
            return Mode.SRC_IN;
        }
        if (i == 9) {
            return Mode.SRC_ATOP;
        }
        switch (i) {
            case 14:
                return Mode.MULTIPLY;
            case 15:
                return Mode.SCREEN;
            case 16:
                return Mode.ADD;
            default:
                return mode;
        }
    }

    /* renamed from: a */
    static void m3840a(Drawable drawable) {
        if (VERSION.SDK_INT == 21 && "android.graphics.drawable.VectorDrawable".equals(drawable.getClass().getName())) {
            m3842c(drawable);
        }
    }

    /* renamed from: b */
    public static boolean m3841b(Drawable drawable) {
        Drawable drawable2;
        if (VERSION.SDK_INT < 15 && (drawable instanceof InsetDrawable)) {
            return false;
        }
        if (VERSION.SDK_INT < 15 && (drawable instanceof GradientDrawable)) {
            return false;
        }
        if (VERSION.SDK_INT < 17 && (drawable instanceof LayerDrawable)) {
            return false;
        }
        if (drawable instanceof DrawableContainer) {
            ConstantState constantState = drawable.getConstantState();
            if (constantState instanceof DrawableContainerState) {
                for (Drawable b : ((DrawableContainerState) constantState).getChildren()) {
                    if (!m3841b(b)) {
                        return false;
                    }
                }
            }
        } else {
            if (drawable instanceof C0443c) {
                drawable2 = ((C0443c) drawable).mo1786a();
            } else if (drawable instanceof C0620c) {
                drawable2 = ((C0620c) drawable).mo2460b();
            } else if (drawable instanceof ScaleDrawable) {
                drawable2 = ((ScaleDrawable) drawable).getDrawable();
            }
            return m3841b(drawable2);
        }
        return true;
    }

    /* renamed from: c */
    private static void m3842c(Drawable drawable) {
        int[] state = drawable.getState();
        drawable.setState((state == null || state.length == 0) ? C0864bi.f3128e : C0864bi.f3131h);
        drawable.setState(state);
    }
}
