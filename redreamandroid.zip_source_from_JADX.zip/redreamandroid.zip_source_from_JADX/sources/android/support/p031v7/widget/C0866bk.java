package android.support.p031v7.widget;

import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.AssetManager;
import android.content.res.Resources;
import android.content.res.Resources.Theme;
import android.os.Build.VERSION;
import java.lang.ref.WeakReference;
import java.util.ArrayList;

/* renamed from: android.support.v7.widget.bk */
public class C0866bk extends ContextWrapper {

    /* renamed from: a */
    private static final Object f3134a = new Object();

    /* renamed from: b */
    private static ArrayList<WeakReference<C0866bk>> f3135b;

    /* renamed from: c */
    private final Resources f3136c;

    /* renamed from: d */
    private final Theme f3137d;

    private C0866bk(Context context) {
        super(context);
        if (C0878bs.m4717a()) {
            this.f3136c = new C0878bs(this, context.getResources());
            this.f3137d = this.f3136c.newTheme();
            this.f3137d.setTo(context.getTheme());
            return;
        }
        this.f3136c = new C0868bm(this, context.getResources());
        this.f3137d = null;
    }

    /* renamed from: a */
    public static Context m4633a(Context context) {
        if (!m4634b(context)) {
            return context;
        }
        synchronized (f3134a) {
            if (f3135b == null) {
                f3135b = new ArrayList<>();
            } else {
                for (int size = f3135b.size() - 1; size >= 0; size--) {
                    WeakReference weakReference = (WeakReference) f3135b.get(size);
                    if (weakReference == null || weakReference.get() == null) {
                        f3135b.remove(size);
                    }
                }
                for (int size2 = f3135b.size() - 1; size2 >= 0; size2--) {
                    WeakReference weakReference2 = (WeakReference) f3135b.get(size2);
                    C0866bk bkVar = weakReference2 != null ? (C0866bk) weakReference2.get() : null;
                    if (bkVar != null && bkVar.getBaseContext() == context) {
                        return bkVar;
                    }
                }
            }
            C0866bk bkVar2 = new C0866bk(context);
            f3135b.add(new WeakReference(bkVar2));
            return bkVar2;
        }
    }

    /* renamed from: b */
    private static boolean m4634b(Context context) {
        boolean z = false;
        if (!(context instanceof C0866bk) && !(context.getResources() instanceof C0868bm)) {
            if (context.getResources() instanceof C0878bs) {
                return false;
            }
            if (VERSION.SDK_INT < 21 || C0878bs.m4717a()) {
                z = true;
            }
        }
        return z;
    }

    public AssetManager getAssets() {
        return this.f3136c.getAssets();
    }

    public Resources getResources() {
        return this.f3136c;
    }

    public Theme getTheme() {
        return this.f3137d == null ? super.getTheme() : this.f3137d;
    }

    public void setTheme(int i) {
        if (this.f3137d == null) {
            super.setTheme(i);
        } else {
            this.f3137d.applyStyle(i, true);
        }
    }
}
