package android.support.p031v7.widget;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.database.Observable;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.PointF;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.StateListDrawable;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.ClassLoaderCreator;
import android.os.Parcelable.Creator;
import android.os.SystemClock;
import android.support.p018v4.p024d.C0393a;
import android.support.p018v4.p027g.C0432k;
import android.support.p018v4.p028h.C0457a;
import android.support.p018v4.p028h.C0471b;
import android.support.p018v4.p028h.C0486i;
import android.support.p018v4.p028h.C0488k;
import android.support.p018v4.p028h.C0489l;
import android.support.p018v4.p028h.C0495r;
import android.support.p018v4.p028h.C0499s;
import android.support.p018v4.p028h.p029a.C0460a;
import android.support.p018v4.p028h.p029a.C0464c;
import android.support.p018v4.p028h.p029a.C0464c.C0465a;
import android.support.p018v4.p028h.p029a.C0464c.C0466b;
import android.support.p031v7.p037d.C0623a.C0624a;
import android.support.p031v7.p037d.C0623a.C0625b;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.view.FocusFinder;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewGroup.MarginLayoutParams;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityManager;
import android.view.animation.Interpolator;
import android.widget.EdgeEffect;
import android.widget.OverScroller;
import java.lang.ref.WeakReference;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/* renamed from: android.support.v7.widget.ay */
public class C0805ay extends ViewGroup implements C0488k {

    /* renamed from: L */
    static final Interpolator f2837L = new Interpolator() {
        public float getInterpolation(float f) {
            float f2 = f - 1.0f;
            return (f2 * f2 * f2 * f2 * f2) + 1.0f;
        }
    };

    /* renamed from: M */
    private static final int[] f2838M = {16843830};

    /* renamed from: N */
    private static final int[] f2839N = {16842987};

    /* renamed from: O */
    private static final boolean f2840O = (VERSION.SDK_INT <= 15);

    /* renamed from: P */
    private static final boolean f2841P = (VERSION.SDK_INT <= 15);

    /* renamed from: Q */
    private static final Class<?>[] f2842Q = {Context.class, AttributeSet.class, Integer.TYPE, Integer.TYPE};

    /* renamed from: a */
    static final boolean f2843a = (VERSION.SDK_INT == 18 || VERSION.SDK_INT == 19 || VERSION.SDK_INT == 20);

    /* renamed from: b */
    static final boolean f2844b = (VERSION.SDK_INT >= 23);

    /* renamed from: c */
    static final boolean f2845c = (VERSION.SDK_INT >= 16);

    /* renamed from: d */
    static final boolean f2846d = (VERSION.SDK_INT >= 21);

    /* renamed from: A */
    final C0845w f2847A;

    /* renamed from: B */
    C0782aq f2848B;

    /* renamed from: C */
    C0784a f2849C;

    /* renamed from: D */
    final C0843u f2850D;

    /* renamed from: E */
    boolean f2851E;

    /* renamed from: F */
    boolean f2852F;

    /* renamed from: G */
    boolean f2853G;

    /* renamed from: H */
    C0847az f2854H;

    /* renamed from: I */
    final int[] f2855I;

    /* renamed from: J */
    final int[] f2856J;

    /* renamed from: K */
    final List<C0846x> f2857K;

    /* renamed from: R */
    private final C0837r f2858R;

    /* renamed from: S */
    private C0838s f2859S;

    /* renamed from: T */
    private final Rect f2860T;

    /* renamed from: U */
    private final ArrayList<C0831m> f2861U;

    /* renamed from: V */
    private C0831m f2862V;

    /* renamed from: W */
    private int f2863W;

    /* renamed from: aA */
    private List<C0832n> f2864aA;

    /* renamed from: aB */
    private C0819b f2865aB;

    /* renamed from: aC */
    private C0815d f2866aC;

    /* renamed from: aD */
    private final int[] f2867aD;

    /* renamed from: aE */
    private C0489l f2868aE;

    /* renamed from: aF */
    private final int[] f2869aF;

    /* renamed from: aG */
    private final int[] f2870aG;

    /* renamed from: aH */
    private Runnable f2871aH;

    /* renamed from: aI */
    private final C0884b f2872aI;

    /* renamed from: aa */
    private boolean f2873aa;

    /* renamed from: ab */
    private int f2874ab;

    /* renamed from: ac */
    private final AccessibilityManager f2875ac;

    /* renamed from: ad */
    private List<C0829k> f2876ad;

    /* renamed from: ae */
    private int f2877ae;

    /* renamed from: af */
    private int f2878af;

    /* renamed from: ag */
    private C0816e f2879ag;

    /* renamed from: ah */
    private EdgeEffect f2880ah;

    /* renamed from: ai */
    private EdgeEffect f2881ai;

    /* renamed from: aj */
    private EdgeEffect f2882aj;

    /* renamed from: ak */
    private EdgeEffect f2883ak;

    /* renamed from: al */
    private int f2884al;

    /* renamed from: am */
    private int f2885am;

    /* renamed from: an */
    private VelocityTracker f2886an;

    /* renamed from: ao */
    private int f2887ao;

    /* renamed from: ap */
    private int f2888ap;

    /* renamed from: aq */
    private int f2889aq;

    /* renamed from: ar */
    private int f2890ar;

    /* renamed from: as */
    private int f2891as;

    /* renamed from: at */
    private C0830l f2892at;

    /* renamed from: au */
    private final int f2893au;

    /* renamed from: av */
    private final int f2894av;

    /* renamed from: aw */
    private float f2895aw;

    /* renamed from: ax */
    private float f2896ax;

    /* renamed from: ay */
    private boolean f2897ay;

    /* renamed from: az */
    private C0832n f2898az;

    /* renamed from: e */
    final C0835p f2899e;

    /* renamed from: f */
    C0901e f2900f;

    /* renamed from: g */
    C0752ah f2901g;

    /* renamed from: h */
    final C0882bu f2902h;

    /* renamed from: i */
    boolean f2903i;

    /* renamed from: j */
    final Runnable f2904j;

    /* renamed from: k */
    final Rect f2905k;

    /* renamed from: l */
    final RectF f2906l;

    /* renamed from: m */
    C0812a f2907m;

    /* renamed from: n */
    C0823i f2908n;

    /* renamed from: o */
    C0836q f2909o;

    /* renamed from: p */
    final ArrayList<C0822h> f2910p;

    /* renamed from: q */
    boolean f2911q;

    /* renamed from: r */
    boolean f2912r;

    /* renamed from: s */
    boolean f2913s;

    /* renamed from: t */
    boolean f2914t;

    /* renamed from: u */
    boolean f2915u;

    /* renamed from: v */
    boolean f2916v;

    /* renamed from: w */
    boolean f2917w;

    /* renamed from: x */
    boolean f2918x;

    /* renamed from: y */
    boolean f2919y;

    /* renamed from: z */
    C0817f f2920z;

    /* renamed from: android.support.v7.widget.ay$a */
    public static abstract class C0812a<VH extends C0846x> {

        /* renamed from: a */
        private final C0813b f2926a;

        /* renamed from: b */
        private boolean f2927b;

        /* renamed from: a */
        public abstract int mo4007a();

        /* renamed from: a */
        public int mo4008a(int i) {
            return 0;
        }

        /* renamed from: a */
        public abstract VH mo4009a(ViewGroup viewGroup, int i);

        /* renamed from: a */
        public void mo4010a(C0814c cVar) {
            this.f2926a.registerObserver(cVar);
        }

        /* renamed from: a */
        public void mo4011a(VH vh) {
        }

        /* renamed from: a */
        public abstract void mo4012a(VH vh, int i);

        /* renamed from: a */
        public void mo4013a(VH vh, int i, List<Object> list) {
            mo4012a(vh, i);
        }

        /* renamed from: a */
        public void mo4014a(C0805ay ayVar) {
        }

        /* renamed from: b */
        public long mo4015b(int i) {
            return -1;
        }

        /* renamed from: b */
        public final VH mo4016b(ViewGroup viewGroup, int i) {
            try {
                C0393a.m1731a("RV CreateView");
                VH a = mo4009a(viewGroup, i);
                if (a.f3023a.getParent() != null) {
                    throw new IllegalStateException("ViewHolder views must not be attached when created. Ensure that you are not passing 'true' to the attachToRoot parameter of LayoutInflater.inflate(..., boolean attachToRoot)");
                }
                a.f3028f = i;
                return a;
            } finally {
                C0393a.m1730a();
            }
        }

        /* renamed from: b */
        public void mo4017b(C0814c cVar) {
            this.f2926a.unregisterObserver(cVar);
        }

        /* renamed from: b */
        public final void mo4018b(VH vh, int i) {
            vh.f3025c = i;
            if (mo4020b()) {
                vh.f3027e = mo4015b(i);
            }
            vh.mo4240a(1, 519);
            C0393a.m1731a("RV OnBindView");
            mo4013a(vh, i, vh.mo4270u());
            vh.mo4268t();
            LayoutParams layoutParams = vh.f3023a.getLayoutParams();
            if (layoutParams instanceof C0828j) {
                ((C0828j) layoutParams).f2965e = true;
            }
            C0393a.m1730a();
        }

        /* renamed from: b */
        public void mo4019b(C0805ay ayVar) {
        }

        /* renamed from: b */
        public final boolean mo4020b() {
            return this.f2927b;
        }

        /* renamed from: b */
        public boolean mo4021b(VH vh) {
            return false;
        }

        /* renamed from: c */
        public void mo4022c(VH vh) {
        }

        /* renamed from: d */
        public void mo4023d(VH vh) {
        }
    }

    /* renamed from: android.support.v7.widget.ay$b */
    static class C0813b extends Observable<C0814c> {
    }

    /* renamed from: android.support.v7.widget.ay$c */
    public static abstract class C0814c {
    }

    /* renamed from: android.support.v7.widget.ay$d */
    public interface C0815d {
        /* renamed from: a */
        int mo4024a(int i, int i2);
    }

    /* renamed from: android.support.v7.widget.ay$e */
    public static class C0816e {
        /* access modifiers changed from: protected */
        /* renamed from: a */
        public EdgeEffect mo4025a(C0805ay ayVar, int i) {
            return new EdgeEffect(ayVar.getContext());
        }
    }

    /* renamed from: android.support.v7.widget.ay$f */
    public static abstract class C0817f {

        /* renamed from: a */
        private C0819b f2928a = null;

        /* renamed from: b */
        private ArrayList<C0818a> f2929b = new ArrayList<>();

        /* renamed from: c */
        private long f2930c = 120;

        /* renamed from: d */
        private long f2931d = 120;

        /* renamed from: e */
        private long f2932e = 250;

        /* renamed from: f */
        private long f2933f = 250;

        /* renamed from: android.support.v7.widget.ay$f$a */
        public interface C0818a {
            /* renamed from: a */
            void mo4042a();
        }

        /* renamed from: android.support.v7.widget.ay$f$b */
        interface C0819b {
            /* renamed from: a */
            void mo4043a(C0846x xVar);
        }

        /* renamed from: android.support.v7.widget.ay$f$c */
        public static class C0820c {

            /* renamed from: a */
            public int f2934a;

            /* renamed from: b */
            public int f2935b;

            /* renamed from: c */
            public int f2936c;

            /* renamed from: d */
            public int f2937d;

            /* renamed from: a */
            public C0820c mo4044a(C0846x xVar) {
                return mo4045a(xVar, 0);
            }

            /* renamed from: a */
            public C0820c mo4045a(C0846x xVar, int i) {
                View view = xVar.f3023a;
                this.f2934a = view.getLeft();
                this.f2935b = view.getTop();
                this.f2936c = view.getRight();
                this.f2937d = view.getBottom();
                return this;
            }
        }

        /* renamed from: e */
        static int m4198e(C0846x xVar) {
            int i = xVar.f3032j & 14;
            if (xVar.mo4262n()) {
                return 4;
            }
            if ((i & 4) == 0) {
                int f = xVar.mo4254f();
                int e = xVar.mo4253e();
                if (!(f == -1 || e == -1 || f == e)) {
                    i |= 2048;
                }
            }
            return i;
        }

        /* renamed from: a */
        public C0820c mo4026a(C0843u uVar, C0846x xVar) {
            return mo4041j().mo4044a(xVar);
        }

        /* renamed from: a */
        public C0820c mo4027a(C0843u uVar, C0846x xVar, int i, List<Object> list) {
            return mo4041j().mo4044a(xVar);
        }

        /* renamed from: a */
        public abstract void mo3642a();

        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public void mo4028a(C0819b bVar) {
            this.f2928a = bVar;
        }

        /* renamed from: a */
        public abstract boolean mo4029a(C0846x xVar, C0820c cVar, C0820c cVar2);

        /* renamed from: a */
        public abstract boolean mo4030a(C0846x xVar, C0846x xVar2, C0820c cVar, C0820c cVar2);

        /* renamed from: a */
        public boolean mo3648a(C0846x xVar, List<Object> list) {
            return mo4039h(xVar);
        }

        /* renamed from: b */
        public abstract boolean mo3650b();

        /* renamed from: b */
        public abstract boolean mo4031b(C0846x xVar, C0820c cVar, C0820c cVar2);

        /* renamed from: c */
        public abstract boolean mo4032c(C0846x xVar, C0820c cVar, C0820c cVar2);

        /* renamed from: d */
        public abstract void mo3654d();

        /* renamed from: d */
        public abstract void mo3655d(C0846x xVar);

        /* renamed from: e */
        public long mo4033e() {
            return this.f2932e;
        }

        /* renamed from: f */
        public long mo4034f() {
            return this.f2930c;
        }

        /* renamed from: f */
        public final void mo4035f(C0846x xVar) {
            mo4037g(xVar);
            if (this.f2928a != null) {
                this.f2928a.mo4043a(xVar);
            }
        }

        /* renamed from: g */
        public long mo4036g() {
            return this.f2931d;
        }

        /* renamed from: g */
        public void mo4037g(C0846x xVar) {
        }

        /* renamed from: h */
        public long mo4038h() {
            return this.f2933f;
        }

        /* renamed from: h */
        public boolean mo4039h(C0846x xVar) {
            return true;
        }

        /* renamed from: i */
        public final void mo4040i() {
            int size = this.f2929b.size();
            for (int i = 0; i < size; i++) {
                ((C0818a) this.f2929b.get(i)).mo4042a();
            }
            this.f2929b.clear();
        }

        /* renamed from: j */
        public C0820c mo4041j() {
            return new C0820c();
        }
    }

    /* renamed from: android.support.v7.widget.ay$g */
    private class C0821g implements C0819b {
        C0821g() {
        }

        /* renamed from: a */
        public void mo4043a(C0846x xVar) {
            xVar.mo4246a(true);
            if (xVar.f3030h != null && xVar.f3031i == null) {
                xVar.f3030h = null;
            }
            xVar.f3031i = null;
            if (!xVar.mo4273x() && !C0805ay.this.mo3855a(xVar.f3023a) && xVar.mo4266r()) {
                C0805ay.this.removeDetachedView(xVar.f3023a, false);
            }
        }
    }

    /* renamed from: android.support.v7.widget.ay$h */
    public static abstract class C0822h {
        @Deprecated
        /* renamed from: a */
        public void mo4046a(Canvas canvas, C0805ay ayVar) {
        }

        /* renamed from: a */
        public void mo3692a(Canvas canvas, C0805ay ayVar, C0843u uVar) {
            mo4049b(canvas, ayVar);
        }

        @Deprecated
        /* renamed from: a */
        public void mo4047a(Rect rect, int i, C0805ay ayVar) {
            rect.set(0, 0, 0, 0);
        }

        /* renamed from: a */
        public void mo4048a(Rect rect, View view, C0805ay ayVar, C0843u uVar) {
            mo4047a(rect, ((C0828j) view.getLayoutParams()).mo4147f(), ayVar);
        }

        @Deprecated
        /* renamed from: b */
        public void mo4049b(Canvas canvas, C0805ay ayVar) {
        }

        /* renamed from: b */
        public void mo4050b(Canvas canvas, C0805ay ayVar, C0843u uVar) {
            mo4046a(canvas, ayVar);
        }
    }

    /* renamed from: android.support.v7.widget.ay$i */
    public static abstract class C0823i {

        /* renamed from: a */
        private final C0881b f2939a = new C0881b() {
            /* renamed from: a */
            public int mo4139a() {
                return C0823i.this.mo4051A();
            }

            /* renamed from: a */
            public int mo4140a(View view) {
                return C0823i.this.mo4117h(view) - ((C0828j) view.getLayoutParams()).leftMargin;
            }

            /* renamed from: a */
            public View mo4141a(int i) {
                return C0823i.this.mo4120i(i);
            }

            /* renamed from: b */
            public int mo4142b() {
                return C0823i.this.mo4137y() - C0823i.this.mo4053C();
            }

            /* renamed from: b */
            public int mo4143b(View view) {
                return C0823i.this.mo4121j(view) + ((C0828j) view.getLayoutParams()).rightMargin;
            }
        };

        /* renamed from: b */
        private final C0881b f2940b = new C0881b() {
            /* renamed from: a */
            public int mo4139a() {
                return C0823i.this.mo4052B();
            }

            /* renamed from: a */
            public int mo4140a(View view) {
                return C0823i.this.mo4119i(view) - ((C0828j) view.getLayoutParams()).topMargin;
            }

            /* renamed from: a */
            public View mo4141a(int i) {
                return C0823i.this.mo4120i(i);
            }

            /* renamed from: b */
            public int mo4142b() {
                return C0823i.this.mo4138z() - C0823i.this.mo4054D();
            }

            /* renamed from: b */
            public int mo4143b(View view) {
                return C0823i.this.mo4122k(view) + ((C0828j) view.getLayoutParams()).bottomMargin;
            }
        };

        /* renamed from: c */
        private boolean f2941c = true;

        /* renamed from: d */
        private boolean f2942d = true;

        /* renamed from: e */
        private int f2943e;

        /* renamed from: f */
        private int f2944f;

        /* renamed from: g */
        private int f2945g;

        /* renamed from: h */
        private int f2946h;

        /* renamed from: p */
        C0752ah f2947p;

        /* renamed from: q */
        C0805ay f2948q;

        /* renamed from: r */
        C0879bt f2949r = new C0879bt(this.f2939a);

        /* renamed from: s */
        C0879bt f2950s = new C0879bt(this.f2940b);

        /* renamed from: t */
        C0840t f2951t;

        /* renamed from: u */
        boolean f2952u = false;

        /* renamed from: v */
        boolean f2953v = false;

        /* renamed from: w */
        boolean f2954w = false;

        /* renamed from: x */
        int f2955x;

        /* renamed from: y */
        boolean f2956y;

        /* renamed from: android.support.v7.widget.ay$i$a */
        public interface C0826a {
            /* renamed from: b */
            void mo3724b(int i, int i2);
        }

        /* renamed from: android.support.v7.widget.ay$i$b */
        public static class C0827b {

            /* renamed from: a */
            public int f2959a;

            /* renamed from: b */
            public int f2960b;

            /* renamed from: c */
            public boolean f2961c;

            /* renamed from: d */
            public boolean f2962d;
        }

        /* renamed from: a */
        public static int m4231a(int i, int i2, int i3) {
            int mode = MeasureSpec.getMode(i);
            int size = MeasureSpec.getSize(i);
            if (mode == Integer.MIN_VALUE) {
                return Math.min(size, Math.max(i2, i3));
            }
            if (mode != 1073741824) {
                size = Math.max(i2, i3);
            }
            return size;
        }

        /* renamed from: a */
        public static int m4232a(int i, int i2, int i3, int i4, boolean z) {
            int i5;
            int i6 = i - i3;
            int i7 = 0;
            int max = Math.max(0, i6);
            if (z) {
                if (i4 < 0) {
                    if (i4 == -1) {
                        if (i2 == Integer.MIN_VALUE || (i2 != 0 && i2 == 1073741824)) {
                            i5 = max;
                        } else {
                            i2 = 0;
                            i5 = 0;
                        }
                        i7 = i2;
                        max = i5;
                        return MeasureSpec.makeMeasureSpec(max, i7);
                    }
                    max = 0;
                    return MeasureSpec.makeMeasureSpec(max, i7);
                }
            } else if (i4 < 0) {
                if (i4 == -1) {
                    i7 = i2;
                } else {
                    if (i4 == -2) {
                        if (i2 == Integer.MIN_VALUE || i2 == 1073741824) {
                            i7 = Integer.MIN_VALUE;
                        }
                    }
                    max = 0;
                }
                return MeasureSpec.makeMeasureSpec(max, i7);
            }
            max = i4;
            i7 = 1073741824;
            return MeasureSpec.makeMeasureSpec(max, i7);
        }

        /* renamed from: a */
        public static C0827b m4233a(Context context, AttributeSet attributeSet, int i, int i2) {
            C0827b bVar = new C0827b();
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, C0625b.RecyclerView, i, i2);
            bVar.f2959a = obtainStyledAttributes.getInt(C0625b.RecyclerView_android_orientation, 1);
            bVar.f2960b = obtainStyledAttributes.getInt(C0625b.RecyclerView_spanCount, 1);
            bVar.f2961c = obtainStyledAttributes.getBoolean(C0625b.RecyclerView_reverseLayout, false);
            bVar.f2962d = obtainStyledAttributes.getBoolean(C0625b.RecyclerView_stackFromEnd, false);
            obtainStyledAttributes.recycle();
            return bVar;
        }

        /* renamed from: a */
        private void m4234a(int i, View view) {
            this.f2947p.mo3589e(i);
        }

        /* renamed from: a */
        private void m4235a(C0835p pVar, int i, View view) {
            C0846x e = C0805ay.m4066e(view);
            if (!e.mo4251c()) {
                if (!e.mo4262n() || e.mo4265q() || this.f2948q.f2907m.mo4020b()) {
                    mo4118h(i);
                    pVar.mo4186c(view);
                    this.f2948q.f2902h.mo4485h(e);
                    return;
                }
                mo4116g(i);
                pVar.mo4180b(e);
            }
        }

        /* renamed from: a */
        private void m4236a(View view, int i, boolean z) {
            C0846x e = C0805ay.m4066e(view);
            if (z || e.mo4265q()) {
                this.f2948q.f2902h.mo4482e(e);
            } else {
                this.f2948q.f2902h.mo4483f(e);
            }
            C0828j jVar = (C0828j) view.getLayoutParams();
            if (e.mo4259k() || e.mo4257i()) {
                if (e.mo4257i()) {
                    e.mo4258j();
                } else {
                    e.mo4260l();
                }
                this.f2947p.mo3578a(view, i, view.getLayoutParams(), false);
            } else if (view.getParent() == this.f2948q) {
                int b = this.f2947p.mo3582b(view);
                if (i == -1) {
                    i = this.f2947p.mo3581b();
                }
                if (b == -1) {
                    StringBuilder sb = new StringBuilder();
                    sb.append("Added View has RecyclerView as parent but view is not a real child. Unfiltered index:");
                    sb.append(this.f2948q.indexOfChild(view));
                    sb.append(this.f2948q.mo3835a());
                    throw new IllegalStateException(sb.toString());
                } else if (b != i) {
                    this.f2948q.f2908n.mo4109e(b, i);
                }
            } else {
                this.f2947p.mo3579a(view, i, false);
                jVar.f2965e = true;
                if (this.f2951t != null && this.f2951t.mo4216d()) {
                    this.f2951t.mo4214b(view);
                }
            }
            if (jVar.f2966f) {
                e.f3023a.invalidate();
                jVar.f2966f = false;
            }
        }

        /* renamed from: b */
        private static boolean m4237b(int i, int i2, int i3) {
            int mode = MeasureSpec.getMode(i2);
            int size = MeasureSpec.getSize(i2);
            boolean z = false;
            if (i3 > 0 && i != i3) {
                return false;
            }
            if (mode == Integer.MIN_VALUE) {
                if (size >= i) {
                    z = true;
                }
                return z;
            } else if (mode == 0) {
                return true;
            } else {
                if (mode != 1073741824) {
                    return false;
                }
                if (size == i) {
                    z = true;
                }
                return z;
            }
        }

        /* renamed from: b */
        private int[] m4238b(C0805ay ayVar, View view, Rect rect, boolean z) {
            int[] iArr = new int[2];
            int A = mo4051A();
            int B = mo4052B();
            int y = mo4137y() - mo4053C();
            int z2 = mo4138z() - mo4054D();
            int left = (view.getLeft() + rect.left) - view.getScrollX();
            int top = (view.getTop() + rect.top) - view.getScrollY();
            int width = rect.width() + left;
            int height = rect.height() + top;
            int i = left - A;
            int min = Math.min(0, i);
            int i2 = top - B;
            int min2 = Math.min(0, i2);
            int i3 = width - y;
            int max = Math.max(0, i3);
            int max2 = Math.max(0, height - z2);
            if (mo4132t() != 1) {
                if (min == 0) {
                    min = Math.min(i, max);
                }
                max = min;
            } else if (max == 0) {
                max = Math.max(min, i3);
            }
            if (min2 == 0) {
                min2 = Math.min(i2, max2);
            }
            iArr[0] = max;
            iArr[1] = min2;
            return iArr;
        }

        /* renamed from: d */
        private boolean m4239d(C0805ay ayVar, int i, int i2) {
            View focusedChild = ayVar.getFocusedChild();
            if (focusedChild == null) {
                return false;
            }
            int A = mo4051A();
            int B = mo4052B();
            int y = mo4137y() - mo4053C();
            int z = mo4138z() - mo4054D();
            Rect rect = this.f2948q.f2905k;
            mo4074a(focusedChild, rect);
            return rect.left - i < y && rect.right - i > A && rect.top - i2 < z && rect.bottom - i2 > B;
        }

        /* renamed from: A */
        public int mo4051A() {
            if (this.f2948q != null) {
                return this.f2948q.getPaddingLeft();
            }
            return 0;
        }

        /* renamed from: B */
        public int mo4052B() {
            if (this.f2948q != null) {
                return this.f2948q.getPaddingTop();
            }
            return 0;
        }

        /* renamed from: C */
        public int mo4053C() {
            if (this.f2948q != null) {
                return this.f2948q.getPaddingRight();
            }
            return 0;
        }

        /* renamed from: D */
        public int mo4054D() {
            if (this.f2948q != null) {
                return this.f2948q.getPaddingBottom();
            }
            return 0;
        }

        /* renamed from: E */
        public View mo4055E() {
            if (this.f2948q == null) {
                return null;
            }
            View focusedChild = this.f2948q.getFocusedChild();
            if (focusedChild == null || this.f2947p.mo3586c(focusedChild)) {
                return null;
            }
            return focusedChild;
        }

        /* renamed from: F */
        public int mo4056F() {
            return C0495r.m2154i(this.f2948q);
        }

        /* renamed from: G */
        public int mo4057G() {
            return C0495r.m2155j(this.f2948q);
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: H */
        public void mo4058H() {
            if (this.f2951t != null) {
                this.f2951t.mo4213b();
            }
        }

        /* renamed from: I */
        public void mo4059I() {
            this.f2952u = true;
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: J */
        public boolean mo4060J() {
            int v = mo4134v();
            for (int i = 0; i < v; i++) {
                LayoutParams layoutParams = mo4120i(i).getLayoutParams();
                if (layoutParams.width < 0 && layoutParams.height < 0) {
                    return true;
                }
            }
            return false;
        }

        /* renamed from: a */
        public int mo3158a(int i, C0835p pVar, C0843u uVar) {
            return 0;
        }

        /* renamed from: a */
        public int mo3159a(C0835p pVar, C0843u uVar) {
            int i = 1;
            if (this.f2948q != null) {
                if (this.f2948q.f2907m == null) {
                    return 1;
                }
                if (mo3215f()) {
                    i = this.f2948q.f2907m.mo4007a();
                }
            }
            return i;
        }

        /* renamed from: a */
        public abstract C0828j mo3160a();

        /* renamed from: a */
        public C0828j mo3161a(Context context, AttributeSet attributeSet) {
            return new C0828j(context, attributeSet);
        }

        /* renamed from: a */
        public C0828j mo3162a(LayoutParams layoutParams) {
            return layoutParams instanceof C0828j ? new C0828j((C0828j) layoutParams) : layoutParams instanceof MarginLayoutParams ? new C0828j((MarginLayoutParams) layoutParams) : new C0828j(layoutParams);
        }

        /* renamed from: a */
        public View mo3164a(View view, int i, C0835p pVar, C0843u uVar) {
            return null;
        }

        /* renamed from: a */
        public void mo3193a(int i, int i2, C0843u uVar, C0826a aVar) {
        }

        /* renamed from: a */
        public void mo3194a(int i, C0826a aVar) {
        }

        /* renamed from: a */
        public void mo4061a(int i, C0835p pVar) {
            View i2 = mo4120i(i);
            mo4116g(i);
            pVar.mo4174a(i2);
        }

        /* renamed from: a */
        public void mo3166a(Rect rect, int i, int i2) {
            mo4113f(m4231a(i, rect.width() + mo4051A() + mo4053C(), mo4056F()), m4231a(i2, rect.height() + mo4052B() + mo4054D(), mo4057G()));
        }

        /* renamed from: a */
        public void mo3195a(Parcelable parcelable) {
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public void mo4062a(C0464c cVar) {
            mo4066a(this.f2948q.f2899e, this.f2948q.f2850D, cVar);
        }

        /* renamed from: a */
        public void mo4063a(C0812a aVar, C0812a aVar2) {
        }

        /* renamed from: a */
        public void mo4064a(C0835p pVar) {
            for (int v = mo4134v() - 1; v >= 0; v--) {
                m4235a(pVar, v, mo4120i(v));
            }
        }

        /* renamed from: a */
        public void mo4065a(C0835p pVar, C0843u uVar, int i, int i2) {
            this.f2948q.mo3895e(i, i2);
        }

        /* renamed from: a */
        public void mo4066a(C0835p pVar, C0843u uVar, C0464c cVar) {
            if (this.f2948q.canScrollVertically(-1) || this.f2948q.canScrollHorizontally(-1)) {
                cVar.mo1857a(8192);
                cVar.mo1866c(true);
            }
            if (this.f2948q.canScrollVertically(1) || this.f2948q.canScrollHorizontally(1)) {
                cVar.mo1857a(4096);
                cVar.mo1866c(true);
            }
            cVar.mo1860a((Object) C0465a.m2038a(mo3159a(pVar, uVar), mo3179b(pVar, uVar), mo4111e(pVar, uVar), mo4103d(pVar, uVar)));
        }

        /* renamed from: a */
        public void mo3169a(C0835p pVar, C0843u uVar, View view, C0464c cVar) {
            int i = 0;
            int d = mo3215f() ? mo4104d(view) : 0;
            if (mo3212e()) {
                i = mo4104d(view);
            }
            cVar.mo1864b((Object) C0466b.m2039a(d, 1, i, 1, false, false));
        }

        /* renamed from: a */
        public void mo4067a(C0835p pVar, C0843u uVar, AccessibilityEvent accessibilityEvent) {
            if (this.f2948q != null && accessibilityEvent != null) {
                boolean z = true;
                if (!this.f2948q.canScrollVertically(1) && !this.f2948q.canScrollVertically(-1) && !this.f2948q.canScrollHorizontally(-1) && !this.f2948q.canScrollHorizontally(1)) {
                    z = false;
                }
                accessibilityEvent.setScrollable(z);
                if (this.f2948q.f2907m != null) {
                    accessibilityEvent.setItemCount(this.f2948q.f2907m.mo4007a());
                }
            }
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public void mo4068a(C0840t tVar) {
            if (this.f2951t == tVar) {
                this.f2951t = null;
            }
        }

        /* renamed from: a */
        public void mo3170a(C0843u uVar) {
        }

        /* renamed from: a */
        public void mo3172a(C0805ay ayVar) {
        }

        /* renamed from: a */
        public void mo3173a(C0805ay ayVar, int i, int i2) {
        }

        /* renamed from: a */
        public void mo3174a(C0805ay ayVar, int i, int i2, int i3) {
        }

        /* renamed from: a */
        public void mo3175a(C0805ay ayVar, int i, int i2, Object obj) {
            mo4100c(ayVar, i, i2);
        }

        /* renamed from: a */
        public void mo3196a(C0805ay ayVar, C0835p pVar) {
            mo4110e(ayVar);
        }

        /* renamed from: a */
        public void mo4069a(View view) {
            mo4070a(view, -1);
        }

        /* renamed from: a */
        public void mo4070a(View view, int i) {
            m4236a(view, i, true);
        }

        /* renamed from: a */
        public void mo4071a(View view, int i, int i2) {
            C0828j jVar = (C0828j) view.getLayoutParams();
            Rect i3 = this.f2948q.mo3929i(view);
            int i4 = i2 + i3.top + i3.bottom;
            int a = m4232a(mo4137y(), mo4135w(), mo4051A() + mo4053C() + jVar.leftMargin + jVar.rightMargin + i + i3.left + i3.right, jVar.width, mo3212e());
            int a2 = m4232a(mo4138z(), mo4136x(), mo4052B() + mo4054D() + jVar.topMargin + jVar.bottomMargin + i4, jVar.height, mo3215f());
            if (mo4096b(view, a, a2, jVar)) {
                view.measure(a, a2);
            }
        }

        /* renamed from: a */
        public void mo4072a(View view, int i, int i2, int i3, int i4) {
            C0828j jVar = (C0828j) view.getLayoutParams();
            Rect rect = jVar.f2964d;
            view.layout(i + rect.left + jVar.leftMargin, i2 + rect.top + jVar.topMargin, (i3 - rect.right) - jVar.rightMargin, (i4 - rect.bottom) - jVar.bottomMargin);
        }

        /* renamed from: a */
        public void mo4073a(View view, int i, C0828j jVar) {
            C0846x e = C0805ay.m4066e(view);
            if (e.mo4265q()) {
                this.f2948q.f2902h.mo4482e(e);
            } else {
                this.f2948q.f2902h.mo4483f(e);
            }
            this.f2947p.mo3578a(view, i, jVar, e.mo4265q());
        }

        /* renamed from: a */
        public void mo4074a(View view, Rect rect) {
            C0805ay.m4057a(view, rect);
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public void mo4075a(View view, C0464c cVar) {
            C0846x e = C0805ay.m4066e(view);
            if (e != null && !e.mo4265q() && !this.f2947p.mo3586c(e.f3023a)) {
                mo3169a(this.f2948q.f2899e, this.f2948q.f2850D, view, cVar);
            }
        }

        /* renamed from: a */
        public void mo4076a(View view, C0835p pVar) {
            mo4101c(view);
            pVar.mo4174a(view);
        }

        /* renamed from: a */
        public void mo4077a(View view, boolean z, Rect rect) {
            if (z) {
                Rect rect2 = ((C0828j) view.getLayoutParams()).f2964d;
                rect.set(-rect2.left, -rect2.top, view.getWidth() + rect2.right, view.getHeight() + rect2.bottom);
            } else {
                rect.set(0, 0, view.getWidth(), view.getHeight());
            }
            if (this.f2948q != null) {
                Matrix matrix = view.getMatrix();
                if (matrix != null && !matrix.isIdentity()) {
                    RectF rectF = this.f2948q.f2906l;
                    rectF.set(rect);
                    matrix.mapRect(rectF);
                    rect.set((int) Math.floor((double) rectF.left), (int) Math.floor((double) rectF.top), (int) Math.ceil((double) rectF.right), (int) Math.ceil((double) rectF.bottom));
                }
            }
            rect.offset(view.getLeft(), view.getTop());
        }

        /* renamed from: a */
        public void mo3197a(AccessibilityEvent accessibilityEvent) {
            mo4067a(this.f2948q.f2899e, this.f2948q.f2850D, accessibilityEvent);
        }

        /* renamed from: a */
        public void mo3198a(String str) {
            if (this.f2948q != null) {
                this.f2948q.mo3849a(str);
            }
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public boolean mo4078a(int i, Bundle bundle) {
            return mo4079a(this.f2948q.f2899e, this.f2948q.f2850D, i, bundle);
        }

        /* renamed from: a */
        public boolean mo3177a(C0828j jVar) {
            return jVar != null;
        }

        /* JADX WARNING: Removed duplicated region for block: B:24:0x0076 A[ADDED_TO_REGION] */
        /* renamed from: a */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public boolean mo4079a(android.support.p031v7.widget.C0805ay.C0835p r2, android.support.p031v7.widget.C0805ay.C0843u r3, int r4, android.os.Bundle r5) {
            /*
                r1 = this;
                android.support.v7.widget.ay r2 = r1.f2948q
                r3 = 0
                if (r2 != 0) goto L_0x0006
                return r3
            L_0x0006:
                r2 = 4096(0x1000, float:5.74E-42)
                r5 = 1
                if (r4 == r2) goto L_0x0044
                r2 = 8192(0x2000, float:1.14794E-41)
                if (r4 == r2) goto L_0x0012
                r2 = r3
                r4 = r2
                goto L_0x0074
            L_0x0012:
                android.support.v7.widget.ay r2 = r1.f2948q
                r4 = -1
                boolean r2 = r2.canScrollVertically(r4)
                if (r2 == 0) goto L_0x002b
                int r2 = r1.mo4138z()
                int r0 = r1.mo4052B()
                int r2 = r2 - r0
                int r0 = r1.mo4054D()
                int r2 = r2 - r0
                int r2 = -r2
                goto L_0x002c
            L_0x002b:
                r2 = r3
            L_0x002c:
                android.support.v7.widget.ay r0 = r1.f2948q
                boolean r4 = r0.canScrollHorizontally(r4)
                if (r4 == 0) goto L_0x0073
                int r4 = r1.mo4137y()
                int r0 = r1.mo4051A()
                int r4 = r4 - r0
                int r0 = r1.mo4053C()
                int r4 = r4 - r0
                int r4 = -r4
                goto L_0x0074
            L_0x0044:
                android.support.v7.widget.ay r2 = r1.f2948q
                boolean r2 = r2.canScrollVertically(r5)
                if (r2 == 0) goto L_0x005b
                int r2 = r1.mo4138z()
                int r4 = r1.mo4052B()
                int r2 = r2 - r4
                int r4 = r1.mo4054D()
                int r2 = r2 - r4
                goto L_0x005c
            L_0x005b:
                r2 = r3
            L_0x005c:
                android.support.v7.widget.ay r4 = r1.f2948q
                boolean r4 = r4.canScrollHorizontally(r5)
                if (r4 == 0) goto L_0x0073
                int r4 = r1.mo4137y()
                int r0 = r1.mo4051A()
                int r4 = r4 - r0
                int r0 = r1.mo4053C()
                int r4 = r4 - r0
                goto L_0x0074
            L_0x0073:
                r4 = r3
            L_0x0074:
                if (r2 != 0) goto L_0x0079
                if (r4 != 0) goto L_0x0079
                return r3
            L_0x0079:
                android.support.v7.widget.ay r3 = r1.f2948q
                r3.mo3836a(r4, r2)
                return r5
            */
            throw new UnsupportedOperationException("Method not decompiled: android.support.p031v7.widget.C0805ay.C0823i.mo4079a(android.support.v7.widget.ay$p, android.support.v7.widget.ay$u, int, android.os.Bundle):boolean");
        }

        /* renamed from: a */
        public boolean mo4080a(C0835p pVar, C0843u uVar, View view, int i, Bundle bundle) {
            return false;
        }

        /* renamed from: a */
        public boolean mo4081a(C0805ay ayVar, C0843u uVar, View view, View view2) {
            return mo4084a(ayVar, view, view2);
        }

        /* renamed from: a */
        public boolean mo4082a(C0805ay ayVar, View view, Rect rect, boolean z) {
            return mo4083a(ayVar, view, rect, z, false);
        }

        /* renamed from: a */
        public boolean mo4083a(C0805ay ayVar, View view, Rect rect, boolean z, boolean z2) {
            int[] b = m4238b(ayVar, view, rect, z);
            int i = b[0];
            int i2 = b[1];
            if ((z2 && !m4239d(ayVar, i, i2)) || (i == 0 && i2 == 0)) {
                return false;
            }
            if (z) {
                ayVar.scrollBy(i, i2);
                return true;
            }
            ayVar.mo3836a(i, i2);
            return true;
        }

        @Deprecated
        /* renamed from: a */
        public boolean mo4084a(C0805ay ayVar, View view, View view2) {
            return mo4131s() || ayVar.mo3941o();
        }

        /* renamed from: a */
        public boolean mo4085a(C0805ay ayVar, ArrayList<View> arrayList, int i, int i2) {
            return false;
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public boolean mo4086a(View view, int i, int i2, C0828j jVar) {
            return !this.f2941c || !m4237b(view.getMeasuredWidth(), i, jVar.width) || !m4237b(view.getMeasuredHeight(), i2, jVar.height);
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public boolean mo4087a(View view, int i, Bundle bundle) {
            return mo4080a(this.f2948q.f2899e, this.f2948q.f2850D, view, i, bundle);
        }

        /* renamed from: a */
        public boolean mo4088a(View view, boolean z, boolean z2) {
            boolean z3 = this.f2949r.mo4464a(view, 24579) && this.f2950s.mo4464a(view, 24579);
            return z ? z3 : !z3;
        }

        /* renamed from: a */
        public boolean mo4089a(Runnable runnable) {
            if (this.f2948q != null) {
                return this.f2948q.removeCallbacks(runnable);
            }
            return false;
        }

        /* renamed from: b */
        public int mo3178b(int i, C0835p pVar, C0843u uVar) {
            return 0;
        }

        /* renamed from: b */
        public int mo3179b(C0835p pVar, C0843u uVar) {
            int i = 1;
            if (this.f2948q != null) {
                if (this.f2948q.f2907m == null) {
                    return 1;
                }
                if (mo3212e()) {
                    i = this.f2948q.f2907m.mo4007a();
                }
            }
            return i;
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: b */
        public void mo4090b(C0835p pVar) {
            int e = pVar.mo4190e();
            for (int i = e - 1; i >= 0; i--) {
                View e2 = pVar.mo4191e(i);
                C0846x e3 = C0805ay.m4066e(e2);
                if (!e3.mo4251c()) {
                    e3.mo4246a(false);
                    if (e3.mo4266r()) {
                        this.f2948q.removeDetachedView(e2, false);
                    }
                    if (this.f2948q.f2920z != null) {
                        this.f2948q.f2920z.mo3655d(e3);
                    }
                    e3.mo4246a(true);
                    pVar.mo4181b(e2);
                }
            }
            pVar.mo4193f();
            if (e > 0) {
                this.f2948q.invalidate();
            }
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: b */
        public void mo4091b(C0805ay ayVar) {
            int height;
            if (ayVar == null) {
                this.f2948q = null;
                this.f2947p = null;
                height = 0;
                this.f2945g = 0;
            } else {
                this.f2948q = ayVar;
                this.f2947p = ayVar.f2901g;
                this.f2945g = ayVar.getWidth();
                height = ayVar.getHeight();
            }
            this.f2946h = height;
            this.f2943e = 1073741824;
            this.f2944f = 1073741824;
        }

        /* renamed from: b */
        public void mo3180b(C0805ay ayVar, int i, int i2) {
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: b */
        public void mo4092b(C0805ay ayVar, C0835p pVar) {
            this.f2953v = false;
            mo3196a(ayVar, pVar);
        }

        /* renamed from: b */
        public void mo4093b(View view) {
            mo4094b(view, -1);
        }

        /* renamed from: b */
        public void mo4094b(View view, int i) {
            m4236a(view, i, false);
        }

        /* renamed from: b */
        public void mo4095b(View view, Rect rect) {
            if (this.f2948q == null) {
                rect.set(0, 0, 0, 0);
            } else {
                rect.set(this.f2948q.mo3929i(view));
            }
        }

        /* renamed from: b */
        public boolean mo3181b() {
            return false;
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: b */
        public boolean mo4096b(View view, int i, int i2, C0828j jVar) {
            return view.isLayoutRequested() || !this.f2941c || !m4237b(view.getWidth(), i, jVar.width) || !m4237b(view.getHeight(), i2, jVar.height);
        }

        /* renamed from: c */
        public int mo3204c(C0843u uVar) {
            return 0;
        }

        /* renamed from: c */
        public View mo3205c(int i) {
            int v = mo4134v();
            for (int i2 = 0; i2 < v; i2++) {
                View i3 = mo4120i(i2);
                C0846x e = C0805ay.m4066e(i3);
                if (e != null && e.mo4252d() == i && !e.mo4251c() && (this.f2948q.f2850D.mo4223a() || !e.mo4265q())) {
                    return i3;
                }
            }
            return null;
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: c */
        public void mo4097c(int i, int i2) {
            this.f2945g = MeasureSpec.getSize(i);
            this.f2943e = MeasureSpec.getMode(i);
            if (this.f2943e == 0 && !C0805ay.f2844b) {
                this.f2945g = 0;
            }
            this.f2946h = MeasureSpec.getSize(i2);
            this.f2944f = MeasureSpec.getMode(i2);
            if (this.f2944f == 0 && !C0805ay.f2844b) {
                this.f2946h = 0;
            }
        }

        /* renamed from: c */
        public void mo4098c(C0835p pVar) {
            for (int v = mo4134v() - 1; v >= 0; v--) {
                if (!C0805ay.m4066e(mo4120i(v)).mo4251c()) {
                    mo4061a(v, pVar);
                }
            }
        }

        /* renamed from: c */
        public void mo3182c(C0835p pVar, C0843u uVar) {
            Log.e("RecyclerView", "You must override onLayoutChildren(Recycler recycler, State state) ");
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: c */
        public void mo4099c(C0805ay ayVar) {
            this.f2953v = true;
            mo4107d(ayVar);
        }

        /* renamed from: c */
        public void mo4100c(C0805ay ayVar, int i, int i2) {
        }

        /* renamed from: c */
        public void mo4101c(View view) {
            this.f2947p.mo3577a(view);
        }

        /* renamed from: c */
        public void mo4102c(View view, int i) {
            mo4073a(view, i, (C0828j) view.getLayoutParams());
        }

        /* renamed from: c */
        public boolean mo3206c() {
            return this.f2954w;
        }

        /* renamed from: d */
        public int mo4103d(C0835p pVar, C0843u uVar) {
            return 0;
        }

        /* renamed from: d */
        public int mo3207d(C0843u uVar) {
            return 0;
        }

        /* renamed from: d */
        public int mo4104d(View view) {
            return ((C0828j) view.getLayoutParams()).mo4147f();
        }

        /* renamed from: d */
        public Parcelable mo3209d() {
            return null;
        }

        /* renamed from: d */
        public View mo4105d(View view, int i) {
            return null;
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: d */
        public void mo4106d(int i, int i2) {
            int v = mo4134v();
            if (v == 0) {
                this.f2948q.mo3895e(i, i2);
                return;
            }
            int i3 = Integer.MAX_VALUE;
            int i4 = Integer.MIN_VALUE;
            int i5 = Integer.MIN_VALUE;
            int i6 = Integer.MAX_VALUE;
            for (int i7 = 0; i7 < v; i7++) {
                View i8 = mo4120i(i7);
                Rect rect = this.f2948q.f2905k;
                mo4074a(i8, rect);
                if (rect.left < i3) {
                    i3 = rect.left;
                }
                if (rect.right > i4) {
                    i4 = rect.right;
                }
                if (rect.top < i6) {
                    i6 = rect.top;
                }
                if (rect.bottom > i5) {
                    i5 = rect.bottom;
                }
            }
            this.f2948q.f2905k.set(i3, i6, i4, i5);
            mo3166a(this.f2948q.f2905k, i, i2);
        }

        /* renamed from: d */
        public void mo4107d(C0805ay ayVar) {
        }

        /* renamed from: e */
        public int mo3210e(C0843u uVar) {
            return 0;
        }

        /* renamed from: e */
        public View mo4108e(View view) {
            if (this.f2948q == null) {
                return null;
            }
            View c = this.f2948q.mo3869c(view);
            if (c != null && !this.f2947p.mo3586c(c)) {
                return c;
            }
            return null;
        }

        /* renamed from: e */
        public void mo3211e(int i) {
        }

        /* renamed from: e */
        public void mo4109e(int i, int i2) {
            View i3 = mo4120i(i);
            if (i3 == null) {
                StringBuilder sb = new StringBuilder();
                sb.append("Cannot move a child from non-existing index:");
                sb.append(i);
                sb.append(this.f2948q.toString());
                throw new IllegalArgumentException(sb.toString());
            }
            mo4118h(i);
            mo4102c(i3, i2);
        }

        @Deprecated
        /* renamed from: e */
        public void mo4110e(C0805ay ayVar) {
        }

        /* renamed from: e */
        public boolean mo3212e() {
            return false;
        }

        /* renamed from: e */
        public boolean mo4111e(C0835p pVar, C0843u uVar) {
            return false;
        }

        /* renamed from: f */
        public int mo3214f(C0843u uVar) {
            return 0;
        }

        /* renamed from: f */
        public int mo4112f(View view) {
            Rect rect = ((C0828j) view.getLayoutParams()).f2964d;
            return view.getMeasuredWidth() + rect.left + rect.right;
        }

        /* renamed from: f */
        public void mo4113f(int i, int i2) {
            this.f2948q.setMeasuredDimension(i, i2);
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: f */
        public void mo4114f(C0805ay ayVar) {
            mo4097c(MeasureSpec.makeMeasureSpec(ayVar.getWidth(), 1073741824), MeasureSpec.makeMeasureSpec(ayVar.getHeight(), 1073741824));
        }

        /* renamed from: f */
        public boolean mo3215f() {
            return false;
        }

        /* renamed from: g */
        public int mo3217g(C0843u uVar) {
            return 0;
        }

        /* renamed from: g */
        public int mo4115g(View view) {
            Rect rect = ((C0828j) view.getLayoutParams()).f2964d;
            return view.getMeasuredHeight() + rect.top + rect.bottom;
        }

        /* renamed from: g */
        public void mo4116g(int i) {
            if (mo4120i(i) != null) {
                this.f2947p.mo3576a(i);
            }
        }

        /* renamed from: h */
        public int mo3218h(C0843u uVar) {
            return 0;
        }

        /* renamed from: h */
        public int mo4117h(View view) {
            return view.getLeft() - mo4125n(view);
        }

        /* renamed from: h */
        public void mo4118h(int i) {
            m4234a(i, mo4120i(i));
        }

        /* renamed from: i */
        public int mo4119i(View view) {
            return view.getTop() - mo4123l(view);
        }

        /* renamed from: i */
        public View mo4120i(int i) {
            if (this.f2947p != null) {
                return this.f2947p.mo3583b(i);
            }
            return null;
        }

        /* renamed from: j */
        public int mo4121j(View view) {
            return view.getRight() + mo4126o(view);
        }

        /* renamed from: j */
        public void mo3351j(int i) {
            if (this.f2948q != null) {
                this.f2948q.mo3894e(i);
            }
        }

        /* renamed from: k */
        public int mo4122k(View view) {
            return view.getBottom() + mo4124m(view);
        }

        /* renamed from: k */
        public void mo3354k(int i) {
            if (this.f2948q != null) {
                this.f2948q.mo3883d(i);
            }
        }

        /* renamed from: l */
        public int mo4123l(View view) {
            return ((C0828j) view.getLayoutParams()).f2964d.top;
        }

        /* renamed from: l */
        public void mo3355l(int i) {
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: l */
        public boolean mo3223l() {
            return false;
        }

        /* renamed from: m */
        public int mo4124m(View view) {
            return ((C0828j) view.getLayoutParams()).f2964d.bottom;
        }

        /* renamed from: n */
        public int mo4125n(View view) {
            return ((C0828j) view.getLayoutParams()).f2964d.left;
        }

        /* renamed from: o */
        public int mo4126o(View view) {
            return ((C0828j) view.getLayoutParams()).f2964d.right;
        }

        /* renamed from: o */
        public void mo4127o() {
            if (this.f2948q != null) {
                this.f2948q.requestLayout();
            }
        }

        /* renamed from: p */
        public final boolean mo4128p() {
            return this.f2942d;
        }

        /* renamed from: q */
        public boolean mo4129q() {
            return this.f2953v;
        }

        /* renamed from: r */
        public boolean mo4130r() {
            return this.f2948q != null && this.f2948q.f2903i;
        }

        /* renamed from: s */
        public boolean mo4131s() {
            return this.f2951t != null && this.f2951t.mo4216d();
        }

        /* renamed from: t */
        public int mo4132t() {
            return C0495r.m2149f(this.f2948q);
        }

        /* renamed from: u */
        public int mo4133u() {
            return -1;
        }

        /* renamed from: v */
        public int mo4134v() {
            if (this.f2947p != null) {
                return this.f2947p.mo3581b();
            }
            return 0;
        }

        /* renamed from: w */
        public int mo4135w() {
            return this.f2943e;
        }

        /* renamed from: x */
        public int mo4136x() {
            return this.f2944f;
        }

        /* renamed from: y */
        public int mo4137y() {
            return this.f2945g;
        }

        /* renamed from: z */
        public int mo4138z() {
            return this.f2946h;
        }
    }

    /* renamed from: android.support.v7.widget.ay$j */
    public static class C0828j extends MarginLayoutParams {

        /* renamed from: c */
        C0846x f2963c;

        /* renamed from: d */
        final Rect f2964d = new Rect();

        /* renamed from: e */
        boolean f2965e = true;

        /* renamed from: f */
        boolean f2966f = false;

        public C0828j(int i, int i2) {
            super(i, i2);
        }

        public C0828j(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
        }

        public C0828j(C0828j jVar) {
            super(jVar);
        }

        public C0828j(LayoutParams layoutParams) {
            super(layoutParams);
        }

        public C0828j(MarginLayoutParams marginLayoutParams) {
            super(marginLayoutParams);
        }

        /* renamed from: c */
        public boolean mo4144c() {
            return this.f2963c.mo4262n();
        }

        /* renamed from: d */
        public boolean mo4145d() {
            return this.f2963c.mo4265q();
        }

        /* renamed from: e */
        public boolean mo4146e() {
            return this.f2963c.mo4275z();
        }

        /* renamed from: f */
        public int mo4147f() {
            return this.f2963c.mo4252d();
        }
    }

    /* renamed from: android.support.v7.widget.ay$k */
    public interface C0829k {
        /* renamed from: a */
        void mo4148a(View view);

        /* renamed from: b */
        void mo4149b(View view);
    }

    /* renamed from: android.support.v7.widget.ay$l */
    public static abstract class C0830l {
        /* renamed from: a */
        public abstract boolean mo4150a(int i, int i2);
    }

    /* renamed from: android.support.v7.widget.ay$m */
    public interface C0831m {
        /* renamed from: a */
        void mo3694a(boolean z);

        /* renamed from: a */
        boolean mo3696a(C0805ay ayVar, MotionEvent motionEvent);

        /* renamed from: b */
        void mo3699b(C0805ay ayVar, MotionEvent motionEvent);
    }

    /* renamed from: android.support.v7.widget.ay$n */
    public static abstract class C0832n {
        /* renamed from: a */
        public void mo4151a(C0805ay ayVar, int i) {
        }

        /* renamed from: a */
        public void mo3702a(C0805ay ayVar, int i, int i2) {
        }
    }

    /* renamed from: android.support.v7.widget.ay$o */
    public static class C0833o {

        /* renamed from: a */
        SparseArray<C0834a> f2967a = new SparseArray<>();

        /* renamed from: b */
        private int f2968b = 0;

        /* renamed from: android.support.v7.widget.ay$o$a */
        static class C0834a {

            /* renamed from: a */
            final ArrayList<C0846x> f2969a = new ArrayList<>();

            /* renamed from: b */
            int f2970b = 5;

            /* renamed from: c */
            long f2971c = 0;

            /* renamed from: d */
            long f2972d = 0;

            C0834a() {
            }
        }

        /* renamed from: b */
        private C0834a m4392b(int i) {
            C0834a aVar = (C0834a) this.f2967a.get(i);
            if (aVar != null) {
                return aVar;
            }
            C0834a aVar2 = new C0834a();
            this.f2967a.put(i, aVar2);
            return aVar2;
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public long mo4152a(long j, long j2) {
            return j == 0 ? j2 : ((j / 4) * 3) + (j2 / 4);
        }

        /* renamed from: a */
        public C0846x mo4153a(int i) {
            C0834a aVar = (C0834a) this.f2967a.get(i);
            if (aVar == null || aVar.f2969a.isEmpty()) {
                return null;
            }
            ArrayList<C0846x> arrayList = aVar.f2969a;
            return (C0846x) arrayList.remove(arrayList.size() - 1);
        }

        /* renamed from: a */
        public void mo4154a() {
            for (int i = 0; i < this.f2967a.size(); i++) {
                ((C0834a) this.f2967a.valueAt(i)).f2969a.clear();
            }
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public void mo4155a(int i, long j) {
            C0834a b = m4392b(i);
            b.f2971c = mo4152a(b.f2971c, j);
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public void mo4156a(C0812a aVar, C0812a aVar2, boolean z) {
            if (aVar != null) {
                mo4162c();
            }
            if (!z && this.f2968b == 0) {
                mo4154a();
            }
            if (aVar2 != null) {
                mo4159b();
            }
        }

        /* renamed from: a */
        public void mo4157a(C0846x xVar) {
            int h = xVar.mo4256h();
            ArrayList<C0846x> arrayList = m4392b(h).f2969a;
            if (((C0834a) this.f2967a.get(h)).f2970b > arrayList.size()) {
                xVar.mo4271v();
                arrayList.add(xVar);
            }
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public boolean mo4158a(int i, long j, long j2) {
            long j3 = m4392b(i).f2971c;
            return j3 == 0 || j + j3 < j2;
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: b */
        public void mo4159b() {
            this.f2968b++;
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: b */
        public void mo4160b(int i, long j) {
            C0834a b = m4392b(i);
            b.f2972d = mo4152a(b.f2972d, j);
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: b */
        public boolean mo4161b(int i, long j, long j2) {
            long j3 = m4392b(i).f2972d;
            return j3 == 0 || j + j3 < j2;
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: c */
        public void mo4162c() {
            this.f2968b--;
        }
    }

    /* renamed from: android.support.v7.widget.ay$p */
    public final class C0835p {

        /* renamed from: a */
        final ArrayList<C0846x> f2973a = new ArrayList<>();

        /* renamed from: b */
        ArrayList<C0846x> f2974b = null;

        /* renamed from: c */
        final ArrayList<C0846x> f2975c = new ArrayList<>();

        /* renamed from: d */
        int f2976d = 2;

        /* renamed from: e */
        C0833o f2977e;

        /* renamed from: g */
        private final List<C0846x> f2979g = Collections.unmodifiableList(this.f2973a);

        /* renamed from: h */
        private int f2980h = 2;

        /* renamed from: i */
        private C0844v f2981i;

        public C0835p() {
        }

        /* renamed from: a */
        private void m4404a(ViewGroup viewGroup, boolean z) {
            for (int childCount = viewGroup.getChildCount() - 1; childCount >= 0; childCount--) {
                View childAt = viewGroup.getChildAt(childCount);
                if (childAt instanceof ViewGroup) {
                    m4404a((ViewGroup) childAt, true);
                }
            }
            if (z) {
                if (viewGroup.getVisibility() == 4) {
                    viewGroup.setVisibility(0);
                    viewGroup.setVisibility(4);
                    return;
                }
                int visibility = viewGroup.getVisibility();
                viewGroup.setVisibility(4);
                viewGroup.setVisibility(visibility);
            }
        }

        /* renamed from: a */
        private boolean m4405a(C0846x xVar, int i, int i2, long j) {
            xVar.f3038p = C0805ay.this;
            int h = xVar.mo4256h();
            long nanoTime = C0805ay.this.getNanoTime();
            if (j != Long.MAX_VALUE && !this.f2977e.mo4161b(h, nanoTime, j)) {
                return false;
            }
            C0805ay.this.f2907m.mo4018b(xVar, i);
            this.f2977e.mo4160b(xVar.mo4256h(), C0805ay.this.getNanoTime() - nanoTime);
            m4406e(xVar);
            if (C0805ay.this.f2850D.mo4223a()) {
                xVar.f3029g = i2;
            }
            return true;
        }

        /* renamed from: e */
        private void m4406e(C0846x xVar) {
            if (C0805ay.this.mo3940n()) {
                View view = xVar.f3023a;
                if (C0495r.m2147e(view) == 0) {
                    C0495r.m2139b(view, 1);
                }
                if (!C0495r.m2141b(view)) {
                    xVar.mo4249b(16384);
                    C0495r.m2132a(view, C0805ay.this.f2854H.mo4277c());
                }
            }
        }

        /* renamed from: f */
        private void m4407f(C0846x xVar) {
            if (xVar.f3023a instanceof ViewGroup) {
                m4404a((ViewGroup) xVar.f3023a, false);
            }
        }

        /* access modifiers changed from: 0000 */
        /* JADX WARNING: Removed duplicated region for block: B:12:0x002d  */
        /* JADX WARNING: Removed duplicated region for block: B:27:0x0061  */
        /* JADX WARNING: Removed duplicated region for block: B:78:0x01ad  */
        /* JADX WARNING: Removed duplicated region for block: B:81:0x01d2  */
        /* JADX WARNING: Removed duplicated region for block: B:94:0x0208  */
        /* JADX WARNING: Removed duplicated region for block: B:96:0x0216  */
        /* renamed from: a */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public android.support.p031v7.widget.C0805ay.C0846x mo4163a(int r18, boolean r19, long r20) {
            /*
                r17 = this;
                r6 = r17
                r3 = r18
                r0 = r19
                if (r3 < 0) goto L_0x0232
                android.support.v7.widget.ay r1 = android.support.p031v7.widget.C0805ay.this
                android.support.v7.widget.ay$u r1 = r1.f2850D
                int r1 = r1.mo4227e()
                if (r3 < r1) goto L_0x0014
                goto L_0x0232
            L_0x0014:
                android.support.v7.widget.ay r1 = android.support.p031v7.widget.C0805ay.this
                android.support.v7.widget.ay$u r1 = r1.f2850D
                boolean r1 = r1.mo4223a()
                r2 = 0
                r7 = 1
                r8 = 0
                if (r1 == 0) goto L_0x0029
                android.support.v7.widget.ay$x r1 = r17.mo4192f(r18)
                if (r1 == 0) goto L_0x002a
                r4 = r7
                goto L_0x002b
            L_0x0029:
                r1 = r2
            L_0x002a:
                r4 = r8
            L_0x002b:
                if (r1 != 0) goto L_0x005f
                android.support.v7.widget.ay$x r1 = r17.mo4177b(r18, r19)
                if (r1 == 0) goto L_0x005f
                boolean r5 = r6.mo4175a(r1)
                if (r5 != 0) goto L_0x005e
                if (r0 != 0) goto L_0x005c
                r5 = 4
                r1.mo4249b(r5)
                boolean r5 = r1.mo4257i()
                if (r5 == 0) goto L_0x0050
                android.support.v7.widget.ay r5 = android.support.p031v7.widget.C0805ay.this
                android.view.View r9 = r1.f3023a
                r5.removeDetachedView(r9, r8)
                r1.mo4258j()
                goto L_0x0059
            L_0x0050:
                boolean r5 = r1.mo4259k()
                if (r5 == 0) goto L_0x0059
                r1.mo4260l()
            L_0x0059:
                r6.mo4180b(r1)
            L_0x005c:
                r1 = r2
                goto L_0x005f
            L_0x005e:
                r4 = r7
            L_0x005f:
                if (r1 != 0) goto L_0x018c
                android.support.v7.widget.ay r5 = android.support.p031v7.widget.C0805ay.this
                android.support.v7.widget.e r5 = r5.f2900f
                int r5 = r5.mo4525b(r3)
                if (r5 < 0) goto L_0x014f
                android.support.v7.widget.ay r9 = android.support.p031v7.widget.C0805ay.this
                android.support.v7.widget.ay$a r9 = r9.f2907m
                int r9 = r9.mo4007a()
                if (r5 < r9) goto L_0x0077
                goto L_0x014f
            L_0x0077:
                android.support.v7.widget.ay r9 = android.support.p031v7.widget.C0805ay.this
                android.support.v7.widget.ay$a r9 = r9.f2907m
                int r9 = r9.mo4008a(r5)
                android.support.v7.widget.ay r10 = android.support.p031v7.widget.C0805ay.this
                android.support.v7.widget.ay$a r10 = r10.f2907m
                boolean r10 = r10.mo4020b()
                if (r10 == 0) goto L_0x009a
                android.support.v7.widget.ay r1 = android.support.p031v7.widget.C0805ay.this
                android.support.v7.widget.ay$a r1 = r1.f2907m
                long r10 = r1.mo4015b(r5)
                android.support.v7.widget.ay$x r1 = r6.mo4164a(r10, r9, r0)
                if (r1 == 0) goto L_0x009a
                r1.f3025c = r5
                r4 = r7
            L_0x009a:
                if (r1 != 0) goto L_0x00f0
                android.support.v7.widget.ay$v r0 = r6.f2981i
                if (r0 == 0) goto L_0x00f0
                android.support.v7.widget.ay$v r0 = r6.f2981i
                android.view.View r0 = r0.mo4229a(r6, r3, r9)
                if (r0 == 0) goto L_0x00f0
                android.support.v7.widget.ay r1 = android.support.p031v7.widget.C0805ay.this
                android.support.v7.widget.ay$x r1 = r1.mo3858b(r0)
                if (r1 != 0) goto L_0x00cd
                java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
                java.lang.StringBuilder r1 = new java.lang.StringBuilder
                r1.<init>()
                java.lang.String r2 = "getViewForPositionAndType returned a view which does not have a ViewHolder"
                r1.append(r2)
                android.support.v7.widget.ay r2 = android.support.p031v7.widget.C0805ay.this
                java.lang.String r2 = r2.mo3835a()
                r1.append(r2)
                java.lang.String r1 = r1.toString()
                r0.<init>(r1)
                throw r0
            L_0x00cd:
                boolean r0 = r1.mo4251c()
                if (r0 == 0) goto L_0x00f0
                java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
                java.lang.StringBuilder r1 = new java.lang.StringBuilder
                r1.<init>()
                java.lang.String r2 = "getViewForPositionAndType returned a view that is ignored. You must call stopIgnoring before returning this view."
                r1.append(r2)
                android.support.v7.widget.ay r2 = android.support.p031v7.widget.C0805ay.this
                java.lang.String r2 = r2.mo3835a()
                r1.append(r2)
                java.lang.String r1 = r1.toString()
                r0.<init>(r1)
                throw r0
            L_0x00f0:
                if (r1 != 0) goto L_0x0106
                android.support.v7.widget.ay$o r0 = r17.mo4194g()
                android.support.v7.widget.ay$x r1 = r0.mo4153a(r9)
                if (r1 == 0) goto L_0x0106
                r1.mo4271v()
                boolean r0 = android.support.p031v7.widget.C0805ay.f2843a
                if (r0 == 0) goto L_0x0106
                r6.m4407f(r1)
            L_0x0106:
                if (r1 != 0) goto L_0x018c
                android.support.v7.widget.ay r0 = android.support.p031v7.widget.C0805ay.this
                long r0 = r0.getNanoTime()
                r10 = 9223372036854775807(0x7fffffffffffffff, double:NaN)
                int r5 = (r20 > r10 ? 1 : (r20 == r10 ? 0 : -1))
                if (r5 == 0) goto L_0x0124
                android.support.v7.widget.ay$o r10 = r6.f2977e
                r11 = r9
                r12 = r0
                r14 = r20
                boolean r5 = r10.mo4158a(r11, r12, r14)
                if (r5 != 0) goto L_0x0124
                return r2
            L_0x0124:
                android.support.v7.widget.ay r2 = android.support.p031v7.widget.C0805ay.this
                android.support.v7.widget.ay$a r2 = r2.f2907m
                android.support.v7.widget.ay r5 = android.support.p031v7.widget.C0805ay.this
                android.support.v7.widget.ay$x r2 = r2.mo4016b(r5, r9)
                boolean r5 = android.support.p031v7.widget.C0805ay.f2846d
                if (r5 == 0) goto L_0x0141
                android.view.View r5 = r2.f3023a
                android.support.v7.widget.ay r5 = android.support.p031v7.widget.C0805ay.m4068j(r5)
                if (r5 == 0) goto L_0x0141
                java.lang.ref.WeakReference r10 = new java.lang.ref.WeakReference
                r10.<init>(r5)
                r2.f3024b = r10
            L_0x0141:
                android.support.v7.widget.ay r5 = android.support.p031v7.widget.C0805ay.this
                long r10 = r5.getNanoTime()
                android.support.v7.widget.ay$o r5 = r6.f2977e
                long r10 = r10 - r0
                r5.mo4155a(r9, r10)
                r10 = r2
                goto L_0x018d
            L_0x014f:
                java.lang.IndexOutOfBoundsException r0 = new java.lang.IndexOutOfBoundsException
                java.lang.StringBuilder r1 = new java.lang.StringBuilder
                r1.<init>()
                java.lang.String r2 = "Inconsistency detected. Invalid item position "
                r1.append(r2)
                r1.append(r3)
                java.lang.String r2 = "(offset:"
                r1.append(r2)
                r1.append(r5)
                java.lang.String r2 = ")."
                r1.append(r2)
                java.lang.String r2 = "state:"
                r1.append(r2)
                android.support.v7.widget.ay r2 = android.support.p031v7.widget.C0805ay.this
                android.support.v7.widget.ay$u r2 = r2.f2850D
                int r2 = r2.mo4227e()
                r1.append(r2)
                android.support.v7.widget.ay r2 = android.support.p031v7.widget.C0805ay.this
                java.lang.String r2 = r2.mo3835a()
                r1.append(r2)
                java.lang.String r1 = r1.toString()
                r0.<init>(r1)
                throw r0
            L_0x018c:
                r10 = r1
            L_0x018d:
                r9 = r4
                if (r9 == 0) goto L_0x01c8
                android.support.v7.widget.ay r0 = android.support.p031v7.widget.C0805ay.this
                android.support.v7.widget.ay$u r0 = r0.f2850D
                boolean r0 = r0.mo4223a()
                if (r0 != 0) goto L_0x01c8
                r0 = 8192(0x2000, float:1.14794E-41)
                boolean r1 = r10.mo4247a(r0)
                if (r1 == 0) goto L_0x01c8
                r10.mo4240a(r8, r0)
                android.support.v7.widget.ay r0 = android.support.p031v7.widget.C0805ay.this
                android.support.v7.widget.ay$u r0 = r0.f2850D
                boolean r0 = r0.f3007j
                if (r0 == 0) goto L_0x01c8
                int r0 = android.support.p031v7.widget.C0805ay.C0817f.m4198e(r10)
                r0 = r0 | 4096(0x1000, float:5.74E-42)
                android.support.v7.widget.ay r1 = android.support.p031v7.widget.C0805ay.this
                android.support.v7.widget.ay$f r1 = r1.f2920z
                android.support.v7.widget.ay r2 = android.support.p031v7.widget.C0805ay.this
                android.support.v7.widget.ay$u r2 = r2.f2850D
                java.util.List r4 = r10.mo4270u()
                android.support.v7.widget.ay$f$c r0 = r1.mo4027a(r2, r10, r0, r4)
                android.support.v7.widget.ay r1 = android.support.p031v7.widget.C0805ay.this
                r1.mo3847a(r10, r0)
            L_0x01c8:
                android.support.v7.widget.ay r0 = android.support.p031v7.widget.C0805ay.this
                android.support.v7.widget.ay$u r0 = r0.f2850D
                boolean r0 = r0.mo4223a()
                if (r0 == 0) goto L_0x01db
                boolean r0 = r10.mo4264p()
                if (r0 == 0) goto L_0x01db
                r10.f3029g = r3
                goto L_0x01ee
            L_0x01db:
                boolean r0 = r10.mo4264p()
                if (r0 == 0) goto L_0x01f0
                boolean r0 = r10.mo4263o()
                if (r0 != 0) goto L_0x01f0
                boolean r0 = r10.mo4262n()
                if (r0 == 0) goto L_0x01ee
                goto L_0x01f0
            L_0x01ee:
                r0 = r8
                goto L_0x0200
            L_0x01f0:
                android.support.v7.widget.ay r0 = android.support.p031v7.widget.C0805ay.this
                android.support.v7.widget.e r0 = r0.f2900f
                int r2 = r0.mo4525b(r3)
                r0 = r6
                r1 = r10
                r4 = r20
                boolean r0 = r0.m4405a(r1, r2, r3, r4)
            L_0x0200:
                android.view.View r1 = r10.f3023a
                android.view.ViewGroup$LayoutParams r1 = r1.getLayoutParams()
                if (r1 != 0) goto L_0x0216
                android.support.v7.widget.ay r1 = android.support.p031v7.widget.C0805ay.this
                android.view.ViewGroup$LayoutParams r1 = r1.generateDefaultLayoutParams()
            L_0x020e:
                android.support.v7.widget.ay$j r1 = (android.support.p031v7.widget.C0805ay.C0828j) r1
                android.view.View r2 = r10.f3023a
                r2.setLayoutParams(r1)
                goto L_0x0227
            L_0x0216:
                android.support.v7.widget.ay r2 = android.support.p031v7.widget.C0805ay.this
                boolean r2 = r2.checkLayoutParams(r1)
                if (r2 != 0) goto L_0x0225
                android.support.v7.widget.ay r2 = android.support.p031v7.widget.C0805ay.this
                android.view.ViewGroup$LayoutParams r1 = r2.generateLayoutParams(r1)
                goto L_0x020e
            L_0x0225:
                android.support.v7.widget.ay$j r1 = (android.support.p031v7.widget.C0805ay.C0828j) r1
            L_0x0227:
                r1.f2963c = r10
                if (r9 == 0) goto L_0x022e
                if (r0 == 0) goto L_0x022e
                goto L_0x022f
            L_0x022e:
                r7 = r8
            L_0x022f:
                r1.f2966f = r7
                return r10
            L_0x0232:
                java.lang.IndexOutOfBoundsException r0 = new java.lang.IndexOutOfBoundsException
                java.lang.StringBuilder r1 = new java.lang.StringBuilder
                r1.<init>()
                java.lang.String r2 = "Invalid item position "
                r1.append(r2)
                r1.append(r3)
                java.lang.String r2 = "("
                r1.append(r2)
                r1.append(r3)
                java.lang.String r2 = "). Item count:"
                r1.append(r2)
                android.support.v7.widget.ay r2 = android.support.p031v7.widget.C0805ay.this
                android.support.v7.widget.ay$u r2 = r2.f2850D
                int r2 = r2.mo4227e()
                r1.append(r2)
                android.support.v7.widget.ay r2 = android.support.p031v7.widget.C0805ay.this
                java.lang.String r2 = r2.mo3835a()
                r1.append(r2)
                java.lang.String r1 = r1.toString()
                r0.<init>(r1)
                throw r0
            */
            throw new UnsupportedOperationException("Method not decompiled: android.support.p031v7.widget.C0805ay.C0835p.mo4163a(int, boolean, long):android.support.v7.widget.ay$x");
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public C0846x mo4164a(long j, int i, boolean z) {
            for (int size = this.f2973a.size() - 1; size >= 0; size--) {
                C0846x xVar = (C0846x) this.f2973a.get(size);
                if (xVar.mo4255g() == j && !xVar.mo4259k()) {
                    if (i == xVar.mo4256h()) {
                        xVar.mo4249b(32);
                        if (xVar.mo4265q() && !C0805ay.this.f2850D.mo4223a()) {
                            xVar.mo4240a(2, 14);
                        }
                        return xVar;
                    } else if (!z) {
                        this.f2973a.remove(size);
                        C0805ay.this.removeDetachedView(xVar.f3023a, false);
                        mo4181b(xVar.f3023a);
                    }
                }
            }
            int size2 = this.f2975c.size();
            while (true) {
                size2--;
                if (size2 < 0) {
                    return null;
                }
                C0846x xVar2 = (C0846x) this.f2975c.get(size2);
                if (xVar2.mo4255g() == j) {
                    if (i == xVar2.mo4256h()) {
                        if (!z) {
                            this.f2975c.remove(size2);
                        }
                        return xVar2;
                    } else if (!z) {
                        mo4188d(size2);
                        return null;
                    }
                }
            }
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public View mo4165a(int i, boolean z) {
            return mo4163a(i, z, Long.MAX_VALUE).f3023a;
        }

        /* renamed from: a */
        public void mo4166a() {
            this.f2973a.clear();
            mo4187d();
        }

        /* renamed from: a */
        public void mo4167a(int i) {
            this.f2980h = i;
            mo4178b();
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public void mo4168a(int i, int i2) {
            int i3;
            int i4;
            int i5;
            if (i < i2) {
                i4 = i2;
                i3 = -1;
                i5 = i;
            } else {
                i4 = i;
                i3 = 1;
                i5 = i2;
            }
            int size = this.f2975c.size();
            for (int i6 = 0; i6 < size; i6++) {
                C0846x xVar = (C0846x) this.f2975c.get(i6);
                if (xVar != null && xVar.f3025c >= i5 && xVar.f3025c <= i4) {
                    if (xVar.f3025c == i) {
                        xVar.mo4242a(i2 - i, false);
                    } else {
                        xVar.mo4242a(i3, false);
                    }
                }
            }
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public void mo4169a(int i, int i2, boolean z) {
            int i3 = i + i2;
            for (int size = this.f2975c.size() - 1; size >= 0; size--) {
                C0846x xVar = (C0846x) this.f2975c.get(size);
                if (xVar != null) {
                    if (xVar.f3025c >= i3) {
                        xVar.mo4242a(-i2, z);
                    } else if (xVar.f3025c >= i) {
                        xVar.mo4249b(8);
                        mo4188d(size);
                    }
                }
            }
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public void mo4170a(C0812a aVar, C0812a aVar2, boolean z) {
            mo4166a();
            mo4194g().mo4156a(aVar, aVar2, z);
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public void mo4171a(C0833o oVar) {
            if (this.f2977e != null) {
                this.f2977e.mo4162c();
            }
            this.f2977e = oVar;
            if (this.f2977e != null && C0805ay.this.getAdapter() != null) {
                this.f2977e.mo4159b();
            }
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public void mo4172a(C0844v vVar) {
            this.f2981i = vVar;
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public void mo4173a(C0846x xVar, boolean z) {
            C0805ay.m4064c(xVar);
            if (xVar.mo4247a(16384)) {
                xVar.mo4240a(0, 16384);
                C0495r.m2132a(xVar.f3023a, (C0471b) null);
            }
            if (z) {
                mo4189d(xVar);
            }
            xVar.f3038p = null;
            mo4194g().mo4157a(xVar);
        }

        /* renamed from: a */
        public void mo4174a(View view) {
            C0846x e = C0805ay.m4066e(view);
            if (e.mo4266r()) {
                C0805ay.this.removeDetachedView(view, false);
            }
            if (e.mo4257i()) {
                e.mo4258j();
            } else if (e.mo4259k()) {
                e.mo4260l();
            }
            mo4180b(e);
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public boolean mo4175a(C0846x xVar) {
            if (xVar.mo4265q()) {
                return C0805ay.this.f2850D.mo4223a();
            }
            if (xVar.f3025c < 0 || xVar.f3025c >= C0805ay.this.f2907m.mo4007a()) {
                StringBuilder sb = new StringBuilder();
                sb.append("Inconsistency detected. Invalid view holder adapter position");
                sb.append(xVar);
                sb.append(C0805ay.this.mo3835a());
                throw new IndexOutOfBoundsException(sb.toString());
            }
            boolean z = false;
            if (!C0805ay.this.f2850D.mo4223a() && C0805ay.this.f2907m.mo4008a(xVar.f3025c) != xVar.mo4256h()) {
                return false;
            }
            if (!C0805ay.this.f2907m.mo4020b()) {
                return true;
            }
            if (xVar.mo4255g() == C0805ay.this.f2907m.mo4015b(xVar.f3025c)) {
                z = true;
            }
            return z;
        }

        /* renamed from: b */
        public int mo4176b(int i) {
            if (i >= 0 && i < C0805ay.this.f2850D.mo4227e()) {
                return !C0805ay.this.f2850D.mo4223a() ? i : C0805ay.this.f2900f.mo4525b(i);
            }
            StringBuilder sb = new StringBuilder();
            sb.append("invalid position ");
            sb.append(i);
            sb.append(". State ");
            sb.append("item count is ");
            sb.append(C0805ay.this.f2850D.mo4227e());
            sb.append(C0805ay.this.mo3835a());
            throw new IndexOutOfBoundsException(sb.toString());
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: b */
        public C0846x mo4177b(int i, boolean z) {
            int size = this.f2973a.size();
            int i2 = 0;
            int i3 = 0;
            while (i3 < size) {
                C0846x xVar = (C0846x) this.f2973a.get(i3);
                if (xVar.mo4259k() || xVar.mo4252d() != i || xVar.mo4262n() || (!C0805ay.this.f2850D.f3004g && xVar.mo4265q())) {
                    i3++;
                } else {
                    xVar.mo4249b(32);
                    return xVar;
                }
            }
            if (!z) {
                View c = C0805ay.this.f2901g.mo3585c(i);
                if (c != null) {
                    C0846x e = C0805ay.m4066e(c);
                    C0805ay.this.f2901g.mo3590e(c);
                    int b = C0805ay.this.f2901g.mo3582b(c);
                    if (b == -1) {
                        StringBuilder sb = new StringBuilder();
                        sb.append("layout index should not be -1 after unhiding a view:");
                        sb.append(e);
                        sb.append(C0805ay.this.mo3835a());
                        throw new IllegalStateException(sb.toString());
                    }
                    C0805ay.this.f2901g.mo3589e(b);
                    mo4186c(c);
                    e.mo4249b(8224);
                    return e;
                }
            }
            int size2 = this.f2975c.size();
            while (i2 < size2) {
                C0846x xVar2 = (C0846x) this.f2975c.get(i2);
                if (xVar2.mo4262n() || xVar2.mo4252d() != i) {
                    i2++;
                } else {
                    if (!z) {
                        this.f2975c.remove(i2);
                    }
                    return xVar2;
                }
            }
            return null;
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: b */
        public void mo4178b() {
            this.f2976d = this.f2980h + (C0805ay.this.f2908n != null ? C0805ay.this.f2908n.f2955x : 0);
            for (int size = this.f2975c.size() - 1; size >= 0 && this.f2975c.size() > this.f2976d; size--) {
                mo4188d(size);
            }
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: b */
        public void mo4179b(int i, int i2) {
            int size = this.f2975c.size();
            for (int i3 = 0; i3 < size; i3++) {
                C0846x xVar = (C0846x) this.f2975c.get(i3);
                if (xVar != null && xVar.f3025c >= i) {
                    xVar.mo4242a(i2, true);
                }
            }
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: b */
        public void mo4180b(C0846x xVar) {
            boolean z;
            boolean z2 = false;
            if (xVar.mo4257i() || xVar.f3023a.getParent() != null) {
                StringBuilder sb = new StringBuilder();
                sb.append("Scrapped or attached views may not be recycled. isScrap:");
                sb.append(xVar.mo4257i());
                sb.append(" isAttached:");
                if (xVar.f3023a.getParent() != null) {
                    z2 = true;
                }
                sb.append(z2);
                sb.append(C0805ay.this.mo3835a());
                throw new IllegalArgumentException(sb.toString());
            } else if (xVar.mo4266r()) {
                StringBuilder sb2 = new StringBuilder();
                sb2.append("Tmp detached view should be removed from RecyclerView before it can be recycled: ");
                sb2.append(xVar);
                sb2.append(C0805ay.this.mo3835a());
                throw new IllegalArgumentException(sb2.toString());
            } else if (xVar.mo4251c()) {
                StringBuilder sb3 = new StringBuilder();
                sb3.append("Trying to recycle an ignored view holder. You should first call stopIgnoringView(view) before calling recycle.");
                sb3.append(C0805ay.this.mo3835a());
                throw new IllegalArgumentException(sb3.toString());
            } else {
                boolean y = xVar.mo4274y();
                if ((C0805ay.this.f2907m != null && y && C0805ay.this.f2907m.mo4021b(xVar)) || xVar.mo4272w()) {
                    if (this.f2976d <= 0 || xVar.mo4247a(526)) {
                        z = false;
                    } else {
                        int size = this.f2975c.size();
                        if (size >= this.f2976d && size > 0) {
                            mo4188d(0);
                            size--;
                        }
                        if (C0805ay.f2846d && size > 0 && !C0805ay.this.f2849C.mo3723a(xVar.f3025c)) {
                            int i = size - 1;
                            while (i >= 0) {
                                if (!C0805ay.this.f2849C.mo3723a(((C0846x) this.f2975c.get(i)).f3025c)) {
                                    break;
                                }
                                i--;
                            }
                            size = i + 1;
                        }
                        this.f2975c.add(size, xVar);
                        z = true;
                    }
                    if (!z) {
                        mo4173a(xVar, true);
                        z2 = true;
                    }
                } else {
                    z = false;
                }
                C0805ay.this.f2902h.mo4484g(xVar);
                if (!z && !z2 && y) {
                    xVar.f3038p = null;
                }
            }
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: b */
        public void mo4181b(View view) {
            C0846x e = C0805ay.m4066e(view);
            e.f3035m = null;
            e.f3036n = false;
            e.mo4260l();
            mo4180b(e);
        }

        /* renamed from: c */
        public View mo4182c(int i) {
            return mo4165a(i, false);
        }

        /* renamed from: c */
        public List<C0846x> mo4183c() {
            return this.f2979g;
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: c */
        public void mo4184c(int i, int i2) {
            int i3 = i2 + i;
            for (int size = this.f2975c.size() - 1; size >= 0; size--) {
                C0846x xVar = (C0846x) this.f2975c.get(size);
                if (xVar != null) {
                    int i4 = xVar.f3025c;
                    if (i4 >= i && i4 < i3) {
                        xVar.mo4249b(2);
                        mo4188d(size);
                    }
                }
            }
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: c */
        public void mo4185c(C0846x xVar) {
            (xVar.f3036n ? this.f2974b : this.f2973a).remove(xVar);
            xVar.f3035m = null;
            xVar.f3036n = false;
            xVar.mo4260l();
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: c */
        public void mo4186c(View view) {
            ArrayList<C0846x> arrayList;
            C0846x e = C0805ay.m4066e(view);
            if (!e.mo4247a(12) && e.mo4275z() && !C0805ay.this.mo3867b(e)) {
                if (this.f2974b == null) {
                    this.f2974b = new ArrayList<>();
                }
                e.mo4243a(this, true);
                arrayList = this.f2974b;
            } else if (!e.mo4262n() || e.mo4265q() || C0805ay.this.f2907m.mo4020b()) {
                e.mo4243a(this, false);
                arrayList = this.f2973a;
            } else {
                StringBuilder sb = new StringBuilder();
                sb.append("Called scrap view with an invalid view. Invalid views cannot be reused from scrap, they should rebound from recycler pool.");
                sb.append(C0805ay.this.mo3835a());
                throw new IllegalArgumentException(sb.toString());
            }
            arrayList.add(e);
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: d */
        public void mo4187d() {
            for (int size = this.f2975c.size() - 1; size >= 0; size--) {
                mo4188d(size);
            }
            this.f2975c.clear();
            if (C0805ay.f2846d) {
                C0805ay.this.f2849C.mo3720a();
            }
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: d */
        public void mo4188d(int i) {
            mo4173a((C0846x) this.f2975c.get(i), true);
            this.f2975c.remove(i);
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: d */
        public void mo4189d(C0846x xVar) {
            if (C0805ay.this.f2909o != null) {
                C0805ay.this.f2909o.mo4198a(xVar);
            }
            if (C0805ay.this.f2907m != null) {
                C0805ay.this.f2907m.mo4011a(xVar);
            }
            if (C0805ay.this.f2850D != null) {
                C0805ay.this.f2902h.mo4484g(xVar);
            }
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: e */
        public int mo4190e() {
            return this.f2973a.size();
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: e */
        public View mo4191e(int i) {
            return ((C0846x) this.f2973a.get(i)).f3023a;
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: f */
        public C0846x mo4192f(int i) {
            if (this.f2974b != null) {
                int size = this.f2974b.size();
                if (size == 0) {
                    return null;
                }
                int i2 = 0;
                int i3 = 0;
                while (i3 < size) {
                    C0846x xVar = (C0846x) this.f2974b.get(i3);
                    if (xVar.mo4259k() || xVar.mo4252d() != i) {
                        i3++;
                    } else {
                        xVar.mo4249b(32);
                        return xVar;
                    }
                }
                if (C0805ay.this.f2907m.mo4020b()) {
                    int b = C0805ay.this.f2900f.mo4525b(i);
                    if (b > 0 && b < C0805ay.this.f2907m.mo4007a()) {
                        long b2 = C0805ay.this.f2907m.mo4015b(b);
                        while (i2 < size) {
                            C0846x xVar2 = (C0846x) this.f2974b.get(i2);
                            if (xVar2.mo4259k() || xVar2.mo4255g() != b2) {
                                i2++;
                            } else {
                                xVar2.mo4249b(32);
                                return xVar2;
                            }
                        }
                    }
                }
            }
            return null;
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: f */
        public void mo4193f() {
            this.f2973a.clear();
            if (this.f2974b != null) {
                this.f2974b.clear();
            }
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: g */
        public C0833o mo4194g() {
            if (this.f2977e == null) {
                this.f2977e = new C0833o();
            }
            return this.f2977e;
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: h */
        public void mo4195h() {
            int size = this.f2975c.size();
            for (int i = 0; i < size; i++) {
                C0846x xVar = (C0846x) this.f2975c.get(i);
                if (xVar != null) {
                    xVar.mo4249b(6);
                    xVar.mo4245a((Object) null);
                }
            }
            if (C0805ay.this.f2907m == null || !C0805ay.this.f2907m.mo4020b()) {
                mo4187d();
            }
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: i */
        public void mo4196i() {
            int size = this.f2975c.size();
            for (int i = 0; i < size; i++) {
                ((C0846x) this.f2975c.get(i)).mo4239a();
            }
            int size2 = this.f2973a.size();
            for (int i2 = 0; i2 < size2; i2++) {
                ((C0846x) this.f2973a.get(i2)).mo4239a();
            }
            if (this.f2974b != null) {
                int size3 = this.f2974b.size();
                for (int i3 = 0; i3 < size3; i3++) {
                    ((C0846x) this.f2974b.get(i3)).mo4239a();
                }
            }
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: j */
        public void mo4197j() {
            int size = this.f2975c.size();
            for (int i = 0; i < size; i++) {
                C0828j jVar = (C0828j) ((C0846x) this.f2975c.get(i)).f3023a.getLayoutParams();
                if (jVar != null) {
                    jVar.f2965e = true;
                }
            }
        }
    }

    /* renamed from: android.support.v7.widget.ay$q */
    public interface C0836q {
        /* renamed from: a */
        void mo4198a(C0846x xVar);
    }

    /* renamed from: android.support.v7.widget.ay$r */
    private class C0837r extends C0814c {
        C0837r() {
        }
    }

    /* renamed from: android.support.v7.widget.ay$s */
    public static class C0838s extends C0457a {
        public static final Creator<C0838s> CREATOR = new ClassLoaderCreator<C0838s>() {
            /* renamed from: a */
            public C0838s createFromParcel(Parcel parcel) {
                return new C0838s(parcel, null);
            }

            /* renamed from: a */
            public C0838s createFromParcel(Parcel parcel, ClassLoader classLoader) {
                return new C0838s(parcel, classLoader);
            }

            /* renamed from: a */
            public C0838s[] newArray(int i) {
                return new C0838s[i];
            }
        };

        /* renamed from: a */
        Parcelable f2983a;

        C0838s(Parcel parcel, ClassLoader classLoader) {
            super(parcel, classLoader);
            if (classLoader == null) {
                classLoader = C0823i.class.getClassLoader();
            }
            this.f2983a = parcel.readParcelable(classLoader);
        }

        C0838s(Parcelable parcelable) {
            super(parcelable);
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public void mo4199a(C0838s sVar) {
            this.f2983a = sVar.f2983a;
        }

        public void writeToParcel(Parcel parcel, int i) {
            super.writeToParcel(parcel, i);
            parcel.writeParcelable(this.f2983a, 0);
        }
    }

    /* renamed from: android.support.v7.widget.ay$t */
    public static abstract class C0840t {

        /* renamed from: a */
        private int f2984a;

        /* renamed from: b */
        private C0805ay f2985b;

        /* renamed from: c */
        private C0823i f2986c;

        /* renamed from: d */
        private boolean f2987d;

        /* renamed from: e */
        private boolean f2988e;

        /* renamed from: f */
        private View f2989f;

        /* renamed from: g */
        private final C0841a f2990g;

        /* renamed from: android.support.v7.widget.ay$t$a */
        public static class C0841a {

            /* renamed from: a */
            private int f2991a;

            /* renamed from: b */
            private int f2992b;

            /* renamed from: c */
            private int f2993c;

            /* renamed from: d */
            private int f2994d;

            /* renamed from: e */
            private Interpolator f2995e;

            /* renamed from: f */
            private boolean f2996f;

            /* renamed from: g */
            private int f2997g;

            /* renamed from: b */
            private void m4461b() {
                if (this.f2995e != null && this.f2993c < 1) {
                    throw new IllegalStateException("If you provide an interpolator, you must set a positive duration");
                } else if (this.f2993c < 1) {
                    throw new IllegalStateException("Scroll duration must be a positive number");
                }
            }

            /* access modifiers changed from: 0000 */
            /* renamed from: a */
            public void mo4219a(C0805ay ayVar) {
                if (this.f2994d >= 0) {
                    int i = this.f2994d;
                    this.f2994d = -1;
                    ayVar.mo3860b(i);
                    this.f2996f = false;
                } else if (this.f2996f) {
                    m4461b();
                    if (this.f2995e != null) {
                        ayVar.f2847A.mo4234a(this.f2991a, this.f2992b, this.f2993c, this.f2995e);
                    } else if (this.f2993c == Integer.MIN_VALUE) {
                        ayVar.f2847A.mo4237b(this.f2991a, this.f2992b);
                    } else {
                        ayVar.f2847A.mo4232a(this.f2991a, this.f2992b, this.f2993c);
                    }
                    this.f2997g++;
                    if (this.f2997g > 10) {
                        Log.e("RecyclerView", "Smooth Scroll action is being updated too frequently. Make sure you are not changing it unless necessary");
                    }
                    this.f2996f = false;
                } else {
                    this.f2997g = 0;
                }
            }

            /* access modifiers changed from: 0000 */
            /* renamed from: a */
            public boolean mo4220a() {
                return this.f2994d >= 0;
            }
        }

        /* renamed from: android.support.v7.widget.ay$t$b */
        public interface C0842b {
            /* renamed from: d */
            PointF mo3208d(int i);
        }

        /* renamed from: a */
        public int mo4206a(View view) {
            return this.f2985b.mo3896f(view);
        }

        /* renamed from: a */
        public C0823i mo4207a() {
            return this.f2986c;
        }

        /* renamed from: a */
        public void mo4208a(int i) {
            this.f2984a = i;
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public void mo4209a(int i, int i2) {
            C0805ay ayVar = this.f2985b;
            if (!this.f2988e || this.f2984a == -1 || ayVar == null) {
                mo4213b();
            }
            if (this.f2987d && this.f2989f == null && this.f2986c != null) {
                PointF b = mo4212b(this.f2984a);
                if (!(b == null || (b.x == 0.0f && b.y == 0.0f))) {
                    ayVar.mo3840a((int) Math.signum(b.x), (int) Math.signum(b.y), (int[]) null);
                }
            }
            this.f2987d = false;
            if (this.f2989f != null) {
                if (mo4206a(this.f2989f) == this.f2984a) {
                    mo4211a(this.f2989f, ayVar.f2850D, this.f2990g);
                    this.f2990g.mo4219a(ayVar);
                    mo4213b();
                } else {
                    Log.e("RecyclerView", "Passed over target position while smooth scrolling.");
                    this.f2989f = null;
                }
            }
            if (this.f2988e) {
                mo4210a(i, i2, ayVar.f2850D, this.f2990g);
                boolean a = this.f2990g.mo4220a();
                this.f2990g.mo4219a(ayVar);
                if (a) {
                    if (this.f2988e) {
                        this.f2987d = true;
                        ayVar.f2847A.mo4230a();
                        return;
                    }
                    mo4213b();
                }
            }
        }

        /* access modifiers changed from: protected */
        /* renamed from: a */
        public abstract void mo4210a(int i, int i2, C0843u uVar, C0841a aVar);

        /* access modifiers changed from: protected */
        /* renamed from: a */
        public abstract void mo4211a(View view, C0843u uVar, C0841a aVar);

        /* renamed from: b */
        public PointF mo4212b(int i) {
            C0823i a = mo4207a();
            if (a instanceof C0842b) {
                return ((C0842b) a).mo3208d(i);
            }
            StringBuilder sb = new StringBuilder();
            sb.append("You should override computeScrollVectorForPosition when the LayoutManager does not implement ");
            sb.append(C0842b.class.getCanonicalName());
            Log.w("RecyclerView", sb.toString());
            return null;
        }

        /* access modifiers changed from: protected */
        /* renamed from: b */
        public final void mo4213b() {
            if (this.f2988e) {
                this.f2988e = false;
                mo4218f();
                this.f2985b.f2850D.f2998a = -1;
                this.f2989f = null;
                this.f2984a = -1;
                this.f2987d = false;
                this.f2986c.mo4068a(this);
                this.f2986c = null;
                this.f2985b = null;
            }
        }

        /* access modifiers changed from: protected */
        /* renamed from: b */
        public void mo4214b(View view) {
            if (mo4206a(view) == mo4217e()) {
                this.f2989f = view;
            }
        }

        /* renamed from: c */
        public boolean mo4215c() {
            return this.f2987d;
        }

        /* renamed from: d */
        public boolean mo4216d() {
            return this.f2988e;
        }

        /* renamed from: e */
        public int mo4217e() {
            return this.f2984a;
        }

        /* access modifiers changed from: protected */
        /* renamed from: f */
        public abstract void mo4218f();
    }

    /* renamed from: android.support.v7.widget.ay$u */
    public static class C0843u {

        /* renamed from: a */
        int f2998a = -1;

        /* renamed from: b */
        int f2999b = 0;

        /* renamed from: c */
        int f3000c = 0;

        /* renamed from: d */
        int f3001d = 1;

        /* renamed from: e */
        int f3002e = 0;

        /* renamed from: f */
        boolean f3003f = false;

        /* renamed from: g */
        boolean f3004g = false;

        /* renamed from: h */
        boolean f3005h = false;

        /* renamed from: i */
        boolean f3006i = false;

        /* renamed from: j */
        boolean f3007j = false;

        /* renamed from: k */
        boolean f3008k = false;

        /* renamed from: l */
        int f3009l;

        /* renamed from: m */
        long f3010m;

        /* renamed from: n */
        int f3011n;

        /* renamed from: o */
        int f3012o;

        /* renamed from: p */
        int f3013p;

        /* renamed from: q */
        private SparseArray<Object> f3014q;

        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public void mo4221a(int i) {
            if ((this.f3001d & i) == 0) {
                StringBuilder sb = new StringBuilder();
                sb.append("Layout state should be one of ");
                sb.append(Integer.toBinaryString(i));
                sb.append(" but it is ");
                sb.append(Integer.toBinaryString(this.f3001d));
                throw new IllegalStateException(sb.toString());
            }
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public void mo4222a(C0812a aVar) {
            this.f3001d = 1;
            this.f3002e = aVar.mo4007a();
            this.f3004g = false;
            this.f3005h = false;
            this.f3006i = false;
        }

        /* renamed from: a */
        public boolean mo4223a() {
            return this.f3004g;
        }

        /* renamed from: b */
        public boolean mo4224b() {
            return this.f3008k;
        }

        /* renamed from: c */
        public int mo4225c() {
            return this.f2998a;
        }

        /* renamed from: d */
        public boolean mo4226d() {
            return this.f2998a != -1;
        }

        /* renamed from: e */
        public int mo4227e() {
            return this.f3004g ? this.f2999b - this.f3000c : this.f3002e;
        }

        public String toString() {
            StringBuilder sb = new StringBuilder();
            sb.append("State{mTargetPosition=");
            sb.append(this.f2998a);
            sb.append(", mData=");
            sb.append(this.f3014q);
            sb.append(", mItemCount=");
            sb.append(this.f3002e);
            sb.append(", mIsMeasuring=");
            sb.append(this.f3006i);
            sb.append(", mPreviousLayoutItemCount=");
            sb.append(this.f2999b);
            sb.append(", mDeletedInvisibleItemCountSincePreviousLayout=");
            sb.append(this.f3000c);
            sb.append(", mStructureChanged=");
            sb.append(this.f3003f);
            sb.append(", mInPreLayout=");
            sb.append(this.f3004g);
            sb.append(", mRunSimpleAnimations=");
            sb.append(this.f3007j);
            sb.append(", mRunPredictiveAnimations=");
            sb.append(this.f3008k);
            sb.append('}');
            return sb.toString();
        }
    }

    /* renamed from: android.support.v7.widget.ay$v */
    public static abstract class C0844v {
        /* renamed from: a */
        public abstract View mo4229a(C0835p pVar, int i, int i2);
    }

    /* renamed from: android.support.v7.widget.ay$w */
    class C0845w implements Runnable {

        /* renamed from: a */
        OverScroller f3015a;

        /* renamed from: b */
        Interpolator f3016b = C0805ay.f2837L;

        /* renamed from: d */
        private int f3018d;

        /* renamed from: e */
        private int f3019e;

        /* renamed from: f */
        private boolean f3020f = false;

        /* renamed from: g */
        private boolean f3021g = false;

        C0845w() {
            this.f3015a = new OverScroller(C0805ay.this.getContext(), C0805ay.f2837L);
        }

        /* renamed from: a */
        private float m4473a(float f) {
            return (float) Math.sin((double) ((f - 0.5f) * 0.47123894f));
        }

        /* renamed from: b */
        private int m4474b(int i, int i2, int i3, int i4) {
            int i5;
            int abs = Math.abs(i);
            int abs2 = Math.abs(i2);
            boolean z = abs > abs2;
            int sqrt = (int) Math.sqrt((double) ((i3 * i3) + (i4 * i4)));
            int sqrt2 = (int) Math.sqrt((double) ((i * i) + (i2 * i2)));
            int width = z ? C0805ay.this.getWidth() : C0805ay.this.getHeight();
            int i6 = width / 2;
            float f = (float) width;
            float f2 = (float) i6;
            float a = f2 + (m4473a(Math.min(1.0f, (((float) sqrt2) * 1.0f) / f)) * f2);
            if (sqrt > 0) {
                i5 = 4 * Math.round(1000.0f * Math.abs(a / ((float) sqrt)));
            } else {
                if (!z) {
                    abs = abs2;
                }
                i5 = (int) (((((float) abs) / f) + 1.0f) * 300.0f);
            }
            return Math.min(i5, 2000);
        }

        /* renamed from: c */
        private void m4475c() {
            this.f3021g = false;
            this.f3020f = true;
        }

        /* renamed from: d */
        private void m4476d() {
            this.f3020f = false;
            if (this.f3021g) {
                mo4230a();
            }
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public void mo4230a() {
            if (this.f3020f) {
                this.f3021g = true;
                return;
            }
            C0805ay.this.removeCallbacks(this);
            C0495r.m2134a((View) C0805ay.this, (Runnable) this);
        }

        /* renamed from: a */
        public void mo4231a(int i, int i2) {
            C0805ay.this.setScrollState(2);
            this.f3019e = 0;
            this.f3018d = 0;
            this.f3015a.fling(0, 0, i, i2, Integer.MIN_VALUE, Integer.MAX_VALUE, Integer.MIN_VALUE, Integer.MAX_VALUE);
            mo4230a();
        }

        /* renamed from: a */
        public void mo4232a(int i, int i2, int i3) {
            mo4234a(i, i2, i3, C0805ay.f2837L);
        }

        /* renamed from: a */
        public void mo4233a(int i, int i2, int i3, int i4) {
            mo4232a(i, i2, m4474b(i, i2, i3, i4));
        }

        /* renamed from: a */
        public void mo4234a(int i, int i2, int i3, Interpolator interpolator) {
            if (this.f3016b != interpolator) {
                this.f3016b = interpolator;
                this.f3015a = new OverScroller(C0805ay.this.getContext(), interpolator);
            }
            C0805ay.this.setScrollState(2);
            this.f3019e = 0;
            this.f3018d = 0;
            this.f3015a.startScroll(0, 0, i, i2, i3);
            if (VERSION.SDK_INT < 23) {
                this.f3015a.computeScrollOffset();
            }
            mo4230a();
        }

        /* renamed from: a */
        public void mo4235a(int i, int i2, Interpolator interpolator) {
            int b = m4474b(i, i2, 0, 0);
            if (interpolator == null) {
                interpolator = C0805ay.f2837L;
            }
            mo4234a(i, i2, b, interpolator);
        }

        /* renamed from: b */
        public void mo4236b() {
            C0805ay.this.removeCallbacks(this);
            this.f3015a.abortAnimation();
        }

        /* renamed from: b */
        public void mo4237b(int i, int i2) {
            mo4233a(i, i2, 0, 0);
        }

        /* JADX WARNING: Code restructure failed: missing block: B:45:0x00eb, code lost:
            if (r8 > 0) goto L_0x00ef;
         */
        /* JADX WARNING: Removed duplicated region for block: B:43:0x00e7  */
        /* JADX WARNING: Removed duplicated region for block: B:49:0x00f7  */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public void run() {
            /*
                r23 = this;
                r0 = r23
                android.support.v7.widget.ay r1 = android.support.p031v7.widget.C0805ay.this
                android.support.v7.widget.ay$i r1 = r1.f2908n
                if (r1 != 0) goto L_0x000c
                r23.mo4236b()
                return
            L_0x000c:
                r23.m4475c()
                android.support.v7.widget.ay r1 = android.support.p031v7.widget.C0805ay.this
                r1.mo3882d()
                android.widget.OverScroller r1 = r0.f3015a
                android.support.v7.widget.ay r2 = android.support.p031v7.widget.C0805ay.this
                android.support.v7.widget.ay$i r2 = r2.f2908n
                android.support.v7.widget.ay$t r2 = r2.f2951t
                boolean r3 = r1.computeScrollOffset()
                r4 = 0
                if (r3 == 0) goto L_0x0191
                android.support.v7.widget.ay r3 = android.support.p031v7.widget.C0805ay.this
                int[] r3 = r3.f2855I
                int r11 = r1.getCurrX()
                int r12 = r1.getCurrY()
                int r5 = r0.f3018d
                int r13 = r11 - r5
                int r5 = r0.f3019e
                int r14 = r12 - r5
                r0.f3018d = r11
                r0.f3019e = r12
                android.support.v7.widget.ay r5 = android.support.p031v7.widget.C0805ay.this
                r9 = 0
                r10 = 1
                r6 = r13
                r7 = r14
                r8 = r3
                boolean r5 = r5.mo3853a(r6, r7, r8, r9, r10)
                r6 = 1
                if (r5 == 0) goto L_0x004f
                r5 = r3[r4]
                int r13 = r13 - r5
                r3 = r3[r6]
                int r14 = r14 - r3
            L_0x004f:
                android.support.v7.widget.ay r3 = android.support.p031v7.widget.C0805ay.this
                android.support.v7.widget.ay$a r3 = r3.f2907m
                if (r3 == 0) goto L_0x009c
                android.support.v7.widget.ay r3 = android.support.p031v7.widget.C0805ay.this
                android.support.v7.widget.ay r5 = android.support.p031v7.widget.C0805ay.this
                int[] r5 = r5.f2856J
                r3.mo3840a(r13, r14, r5)
                android.support.v7.widget.ay r3 = android.support.p031v7.widget.C0805ay.this
                int[] r3 = r3.f2856J
                r3 = r3[r4]
                android.support.v7.widget.ay r5 = android.support.p031v7.widget.C0805ay.this
                int[] r5 = r5.f2856J
                r5 = r5[r6]
                int r7 = r13 - r3
                int r8 = r14 - r5
                if (r2 == 0) goto L_0x00a0
                boolean r9 = r2.mo4215c()
                if (r9 != 0) goto L_0x00a0
                boolean r9 = r2.mo4216d()
                if (r9 == 0) goto L_0x00a0
                android.support.v7.widget.ay r9 = android.support.p031v7.widget.C0805ay.this
                android.support.v7.widget.ay$u r9 = r9.f2850D
                int r9 = r9.mo4227e()
                if (r9 != 0) goto L_0x008a
                r2.mo4213b()
                goto L_0x00a0
            L_0x008a:
                int r10 = r2.mo4217e()
                if (r10 < r9) goto L_0x0094
                int r9 = r9 - r6
                r2.mo4208a(r9)
            L_0x0094:
                int r9 = r13 - r7
                int r10 = r14 - r8
                r2.mo4209a(r9, r10)
                goto L_0x00a0
            L_0x009c:
                r3 = r4
                r5 = r3
                r7 = r5
                r8 = r7
            L_0x00a0:
                android.support.v7.widget.ay r9 = android.support.p031v7.widget.C0805ay.this
                java.util.ArrayList<android.support.v7.widget.ay$h> r9 = r9.f2910p
                boolean r9 = r9.isEmpty()
                if (r9 != 0) goto L_0x00af
                android.support.v7.widget.ay r9 = android.support.p031v7.widget.C0805ay.this
                r9.invalidate()
            L_0x00af:
                android.support.v7.widget.ay r9 = android.support.p031v7.widget.C0805ay.this
                int r9 = r9.getOverScrollMode()
                r10 = 2
                if (r9 == r10) goto L_0x00bd
                android.support.v7.widget.ay r9 = android.support.p031v7.widget.C0805ay.this
                r9.mo3871c(r13, r14)
            L_0x00bd:
                android.support.v7.widget.ay r15 = android.support.p031v7.widget.C0805ay.this
                r20 = 0
                r21 = 1
                r16 = r3
                r17 = r5
                r18 = r7
                r19 = r8
                boolean r9 = r15.mo3851a(r16, r17, r18, r19, r20, r21)
                if (r9 != 0) goto L_0x0113
                if (r7 != 0) goto L_0x00d5
                if (r8 == 0) goto L_0x0113
            L_0x00d5:
                float r9 = r1.getCurrVelocity()
                int r9 = (int) r9
                if (r7 == r11) goto L_0x00e4
                if (r7 >= 0) goto L_0x00e0
                int r15 = -r9
                goto L_0x00e5
            L_0x00e0:
                if (r7 <= 0) goto L_0x00e4
                r15 = r9
                goto L_0x00e5
            L_0x00e4:
                r15 = r4
            L_0x00e5:
                if (r8 == r12) goto L_0x00ee
                if (r8 >= 0) goto L_0x00eb
                int r9 = -r9
                goto L_0x00ef
            L_0x00eb:
                if (r8 <= 0) goto L_0x00ee
                goto L_0x00ef
            L_0x00ee:
                r9 = r4
            L_0x00ef:
                android.support.v7.widget.ay r4 = android.support.p031v7.widget.C0805ay.this
                int r4 = r4.getOverScrollMode()
                if (r4 == r10) goto L_0x00fc
                android.support.v7.widget.ay r4 = android.support.p031v7.widget.C0805ay.this
                r4.mo3884d(r15, r9)
            L_0x00fc:
                if (r15 != 0) goto L_0x0106
                if (r7 == r11) goto L_0x0106
                int r4 = r1.getFinalX()
                if (r4 != 0) goto L_0x0113
            L_0x0106:
                if (r9 != 0) goto L_0x0110
                if (r8 == r12) goto L_0x0110
                int r4 = r1.getFinalY()
                if (r4 != 0) goto L_0x0113
            L_0x0110:
                r1.abortAnimation()
            L_0x0113:
                if (r3 != 0) goto L_0x0117
                if (r5 == 0) goto L_0x011c
            L_0x0117:
                android.support.v7.widget.ay r4 = android.support.p031v7.widget.C0805ay.this
                r4.mo3931i(r3, r5)
            L_0x011c:
                android.support.v7.widget.ay r4 = android.support.p031v7.widget.C0805ay.this
                boolean r4 = r4.awakenScrollBars()
                if (r4 != 0) goto L_0x0129
                android.support.v7.widget.ay r4 = android.support.p031v7.widget.C0805ay.this
                r4.invalidate()
            L_0x0129:
                if (r14 == 0) goto L_0x0139
                android.support.v7.widget.ay r4 = android.support.p031v7.widget.C0805ay.this
                android.support.v7.widget.ay$i r4 = r4.f2908n
                boolean r4 = r4.mo3215f()
                if (r4 == 0) goto L_0x0139
                if (r5 != r14) goto L_0x0139
                r4 = r6
                goto L_0x013a
            L_0x0139:
                r4 = 0
            L_0x013a:
                if (r13 == 0) goto L_0x014a
                android.support.v7.widget.ay r5 = android.support.p031v7.widget.C0805ay.this
                android.support.v7.widget.ay$i r5 = r5.f2908n
                boolean r5 = r5.mo3212e()
                if (r5 == 0) goto L_0x014a
                if (r3 != r13) goto L_0x014a
                r3 = r6
                goto L_0x014b
            L_0x014a:
                r3 = 0
            L_0x014b:
                if (r13 != 0) goto L_0x014f
                if (r14 == 0) goto L_0x0156
            L_0x014f:
                if (r3 != 0) goto L_0x0156
                if (r4 == 0) goto L_0x0154
                goto L_0x0156
            L_0x0154:
                r3 = 0
                goto L_0x0157
            L_0x0156:
                r3 = r6
            L_0x0157:
                boolean r1 = r1.isFinished()
                if (r1 != 0) goto L_0x017b
                if (r3 != 0) goto L_0x0168
                android.support.v7.widget.ay r1 = android.support.p031v7.widget.C0805ay.this
                boolean r1 = r1.mo3927h(r6)
                if (r1 != 0) goto L_0x0168
                goto L_0x017b
            L_0x0168:
                r23.mo4230a()
                android.support.v7.widget.ay r1 = android.support.p031v7.widget.C0805ay.this
                android.support.v7.widget.aq r1 = r1.f2848B
                if (r1 == 0) goto L_0x0191
                android.support.v7.widget.ay r1 = android.support.p031v7.widget.C0805ay.this
                android.support.v7.widget.aq r1 = r1.f2848B
                android.support.v7.widget.ay r3 = android.support.p031v7.widget.C0805ay.this
                r1.mo3715a(r3, r13, r14)
                goto L_0x0191
            L_0x017b:
                android.support.v7.widget.ay r1 = android.support.p031v7.widget.C0805ay.this
                r3 = 0
                r1.setScrollState(r3)
                boolean r1 = android.support.p031v7.widget.C0805ay.f2846d
                if (r1 == 0) goto L_0x018c
                android.support.v7.widget.ay r1 = android.support.p031v7.widget.C0805ay.this
                android.support.v7.widget.aq$a r1 = r1.f2849C
                r1.mo3720a()
            L_0x018c:
                android.support.v7.widget.ay r1 = android.support.p031v7.widget.C0805ay.this
                r1.mo1929a(r6)
            L_0x0191:
                if (r2 == 0) goto L_0x01a4
                boolean r1 = r2.mo4215c()
                if (r1 == 0) goto L_0x019d
                r1 = 0
                r2.mo4209a(r1, r1)
            L_0x019d:
                boolean r1 = r0.f3021g
                if (r1 != 0) goto L_0x01a4
                r2.mo4213b()
            L_0x01a4:
                r23.m4476d()
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: android.support.p031v7.widget.C0805ay.C0845w.run():void");
        }
    }

    /* renamed from: android.support.v7.widget.ay$x */
    public static abstract class C0846x {

        /* renamed from: q */
        private static final List<Object> f3022q = Collections.emptyList();

        /* renamed from: a */
        public final View f3023a;

        /* renamed from: b */
        WeakReference<C0805ay> f3024b;

        /* renamed from: c */
        int f3025c;

        /* renamed from: d */
        int f3026d;

        /* renamed from: e */
        long f3027e;

        /* renamed from: f */
        int f3028f;

        /* renamed from: g */
        int f3029g;

        /* renamed from: h */
        C0846x f3030h;

        /* renamed from: i */
        C0846x f3031i;

        /* renamed from: j */
        int f3032j;

        /* renamed from: k */
        List<Object> f3033k;

        /* renamed from: l */
        List<Object> f3034l;

        /* renamed from: m */
        C0835p f3035m;

        /* renamed from: n */
        boolean f3036n;

        /* renamed from: o */
        int f3037o;

        /* renamed from: p */
        C0805ay f3038p;

        /* renamed from: r */
        private int f3039r;

        /* renamed from: s */
        private int f3040s;

        /* renamed from: A */
        private void m4485A() {
            if (this.f3033k == null) {
                this.f3033k = new ArrayList();
                this.f3034l = Collections.unmodifiableList(this.f3033k);
            }
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public void mo4239a() {
            this.f3026d = -1;
            this.f3029g = -1;
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public void mo4240a(int i, int i2) {
            this.f3032j = (i & i2) | (this.f3032j & (~i2));
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public void mo4241a(int i, int i2, boolean z) {
            mo4249b(8);
            mo4242a(i2, z);
            this.f3025c = i;
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public void mo4242a(int i, boolean z) {
            if (this.f3026d == -1) {
                this.f3026d = this.f3025c;
            }
            if (this.f3029g == -1) {
                this.f3029g = this.f3025c;
            }
            if (z) {
                this.f3029g += i;
            }
            this.f3025c += i;
            if (this.f3023a.getLayoutParams() != null) {
                ((C0828j) this.f3023a.getLayoutParams()).f2965e = true;
            }
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public void mo4243a(C0835p pVar, boolean z) {
            this.f3035m = pVar;
            this.f3036n = z;
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public void mo4244a(C0805ay ayVar) {
            this.f3040s = this.f3037o != -1 ? this.f3037o : C0495r.m2147e(this.f3023a);
            ayVar.mo3854a(this, 4);
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public void mo4245a(Object obj) {
            if (obj == null) {
                mo4249b(1024);
                return;
            }
            if ((1024 & this.f3032j) == 0) {
                m4485A();
                this.f3033k.add(obj);
            }
        }

        /* renamed from: a */
        public final void mo4246a(boolean z) {
            int i;
            this.f3039r = z ? this.f3039r - 1 : this.f3039r + 1;
            if (this.f3039r < 0) {
                this.f3039r = 0;
                StringBuilder sb = new StringBuilder();
                sb.append("isRecyclable decremented below 0: unmatched pair of setIsRecyable() calls for ");
                sb.append(this);
                Log.e("View", sb.toString());
                return;
            }
            if (!z && this.f3039r == 1) {
                i = this.f3032j | 16;
            } else if (z && this.f3039r == 0) {
                i = this.f3032j & -17;
            } else {
                return;
            }
            this.f3032j = i;
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public boolean mo4247a(int i) {
            return (i & this.f3032j) != 0;
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: b */
        public void mo4248b() {
            if (this.f3026d == -1) {
                this.f3026d = this.f3025c;
            }
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: b */
        public void mo4249b(int i) {
            this.f3032j = i | this.f3032j;
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: b */
        public void mo4250b(C0805ay ayVar) {
            ayVar.mo3854a(this, this.f3040s);
            this.f3040s = 0;
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: c */
        public boolean mo4251c() {
            return (this.f3032j & 128) != 0;
        }

        /* renamed from: d */
        public final int mo4252d() {
            return this.f3029g == -1 ? this.f3025c : this.f3029g;
        }

        /* renamed from: e */
        public final int mo4253e() {
            if (this.f3038p == null) {
                return -1;
            }
            return this.f3038p.mo3880d(this);
        }

        /* renamed from: f */
        public final int mo4254f() {
            return this.f3026d;
        }

        /* renamed from: g */
        public final long mo4255g() {
            return this.f3027e;
        }

        /* renamed from: h */
        public final int mo4256h() {
            return this.f3028f;
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: i */
        public boolean mo4257i() {
            return this.f3035m != null;
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: j */
        public void mo4258j() {
            this.f3035m.mo4185c(this);
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: k */
        public boolean mo4259k() {
            return (this.f3032j & 32) != 0;
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: l */
        public void mo4260l() {
            this.f3032j &= -33;
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: m */
        public void mo4261m() {
            this.f3032j &= -257;
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: n */
        public boolean mo4262n() {
            return (this.f3032j & 4) != 0;
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: o */
        public boolean mo4263o() {
            return (this.f3032j & 2) != 0;
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: p */
        public boolean mo4264p() {
            return (this.f3032j & 1) != 0;
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: q */
        public boolean mo4265q() {
            return (this.f3032j & 8) != 0;
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: r */
        public boolean mo4266r() {
            return (this.f3032j & 256) != 0;
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: s */
        public boolean mo4267s() {
            return (this.f3032j & 512) != 0 || mo4262n();
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: t */
        public void mo4268t() {
            if (this.f3033k != null) {
                this.f3033k.clear();
            }
            this.f3032j &= -1025;
        }

        public String toString() {
            StringBuilder sb = new StringBuilder();
            sb.append("ViewHolder{");
            sb.append(Integer.toHexString(hashCode()));
            sb.append(" position=");
            sb.append(this.f3025c);
            sb.append(" id=");
            sb.append(this.f3027e);
            sb.append(", oldPos=");
            sb.append(this.f3026d);
            sb.append(", pLpos:");
            sb.append(this.f3029g);
            StringBuilder sb2 = new StringBuilder(sb.toString());
            if (mo4257i()) {
                sb2.append(" scrap ");
                sb2.append(this.f3036n ? "[changeScrap]" : "[attachedScrap]");
            }
            if (mo4262n()) {
                sb2.append(" invalid");
            }
            if (!mo4264p()) {
                sb2.append(" unbound");
            }
            if (mo4263o()) {
                sb2.append(" update");
            }
            if (mo4265q()) {
                sb2.append(" removed");
            }
            if (mo4251c()) {
                sb2.append(" ignored");
            }
            if (mo4266r()) {
                sb2.append(" tmpDetached");
            }
            if (!mo4272w()) {
                StringBuilder sb3 = new StringBuilder();
                sb3.append(" not recyclable(");
                sb3.append(this.f3039r);
                sb3.append(")");
                sb2.append(sb3.toString());
            }
            if (mo4267s()) {
                sb2.append(" undefined adapter position");
            }
            if (this.f3023a.getParent() == null) {
                sb2.append(" no parent");
            }
            sb2.append("}");
            return sb2.toString();
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: u */
        public List<Object> mo4270u() {
            return (this.f3032j & 1024) == 0 ? (this.f3033k == null || this.f3033k.size() == 0) ? f3022q : this.f3034l : f3022q;
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: v */
        public void mo4271v() {
            this.f3032j = 0;
            this.f3025c = -1;
            this.f3026d = -1;
            this.f3027e = -1;
            this.f3029g = -1;
            this.f3039r = 0;
            this.f3030h = null;
            this.f3031i = null;
            mo4268t();
            this.f3040s = 0;
            this.f3037o = -1;
            C0805ay.m4064c(this);
        }

        /* renamed from: w */
        public final boolean mo4272w() {
            return (this.f3032j & 16) == 0 && !C0495r.m2144c(this.f3023a);
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: x */
        public boolean mo4273x() {
            return (this.f3032j & 16) != 0;
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: y */
        public boolean mo4274y() {
            return (this.f3032j & 16) == 0 && C0495r.m2144c(this.f3023a);
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: z */
        public boolean mo4275z() {
            return (this.f3032j & 2) != 0;
        }
    }

    public C0805ay(Context context) {
        this(context, null);
    }

    public C0805ay(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public C0805ay(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f2858R = new C0837r();
        this.f2899e = new C0835p();
        this.f2902h = new C0882bu();
        this.f2904j = new Runnable() {
            public void run() {
                if (C0805ay.this.f2914t && !C0805ay.this.isLayoutRequested()) {
                    if (!C0805ay.this.f2911q) {
                        C0805ay.this.requestLayout();
                    } else if (C0805ay.this.f2916v) {
                        C0805ay.this.f2915u = true;
                    } else {
                        C0805ay.this.mo3882d();
                    }
                }
            }
        };
        this.f2905k = new Rect();
        this.f2860T = new Rect();
        this.f2906l = new RectF();
        this.f2910p = new ArrayList<>();
        this.f2861U = new ArrayList<>();
        this.f2863W = 0;
        this.f2918x = false;
        this.f2919y = false;
        this.f2877ae = 0;
        this.f2878af = 0;
        this.f2879ag = new C0816e();
        this.f2920z = new C0757ak();
        this.f2884al = 0;
        this.f2885am = -1;
        this.f2895aw = Float.MIN_VALUE;
        this.f2896ax = Float.MIN_VALUE;
        boolean z = true;
        this.f2897ay = true;
        this.f2847A = new C0845w();
        this.f2849C = f2846d ? new C0784a() : null;
        this.f2850D = new C0843u();
        this.f2851E = false;
        this.f2852F = false;
        this.f2865aB = new C0821g();
        this.f2853G = false;
        this.f2867aD = new int[2];
        this.f2869aF = new int[2];
        this.f2855I = new int[2];
        this.f2870aG = new int[2];
        this.f2856J = new int[2];
        this.f2857K = new ArrayList();
        this.f2871aH = new Runnable() {
            public void run() {
                if (C0805ay.this.f2920z != null) {
                    C0805ay.this.f2920z.mo3642a();
                }
                C0805ay.this.f2853G = false;
            }
        };
        this.f2872aI = new C0884b() {
            /* renamed from: a */
            public void mo3994a(C0846x xVar) {
                C0805ay.this.f2908n.mo4076a(xVar.f3023a, C0805ay.this.f2899e);
            }

            /* renamed from: a */
            public void mo3995a(C0846x xVar, C0820c cVar, C0820c cVar2) {
                C0805ay.this.f2899e.mo4185c(xVar);
                C0805ay.this.mo3864b(xVar, cVar, cVar2);
            }

            /* renamed from: b */
            public void mo3996b(C0846x xVar, C0820c cVar, C0820c cVar2) {
                C0805ay.this.mo3848a(xVar, cVar, cVar2);
            }

            /* renamed from: c */
            public void mo3997c(C0846x xVar, C0820c cVar, C0820c cVar2) {
                xVar.mo4246a(false);
                if (!C0805ay.this.f2918x ? C0805ay.this.f2920z.mo4032c(xVar, cVar, cVar2) : C0805ay.this.f2920z.mo4030a(xVar, xVar, cVar, cVar2)) {
                    C0805ay.this.mo3954p();
                }
            }
        };
        if (attributeSet != null) {
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, f2839N, i, 0);
            this.f2903i = obtainStyledAttributes.getBoolean(0, true);
            obtainStyledAttributes.recycle();
        } else {
            this.f2903i = true;
        }
        setScrollContainer(true);
        setFocusableInTouchMode(true);
        ViewConfiguration viewConfiguration = ViewConfiguration.get(context);
        this.f2891as = viewConfiguration.getScaledTouchSlop();
        this.f2895aw = C0499s.m2180a(viewConfiguration, context);
        this.f2896ax = C0499s.m2182b(viewConfiguration, context);
        this.f2893au = viewConfiguration.getScaledMinimumFlingVelocity();
        this.f2894av = viewConfiguration.getScaledMaximumFlingVelocity();
        setWillNotDraw(getOverScrollMode() == 2);
        this.f2920z.mo4028a(this.f2865aB);
        mo3859b();
        m4072z();
        m4071y();
        if (C0495r.m2147e(this) == 0) {
            C0495r.m2139b((View) this, 1);
        }
        this.f2875ac = (AccessibilityManager) getContext().getSystemService("accessibility");
        setAccessibilityDelegateCompat(new C0847az(this));
        if (attributeSet != null) {
            TypedArray obtainStyledAttributes2 = context.obtainStyledAttributes(attributeSet, C0625b.RecyclerView, i, 0);
            String string = obtainStyledAttributes2.getString(C0625b.RecyclerView_layoutManager);
            if (obtainStyledAttributes2.getInt(C0625b.RecyclerView_android_descendantFocusability, -1) == -1) {
                setDescendantFocusability(262144);
            }
            this.f2913s = obtainStyledAttributes2.getBoolean(C0625b.RecyclerView_fastScrollEnabled, false);
            if (this.f2913s) {
                mo3841a((StateListDrawable) obtainStyledAttributes2.getDrawable(C0625b.RecyclerView_fastScrollVerticalThumbDrawable), obtainStyledAttributes2.getDrawable(C0625b.RecyclerView_fastScrollVerticalTrackDrawable), (StateListDrawable) obtainStyledAttributes2.getDrawable(C0625b.RecyclerView_fastScrollHorizontalThumbDrawable), obtainStyledAttributes2.getDrawable(C0625b.RecyclerView_fastScrollHorizontalTrackDrawable));
            }
            obtainStyledAttributes2.recycle();
            m4051a(context, string, attributeSet, i, 0);
            if (VERSION.SDK_INT >= 21) {
                TypedArray obtainStyledAttributes3 = context.obtainStyledAttributes(attributeSet, f2838M, i, 0);
                boolean z2 = obtainStyledAttributes3.getBoolean(0, true);
                obtainStyledAttributes3.recycle();
                z = z2;
            }
        } else {
            setDescendantFocusability(262144);
        }
        setNestedScrollingEnabled(z);
    }

    /* renamed from: A */
    private boolean m4033A() {
        int b = this.f2901g.mo3581b();
        for (int i = 0; i < b; i++) {
            C0846x e = m4066e(this.f2901g.mo3583b(i));
            if (e != null && !e.mo4251c() && e.mo4275z()) {
                return true;
            }
        }
        return false;
    }

    /* renamed from: B */
    private void m4034B() {
        this.f2847A.mo4236b();
        if (this.f2908n != null) {
            this.f2908n.mo4058H();
        }
    }

    /* renamed from: C */
    private void m4035C() {
        boolean z;
        if (this.f2880ah != null) {
            this.f2880ah.onRelease();
            z = this.f2880ah.isFinished();
        } else {
            z = false;
        }
        if (this.f2881ai != null) {
            this.f2881ai.onRelease();
            z |= this.f2881ai.isFinished();
        }
        if (this.f2882aj != null) {
            this.f2882aj.onRelease();
            z |= this.f2882aj.isFinished();
        }
        if (this.f2883ak != null) {
            this.f2883ak.onRelease();
            z |= this.f2883ak.isFinished();
        }
        if (z) {
            C0495r.m2145d(this);
        }
    }

    /* renamed from: D */
    private void m4036D() {
        if (this.f2886an != null) {
            this.f2886an.clear();
        }
        mo1929a(0);
        m4035C();
    }

    /* renamed from: E */
    private void m4037E() {
        m4036D();
        setScrollState(0);
    }

    /* renamed from: F */
    private void m4038F() {
        int i = this.f2874ab;
        this.f2874ab = 0;
        if (i != 0 && mo3940n()) {
            AccessibilityEvent obtain = AccessibilityEvent.obtain();
            obtain.setEventType(2048);
            C0460a.m2006a(obtain, i);
            sendAccessibilityEventUnchecked(obtain);
        }
    }

    /* renamed from: G */
    private boolean m4039G() {
        return this.f2920z != null && this.f2908n.mo3181b();
    }

    /* renamed from: H */
    private void m4040H() {
        if (this.f2918x) {
            this.f2900f.mo4521a();
            if (this.f2919y) {
                this.f2908n.mo3172a(this);
            }
        }
        if (m4039G()) {
            this.f2900f.mo4526b();
        } else {
            this.f2900f.mo4530e();
        }
        boolean z = true;
        boolean z2 = this.f2851E || this.f2852F;
        this.f2850D.f3007j = this.f2914t && this.f2920z != null && (this.f2918x || z2 || this.f2908n.f2952u) && (!this.f2918x || this.f2907m.mo4020b());
        C0843u uVar = this.f2850D;
        if (!this.f2850D.f3007j || !z2 || this.f2918x || !m4039G()) {
            z = false;
        }
        uVar.f3008k = z;
    }

    /* renamed from: I */
    private void m4041I() {
        C0846x xVar = null;
        View focusedChild = (!this.f2897ay || !hasFocus() || this.f2907m == null) ? null : getFocusedChild();
        if (focusedChild != null) {
            xVar = mo3881d(focusedChild);
        }
        if (xVar == null) {
            m4042J();
            return;
        }
        this.f2850D.f3010m = this.f2907m.mo4020b() ? xVar.mo4255g() : -1;
        C0843u uVar = this.f2850D;
        int i = this.f2918x ? -1 : xVar.mo4265q() ? xVar.f3026d : xVar.mo4253e();
        uVar.f3009l = i;
        this.f2850D.f3011n = m4070m(xVar.f3023a);
    }

    /* renamed from: J */
    private void m4042J() {
        this.f2850D.f3010m = -1;
        this.f2850D.f3009l = -1;
        this.f2850D.f3011n = -1;
    }

    /* renamed from: K */
    private View m4043K() {
        int i = this.f2850D.f3009l != -1 ? this.f2850D.f3009l : 0;
        int e = this.f2850D.mo4227e();
        int i2 = i;
        while (i2 < e) {
            C0846x c = mo3868c(i2);
            if (c == null) {
                break;
            } else if (c.f3023a.hasFocusable()) {
                return c.f3023a;
            } else {
                i2++;
            }
        }
        int min = Math.min(e, i);
        while (true) {
            min--;
            if (min < 0) {
                return null;
            }
            C0846x c2 = mo3868c(min);
            if (c2 == null) {
                return null;
            }
            if (c2.f3023a.hasFocusable()) {
                return c2.f3023a;
            }
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:49:0x00ae, code lost:
        if (r0.isFocusable() != false) goto L_0x00b2;
     */
    /* renamed from: L */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private void m4044L() {
        /*
            r6 = this;
            boolean r0 = r6.f2897ay
            if (r0 == 0) goto L_0x00b5
            android.support.v7.widget.ay$a r0 = r6.f2907m
            if (r0 == 0) goto L_0x00b5
            boolean r0 = r6.hasFocus()
            if (r0 == 0) goto L_0x00b5
            int r0 = r6.getDescendantFocusability()
            r1 = 393216(0x60000, float:5.51013E-40)
            if (r0 == r1) goto L_0x00b5
            int r0 = r6.getDescendantFocusability()
            r1 = 131072(0x20000, float:1.83671E-40)
            if (r0 != r1) goto L_0x0025
            boolean r0 = r6.isFocused()
            if (r0 == 0) goto L_0x0025
            return
        L_0x0025:
            boolean r0 = r6.isFocused()
            if (r0 != 0) goto L_0x0054
            android.view.View r0 = r6.getFocusedChild()
            boolean r1 = f2841P
            if (r1 == 0) goto L_0x004b
            android.view.ViewParent r1 = r0.getParent()
            if (r1 == 0) goto L_0x003f
            boolean r1 = r0.hasFocus()
            if (r1 != 0) goto L_0x004b
        L_0x003f:
            android.support.v7.widget.ah r0 = r6.f2901g
            int r0 = r0.mo3581b()
            if (r0 != 0) goto L_0x0054
            r6.requestFocus()
            return
        L_0x004b:
            android.support.v7.widget.ah r1 = r6.f2901g
            boolean r0 = r1.mo3586c(r0)
            if (r0 != 0) goto L_0x0054
            return
        L_0x0054:
            android.support.v7.widget.ay$u r0 = r6.f2850D
            long r0 = r0.f3010m
            r2 = -1
            int r0 = (r0 > r2 ? 1 : (r0 == r2 ? 0 : -1))
            r1 = 0
            if (r0 == 0) goto L_0x0070
            android.support.v7.widget.ay$a r0 = r6.f2907m
            boolean r0 = r0.mo4020b()
            if (r0 == 0) goto L_0x0070
            android.support.v7.widget.ay$u r0 = r6.f2850D
            long r4 = r0.f3010m
            android.support.v7.widget.ay$x r0 = r6.mo3834a(r4)
            goto L_0x0071
        L_0x0070:
            r0 = r1
        L_0x0071:
            if (r0 == 0) goto L_0x0089
            android.support.v7.widget.ah r4 = r6.f2901g
            android.view.View r5 = r0.f3023a
            boolean r4 = r4.mo3586c(r5)
            if (r4 != 0) goto L_0x0089
            android.view.View r4 = r0.f3023a
            boolean r4 = r4.hasFocusable()
            if (r4 != 0) goto L_0x0086
            goto L_0x0089
        L_0x0086:
            android.view.View r1 = r0.f3023a
            goto L_0x0095
        L_0x0089:
            android.support.v7.widget.ah r0 = r6.f2901g
            int r0 = r0.mo3581b()
            if (r0 <= 0) goto L_0x0095
            android.view.View r1 = r6.m4043K()
        L_0x0095:
            if (r1 == 0) goto L_0x00b5
            android.support.v7.widget.ay$u r0 = r6.f2850D
            int r0 = r0.f3011n
            long r4 = (long) r0
            int r0 = (r4 > r2 ? 1 : (r4 == r2 ? 0 : -1))
            if (r0 == 0) goto L_0x00b1
            android.support.v7.widget.ay$u r0 = r6.f2850D
            int r0 = r0.f3011n
            android.view.View r0 = r1.findViewById(r0)
            if (r0 == 0) goto L_0x00b1
            boolean r2 = r0.isFocusable()
            if (r2 == 0) goto L_0x00b1
            goto L_0x00b2
        L_0x00b1:
            r0 = r1
        L_0x00b2:
            r0.requestFocus()
        L_0x00b5:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.p031v7.widget.C0805ay.m4044L():void");
    }

    /* renamed from: M */
    private void m4045M() {
        boolean z = true;
        this.f2850D.mo4221a(1);
        mo3846a(this.f2850D);
        this.f2850D.f3006i = false;
        mo3893e();
        this.f2902h.mo4471a();
        mo3937l();
        m4040H();
        m4041I();
        C0843u uVar = this.f2850D;
        if (!this.f2850D.f3007j || !this.f2852F) {
            z = false;
        }
        uVar.f3005h = z;
        this.f2852F = false;
        this.f2851E = false;
        this.f2850D.f3004g = this.f2850D.f3008k;
        this.f2850D.f3002e = this.f2907m.mo4007a();
        m4059a(this.f2867aD);
        if (this.f2850D.f3007j) {
            int b = this.f2901g.mo3581b();
            for (int i = 0; i < b; i++) {
                C0846x e = m4066e(this.f2901g.mo3583b(i));
                if (!e.mo4251c() && (!e.mo4262n() || this.f2907m.mo4020b())) {
                    this.f2902h.mo4473a(e, this.f2920z.mo4027a(this.f2850D, e, C0817f.m4198e(e), e.mo4270u()));
                    if (this.f2850D.f3005h && e.mo4275z() && !e.mo4265q() && !e.mo4251c() && !e.mo4262n()) {
                        this.f2902h.mo4472a(mo3832a(e), e);
                    }
                }
            }
        }
        if (this.f2850D.f3008k) {
            mo3962s();
            boolean z2 = this.f2850D.f3003f;
            this.f2850D.f3003f = false;
            this.f2908n.mo3182c(this.f2899e, this.f2850D);
            this.f2850D.f3003f = z2;
            for (int i2 = 0; i2 < this.f2901g.mo3581b(); i2++) {
                C0846x e2 = m4066e(this.f2901g.mo3583b(i2));
                if (!e2.mo4251c() && !this.f2902h.mo4481d(e2)) {
                    int e3 = C0817f.m4198e(e2);
                    boolean a = e2.mo4247a(8192);
                    if (!a) {
                        e3 |= 4096;
                    }
                    C0820c a2 = this.f2920z.mo4027a(this.f2850D, e2, e3, e2.mo4270u());
                    if (a) {
                        mo3847a(e2, a2);
                    } else {
                        this.f2902h.mo4478b(e2, a2);
                    }
                }
            }
        }
        mo3986t();
        mo3939m();
        mo3850a(false);
        this.f2850D.f3001d = 2;
    }

    /* renamed from: N */
    private void m4046N() {
        mo3893e();
        mo3937l();
        this.f2850D.mo4221a(6);
        this.f2900f.mo4530e();
        this.f2850D.f3002e = this.f2907m.mo4007a();
        this.f2850D.f3000c = 0;
        this.f2850D.f3004g = false;
        this.f2908n.mo3182c(this.f2899e, this.f2850D);
        this.f2850D.f3003f = false;
        this.f2859S = null;
        this.f2850D.f3007j = this.f2850D.f3007j && this.f2920z != null;
        this.f2850D.f3001d = 4;
        mo3939m();
        mo3850a(false);
    }

    /* renamed from: O */
    private void m4047O() {
        this.f2850D.mo4221a(4);
        mo3893e();
        mo3937l();
        this.f2850D.f3001d = 1;
        if (this.f2850D.f3007j) {
            for (int b = this.f2901g.mo3581b() - 1; b >= 0; b--) {
                C0846x e = m4066e(this.f2901g.mo3583b(b));
                if (!e.mo4251c()) {
                    long a = mo3832a(e);
                    C0820c a2 = this.f2920z.mo4026a(this.f2850D, e);
                    C0846x a3 = this.f2902h.mo4470a(a);
                    if (a3 != null && !a3.mo4251c()) {
                        boolean a4 = this.f2902h.mo4475a(a3);
                        boolean a5 = this.f2902h.mo4475a(e);
                        if (!a4 || a3 != e) {
                            C0820c b2 = this.f2902h.mo4476b(a3);
                            this.f2902h.mo4480c(e, a2);
                            C0820c c = this.f2902h.mo4479c(e);
                            if (b2 == null) {
                                m4050a(a, e, a3);
                            } else {
                                m4053a(a3, e, b2, c, a4, a5);
                            }
                        }
                    }
                    this.f2902h.mo4480c(e, a2);
                }
            }
            this.f2902h.mo4474a(this.f2872aI);
        }
        this.f2908n.mo4090b(this.f2899e);
        this.f2850D.f2999b = this.f2850D.f3002e;
        this.f2918x = false;
        this.f2919y = false;
        this.f2850D.f3007j = false;
        this.f2850D.f3008k = false;
        this.f2908n.f2952u = false;
        if (this.f2899e.f2974b != null) {
            this.f2899e.f2974b.clear();
        }
        if (this.f2908n.f2956y) {
            this.f2908n.f2955x = 0;
            this.f2908n.f2956y = false;
            this.f2899e.mo4178b();
        }
        this.f2908n.mo3170a(this.f2850D);
        mo3939m();
        mo3850a(false);
        this.f2902h.mo4471a();
        if (m4069k(this.f2867aD[0], this.f2867aD[1])) {
            mo3931i(0, 0);
        }
        m4044L();
        m4042J();
    }

    /* renamed from: a */
    private String m4048a(Context context, String str) {
        if (str.charAt(0) == '.') {
            StringBuilder sb = new StringBuilder();
            sb.append(context.getPackageName());
            sb.append(str);
            return sb.toString();
        } else if (str.contains(".")) {
            return str;
        } else {
            StringBuilder sb2 = new StringBuilder();
            sb2.append(C0805ay.class.getPackage().getName());
            sb2.append('.');
            sb2.append(str);
            return sb2.toString();
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:10:0x003d  */
    /* JADX WARNING: Removed duplicated region for block: B:11:0x0053  */
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private void m4049a(float r7, float r8, float r9, float r10) {
        /*
            r6 = this;
            r0 = 0
            int r1 = (r8 > r0 ? 1 : (r8 == r0 ? 0 : -1))
            r2 = 1065353216(0x3f800000, float:1.0)
            r3 = 1
            if (r1 >= 0) goto L_0x0021
            r6.mo3901g()
            android.widget.EdgeEffect r1 = r6.f2880ah
            float r4 = -r8
            int r5 = r6.getWidth()
            float r5 = (float) r5
            float r4 = r4 / r5
            int r5 = r6.getHeight()
            float r5 = (float) r5
            float r9 = r9 / r5
            float r9 = r2 - r9
        L_0x001c:
            android.support.p018v4.widget.C0525g.m2329a(r1, r4, r9)
            r9 = r3
            goto L_0x0039
        L_0x0021:
            int r1 = (r8 > r0 ? 1 : (r8 == r0 ? 0 : -1))
            if (r1 <= 0) goto L_0x0038
            r6.mo3924h()
            android.widget.EdgeEffect r1 = r6.f2882aj
            int r4 = r6.getWidth()
            float r4 = (float) r4
            float r4 = r8 / r4
            int r5 = r6.getHeight()
            float r5 = (float) r5
            float r9 = r9 / r5
            goto L_0x001c
        L_0x0038:
            r9 = 0
        L_0x0039:
            int r1 = (r10 > r0 ? 1 : (r10 == r0 ? 0 : -1))
            if (r1 >= 0) goto L_0x0053
            r6.mo3930i()
            android.widget.EdgeEffect r9 = r6.f2881ai
            float r1 = -r10
            int r2 = r6.getHeight()
            float r2 = (float) r2
            float r1 = r1 / r2
            int r2 = r6.getWidth()
            float r2 = (float) r2
            float r7 = r7 / r2
            android.support.p018v4.widget.C0525g.m2329a(r9, r1, r7)
            goto L_0x006f
        L_0x0053:
            int r1 = (r10 > r0 ? 1 : (r10 == r0 ? 0 : -1))
            if (r1 <= 0) goto L_0x006e
            r6.mo3933j()
            android.widget.EdgeEffect r9 = r6.f2883ak
            int r1 = r6.getHeight()
            float r1 = (float) r1
            float r1 = r10 / r1
            int r4 = r6.getWidth()
            float r4 = (float) r4
            float r7 = r7 / r4
            float r2 = r2 - r7
            android.support.p018v4.widget.C0525g.m2329a(r9, r1, r2)
            goto L_0x006f
        L_0x006e:
            r3 = r9
        L_0x006f:
            if (r3 != 0) goto L_0x0079
            int r7 = (r8 > r0 ? 1 : (r8 == r0 ? 0 : -1))
            if (r7 != 0) goto L_0x0079
            int r7 = (r10 > r0 ? 1 : (r10 == r0 ? 0 : -1))
            if (r7 == 0) goto L_0x007c
        L_0x0079:
            android.support.p018v4.p028h.C0495r.m2145d(r6)
        L_0x007c:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.p031v7.widget.C0805ay.m4049a(float, float, float, float):void");
    }

    /* renamed from: a */
    private void m4050a(long j, C0846x xVar, C0846x xVar2) {
        int b = this.f2901g.mo3581b();
        int i = 0;
        while (i < b) {
            C0846x e = m4066e(this.f2901g.mo3583b(i));
            if (e == xVar || mo3832a(e) != j) {
                i++;
            } else if (this.f2907m == null || !this.f2907m.mo4020b()) {
                StringBuilder sb = new StringBuilder();
                sb.append("Two different ViewHolders have the same change ID. This might happen due to inconsistent Adapter update events or if the LayoutManager lays out the same View multiple times.\n ViewHolder 1:");
                sb.append(e);
                sb.append(" \n View Holder 2:");
                sb.append(xVar);
                sb.append(mo3835a());
                throw new IllegalStateException(sb.toString());
            } else {
                StringBuilder sb2 = new StringBuilder();
                sb2.append("Two different ViewHolders have the same stable ID. Stable IDs in your adapter MUST BE unique and SHOULD NOT change.\n ViewHolder 1:");
                sb2.append(e);
                sb2.append(" \n View Holder 2:");
                sb2.append(xVar);
                sb2.append(mo3835a());
                throw new IllegalStateException(sb2.toString());
            }
        }
        StringBuilder sb3 = new StringBuilder();
        sb3.append("Problem while matching changed view holders with the newones. The pre-layout information for the change holder ");
        sb3.append(xVar2);
        sb3.append(" cannot be found but it is necessary for ");
        sb3.append(xVar);
        sb3.append(mo3835a());
        Log.e("RecyclerView", sb3.toString());
    }

    /* renamed from: a */
    private void m4051a(Context context, String str, AttributeSet attributeSet, int i, int i2) {
        Constructor constructor;
        if (str != null) {
            String trim = str.trim();
            if (!trim.isEmpty()) {
                String a = m4048a(context, trim);
                try {
                    Class asSubclass = (isInEditMode() ? getClass().getClassLoader() : context.getClassLoader()).loadClass(a).asSubclass(C0823i.class);
                    Object[] objArr = null;
                    try {
                        constructor = asSubclass.getConstructor(f2842Q);
                        objArr = new Object[]{context, attributeSet, Integer.valueOf(i), Integer.valueOf(i2)};
                    } catch (NoSuchMethodException e) {
                        constructor = asSubclass.getConstructor(new Class[0]);
                    }
                    constructor.setAccessible(true);
                    setLayoutManager((C0823i) constructor.newInstance(objArr));
                } catch (NoSuchMethodException e2) {
                    e2.initCause(e);
                    StringBuilder sb = new StringBuilder();
                    sb.append(attributeSet.getPositionDescription());
                    sb.append(": Error creating LayoutManager ");
                    sb.append(a);
                    throw new IllegalStateException(sb.toString(), e2);
                } catch (ClassNotFoundException e3) {
                    StringBuilder sb2 = new StringBuilder();
                    sb2.append(attributeSet.getPositionDescription());
                    sb2.append(": Unable to find LayoutManager ");
                    sb2.append(a);
                    throw new IllegalStateException(sb2.toString(), e3);
                } catch (InvocationTargetException e4) {
                    StringBuilder sb3 = new StringBuilder();
                    sb3.append(attributeSet.getPositionDescription());
                    sb3.append(": Could not instantiate the LayoutManager: ");
                    sb3.append(a);
                    throw new IllegalStateException(sb3.toString(), e4);
                } catch (InstantiationException e5) {
                    StringBuilder sb4 = new StringBuilder();
                    sb4.append(attributeSet.getPositionDescription());
                    sb4.append(": Could not instantiate the LayoutManager: ");
                    sb4.append(a);
                    throw new IllegalStateException(sb4.toString(), e5);
                } catch (IllegalAccessException e6) {
                    StringBuilder sb5 = new StringBuilder();
                    sb5.append(attributeSet.getPositionDescription());
                    sb5.append(": Cannot access non-public constructor ");
                    sb5.append(a);
                    throw new IllegalStateException(sb5.toString(), e6);
                } catch (ClassCastException e7) {
                    StringBuilder sb6 = new StringBuilder();
                    sb6.append(attributeSet.getPositionDescription());
                    sb6.append(": Class is not a LayoutManager ");
                    sb6.append(a);
                    throw new IllegalStateException(sb6.toString(), e7);
                }
            }
        }
    }

    /* renamed from: a */
    private void m4052a(C0812a aVar, boolean z, boolean z2) {
        if (this.f2907m != null) {
            this.f2907m.mo4017b((C0814c) this.f2858R);
            this.f2907m.mo4019b(this);
        }
        if (!z || z2) {
            mo3870c();
        }
        this.f2900f.mo4521a();
        C0812a aVar2 = this.f2907m;
        this.f2907m = aVar;
        if (aVar != null) {
            aVar.mo4010a((C0814c) this.f2858R);
            aVar.mo4014a(this);
        }
        if (this.f2908n != null) {
            this.f2908n.mo4063a(aVar2, this.f2907m);
        }
        this.f2899e.mo4170a(aVar2, this.f2907m, z);
        this.f2850D.f3003f = true;
    }

    /* renamed from: a */
    private void m4053a(C0846x xVar, C0846x xVar2, C0820c cVar, C0820c cVar2, boolean z, boolean z2) {
        xVar.mo4246a(false);
        if (z) {
            m4067e(xVar);
        }
        if (xVar != xVar2) {
            if (z2) {
                m4067e(xVar2);
            }
            xVar.f3030h = xVar2;
            m4067e(xVar);
            this.f2899e.mo4185c(xVar);
            xVar2.mo4246a(false);
            xVar2.f3031i = xVar;
        }
        if (this.f2920z.mo4030a(xVar, xVar2, cVar, cVar2)) {
            mo3954p();
        }
    }

    /* renamed from: a */
    static void m4057a(View view, Rect rect) {
        C0828j jVar = (C0828j) view.getLayoutParams();
        Rect rect2 = jVar.f2964d;
        rect.set((view.getLeft() - rect2.left) - jVar.leftMargin, (view.getTop() - rect2.top) - jVar.topMargin, view.getRight() + rect2.right + jVar.rightMargin, view.getBottom() + rect2.bottom + jVar.bottomMargin);
    }

    /* renamed from: a */
    private void m4058a(View view, View view2) {
        View view3 = view2 != null ? view2 : view;
        this.f2905k.set(0, 0, view3.getWidth(), view3.getHeight());
        LayoutParams layoutParams = view3.getLayoutParams();
        if (layoutParams instanceof C0828j) {
            C0828j jVar = (C0828j) layoutParams;
            if (!jVar.f2965e) {
                Rect rect = jVar.f2964d;
                this.f2905k.left -= rect.left;
                this.f2905k.right += rect.right;
                this.f2905k.top -= rect.top;
                this.f2905k.bottom += rect.bottom;
            }
        }
        if (view2 != null) {
            offsetDescendantRectToMyCoords(view2, this.f2905k);
            offsetRectIntoDescendantCoords(view, this.f2905k);
        }
        this.f2908n.mo4083a(this, view, this.f2905k, !this.f2914t, view2 == null);
    }

    /* renamed from: a */
    private void m4059a(int[] iArr) {
        int b = this.f2901g.mo3581b();
        if (b == 0) {
            iArr[0] = -1;
            iArr[1] = -1;
            return;
        }
        int i = Integer.MIN_VALUE;
        int i2 = Integer.MAX_VALUE;
        for (int i3 = 0; i3 < b; i3++) {
            C0846x e = m4066e(this.f2901g.mo3583b(i3));
            if (!e.mo4251c()) {
                int d = e.mo4252d();
                if (d < i2) {
                    i2 = d;
                }
                if (d > i) {
                    i = d;
                }
            }
        }
        iArr[0] = i2;
        iArr[1] = i;
    }

    /* renamed from: a */
    private boolean m4061a(MotionEvent motionEvent) {
        int action = motionEvent.getAction();
        if (action == 3 || action == 0) {
            this.f2862V = null;
        }
        int size = this.f2861U.size();
        int i = 0;
        while (i < size) {
            C0831m mVar = (C0831m) this.f2861U.get(i);
            if (!mVar.mo3696a(this, motionEvent) || action == 3) {
                i++;
            } else {
                this.f2862V = mVar;
                return true;
            }
        }
        return false;
    }

    /* renamed from: a */
    private boolean m4062a(View view, View view2, int i) {
        boolean z = false;
        if (view2 != null) {
            if (view2 == this || mo3869c(view2) == null) {
                return false;
            }
            if (view == null || mo3869c(view) == null) {
                return true;
            }
            this.f2905k.set(0, 0, view.getWidth(), view.getHeight());
            this.f2860T.set(0, 0, view2.getWidth(), view2.getHeight());
            offsetDescendantRectToMyCoords(view, this.f2905k);
            offsetDescendantRectToMyCoords(view2, this.f2860T);
            char c = 65535;
            int i2 = this.f2908n.mo4132t() == 1 ? -1 : 1;
            int i3 = ((this.f2905k.left < this.f2860T.left || this.f2905k.right <= this.f2860T.left) && this.f2905k.right < this.f2860T.right) ? 1 : ((this.f2905k.right > this.f2860T.right || this.f2905k.left >= this.f2860T.right) && this.f2905k.left > this.f2860T.left) ? -1 : 0;
            if ((this.f2905k.top < this.f2860T.top || this.f2905k.bottom <= this.f2860T.top) && this.f2905k.bottom < this.f2860T.bottom) {
                c = 1;
            } else if ((this.f2905k.bottom <= this.f2860T.bottom && this.f2905k.top < this.f2860T.bottom) || this.f2905k.top <= this.f2860T.top) {
                c = 0;
            }
            if (i != 17) {
                if (i == 33) {
                    if (c < 0) {
                        z = true;
                    }
                    return z;
                } else if (i == 66) {
                    if (i3 > 0) {
                        z = true;
                    }
                    return z;
                } else if (i != 130) {
                    switch (i) {
                        case 1:
                            if (c < 0 || (c == 0 && i3 * i2 <= 0)) {
                                z = true;
                            }
                            return z;
                        case 2:
                            if (c > 0 || (c == 0 && i3 * i2 >= 0)) {
                                z = true;
                            }
                            return z;
                        default:
                            StringBuilder sb = new StringBuilder();
                            sb.append("Invalid direction: ");
                            sb.append(i);
                            sb.append(mo3835a());
                            throw new IllegalArgumentException(sb.toString());
                    }
                } else {
                    if (c > 0) {
                        z = true;
                    }
                    return z;
                }
            } else if (i3 < 0) {
                z = true;
            }
        }
        return z;
    }

    /* renamed from: b */
    private boolean m4063b(MotionEvent motionEvent) {
        int action = motionEvent.getAction();
        if (this.f2862V != null) {
            if (action == 0) {
                this.f2862V = null;
            } else {
                this.f2862V.mo3699b(this, motionEvent);
                if (action == 3 || action == 1) {
                    this.f2862V = null;
                }
                return true;
            }
        }
        if (action != 0) {
            int size = this.f2861U.size();
            for (int i = 0; i < size; i++) {
                C0831m mVar = (C0831m) this.f2861U.get(i);
                if (mVar.mo3696a(this, motionEvent)) {
                    this.f2862V = mVar;
                    return true;
                }
            }
        }
        return false;
    }

    /* renamed from: c */
    static void m4064c(C0846x xVar) {
        if (xVar.f3024b != null) {
            Object obj = xVar.f3024b.get();
            loop0:
            while (true) {
                View view = (View) obj;
                while (true) {
                    if (view == null) {
                        xVar.f3024b = null;
                        break loop0;
                    } else if (view != xVar.f3023a) {
                        obj = view.getParent();
                        if (!(obj instanceof View)) {
                            view = null;
                        }
                    } else {
                        return;
                    }
                }
            }
        }
    }

    /* renamed from: c */
    private void m4065c(MotionEvent motionEvent) {
        int actionIndex = motionEvent.getActionIndex();
        if (motionEvent.getPointerId(actionIndex) == this.f2885am) {
            int i = actionIndex == 0 ? 1 : 0;
            this.f2885am = motionEvent.getPointerId(i);
            int x = (int) (motionEvent.getX(i) + 0.5f);
            this.f2889aq = x;
            this.f2887ao = x;
            int y = (int) (motionEvent.getY(i) + 0.5f);
            this.f2890ar = y;
            this.f2888ap = y;
        }
    }

    /* renamed from: e */
    static C0846x m4066e(View view) {
        if (view == null) {
            return null;
        }
        return ((C0828j) view.getLayoutParams()).f2963c;
    }

    /* renamed from: e */
    private void m4067e(C0846x xVar) {
        View view = xVar.f3023a;
        boolean z = view.getParent() == this;
        this.f2899e.mo4185c(mo3858b(view));
        if (xVar.mo4266r()) {
            this.f2901g.mo3578a(view, -1, view.getLayoutParams(), true);
        } else if (!z) {
            this.f2901g.mo3580a(view, true);
        } else {
            this.f2901g.mo3588d(view);
        }
    }

    private C0489l getScrollingChildHelper() {
        if (this.f2868aE == null) {
            this.f2868aE = new C0489l(this);
        }
        return this.f2868aE;
    }

    /* renamed from: j */
    static C0805ay m4068j(View view) {
        if (!(view instanceof ViewGroup)) {
            return null;
        }
        if (view instanceof C0805ay) {
            return (C0805ay) view;
        }
        ViewGroup viewGroup = (ViewGroup) view;
        int childCount = viewGroup.getChildCount();
        for (int i = 0; i < childCount; i++) {
            C0805ay j = m4068j(viewGroup.getChildAt(i));
            if (j != null) {
                return j;
            }
        }
        return null;
    }

    /* renamed from: k */
    private boolean m4069k(int i, int i2) {
        m4059a(this.f2867aD);
        return (this.f2867aD[0] == i && this.f2867aD[1] == i2) ? false : true;
    }

    /* renamed from: m */
    private int m4070m(View view) {
        int id;
        loop0:
        while (true) {
            id = view.getId();
            while (true) {
                if (view.isFocused() || !(view instanceof ViewGroup) || !view.hasFocus()) {
                    return id;
                }
                view = ((ViewGroup) view).getFocusedChild();
                if (view.getId() != -1) {
                }
            }
        }
        return id;
    }

    @SuppressLint({"InlinedApi"})
    /* renamed from: y */
    private void m4071y() {
        if (C0495r.m2121a(this) == 0) {
            C0495r.m2125a((View) this, 8);
        }
    }

    /* renamed from: z */
    private void m4072z() {
        this.f2901g = new C0752ah(new C0754b() {
            /* renamed from: a */
            public int mo3601a() {
                return C0805ay.this.getChildCount();
            }

            /* renamed from: a */
            public int mo3602a(View view) {
                return C0805ay.this.indexOfChild(view);
            }

            /* renamed from: a */
            public void mo3603a(int i) {
                View childAt = C0805ay.this.getChildAt(i);
                if (childAt != null) {
                    C0805ay.this.mo3936k(childAt);
                    childAt.clearAnimation();
                }
                C0805ay.this.removeViewAt(i);
            }

            /* renamed from: a */
            public void mo3604a(View view, int i) {
                C0805ay.this.addView(view, i);
                C0805ay.this.mo3938l(view);
            }

            /* renamed from: a */
            public void mo3605a(View view, int i, LayoutParams layoutParams) {
                C0846x e = C0805ay.m4066e(view);
                if (e != null) {
                    if (e.mo4266r() || e.mo4251c()) {
                        e.mo4261m();
                    } else {
                        StringBuilder sb = new StringBuilder();
                        sb.append("Called attach on a child which is not detached: ");
                        sb.append(e);
                        sb.append(C0805ay.this.mo3835a());
                        throw new IllegalArgumentException(sb.toString());
                    }
                }
                C0805ay.this.attachViewToParent(view, i, layoutParams);
            }

            /* renamed from: b */
            public C0846x mo3606b(View view) {
                return C0805ay.m4066e(view);
            }

            /* renamed from: b */
            public View mo3607b(int i) {
                return C0805ay.this.getChildAt(i);
            }

            /* renamed from: b */
            public void mo3608b() {
                int a = mo3601a();
                for (int i = 0; i < a; i++) {
                    View b = mo3607b(i);
                    C0805ay.this.mo3936k(b);
                    b.clearAnimation();
                }
                C0805ay.this.removeAllViews();
            }

            /* renamed from: c */
            public void mo3609c(int i) {
                View b = mo3607b(i);
                if (b != null) {
                    C0846x e = C0805ay.m4066e(b);
                    if (e != null) {
                        if (!e.mo4266r() || e.mo4251c()) {
                            e.mo4249b(256);
                        } else {
                            StringBuilder sb = new StringBuilder();
                            sb.append("called detach on an already detached child ");
                            sb.append(e);
                            sb.append(C0805ay.this.mo3835a());
                            throw new IllegalArgumentException(sb.toString());
                        }
                    }
                }
                C0805ay.this.detachViewFromParent(i);
            }

            /* renamed from: c */
            public void mo3610c(View view) {
                C0846x e = C0805ay.m4066e(view);
                if (e != null) {
                    e.mo4244a(C0805ay.this);
                }
            }

            /* renamed from: d */
            public void mo3611d(View view) {
                C0846x e = C0805ay.m4066e(view);
                if (e != null) {
                    e.mo4250b(C0805ay.this);
                }
            }
        });
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public long mo3832a(C0846x xVar) {
        return this.f2907m.mo4020b() ? xVar.mo4255g() : (long) xVar.f3025c;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public C0846x mo3833a(int i, boolean z) {
        int c = this.f2901g.mo3584c();
        C0846x xVar = null;
        for (int i2 = 0; i2 < c; i2++) {
            C0846x e = m4066e(this.f2901g.mo3587d(i2));
            if (e != null && !e.mo4265q()) {
                if (z) {
                    if (e.f3025c != i) {
                        continue;
                    }
                } else if (e.mo4252d() != i) {
                    continue;
                }
                if (!this.f2901g.mo3586c(e.f3023a)) {
                    return e;
                }
                xVar = e;
            }
        }
        return xVar;
    }

    /* renamed from: a */
    public C0846x mo3834a(long j) {
        C0846x xVar = null;
        if (this.f2907m != null) {
            if (!this.f2907m.mo4020b()) {
                return null;
            }
            int c = this.f2901g.mo3584c();
            for (int i = 0; i < c; i++) {
                C0846x e = m4066e(this.f2901g.mo3587d(i));
                if (e != null && !e.mo4265q() && e.mo4255g() == j) {
                    if (!this.f2901g.mo3586c(e.f3023a)) {
                        return e;
                    }
                    xVar = e;
                }
            }
        }
        return xVar;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public String mo3835a() {
        StringBuilder sb = new StringBuilder();
        sb.append(" ");
        sb.append(super.toString());
        sb.append(", adapter:");
        sb.append(this.f2907m);
        sb.append(", layout:");
        sb.append(this.f2908n);
        sb.append(", context:");
        sb.append(getContext());
        return sb.toString();
    }

    /* renamed from: a */
    public void mo1929a(int i) {
        getScrollingChildHelper().mo1943c(i);
    }

    /* renamed from: a */
    public void mo3836a(int i, int i2) {
        mo3837a(i, i2, (Interpolator) null);
    }

    /* renamed from: a */
    public void mo3837a(int i, int i2, Interpolator interpolator) {
        if (this.f2908n == null) {
            Log.e("RecyclerView", "Cannot smooth scroll without a LayoutManager set. Call setLayoutManager with a non-null argument.");
        } else if (!this.f2916v) {
            if (!this.f2908n.mo3212e()) {
                i = 0;
            }
            if (!this.f2908n.mo3215f()) {
                i2 = 0;
            }
            if (!(i == 0 && i2 == 0)) {
                this.f2847A.mo4235a(i, i2, interpolator);
            }
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo3838a(int i, int i2, Object obj) {
        int c = this.f2901g.mo3584c();
        int i3 = i + i2;
        for (int i4 = 0; i4 < c; i4++) {
            View d = this.f2901g.mo3587d(i4);
            C0846x e = m4066e(d);
            if (e != null && !e.mo4251c() && e.f3025c >= i && e.f3025c < i3) {
                e.mo4249b(2);
                e.mo4245a(obj);
                ((C0828j) d.getLayoutParams()).f2965e = true;
            }
        }
        this.f2899e.mo4184c(i, i2);
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo3839a(int i, int i2, boolean z) {
        int i3 = i + i2;
        int c = this.f2901g.mo3584c();
        for (int i4 = 0; i4 < c; i4++) {
            C0846x e = m4066e(this.f2901g.mo3587d(i4));
            if (e != null && !e.mo4251c()) {
                if (e.f3025c >= i3) {
                    e.mo4242a(-i2, z);
                } else if (e.f3025c >= i) {
                    e.mo4241a(i - 1, -i2, z);
                }
                this.f2850D.f3003f = true;
            }
        }
        this.f2899e.mo4169a(i, i2, z);
        requestLayout();
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo3840a(int i, int i2, int[] iArr) {
        mo3893e();
        mo3937l();
        C0393a.m1731a("RV Scroll");
        mo3846a(this.f2850D);
        int a = i != 0 ? this.f2908n.mo3158a(i, this.f2899e, this.f2850D) : 0;
        int b = i2 != 0 ? this.f2908n.mo3178b(i2, this.f2899e, this.f2850D) : 0;
        C0393a.m1730a();
        mo3989w();
        mo3939m();
        mo3850a(false);
        if (iArr != null) {
            iArr[0] = a;
            iArr[1] = b;
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo3841a(StateListDrawable stateListDrawable, Drawable drawable, StateListDrawable stateListDrawable2, Drawable drawable2) {
        if (stateListDrawable == null || drawable == null || stateListDrawable2 == null || drawable2 == null) {
            StringBuilder sb = new StringBuilder();
            sb.append("Trying to set fast scroller without both required drawables.");
            sb.append(mo3835a());
            throw new IllegalArgumentException(sb.toString());
        }
        Resources resources = getContext().getResources();
        new C0772an(this, stateListDrawable, drawable, stateListDrawable2, drawable2, resources.getDimensionPixelSize(C0624a.fastscroll_default_thickness), resources.getDimensionPixelSize(C0624a.fastscroll_minimum_range), resources.getDimensionPixelOffset(C0624a.fastscroll_margin));
    }

    /* renamed from: a */
    public void mo3842a(C0822h hVar) {
        mo3843a(hVar, -1);
    }

    /* renamed from: a */
    public void mo3843a(C0822h hVar, int i) {
        if (this.f2908n != null) {
            this.f2908n.mo3198a("Cannot add item decoration during a scroll  or layout");
        }
        if (this.f2910p.isEmpty()) {
            setWillNotDraw(false);
        }
        if (i < 0) {
            this.f2910p.add(hVar);
        } else {
            this.f2910p.add(i, hVar);
        }
        mo3956r();
        requestLayout();
    }

    /* renamed from: a */
    public void mo3844a(C0831m mVar) {
        this.f2861U.add(mVar);
    }

    /* renamed from: a */
    public void mo3845a(C0832n nVar) {
        if (this.f2864aA == null) {
            this.f2864aA = new ArrayList();
        }
        this.f2864aA.add(nVar);
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public final void mo3846a(C0843u uVar) {
        if (getScrollState() == 2) {
            OverScroller overScroller = this.f2847A.f3015a;
            uVar.f3012o = overScroller.getFinalX() - overScroller.getCurrX();
            uVar.f3013p = overScroller.getFinalY() - overScroller.getCurrY();
            return;
        }
        uVar.f3012o = 0;
        uVar.f3013p = 0;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo3847a(C0846x xVar, C0820c cVar) {
        xVar.mo4240a(0, 8192);
        if (this.f2850D.f3005h && xVar.mo4275z() && !xVar.mo4265q() && !xVar.mo4251c()) {
            this.f2902h.mo4472a(mo3832a(xVar), xVar);
        }
        this.f2902h.mo4473a(xVar, cVar);
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo3848a(C0846x xVar, C0820c cVar, C0820c cVar2) {
        xVar.mo4246a(false);
        if (this.f2920z.mo4031b(xVar, cVar, cVar2)) {
            mo3954p();
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo3849a(String str) {
        if (mo3941o()) {
            if (str == null) {
                StringBuilder sb = new StringBuilder();
                sb.append("Cannot call this method while RecyclerView is computing a layout or scrolling");
                sb.append(mo3835a());
                throw new IllegalStateException(sb.toString());
            }
            throw new IllegalStateException(str);
        } else if (this.f2878af > 0) {
            StringBuilder sb2 = new StringBuilder();
            sb2.append("");
            sb2.append(mo3835a());
            Log.w("RecyclerView", "Cannot call this method in a scroll callback. Scroll callbacks mightbe run during a measure & layout pass where you cannot change theRecyclerView data. Any method call that might change the structureof the RecyclerView or the adapter contents should be postponed tothe next frame.", new IllegalStateException(sb2.toString()));
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo3850a(boolean z) {
        if (this.f2863W < 1) {
            this.f2863W = 1;
        }
        if (!z && !this.f2916v) {
            this.f2915u = false;
        }
        if (this.f2863W == 1) {
            if (z && this.f2915u && !this.f2916v && this.f2908n != null && this.f2907m != null) {
                mo3955q();
            }
            if (!this.f2916v) {
                this.f2915u = false;
            }
        }
        this.f2863W--;
    }

    /* renamed from: a */
    public boolean mo3851a(int i, int i2, int i3, int i4, int[] iArr, int i5) {
        return getScrollingChildHelper().mo1937a(i, i2, i3, i4, iArr, i5);
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public boolean mo3852a(int i, int i2, MotionEvent motionEvent) {
        int i3;
        int i4;
        int i5;
        int i6;
        int i7 = i;
        int i8 = i2;
        MotionEvent motionEvent2 = motionEvent;
        mo3882d();
        boolean z = true;
        if (this.f2907m != null) {
            mo3840a(i7, i8, this.f2856J);
            int i9 = this.f2856J[0];
            int i10 = this.f2856J[1];
            i5 = i9;
            i4 = i10;
            i3 = i7 - i9;
            i6 = i8 - i10;
        } else {
            i6 = 0;
            i5 = 0;
            i4 = 0;
            i3 = 0;
        }
        if (!this.f2910p.isEmpty()) {
            invalidate();
        }
        int i11 = i6;
        if (mo3851a(i5, i4, i3, i6, this.f2869aF, 0)) {
            this.f2889aq -= this.f2869aF[0];
            this.f2890ar -= this.f2869aF[1];
            if (motionEvent2 != null) {
                motionEvent2.offsetLocation((float) this.f2869aF[0], (float) this.f2869aF[1]);
            }
            int[] iArr = this.f2870aG;
            iArr[0] = iArr[0] + this.f2869aF[0];
            int[] iArr2 = this.f2870aG;
            iArr2[1] = iArr2[1] + this.f2869aF[1];
        } else if (getOverScrollMode() != 2) {
            if (motionEvent2 != null && !C0486i.m2090a(motionEvent2, 8194)) {
                m4049a(motionEvent.getX(), (float) i3, motionEvent.getY(), (float) i11);
            }
            mo3871c(i, i2);
        }
        if (!(i5 == 0 && i4 == 0)) {
            mo3931i(i5, i4);
        }
        if (!awakenScrollBars()) {
            invalidate();
        }
        if (i5 == 0) {
            if (i4 != 0) {
                return true;
            }
            z = false;
        }
        return z;
    }

    /* renamed from: a */
    public boolean mo3853a(int i, int i2, int[] iArr, int[] iArr2, int i3) {
        return getScrollingChildHelper().mo1939a(i, i2, iArr, iArr2, i3);
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public boolean mo3854a(C0846x xVar, int i) {
        if (mo3941o()) {
            xVar.f3037o = i;
            this.f2857K.add(xVar);
            return false;
        }
        C0495r.m2139b(xVar.f3023a, i);
        return true;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public boolean mo3855a(View view) {
        mo3893e();
        boolean f = this.f2901g.mo3591f(view);
        if (f) {
            C0846x e = m4066e(view);
            this.f2899e.mo4185c(e);
            this.f2899e.mo4180b(e);
        }
        mo3850a(!f);
        return f;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public boolean mo3856a(AccessibilityEvent accessibilityEvent) {
        if (!mo3941o()) {
            return false;
        }
        int a = accessibilityEvent != null ? C0460a.m2005a(accessibilityEvent) : 0;
        if (a == 0) {
            a = 0;
        }
        this.f2874ab = a | this.f2874ab;
        return true;
    }

    public void addFocusables(ArrayList<View> arrayList, int i, int i2) {
        if (this.f2908n == null || !this.f2908n.mo4085a(this, arrayList, i, i2)) {
            super.addFocusables(arrayList, i, i2);
        }
    }

    /* renamed from: b */
    public C0846x mo3858b(View view) {
        ViewParent parent = view.getParent();
        if (parent == null || parent == this) {
            return m4066e(view);
        }
        StringBuilder sb = new StringBuilder();
        sb.append("View ");
        sb.append(view);
        sb.append(" is not a direct child of ");
        sb.append(this);
        throw new IllegalArgumentException(sb.toString());
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: b */
    public void mo3859b() {
        this.f2900f = new C0901e(new C0902a() {
            /* renamed from: a */
            public C0846x mo3998a(int i) {
                C0846x a = C0805ay.this.mo3833a(i, true);
                if (a != null && !C0805ay.this.f2901g.mo3586c(a.f3023a)) {
                    return a;
                }
                return null;
            }

            /* renamed from: a */
            public void mo3999a(int i, int i2) {
                C0805ay.this.mo3839a(i, i2, true);
                C0805ay.this.f2851E = true;
                C0805ay.this.f2850D.f3000c += i2;
            }

            /* renamed from: a */
            public void mo4000a(int i, int i2, Object obj) {
                C0805ay.this.mo3838a(i, i2, obj);
                C0805ay.this.f2852F = true;
            }

            /* renamed from: a */
            public void mo4001a(C0903b bVar) {
                mo4005c(bVar);
            }

            /* renamed from: b */
            public void mo4002b(int i, int i2) {
                C0805ay.this.mo3839a(i, i2, false);
                C0805ay.this.f2851E = true;
            }

            /* renamed from: b */
            public void mo4003b(C0903b bVar) {
                mo4005c(bVar);
            }

            /* renamed from: c */
            public void mo4004c(int i, int i2) {
                C0805ay.this.mo3903g(i, i2);
                C0805ay.this.f2851E = true;
            }

            /* access modifiers changed from: 0000 */
            /* renamed from: c */
            public void mo4005c(C0903b bVar) {
                int i = bVar.f3265a;
                if (i == 4) {
                    C0805ay.this.f2908n.mo3175a(C0805ay.this, bVar.f3266b, bVar.f3268d, bVar.f3267c);
                } else if (i != 8) {
                    switch (i) {
                        case 1:
                            C0805ay.this.f2908n.mo3173a(C0805ay.this, bVar.f3266b, bVar.f3268d);
                            return;
                        case 2:
                            C0805ay.this.f2908n.mo3180b(C0805ay.this, bVar.f3266b, bVar.f3268d);
                            return;
                        default:
                            return;
                    }
                } else {
                    C0805ay.this.f2908n.mo3174a(C0805ay.this, bVar.f3266b, bVar.f3268d, 1);
                }
            }

            /* renamed from: d */
            public void mo4006d(int i, int i2) {
                C0805ay.this.mo3899f(i, i2);
                C0805ay.this.f2851E = true;
            }
        });
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: b */
    public void mo3860b(int i) {
        if (this.f2908n != null) {
            this.f2908n.mo3211e(i);
            awakenScrollBars();
        }
    }

    /* renamed from: b */
    public void mo3861b(C0822h hVar) {
        if (this.f2908n != null) {
            this.f2908n.mo3198a("Cannot remove item decoration during a scroll  or layout");
        }
        this.f2910p.remove(hVar);
        if (this.f2910p.isEmpty()) {
            setWillNotDraw(getOverScrollMode() == 2);
        }
        mo3956r();
        requestLayout();
    }

    /* renamed from: b */
    public void mo3862b(C0831m mVar) {
        this.f2861U.remove(mVar);
        if (this.f2862V == mVar) {
            this.f2862V = null;
        }
    }

    /* renamed from: b */
    public void mo3863b(C0832n nVar) {
        if (this.f2864aA != null) {
            this.f2864aA.remove(nVar);
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: b */
    public void mo3864b(C0846x xVar, C0820c cVar, C0820c cVar2) {
        m4067e(xVar);
        xVar.mo4246a(false);
        if (this.f2920z.mo4029a(xVar, cVar, cVar2)) {
            mo3954p();
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: b */
    public void mo3865b(boolean z) {
        this.f2877ae--;
        if (this.f2877ae < 1) {
            this.f2877ae = 0;
            if (z) {
                m4038F();
                mo3990x();
            }
        }
    }

    /* renamed from: b */
    public boolean mo3866b(int i, int i2) {
        int i3 = 0;
        if (this.f2908n == null) {
            Log.e("RecyclerView", "Cannot fling without a LayoutManager set. Call setLayoutManager with a non-null argument.");
            return false;
        } else if (this.f2916v) {
            return false;
        } else {
            boolean e = this.f2908n.mo3212e();
            boolean f = this.f2908n.mo3215f();
            if (!e || Math.abs(i) < this.f2893au) {
                i = 0;
            }
            if (!f || Math.abs(i2) < this.f2893au) {
                i2 = 0;
            }
            if (i == 0 && i2 == 0) {
                return false;
            }
            float f2 = (float) i;
            float f3 = (float) i2;
            if (!dispatchNestedPreFling(f2, f3)) {
                boolean z = e || f;
                dispatchNestedFling(f2, f3, z);
                if (this.f2892at != null && this.f2892at.mo4150a(i, i2)) {
                    return true;
                }
                if (z) {
                    if (e) {
                        i3 = 1;
                    }
                    if (f) {
                        i3 |= 2;
                    }
                    mo3934j(i3, 1);
                    this.f2847A.mo4231a(Math.max(-this.f2894av, Math.min(i, this.f2894av)), Math.max(-this.f2894av, Math.min(i2, this.f2894av)));
                    return true;
                }
            }
            return false;
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: b */
    public boolean mo3867b(C0846x xVar) {
        return this.f2920z == null || this.f2920z.mo3648a(xVar, xVar.mo4270u());
    }

    /* renamed from: c */
    public C0846x mo3868c(int i) {
        C0846x xVar = null;
        if (this.f2918x) {
            return null;
        }
        int c = this.f2901g.mo3584c();
        for (int i2 = 0; i2 < c; i2++) {
            C0846x e = m4066e(this.f2901g.mo3587d(i2));
            if (e != null && !e.mo4265q() && mo3880d(e) == i) {
                if (!this.f2901g.mo3586c(e.f3023a)) {
                    return e;
                }
                xVar = e;
            }
        }
        return xVar;
    }

    /* JADX WARNING: Removed duplicated region for block: B:7:0x0012 A[RETURN] */
    /* JADX WARNING: Removed duplicated region for block: B:8:0x0013  */
    /* renamed from: c */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public android.view.View mo3869c(android.view.View r3) {
        /*
            r2 = this;
        L_0x0000:
            android.view.ViewParent r0 = r3.getParent()
            if (r0 == 0) goto L_0x0010
            if (r0 == r2) goto L_0x0010
            boolean r1 = r0 instanceof android.view.View
            if (r1 == 0) goto L_0x0010
            r3 = r0
            android.view.View r3 = (android.view.View) r3
            goto L_0x0000
        L_0x0010:
            if (r0 != r2) goto L_0x0013
            return r3
        L_0x0013:
            r3 = 0
            return r3
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.p031v7.widget.C0805ay.mo3869c(android.view.View):android.view.View");
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: c */
    public void mo3870c() {
        if (this.f2920z != null) {
            this.f2920z.mo3654d();
        }
        if (this.f2908n != null) {
            this.f2908n.mo4098c(this.f2899e);
            this.f2908n.mo4090b(this.f2899e);
        }
        this.f2899e.mo4166a();
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: c */
    public void mo3871c(int i, int i2) {
        boolean z;
        if (this.f2880ah == null || this.f2880ah.isFinished() || i <= 0) {
            z = false;
        } else {
            this.f2880ah.onRelease();
            z = this.f2880ah.isFinished();
        }
        if (this.f2882aj != null && !this.f2882aj.isFinished() && i < 0) {
            this.f2882aj.onRelease();
            z |= this.f2882aj.isFinished();
        }
        if (this.f2881ai != null && !this.f2881ai.isFinished() && i2 > 0) {
            this.f2881ai.onRelease();
            z |= this.f2881ai.isFinished();
        }
        if (this.f2883ak != null && !this.f2883ak.isFinished() && i2 < 0) {
            this.f2883ak.onRelease();
            z |= this.f2883ak.isFinished();
        }
        if (z) {
            C0495r.m2145d(this);
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: c */
    public void mo3872c(boolean z) {
        this.f2919y = z | this.f2919y;
        this.f2918x = true;
        mo3987u();
    }

    /* access modifiers changed from: protected */
    public boolean checkLayoutParams(LayoutParams layoutParams) {
        return (layoutParams instanceof C0828j) && this.f2908n.mo3177a((C0828j) layoutParams);
    }

    public int computeHorizontalScrollExtent() {
        int i = 0;
        if (this.f2908n == null) {
            return 0;
        }
        if (this.f2908n.mo3212e()) {
            i = this.f2908n.mo3210e(this.f2850D);
        }
        return i;
    }

    public int computeHorizontalScrollOffset() {
        int i = 0;
        if (this.f2908n == null) {
            return 0;
        }
        if (this.f2908n.mo3212e()) {
            i = this.f2908n.mo3204c(this.f2850D);
        }
        return i;
    }

    public int computeHorizontalScrollRange() {
        int i = 0;
        if (this.f2908n == null) {
            return 0;
        }
        if (this.f2908n.mo3212e()) {
            i = this.f2908n.mo3217g(this.f2850D);
        }
        return i;
    }

    public int computeVerticalScrollExtent() {
        int i = 0;
        if (this.f2908n == null) {
            return 0;
        }
        if (this.f2908n.mo3215f()) {
            i = this.f2908n.mo3214f(this.f2850D);
        }
        return i;
    }

    public int computeVerticalScrollOffset() {
        int i = 0;
        if (this.f2908n == null) {
            return 0;
        }
        if (this.f2908n.mo3215f()) {
            i = this.f2908n.mo3207d(this.f2850D);
        }
        return i;
    }

    public int computeVerticalScrollRange() {
        int i = 0;
        if (this.f2908n == null) {
            return 0;
        }
        if (this.f2908n.mo3215f()) {
            i = this.f2908n.mo3218h(this.f2850D);
        }
        return i;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: d */
    public int mo3880d(C0846x xVar) {
        if (xVar.mo4247a(524) || !xVar.mo4264p()) {
            return -1;
        }
        return this.f2900f.mo4527c(xVar.f3025c);
    }

    /* renamed from: d */
    public C0846x mo3881d(View view) {
        View c = mo3869c(view);
        if (c == null) {
            return null;
        }
        return mo3858b(c);
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: d */
    public void mo3882d() {
        if (!this.f2914t || this.f2918x) {
            C0393a.m1731a("RV FullInvalidate");
            mo3955q();
            C0393a.m1730a();
        } else if (this.f2900f.mo4529d()) {
            if (!this.f2900f.mo4524a(4) || this.f2900f.mo4524a(11)) {
                if (this.f2900f.mo4529d()) {
                    C0393a.m1731a("RV FullInvalidate");
                    mo3955q();
                }
            }
            C0393a.m1731a("RV PartialInvalidate");
            mo3893e();
            mo3937l();
            this.f2900f.mo4526b();
            if (!this.f2915u) {
                if (m4033A()) {
                    mo3955q();
                } else {
                    this.f2900f.mo4528c();
                }
            }
            mo3850a(true);
            mo3939m();
            C0393a.m1730a();
        }
    }

    /* renamed from: d */
    public void mo3883d(int i) {
        int b = this.f2901g.mo3581b();
        for (int i2 = 0; i2 < b; i2++) {
            this.f2901g.mo3583b(i2).offsetTopAndBottom(i);
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: d */
    public void mo3884d(int i, int i2) {
        if (i < 0) {
            mo3901g();
            this.f2880ah.onAbsorb(-i);
        } else if (i > 0) {
            mo3924h();
            this.f2882aj.onAbsorb(i);
        }
        if (i2 < 0) {
            mo3930i();
            this.f2881ai.onAbsorb(-i2);
        } else if (i2 > 0) {
            mo3933j();
            this.f2883ak.onAbsorb(i2);
        }
        if (i != 0 || i2 != 0) {
            C0495r.m2145d(this);
        }
    }

    public boolean dispatchNestedFling(float f, float f2, boolean z) {
        return getScrollingChildHelper().mo1933a(f, f2, z);
    }

    public boolean dispatchNestedPreFling(float f, float f2) {
        return getScrollingChildHelper().mo1932a(f, f2);
    }

    public boolean dispatchNestedPreScroll(int i, int i2, int[] iArr, int[] iArr2) {
        return getScrollingChildHelper().mo1938a(i, i2, iArr, iArr2);
    }

    public boolean dispatchNestedScroll(int i, int i2, int i3, int i4, int[] iArr) {
        return getScrollingChildHelper().mo1936a(i, i2, i3, i4, iArr);
    }

    /* access modifiers changed from: protected */
    public void dispatchRestoreInstanceState(SparseArray<Parcelable> sparseArray) {
        dispatchThawSelfOnly(sparseArray);
    }

    /* access modifiers changed from: protected */
    public void dispatchSaveInstanceState(SparseArray<Parcelable> sparseArray) {
        dispatchFreezeSelfOnly(sparseArray);
    }

    public void draw(Canvas canvas) {
        boolean z;
        boolean z2;
        float f;
        int i;
        super.draw(canvas);
        int size = this.f2910p.size();
        boolean z3 = false;
        for (int i2 = 0; i2 < size; i2++) {
            ((C0822h) this.f2910p.get(i2)).mo3692a(canvas, this, this.f2850D);
        }
        if (this.f2880ah == null || this.f2880ah.isFinished()) {
            z = false;
        } else {
            int save = canvas.save();
            int paddingBottom = this.f2903i ? getPaddingBottom() : 0;
            canvas.rotate(270.0f);
            canvas.translate((float) ((-getHeight()) + paddingBottom), 0.0f);
            z = this.f2880ah != null && this.f2880ah.draw(canvas);
            canvas.restoreToCount(save);
        }
        if (this.f2881ai != null && !this.f2881ai.isFinished()) {
            int save2 = canvas.save();
            if (this.f2903i) {
                canvas.translate((float) getPaddingLeft(), (float) getPaddingTop());
            }
            z |= this.f2881ai != null && this.f2881ai.draw(canvas);
            canvas.restoreToCount(save2);
        }
        if (this.f2882aj != null && !this.f2882aj.isFinished()) {
            int save3 = canvas.save();
            int width = getWidth();
            int paddingTop = this.f2903i ? getPaddingTop() : 0;
            canvas.rotate(90.0f);
            canvas.translate((float) (-paddingTop), (float) (-width));
            z |= this.f2882aj != null && this.f2882aj.draw(canvas);
            canvas.restoreToCount(save3);
        }
        if (this.f2883ak == null || this.f2883ak.isFinished()) {
            z2 = z;
        } else {
            int save4 = canvas.save();
            canvas.rotate(180.0f);
            if (this.f2903i) {
                f = (float) ((-getWidth()) + getPaddingRight());
                i = (-getHeight()) + getPaddingBottom();
            } else {
                f = (float) (-getWidth());
                i = -getHeight();
            }
            canvas.translate(f, (float) i);
            if (this.f2883ak != null && this.f2883ak.draw(canvas)) {
                z3 = true;
            }
            z2 = z3 | z;
            canvas.restoreToCount(save4);
        }
        if (!z2 && this.f2920z != null && this.f2910p.size() > 0 && this.f2920z.mo3650b()) {
            z2 = true;
        }
        if (z2) {
            C0495r.m2145d(this);
        }
    }

    public boolean drawChild(Canvas canvas, View view, long j) {
        return super.drawChild(canvas, view, j);
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: e */
    public void mo3893e() {
        this.f2863W++;
        if (this.f2863W == 1 && !this.f2916v) {
            this.f2915u = false;
        }
    }

    /* renamed from: e */
    public void mo3894e(int i) {
        int b = this.f2901g.mo3581b();
        for (int i2 = 0; i2 < b; i2++) {
            this.f2901g.mo3583b(i2).offsetLeftAndRight(i);
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: e */
    public void mo3895e(int i, int i2) {
        setMeasuredDimension(C0823i.m4231a(i, getPaddingLeft() + getPaddingRight(), C0495r.m2154i(this)), C0823i.m4231a(i2, getPaddingTop() + getPaddingBottom(), C0495r.m2155j(this)));
    }

    /* renamed from: f */
    public int mo3896f(View view) {
        C0846x e = m4066e(view);
        if (e != null) {
            return e.mo4252d();
        }
        return -1;
    }

    /* renamed from: f */
    public void mo3897f() {
        setScrollState(0);
        m4034B();
    }

    /* renamed from: f */
    public void mo3898f(int i) {
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: f */
    public void mo3899f(int i, int i2) {
        int i3;
        int i4;
        int i5;
        int c = this.f2901g.mo3584c();
        if (i < i2) {
            i4 = i2;
            i3 = -1;
            i5 = i;
        } else {
            i4 = i;
            i5 = i2;
            i3 = 1;
        }
        for (int i6 = 0; i6 < c; i6++) {
            C0846x e = m4066e(this.f2901g.mo3587d(i6));
            if (e != null && e.f3025c >= i5 && e.f3025c <= i4) {
                if (e.f3025c == i) {
                    e.mo4242a(i2 - i, false);
                } else {
                    e.mo4242a(i3, false);
                }
                this.f2850D.f3003f = true;
            }
        }
        this.f2899e.mo4168a(i, i2);
        requestLayout();
    }

    public View focusSearch(View view, int i) {
        View view2;
        boolean z;
        View d = this.f2908n.mo4105d(view, i);
        if (d != null) {
            return d;
        }
        boolean z2 = this.f2907m != null && this.f2908n != null && !mo3941o() && !this.f2916v;
        FocusFinder instance = FocusFinder.getInstance();
        if (!z2 || !(i == 2 || i == 1)) {
            View findNextFocus = instance.findNextFocus(this, view, i);
            if (findNextFocus != null || !z2) {
                view2 = findNextFocus;
            } else {
                mo3882d();
                if (mo3869c(view) == null) {
                    return null;
                }
                mo3893e();
                view2 = this.f2908n.mo3164a(view, i, this.f2899e, this.f2850D);
                mo3850a(false);
            }
        } else {
            if (this.f2908n.mo3215f()) {
                int i2 = i == 2 ? 130 : 33;
                z = instance.findNextFocus(this, view, i2) == null;
                if (f2840O) {
                    i = i2;
                }
            } else {
                z = false;
            }
            if (!z && this.f2908n.mo3212e()) {
                int i3 = (this.f2908n.mo4132t() == 1) ^ (i == 2) ? 66 : 17;
                z = instance.findNextFocus(this, view, i3) == null;
                if (f2840O) {
                    i = i3;
                }
            }
            if (z) {
                mo3882d();
                if (mo3869c(view) == null) {
                    return null;
                }
                mo3893e();
                this.f2908n.mo3164a(view, i, this.f2899e, this.f2850D);
                mo3850a(false);
            }
            view2 = instance.findNextFocus(this, view, i);
        }
        if (view2 == null || view2.hasFocusable()) {
            return m4062a(view, view2, i) ? view2 : super.focusSearch(view, i);
        }
        if (getFocusedChild() == null) {
            return super.focusSearch(view, i);
        }
        m4058a(view2, (View) null);
        return view;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: g */
    public void mo3901g() {
        EdgeEffect edgeEffect;
        int measuredHeight;
        int measuredWidth;
        if (this.f2880ah == null) {
            this.f2880ah = this.f2879ag.mo4025a(this, 0);
            if (this.f2903i) {
                edgeEffect = this.f2880ah;
                measuredHeight = (getMeasuredHeight() - getPaddingTop()) - getPaddingBottom();
                measuredWidth = (getMeasuredWidth() - getPaddingLeft()) - getPaddingRight();
            } else {
                edgeEffect = this.f2880ah;
                measuredHeight = getMeasuredHeight();
                measuredWidth = getMeasuredWidth();
            }
            edgeEffect.setSize(measuredHeight, measuredWidth);
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: g */
    public void mo3902g(int i) {
        if (this.f2908n != null) {
            this.f2908n.mo3355l(i);
        }
        mo3898f(i);
        if (this.f2898az != null) {
            this.f2898az.mo4151a(this, i);
        }
        if (this.f2864aA != null) {
            for (int size = this.f2864aA.size() - 1; size >= 0; size--) {
                ((C0832n) this.f2864aA.get(size)).mo4151a(this, i);
            }
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: g */
    public void mo3903g(int i, int i2) {
        int c = this.f2901g.mo3584c();
        for (int i3 = 0; i3 < c; i3++) {
            C0846x e = m4066e(this.f2901g.mo3587d(i3));
            if (e != null && !e.mo4251c() && e.f3025c >= i) {
                e.mo4242a(i2, false);
                this.f2850D.f3003f = true;
            }
        }
        this.f2899e.mo4179b(i, i2);
        requestLayout();
    }

    /* renamed from: g */
    public void mo3904g(View view) {
    }

    /* access modifiers changed from: protected */
    public LayoutParams generateDefaultLayoutParams() {
        if (this.f2908n != null) {
            return this.f2908n.mo3160a();
        }
        StringBuilder sb = new StringBuilder();
        sb.append("RecyclerView has no LayoutManager");
        sb.append(mo3835a());
        throw new IllegalStateException(sb.toString());
    }

    public LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        if (this.f2908n != null) {
            return this.f2908n.mo3161a(getContext(), attributeSet);
        }
        StringBuilder sb = new StringBuilder();
        sb.append("RecyclerView has no LayoutManager");
        sb.append(mo3835a());
        throw new IllegalStateException(sb.toString());
    }

    /* access modifiers changed from: protected */
    public LayoutParams generateLayoutParams(LayoutParams layoutParams) {
        if (this.f2908n != null) {
            return this.f2908n.mo3162a(layoutParams);
        }
        StringBuilder sb = new StringBuilder();
        sb.append("RecyclerView has no LayoutManager");
        sb.append(mo3835a());
        throw new IllegalStateException(sb.toString());
    }

    public C0812a getAdapter() {
        return this.f2907m;
    }

    public int getBaseline() {
        return this.f2908n != null ? this.f2908n.mo4133u() : super.getBaseline();
    }

    /* access modifiers changed from: protected */
    public int getChildDrawingOrder(int i, int i2) {
        return this.f2866aC == null ? super.getChildDrawingOrder(i, i2) : this.f2866aC.mo4024a(i, i2);
    }

    public boolean getClipToPadding() {
        return this.f2903i;
    }

    public C0847az getCompatAccessibilityDelegate() {
        return this.f2854H;
    }

    public C0816e getEdgeEffectFactory() {
        return this.f2879ag;
    }

    public C0817f getItemAnimator() {
        return this.f2920z;
    }

    public int getItemDecorationCount() {
        return this.f2910p.size();
    }

    public C0823i getLayoutManager() {
        return this.f2908n;
    }

    public int getMaxFlingVelocity() {
        return this.f2894av;
    }

    public int getMinFlingVelocity() {
        return this.f2893au;
    }

    /* access modifiers changed from: 0000 */
    public long getNanoTime() {
        if (f2846d) {
            return System.nanoTime();
        }
        return 0;
    }

    public C0830l getOnFlingListener() {
        return this.f2892at;
    }

    public boolean getPreserveFocusAfterLayout() {
        return this.f2897ay;
    }

    public C0833o getRecycledViewPool() {
        return this.f2899e.mo4194g();
    }

    public int getScrollState() {
        return this.f2884al;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: h */
    public void mo3924h() {
        EdgeEffect edgeEffect;
        int measuredHeight;
        int measuredWidth;
        if (this.f2882aj == null) {
            this.f2882aj = this.f2879ag.mo4025a(this, 2);
            if (this.f2903i) {
                edgeEffect = this.f2882aj;
                measuredHeight = (getMeasuredHeight() - getPaddingTop()) - getPaddingBottom();
                measuredWidth = (getMeasuredWidth() - getPaddingLeft()) - getPaddingRight();
            } else {
                edgeEffect = this.f2882aj;
                measuredHeight = getMeasuredHeight();
                measuredWidth = getMeasuredWidth();
            }
            edgeEffect.setSize(measuredHeight, measuredWidth);
        }
    }

    /* renamed from: h */
    public void mo3925h(int i, int i2) {
    }

    /* renamed from: h */
    public void mo3926h(View view) {
    }

    /* renamed from: h */
    public boolean mo3927h(int i) {
        return getScrollingChildHelper().mo1934a(i);
    }

    public boolean hasNestedScrollingParent() {
        return getScrollingChildHelper().mo1940b();
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: i */
    public Rect mo3929i(View view) {
        C0828j jVar = (C0828j) view.getLayoutParams();
        if (!jVar.f2965e) {
            return jVar.f2964d;
        }
        if (this.f2850D.mo4223a() && (jVar.mo4146e() || jVar.mo4144c())) {
            return jVar.f2964d;
        }
        Rect rect = jVar.f2964d;
        rect.set(0, 0, 0, 0);
        int size = this.f2910p.size();
        for (int i = 0; i < size; i++) {
            this.f2905k.set(0, 0, 0, 0);
            ((C0822h) this.f2910p.get(i)).mo4048a(this.f2905k, view, this, this.f2850D);
            rect.left += this.f2905k.left;
            rect.top += this.f2905k.top;
            rect.right += this.f2905k.right;
            rect.bottom += this.f2905k.bottom;
        }
        jVar.f2965e = false;
        return rect;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: i */
    public void mo3930i() {
        EdgeEffect edgeEffect;
        int measuredWidth;
        int measuredHeight;
        if (this.f2881ai == null) {
            this.f2881ai = this.f2879ag.mo4025a(this, 1);
            if (this.f2903i) {
                edgeEffect = this.f2881ai;
                measuredWidth = (getMeasuredWidth() - getPaddingLeft()) - getPaddingRight();
                measuredHeight = (getMeasuredHeight() - getPaddingTop()) - getPaddingBottom();
            } else {
                edgeEffect = this.f2881ai;
                measuredWidth = getMeasuredWidth();
                measuredHeight = getMeasuredHeight();
            }
            edgeEffect.setSize(measuredWidth, measuredHeight);
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: i */
    public void mo3931i(int i, int i2) {
        this.f2878af++;
        int scrollX = getScrollX();
        int scrollY = getScrollY();
        onScrollChanged(scrollX, scrollY, scrollX, scrollY);
        mo3925h(i, i2);
        if (this.f2898az != null) {
            this.f2898az.mo3702a(this, i, i2);
        }
        if (this.f2864aA != null) {
            for (int size = this.f2864aA.size() - 1; size >= 0; size--) {
                ((C0832n) this.f2864aA.get(size)).mo3702a(this, i, i2);
            }
        }
        this.f2878af--;
    }

    public boolean isAttachedToWindow() {
        return this.f2911q;
    }

    public boolean isNestedScrollingEnabled() {
        return getScrollingChildHelper().mo1931a();
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: j */
    public void mo3933j() {
        EdgeEffect edgeEffect;
        int measuredWidth;
        int measuredHeight;
        if (this.f2883ak == null) {
            this.f2883ak = this.f2879ag.mo4025a(this, 3);
            if (this.f2903i) {
                edgeEffect = this.f2883ak;
                measuredWidth = (getMeasuredWidth() - getPaddingLeft()) - getPaddingRight();
                measuredHeight = (getMeasuredHeight() - getPaddingTop()) - getPaddingBottom();
            } else {
                edgeEffect = this.f2883ak;
                measuredWidth = getMeasuredWidth();
                measuredHeight = getMeasuredHeight();
            }
            edgeEffect.setSize(measuredWidth, measuredHeight);
        }
    }

    /* renamed from: j */
    public boolean mo3934j(int i, int i2) {
        return getScrollingChildHelper().mo1935a(i, i2);
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: k */
    public void mo3935k() {
        this.f2883ak = null;
        this.f2881ai = null;
        this.f2882aj = null;
        this.f2880ah = null;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: k */
    public void mo3936k(View view) {
        C0846x e = m4066e(view);
        mo3926h(view);
        if (!(this.f2907m == null || e == null)) {
            this.f2907m.mo4023d(e);
        }
        if (this.f2876ad != null) {
            for (int size = this.f2876ad.size() - 1; size >= 0; size--) {
                ((C0829k) this.f2876ad.get(size)).mo4149b(view);
            }
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: l */
    public void mo3937l() {
        this.f2877ae++;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: l */
    public void mo3938l(View view) {
        C0846x e = m4066e(view);
        mo3904g(view);
        if (!(this.f2907m == null || e == null)) {
            this.f2907m.mo4022c(e);
        }
        if (this.f2876ad != null) {
            for (int size = this.f2876ad.size() - 1; size >= 0; size--) {
                ((C0829k) this.f2876ad.get(size)).mo4148a(view);
            }
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: m */
    public void mo3939m() {
        mo3865b(true);
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: n */
    public boolean mo3940n() {
        return this.f2875ac != null && this.f2875ac.isEnabled();
    }

    /* renamed from: o */
    public boolean mo3941o() {
        return this.f2877ae > 0;
    }

    /* access modifiers changed from: protected */
    /* JADX WARNING: Code restructure failed: missing block: B:16:0x0051, code lost:
        if (r0 >= 30.0f) goto L_0x0055;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void onAttachedToWindow() {
        /*
            r4 = this;
            super.onAttachedToWindow()
            r0 = 0
            r4.f2877ae = r0
            r1 = 1
            r4.f2911q = r1
            boolean r2 = r4.f2914t
            if (r2 == 0) goto L_0x0014
            boolean r2 = r4.isLayoutRequested()
            if (r2 != 0) goto L_0x0014
            goto L_0x0015
        L_0x0014:
            r1 = r0
        L_0x0015:
            r4.f2914t = r1
            android.support.v7.widget.ay$i r1 = r4.f2908n
            if (r1 == 0) goto L_0x0020
            android.support.v7.widget.ay$i r1 = r4.f2908n
            r1.mo4099c(r4)
        L_0x0020:
            r4.f2853G = r0
            boolean r0 = f2846d
            if (r0 == 0) goto L_0x006a
            java.lang.ThreadLocal<android.support.v7.widget.aq> r0 = android.support.p031v7.widget.C0782aq.f2743a
            java.lang.Object r0 = r0.get()
            android.support.v7.widget.aq r0 = (android.support.p031v7.widget.C0782aq) r0
            r4.f2848B = r0
            android.support.v7.widget.aq r0 = r4.f2848B
            if (r0 != 0) goto L_0x0065
            android.support.v7.widget.aq r0 = new android.support.v7.widget.aq
            r0.<init>()
            r4.f2848B = r0
            android.view.Display r0 = android.support.p018v4.p028h.C0495r.m2119B(r4)
            r1 = 1114636288(0x42700000, float:60.0)
            boolean r2 = r4.isInEditMode()
            if (r2 != 0) goto L_0x0054
            if (r0 == 0) goto L_0x0054
            float r0 = r0.getRefreshRate()
            r2 = 1106247680(0x41f00000, float:30.0)
            int r2 = (r0 > r2 ? 1 : (r0 == r2 ? 0 : -1))
            if (r2 < 0) goto L_0x0054
            goto L_0x0055
        L_0x0054:
            r0 = r1
        L_0x0055:
            android.support.v7.widget.aq r1 = r4.f2848B
            r2 = 1315859240(0x4e6e6b28, float:1.0E9)
            float r2 = r2 / r0
            long r2 = (long) r2
            r1.f2747d = r2
            java.lang.ThreadLocal<android.support.v7.widget.aq> r0 = android.support.p031v7.widget.C0782aq.f2743a
            android.support.v7.widget.aq r1 = r4.f2848B
            r0.set(r1)
        L_0x0065:
            android.support.v7.widget.aq r0 = r4.f2848B
            r0.mo3714a(r4)
        L_0x006a:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.p031v7.widget.C0805ay.onAttachedToWindow():void");
    }

    /* access modifiers changed from: protected */
    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        if (this.f2920z != null) {
            this.f2920z.mo3654d();
        }
        mo3897f();
        this.f2911q = false;
        if (this.f2908n != null) {
            this.f2908n.mo4092b(this, this.f2899e);
        }
        this.f2857K.clear();
        removeCallbacks(this.f2871aH);
        this.f2902h.mo4477b();
        if (f2846d && this.f2848B != null) {
            this.f2848B.mo3716b(this);
            this.f2848B = null;
        }
    }

    public void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        int size = this.f2910p.size();
        for (int i = 0; i < size; i++) {
            ((C0822h) this.f2910p.get(i)).mo4050b(canvas, this, this.f2850D);
        }
    }

    public boolean onGenericMotionEvent(MotionEvent motionEvent) {
        float f;
        float f2;
        if (this.f2908n != null && !this.f2916v && motionEvent.getAction() == 8) {
            if ((motionEvent.getSource() & 2) != 0) {
                f2 = this.f2908n.mo3215f() ? -motionEvent.getAxisValue(9) : 0.0f;
                if (this.f2908n.mo3212e()) {
                    f = motionEvent.getAxisValue(10);
                    if (!(f2 == 0.0f && f == 0.0f)) {
                        mo3852a((int) (f * this.f2895aw), (int) (f2 * this.f2896ax), motionEvent);
                    }
                }
            } else {
                if ((motionEvent.getSource() & 4194304) != 0) {
                    float axisValue = motionEvent.getAxisValue(26);
                    if (this.f2908n.mo3215f()) {
                        f2 = -axisValue;
                    } else if (this.f2908n.mo3212e()) {
                        f = axisValue;
                        f2 = 0.0f;
                        mo3852a((int) (f * this.f2895aw), (int) (f2 * this.f2896ax), motionEvent);
                    }
                }
                f2 = 0.0f;
                f = 0.0f;
                mo3852a((int) (f * this.f2895aw), (int) (f2 * this.f2896ax), motionEvent);
            }
            f = 0.0f;
            mo3852a((int) (f * this.f2895aw), (int) (f2 * this.f2896ax), motionEvent);
        }
        return false;
    }

    public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        boolean z;
        boolean z2 = false;
        if (this.f2916v) {
            return false;
        }
        if (m4061a(motionEvent)) {
            m4037E();
            return true;
        } else if (this.f2908n == null) {
            return false;
        } else {
            boolean e = this.f2908n.mo3212e();
            boolean f = this.f2908n.mo3215f();
            if (this.f2886an == null) {
                this.f2886an = VelocityTracker.obtain();
            }
            this.f2886an.addMovement(motionEvent);
            int actionMasked = motionEvent.getActionMasked();
            int actionIndex = motionEvent.getActionIndex();
            switch (actionMasked) {
                case 0:
                    if (this.f2873aa) {
                        this.f2873aa = false;
                    }
                    this.f2885am = motionEvent.getPointerId(0);
                    int x = (int) (motionEvent.getX() + 0.5f);
                    this.f2889aq = x;
                    this.f2887ao = x;
                    int y = (int) (motionEvent.getY() + 0.5f);
                    this.f2890ar = y;
                    this.f2888ap = y;
                    if (this.f2884al == 2) {
                        getParent().requestDisallowInterceptTouchEvent(true);
                        setScrollState(1);
                    }
                    int[] iArr = this.f2870aG;
                    this.f2870aG[1] = 0;
                    iArr[0] = 0;
                    int i = e ? 1 : 0;
                    if (f) {
                        i |= 2;
                    }
                    mo3934j(i, 0);
                    break;
                case 1:
                    this.f2886an.clear();
                    mo1929a(0);
                    break;
                case 2:
                    int findPointerIndex = motionEvent.findPointerIndex(this.f2885am);
                    if (findPointerIndex >= 0) {
                        int x2 = (int) (motionEvent.getX(findPointerIndex) + 0.5f);
                        int y2 = (int) (motionEvent.getY(findPointerIndex) + 0.5f);
                        if (this.f2884al != 1) {
                            int i2 = x2 - this.f2887ao;
                            int i3 = y2 - this.f2888ap;
                            if (!e || Math.abs(i2) <= this.f2891as) {
                                z = false;
                            } else {
                                this.f2889aq = x2;
                                z = true;
                            }
                            if (f && Math.abs(i3) > this.f2891as) {
                                this.f2890ar = y2;
                                z = true;
                            }
                            if (z) {
                                setScrollState(1);
                                break;
                            }
                        }
                    } else {
                        StringBuilder sb = new StringBuilder();
                        sb.append("Error processing scroll; pointer index for id ");
                        sb.append(this.f2885am);
                        sb.append(" not found. Did any MotionEvents get skipped?");
                        Log.e("RecyclerView", sb.toString());
                        return false;
                    }
                    break;
                case 3:
                    m4037E();
                    break;
                case 5:
                    this.f2885am = motionEvent.getPointerId(actionIndex);
                    int x3 = (int) (motionEvent.getX(actionIndex) + 0.5f);
                    this.f2889aq = x3;
                    this.f2887ao = x3;
                    int y3 = (int) (motionEvent.getY(actionIndex) + 0.5f);
                    this.f2890ar = y3;
                    this.f2888ap = y3;
                    break;
                case 6:
                    m4065c(motionEvent);
                    break;
            }
            if (this.f2884al == 1) {
                z2 = true;
            }
            return z2;
        }
    }

    /* access modifiers changed from: protected */
    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        C0393a.m1731a("RV OnLayout");
        mo3955q();
        C0393a.m1730a();
        this.f2914t = true;
    }

    /* access modifiers changed from: protected */
    public void onMeasure(int i, int i2) {
        if (this.f2908n == null) {
            mo3895e(i, i2);
            return;
        }
        boolean z = false;
        if (this.f2908n.mo3206c()) {
            int mode = MeasureSpec.getMode(i);
            int mode2 = MeasureSpec.getMode(i2);
            this.f2908n.mo4065a(this.f2899e, this.f2850D, i, i2);
            if (mode == 1073741824 && mode2 == 1073741824) {
                z = true;
            }
            if (!z && this.f2907m != null) {
                if (this.f2850D.f3001d == 1) {
                    m4045M();
                }
                this.f2908n.mo4097c(i, i2);
                this.f2850D.f3006i = true;
                m4046N();
                this.f2908n.mo4106d(i, i2);
                if (this.f2908n.mo3223l()) {
                    this.f2908n.mo4097c(MeasureSpec.makeMeasureSpec(getMeasuredWidth(), 1073741824), MeasureSpec.makeMeasureSpec(getMeasuredHeight(), 1073741824));
                    this.f2850D.f3006i = true;
                    m4046N();
                    this.f2908n.mo4106d(i, i2);
                }
            }
        } else if (this.f2912r) {
            this.f2908n.mo4065a(this.f2899e, this.f2850D, i, i2);
        } else {
            if (this.f2917w) {
                mo3893e();
                mo3937l();
                m4040H();
                mo3939m();
                if (this.f2850D.f3008k) {
                    this.f2850D.f3004g = true;
                } else {
                    this.f2900f.mo4530e();
                    this.f2850D.f3004g = false;
                }
                this.f2917w = false;
                mo3850a(false);
            } else if (this.f2850D.f3008k) {
                setMeasuredDimension(getMeasuredWidth(), getMeasuredHeight());
                return;
            }
            if (this.f2907m != null) {
                this.f2850D.f3002e = this.f2907m.mo4007a();
            } else {
                this.f2850D.f3002e = 0;
            }
            mo3893e();
            this.f2908n.mo4065a(this.f2899e, this.f2850D, i, i2);
            mo3850a(false);
            this.f2850D.f3004g = false;
        }
    }

    /* access modifiers changed from: protected */
    public boolean onRequestFocusInDescendants(int i, Rect rect) {
        if (mo3941o()) {
            return false;
        }
        return super.onRequestFocusInDescendants(i, rect);
    }

    /* access modifiers changed from: protected */
    public void onRestoreInstanceState(Parcelable parcelable) {
        if (!(parcelable instanceof C0838s)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        this.f2859S = (C0838s) parcelable;
        super.onRestoreInstanceState(this.f2859S.mo1845a());
        if (!(this.f2908n == null || this.f2859S.f2983a == null)) {
            this.f2908n.mo3195a(this.f2859S.f2983a);
        }
    }

    /* access modifiers changed from: protected */
    public Parcelable onSaveInstanceState() {
        C0838s sVar = new C0838s(super.onSaveInstanceState());
        if (this.f2859S != null) {
            sVar.mo4199a(this.f2859S);
            return sVar;
        }
        sVar.f2983a = this.f2908n != null ? this.f2908n.mo3209d() : null;
        return sVar;
    }

    /* access modifiers changed from: protected */
    public void onSizeChanged(int i, int i2, int i3, int i4) {
        super.onSizeChanged(i, i2, i3, i4);
        if (i != i3 || i2 != i4) {
            mo3935k();
        }
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        int i;
        int i2;
        boolean z;
        boolean z2 = false;
        if (this.f2916v || this.f2873aa) {
            return false;
        }
        if (m4063b(motionEvent)) {
            m4037E();
            return true;
        } else if (this.f2908n == null) {
            return false;
        } else {
            boolean e = this.f2908n.mo3212e();
            boolean f = this.f2908n.mo3215f();
            if (this.f2886an == null) {
                this.f2886an = VelocityTracker.obtain();
            }
            MotionEvent obtain = MotionEvent.obtain(motionEvent);
            int actionMasked = motionEvent.getActionMasked();
            int actionIndex = motionEvent.getActionIndex();
            if (actionMasked == 0) {
                int[] iArr = this.f2870aG;
                this.f2870aG[1] = 0;
                iArr[0] = 0;
            }
            obtain.offsetLocation((float) this.f2870aG[0], (float) this.f2870aG[1]);
            switch (actionMasked) {
                case 0:
                    this.f2885am = motionEvent.getPointerId(0);
                    int x = (int) (motionEvent.getX() + 0.5f);
                    this.f2889aq = x;
                    this.f2887ao = x;
                    int y = (int) (motionEvent.getY() + 0.5f);
                    this.f2890ar = y;
                    this.f2888ap = y;
                    int i3 = e ? 1 : 0;
                    if (f) {
                        i3 |= 2;
                    }
                    mo3934j(i3, 0);
                    break;
                case 1:
                    this.f2886an.addMovement(obtain);
                    this.f2886an.computeCurrentVelocity(1000, (float) this.f2894av);
                    float f2 = e ? -this.f2886an.getXVelocity(this.f2885am) : 0.0f;
                    float f3 = f ? -this.f2886an.getYVelocity(this.f2885am) : 0.0f;
                    if ((f2 == 0.0f && f3 == 0.0f) || !mo3866b((int) f2, (int) f3)) {
                        setScrollState(0);
                    }
                    m4036D();
                    z2 = true;
                    break;
                case 2:
                    int findPointerIndex = motionEvent.findPointerIndex(this.f2885am);
                    if (findPointerIndex >= 0) {
                        int x2 = (int) (motionEvent.getX(findPointerIndex) + 0.5f);
                        int y2 = (int) (motionEvent.getY(findPointerIndex) + 0.5f);
                        int i4 = this.f2889aq - x2;
                        int i5 = this.f2890ar - y2;
                        if (mo3853a(i4, i5, this.f2855I, this.f2869aF, 0)) {
                            i4 -= this.f2855I[0];
                            i5 -= this.f2855I[1];
                            obtain.offsetLocation((float) this.f2869aF[0], (float) this.f2869aF[1]);
                            int[] iArr2 = this.f2870aG;
                            iArr2[0] = iArr2[0] + this.f2869aF[0];
                            int[] iArr3 = this.f2870aG;
                            iArr3[1] = iArr3[1] + this.f2869aF[1];
                        }
                        if (this.f2884al != 1) {
                            if (!e || Math.abs(i2) <= this.f2891as) {
                                z = false;
                            } else {
                                i2 = i2 > 0 ? i2 - this.f2891as : i2 + this.f2891as;
                                z = true;
                            }
                            if (f && Math.abs(i) > this.f2891as) {
                                i = i > 0 ? i - this.f2891as : i + this.f2891as;
                                z = true;
                            }
                            if (z) {
                                setScrollState(1);
                            }
                        }
                        if (this.f2884al == 1) {
                            this.f2889aq = x2 - this.f2869aF[0];
                            this.f2890ar = y2 - this.f2869aF[1];
                            if (mo3852a(e ? i2 : 0, f ? i : 0, obtain)) {
                                getParent().requestDisallowInterceptTouchEvent(true);
                            }
                            if (!(this.f2848B == null || (i2 == 0 && i == 0))) {
                                this.f2848B.mo3715a(this, i2, i);
                                break;
                            }
                        }
                    } else {
                        StringBuilder sb = new StringBuilder();
                        sb.append("Error processing scroll; pointer index for id ");
                        sb.append(this.f2885am);
                        sb.append(" not found. Did any MotionEvents get skipped?");
                        Log.e("RecyclerView", sb.toString());
                        return false;
                    }
                    break;
                case 3:
                    m4037E();
                    break;
                case 5:
                    this.f2885am = motionEvent.getPointerId(actionIndex);
                    int x3 = (int) (motionEvent.getX(actionIndex) + 0.5f);
                    this.f2889aq = x3;
                    this.f2887ao = x3;
                    int y3 = (int) (motionEvent.getY(actionIndex) + 0.5f);
                    this.f2890ar = y3;
                    this.f2888ap = y3;
                    break;
                case 6:
                    m4065c(motionEvent);
                    break;
            }
            if (!z2) {
                this.f2886an.addMovement(obtain);
            }
            obtain.recycle();
            return true;
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: p */
    public void mo3954p() {
        if (!this.f2853G && this.f2911q) {
            C0495r.m2134a((View) this, this.f2871aH);
            this.f2853G = true;
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: q */
    public void mo3955q() {
        String str;
        String str2;
        if (this.f2907m == null) {
            str = "RecyclerView";
            str2 = "No adapter attached; skipping layout";
        } else if (this.f2908n == null) {
            str = "RecyclerView";
            str2 = "No layout manager attached; skipping layout";
        } else {
            this.f2850D.f3006i = false;
            if (this.f2850D.f3001d == 1) {
                m4045M();
            } else if (!this.f2900f.mo4531f() && this.f2908n.mo4137y() == getWidth() && this.f2908n.mo4138z() == getHeight()) {
                this.f2908n.mo4114f(this);
                m4047O();
                return;
            }
            this.f2908n.mo4114f(this);
            m4046N();
            m4047O();
            return;
        }
        Log.e(str, str2);
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: r */
    public void mo3956r() {
        int c = this.f2901g.mo3584c();
        for (int i = 0; i < c; i++) {
            ((C0828j) this.f2901g.mo3587d(i).getLayoutParams()).f2965e = true;
        }
        this.f2899e.mo4197j();
    }

    /* access modifiers changed from: protected */
    public void removeDetachedView(View view, boolean z) {
        C0846x e = m4066e(view);
        if (e != null) {
            if (e.mo4266r()) {
                e.mo4261m();
            } else if (!e.mo4251c()) {
                StringBuilder sb = new StringBuilder();
                sb.append("Called removeDetachedView with a view which is not flagged as tmp detached.");
                sb.append(e);
                sb.append(mo3835a());
                throw new IllegalArgumentException(sb.toString());
            }
        }
        view.clearAnimation();
        mo3936k(view);
        super.removeDetachedView(view, z);
    }

    public void requestChildFocus(View view, View view2) {
        if (!this.f2908n.mo4081a(this, this.f2850D, view, view2) && view2 != null) {
            m4058a(view, view2);
        }
        super.requestChildFocus(view, view2);
    }

    public boolean requestChildRectangleOnScreen(View view, Rect rect, boolean z) {
        return this.f2908n.mo4082a(this, view, rect, z);
    }

    public void requestDisallowInterceptTouchEvent(boolean z) {
        int size = this.f2861U.size();
        for (int i = 0; i < size; i++) {
            ((C0831m) this.f2861U.get(i)).mo3694a(z);
        }
        super.requestDisallowInterceptTouchEvent(z);
    }

    public void requestLayout() {
        if (this.f2863W != 0 || this.f2916v) {
            this.f2915u = true;
        } else {
            super.requestLayout();
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: s */
    public void mo3962s() {
        int c = this.f2901g.mo3584c();
        for (int i = 0; i < c; i++) {
            C0846x e = m4066e(this.f2901g.mo3587d(i));
            if (!e.mo4251c()) {
                e.mo4248b();
            }
        }
    }

    public void scrollBy(int i, int i2) {
        if (this.f2908n == null) {
            Log.e("RecyclerView", "Cannot scroll without a LayoutManager set. Call setLayoutManager with a non-null argument.");
        } else if (!this.f2916v) {
            boolean e = this.f2908n.mo3212e();
            boolean f = this.f2908n.mo3215f();
            if (e || f) {
                if (!e) {
                    i = 0;
                }
                if (!f) {
                    i2 = 0;
                }
                mo3852a(i, i2, (MotionEvent) null);
            }
        }
    }

    public void scrollTo(int i, int i2) {
        Log.w("RecyclerView", "RecyclerView does not support scrolling to an absolute position. Use scrollToPosition instead");
    }

    public void sendAccessibilityEventUnchecked(AccessibilityEvent accessibilityEvent) {
        if (!mo3856a(accessibilityEvent)) {
            super.sendAccessibilityEventUnchecked(accessibilityEvent);
        }
    }

    public void setAccessibilityDelegateCompat(C0847az azVar) {
        this.f2854H = azVar;
        C0495r.m2132a((View) this, (C0471b) this.f2854H);
    }

    public void setAdapter(C0812a aVar) {
        setLayoutFrozen(false);
        m4052a(aVar, false, true);
        mo3872c(false);
        requestLayout();
    }

    public void setChildDrawingOrderCallback(C0815d dVar) {
        if (dVar != this.f2866aC) {
            this.f2866aC = dVar;
            setChildrenDrawingOrderEnabled(this.f2866aC != null);
        }
    }

    public void setClipToPadding(boolean z) {
        if (z != this.f2903i) {
            mo3935k();
        }
        this.f2903i = z;
        super.setClipToPadding(z);
        if (this.f2914t) {
            requestLayout();
        }
    }

    public void setEdgeEffectFactory(C0816e eVar) {
        C0432k.m1863a(eVar);
        this.f2879ag = eVar;
        mo3935k();
    }

    public void setHasFixedSize(boolean z) {
        this.f2912r = z;
    }

    public void setItemAnimator(C0817f fVar) {
        if (this.f2920z != null) {
            this.f2920z.mo3654d();
            this.f2920z.mo4028a(null);
        }
        this.f2920z = fVar;
        if (this.f2920z != null) {
            this.f2920z.mo4028a(this.f2865aB);
        }
    }

    public void setItemViewCacheSize(int i) {
        this.f2899e.mo4167a(i);
    }

    public void setLayoutFrozen(boolean z) {
        if (z != this.f2916v) {
            mo3849a("Do not setLayoutFrozen in layout or scroll");
            if (!z) {
                this.f2916v = false;
                if (!(!this.f2915u || this.f2908n == null || this.f2907m == null)) {
                    requestLayout();
                }
                this.f2915u = false;
                return;
            }
            long uptimeMillis = SystemClock.uptimeMillis();
            onTouchEvent(MotionEvent.obtain(uptimeMillis, uptimeMillis, 3, 0.0f, 0.0f, 0));
            this.f2916v = true;
            this.f2873aa = true;
            mo3897f();
        }
    }

    public void setLayoutManager(C0823i iVar) {
        if (iVar != this.f2908n) {
            mo3897f();
            if (this.f2908n != null) {
                if (this.f2920z != null) {
                    this.f2920z.mo3654d();
                }
                this.f2908n.mo4098c(this.f2899e);
                this.f2908n.mo4090b(this.f2899e);
                this.f2899e.mo4166a();
                if (this.f2911q) {
                    this.f2908n.mo4092b(this, this.f2899e);
                }
                this.f2908n.mo4091b((C0805ay) null);
                this.f2908n = null;
            } else {
                this.f2899e.mo4166a();
            }
            this.f2901g.mo3575a();
            this.f2908n = iVar;
            if (iVar != null) {
                if (iVar.f2948q != null) {
                    StringBuilder sb = new StringBuilder();
                    sb.append("LayoutManager ");
                    sb.append(iVar);
                    sb.append(" is already attached to a RecyclerView:");
                    sb.append(iVar.f2948q.mo3835a());
                    throw new IllegalArgumentException(sb.toString());
                }
                this.f2908n.mo4091b(this);
                if (this.f2911q) {
                    this.f2908n.mo4099c(this);
                }
            }
            this.f2899e.mo4178b();
            requestLayout();
        }
    }

    public void setNestedScrollingEnabled(boolean z) {
        getScrollingChildHelper().mo1930a(z);
    }

    public void setOnFlingListener(C0830l lVar) {
        this.f2892at = lVar;
    }

    @Deprecated
    public void setOnScrollListener(C0832n nVar) {
        this.f2898az = nVar;
    }

    public void setPreserveFocusAfterLayout(boolean z) {
        this.f2897ay = z;
    }

    public void setRecycledViewPool(C0833o oVar) {
        this.f2899e.mo4171a(oVar);
    }

    public void setRecyclerListener(C0836q qVar) {
        this.f2909o = qVar;
    }

    /* access modifiers changed from: 0000 */
    public void setScrollState(int i) {
        if (i != this.f2884al) {
            this.f2884al = i;
            if (i != 2) {
                m4034B();
            }
            mo3902g(i);
        }
    }

    public void setScrollingTouchSlop(int i) {
        int i2;
        ViewConfiguration viewConfiguration = ViewConfiguration.get(getContext());
        switch (i) {
            case 0:
                break;
            case 1:
                i2 = viewConfiguration.getScaledPagingTouchSlop();
                break;
            default:
                StringBuilder sb = new StringBuilder();
                sb.append("setScrollingTouchSlop(): bad argument constant ");
                sb.append(i);
                sb.append("; using default value");
                Log.w("RecyclerView", sb.toString());
                break;
        }
        i2 = viewConfiguration.getScaledTouchSlop();
        this.f2891as = i2;
    }

    public void setViewCacheExtension(C0844v vVar) {
        this.f2899e.mo4172a(vVar);
    }

    public boolean startNestedScroll(int i) {
        return getScrollingChildHelper().mo1941b(i);
    }

    public void stopNestedScroll() {
        getScrollingChildHelper().mo1942c();
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: t */
    public void mo3986t() {
        int c = this.f2901g.mo3584c();
        for (int i = 0; i < c; i++) {
            C0846x e = m4066e(this.f2901g.mo3587d(i));
            if (!e.mo4251c()) {
                e.mo4239a();
            }
        }
        this.f2899e.mo4196i();
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: u */
    public void mo3987u() {
        int c = this.f2901g.mo3584c();
        for (int i = 0; i < c; i++) {
            C0846x e = m4066e(this.f2901g.mo3587d(i));
            if (e != null && !e.mo4251c()) {
                e.mo4249b(6);
            }
        }
        mo3956r();
        this.f2899e.mo4195h();
    }

    /* renamed from: v */
    public boolean mo3988v() {
        return !this.f2914t || this.f2918x || this.f2900f.mo4529d();
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: w */
    public void mo3989w() {
        int b = this.f2901g.mo3581b();
        for (int i = 0; i < b; i++) {
            View b2 = this.f2901g.mo3583b(i);
            C0846x b3 = mo3858b(b2);
            if (!(b3 == null || b3.f3031i == null)) {
                View view = b3.f3031i.f3023a;
                int left = b2.getLeft();
                int top = b2.getTop();
                if (left != view.getLeft() || top != view.getTop()) {
                    view.layout(left, top, view.getWidth() + left, view.getHeight() + top);
                }
            }
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: x */
    public void mo3990x() {
        for (int size = this.f2857K.size() - 1; size >= 0; size--) {
            C0846x xVar = (C0846x) this.f2857K.get(size);
            if (xVar.f3023a.getParent() == this && !xVar.mo4251c()) {
                int i = xVar.f3037o;
                if (i != -1) {
                    C0495r.m2139b(xVar.f3023a, i);
                    xVar.f3037o = -1;
                }
            }
        }
        this.f2857K.clear();
    }
}
