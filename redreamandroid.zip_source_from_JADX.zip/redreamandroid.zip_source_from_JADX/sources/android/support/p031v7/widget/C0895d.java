package android.support.p031v7.widget;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ResolveInfo;
import android.database.DataSetObservable;
import android.os.AsyncTask;
import android.text.TextUtils;
import android.util.Log;
import android.util.Xml;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

/* renamed from: android.support.v7.widget.d */
class C0895d extends DataSetObservable {

    /* renamed from: a */
    static final String f3235a = "d";

    /* renamed from: e */
    private static final Object f3236e = new Object();

    /* renamed from: f */
    private static final Map<String, C0895d> f3237f = new HashMap();

    /* renamed from: b */
    final Context f3238b;

    /* renamed from: c */
    final String f3239c;

    /* renamed from: d */
    boolean f3240d;

    /* renamed from: g */
    private final Object f3241g;

    /* renamed from: h */
    private final List<C0896a> f3242h;

    /* renamed from: i */
    private final List<C0898c> f3243i;

    /* renamed from: j */
    private Intent f3244j;

    /* renamed from: k */
    private C0897b f3245k;

    /* renamed from: l */
    private int f3246l;

    /* renamed from: m */
    private boolean f3247m;

    /* renamed from: n */
    private boolean f3248n;

    /* renamed from: o */
    private boolean f3249o;

    /* renamed from: p */
    private C0899d f3250p;

    /* renamed from: android.support.v7.widget.d$a */
    public static final class C0896a implements Comparable<C0896a> {

        /* renamed from: a */
        public final ResolveInfo f3251a;

        /* renamed from: b */
        public float f3252b;

        public C0896a(ResolveInfo resolveInfo) {
            this.f3251a = resolveInfo;
        }

        /* renamed from: a */
        public int compareTo(C0896a aVar) {
            return Float.floatToIntBits(aVar.f3252b) - Float.floatToIntBits(this.f3252b);
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (obj == null || getClass() != obj.getClass()) {
                return false;
            }
            return Float.floatToIntBits(this.f3252b) == Float.floatToIntBits(((C0896a) obj).f3252b);
        }

        public int hashCode() {
            return 31 + Float.floatToIntBits(this.f3252b);
        }

        public String toString() {
            StringBuilder sb = new StringBuilder();
            sb.append("[");
            sb.append("resolveInfo:");
            sb.append(this.f3251a.toString());
            sb.append("; weight:");
            sb.append(new BigDecimal((double) this.f3252b));
            sb.append("]");
            return sb.toString();
        }
    }

    /* renamed from: android.support.v7.widget.d$b */
    public interface C0897b {
        /* renamed from: a */
        void mo4513a(Intent intent, List<C0896a> list, List<C0898c> list2);
    }

    /* renamed from: android.support.v7.widget.d$c */
    public static final class C0898c {

        /* renamed from: a */
        public final ComponentName f3253a;

        /* renamed from: b */
        public final long f3254b;

        /* renamed from: c */
        public final float f3255c;

        public C0898c(ComponentName componentName, long j, float f) {
            this.f3253a = componentName;
            this.f3254b = j;
            this.f3255c = f;
        }

        public C0898c(String str, long j, float f) {
            this(ComponentName.unflattenFromString(str), j, f);
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (obj == null || getClass() != obj.getClass()) {
                return false;
            }
            C0898c cVar = (C0898c) obj;
            if (this.f3253a == null) {
                if (cVar.f3253a != null) {
                    return false;
                }
            } else if (!this.f3253a.equals(cVar.f3253a)) {
                return false;
            }
            return this.f3254b == cVar.f3254b && Float.floatToIntBits(this.f3255c) == Float.floatToIntBits(cVar.f3255c);
        }

        public int hashCode() {
            return (31 * ((((this.f3253a == null ? 0 : this.f3253a.hashCode()) + 31) * 31) + ((int) (this.f3254b ^ (this.f3254b >>> 32))))) + Float.floatToIntBits(this.f3255c);
        }

        public String toString() {
            StringBuilder sb = new StringBuilder();
            sb.append("[");
            sb.append("; activity:");
            sb.append(this.f3253a);
            sb.append("; time:");
            sb.append(this.f3254b);
            sb.append("; weight:");
            sb.append(new BigDecimal((double) this.f3255c));
            sb.append("]");
            return sb.toString();
        }
    }

    /* renamed from: android.support.v7.widget.d$d */
    public interface C0899d {
        /* renamed from: a */
        boolean mo4517a(C0895d dVar, Intent intent);
    }

    /* renamed from: android.support.v7.widget.d$e */
    private final class C0900e extends AsyncTask<Object, Void, Void> {
        C0900e() {
        }

        /* JADX WARNING: Code restructure failed: missing block: B:10:0x006f, code lost:
            if (r4 != null) goto L_0x0071;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:12:?, code lost:
            r4.close();
         */
        /* JADX WARNING: Code restructure failed: missing block: B:13:0x0074, code lost:
            return null;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:19:0x0096, code lost:
            if (r4 == null) goto L_0x00dd;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:24:0x00b8, code lost:
            if (r4 == null) goto L_0x00dd;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:29:0x00da, code lost:
            if (r4 == null) goto L_0x00dd;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:30:0x00dd, code lost:
            return null;
         */
        /* renamed from: a */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public java.lang.Void doInBackground(java.lang.Object... r12) {
            /*
                r11 = this;
                r0 = 0
                r1 = r12[r0]
                java.util.List r1 = (java.util.List) r1
                r2 = 1
                r12 = r12[r2]
                java.lang.String r12 = (java.lang.String) r12
                r3 = 0
                android.support.v7.widget.d r4 = android.support.p031v7.widget.C0895d.this     // Catch:{ FileNotFoundException -> 0x00e8 }
                android.content.Context r4 = r4.f3238b     // Catch:{ FileNotFoundException -> 0x00e8 }
                java.io.FileOutputStream r4 = r4.openFileOutput(r12, r0)     // Catch:{ FileNotFoundException -> 0x00e8 }
                org.xmlpull.v1.XmlSerializer r12 = android.util.Xml.newSerializer()
                r12.setOutput(r4, r3)     // Catch:{ IllegalArgumentException -> 0x00bb, IllegalStateException -> 0x0099, IOException -> 0x0077 }
                java.lang.String r5 = "UTF-8"
                java.lang.Boolean r6 = java.lang.Boolean.valueOf(r2)     // Catch:{ IllegalArgumentException -> 0x00bb, IllegalStateException -> 0x0099, IOException -> 0x0077 }
                r12.startDocument(r5, r6)     // Catch:{ IllegalArgumentException -> 0x00bb, IllegalStateException -> 0x0099, IOException -> 0x0077 }
                java.lang.String r5 = "historical-records"
                r12.startTag(r3, r5)     // Catch:{ IllegalArgumentException -> 0x00bb, IllegalStateException -> 0x0099, IOException -> 0x0077 }
                int r5 = r1.size()     // Catch:{ IllegalArgumentException -> 0x00bb, IllegalStateException -> 0x0099, IOException -> 0x0077 }
                r6 = r0
            L_0x002d:
                if (r6 >= r5) goto L_0x0063
                java.lang.Object r7 = r1.remove(r0)     // Catch:{ IllegalArgumentException -> 0x00bb, IllegalStateException -> 0x0099, IOException -> 0x0077 }
                android.support.v7.widget.d$c r7 = (android.support.p031v7.widget.C0895d.C0898c) r7     // Catch:{ IllegalArgumentException -> 0x00bb, IllegalStateException -> 0x0099, IOException -> 0x0077 }
                java.lang.String r8 = "historical-record"
                r12.startTag(r3, r8)     // Catch:{ IllegalArgumentException -> 0x00bb, IllegalStateException -> 0x0099, IOException -> 0x0077 }
                java.lang.String r8 = "activity"
                android.content.ComponentName r9 = r7.f3253a     // Catch:{ IllegalArgumentException -> 0x00bb, IllegalStateException -> 0x0099, IOException -> 0x0077 }
                java.lang.String r9 = r9.flattenToString()     // Catch:{ IllegalArgumentException -> 0x00bb, IllegalStateException -> 0x0099, IOException -> 0x0077 }
                r12.attribute(r3, r8, r9)     // Catch:{ IllegalArgumentException -> 0x00bb, IllegalStateException -> 0x0099, IOException -> 0x0077 }
                java.lang.String r8 = "time"
                long r9 = r7.f3254b     // Catch:{ IllegalArgumentException -> 0x00bb, IllegalStateException -> 0x0099, IOException -> 0x0077 }
                java.lang.String r9 = java.lang.String.valueOf(r9)     // Catch:{ IllegalArgumentException -> 0x00bb, IllegalStateException -> 0x0099, IOException -> 0x0077 }
                r12.attribute(r3, r8, r9)     // Catch:{ IllegalArgumentException -> 0x00bb, IllegalStateException -> 0x0099, IOException -> 0x0077 }
                java.lang.String r8 = "weight"
                float r7 = r7.f3255c     // Catch:{ IllegalArgumentException -> 0x00bb, IllegalStateException -> 0x0099, IOException -> 0x0077 }
                java.lang.String r7 = java.lang.String.valueOf(r7)     // Catch:{ IllegalArgumentException -> 0x00bb, IllegalStateException -> 0x0099, IOException -> 0x0077 }
                r12.attribute(r3, r8, r7)     // Catch:{ IllegalArgumentException -> 0x00bb, IllegalStateException -> 0x0099, IOException -> 0x0077 }
                java.lang.String r7 = "historical-record"
                r12.endTag(r3, r7)     // Catch:{ IllegalArgumentException -> 0x00bb, IllegalStateException -> 0x0099, IOException -> 0x0077 }
                int r6 = r6 + 1
                goto L_0x002d
            L_0x0063:
                java.lang.String r0 = "historical-records"
                r12.endTag(r3, r0)     // Catch:{ IllegalArgumentException -> 0x00bb, IllegalStateException -> 0x0099, IOException -> 0x0077 }
                r12.endDocument()     // Catch:{ IllegalArgumentException -> 0x00bb, IllegalStateException -> 0x0099, IOException -> 0x0077 }
                android.support.v7.widget.d r12 = android.support.p031v7.widget.C0895d.this
                r12.f3240d = r2
                if (r4 == 0) goto L_0x00dd
            L_0x0071:
                r4.close()     // Catch:{ IOException -> 0x00dd }
                return r3
            L_0x0075:
                r12 = move-exception
                goto L_0x00de
            L_0x0077:
                r12 = move-exception
                java.lang.String r0 = android.support.p031v7.widget.C0895d.f3235a     // Catch:{ all -> 0x0075 }
                java.lang.StringBuilder r1 = new java.lang.StringBuilder     // Catch:{ all -> 0x0075 }
                r1.<init>()     // Catch:{ all -> 0x0075 }
                java.lang.String r5 = "Error writing historical record file: "
                r1.append(r5)     // Catch:{ all -> 0x0075 }
                android.support.v7.widget.d r5 = android.support.p031v7.widget.C0895d.this     // Catch:{ all -> 0x0075 }
                java.lang.String r5 = r5.f3239c     // Catch:{ all -> 0x0075 }
                r1.append(r5)     // Catch:{ all -> 0x0075 }
                java.lang.String r1 = r1.toString()     // Catch:{ all -> 0x0075 }
                android.util.Log.e(r0, r1, r12)     // Catch:{ all -> 0x0075 }
                android.support.v7.widget.d r12 = android.support.p031v7.widget.C0895d.this
                r12.f3240d = r2
                if (r4 == 0) goto L_0x00dd
                goto L_0x0071
            L_0x0099:
                r12 = move-exception
                java.lang.String r0 = android.support.p031v7.widget.C0895d.f3235a     // Catch:{ all -> 0x0075 }
                java.lang.StringBuilder r1 = new java.lang.StringBuilder     // Catch:{ all -> 0x0075 }
                r1.<init>()     // Catch:{ all -> 0x0075 }
                java.lang.String r5 = "Error writing historical record file: "
                r1.append(r5)     // Catch:{ all -> 0x0075 }
                android.support.v7.widget.d r5 = android.support.p031v7.widget.C0895d.this     // Catch:{ all -> 0x0075 }
                java.lang.String r5 = r5.f3239c     // Catch:{ all -> 0x0075 }
                r1.append(r5)     // Catch:{ all -> 0x0075 }
                java.lang.String r1 = r1.toString()     // Catch:{ all -> 0x0075 }
                android.util.Log.e(r0, r1, r12)     // Catch:{ all -> 0x0075 }
                android.support.v7.widget.d r12 = android.support.p031v7.widget.C0895d.this
                r12.f3240d = r2
                if (r4 == 0) goto L_0x00dd
                goto L_0x0071
            L_0x00bb:
                r12 = move-exception
                java.lang.String r0 = android.support.p031v7.widget.C0895d.f3235a     // Catch:{ all -> 0x0075 }
                java.lang.StringBuilder r1 = new java.lang.StringBuilder     // Catch:{ all -> 0x0075 }
                r1.<init>()     // Catch:{ all -> 0x0075 }
                java.lang.String r5 = "Error writing historical record file: "
                r1.append(r5)     // Catch:{ all -> 0x0075 }
                android.support.v7.widget.d r5 = android.support.p031v7.widget.C0895d.this     // Catch:{ all -> 0x0075 }
                java.lang.String r5 = r5.f3239c     // Catch:{ all -> 0x0075 }
                r1.append(r5)     // Catch:{ all -> 0x0075 }
                java.lang.String r1 = r1.toString()     // Catch:{ all -> 0x0075 }
                android.util.Log.e(r0, r1, r12)     // Catch:{ all -> 0x0075 }
                android.support.v7.widget.d r12 = android.support.p031v7.widget.C0895d.this
                r12.f3240d = r2
                if (r4 == 0) goto L_0x00dd
                goto L_0x0071
            L_0x00dd:
                return r3
            L_0x00de:
                android.support.v7.widget.d r0 = android.support.p031v7.widget.C0895d.this
                r0.f3240d = r2
                if (r4 == 0) goto L_0x00e7
                r4.close()     // Catch:{ IOException -> 0x00e7 }
            L_0x00e7:
                throw r12
            L_0x00e8:
                r0 = move-exception
                java.lang.String r1 = android.support.p031v7.widget.C0895d.f3235a
                java.lang.StringBuilder r2 = new java.lang.StringBuilder
                r2.<init>()
                java.lang.String r4 = "Error writing historical record file: "
                r2.append(r4)
                r2.append(r12)
                java.lang.String r12 = r2.toString()
                android.util.Log.e(r1, r12, r0)
                return r3
            */
            throw new UnsupportedOperationException("Method not decompiled: android.support.p031v7.widget.C0895d.C0900e.doInBackground(java.lang.Object[]):java.lang.Void");
        }
    }

    /* renamed from: a */
    private boolean m4800a(C0898c cVar) {
        boolean add = this.f3243i.add(cVar);
        if (add) {
            this.f3248n = true;
            m4806h();
            m4801c();
            m4803e();
            notifyChanged();
        }
        return add;
    }

    /* renamed from: c */
    private void m4801c() {
        if (!this.f3247m) {
            throw new IllegalStateException("No preceding call to #readHistoricalData");
        } else if (this.f3248n) {
            this.f3248n = false;
            if (!TextUtils.isEmpty(this.f3239c)) {
                new C0900e().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, new Object[]{new ArrayList(this.f3243i), this.f3239c});
            }
        }
    }

    /* renamed from: d */
    private void m4802d() {
        boolean f = m4804f() | m4805g();
        m4806h();
        if (f) {
            m4803e();
            notifyChanged();
        }
    }

    /* renamed from: e */
    private boolean m4803e() {
        if (this.f3245k == null || this.f3244j == null || this.f3242h.isEmpty() || this.f3243i.isEmpty()) {
            return false;
        }
        this.f3245k.mo4513a(this.f3244j, this.f3242h, Collections.unmodifiableList(this.f3243i));
        return true;
    }

    /* renamed from: f */
    private boolean m4804f() {
        if (!this.f3249o || this.f3244j == null) {
            return false;
        }
        this.f3249o = false;
        this.f3242h.clear();
        List queryIntentActivities = this.f3238b.getPackageManager().queryIntentActivities(this.f3244j, 0);
        int size = queryIntentActivities.size();
        for (int i = 0; i < size; i++) {
            this.f3242h.add(new C0896a((ResolveInfo) queryIntentActivities.get(i)));
        }
        return true;
    }

    /* renamed from: g */
    private boolean m4805g() {
        if (!this.f3240d || !this.f3248n || TextUtils.isEmpty(this.f3239c)) {
            return false;
        }
        this.f3240d = false;
        this.f3247m = true;
        m4807i();
        return true;
    }

    /* renamed from: h */
    private void m4806h() {
        int size = this.f3243i.size() - this.f3246l;
        if (size > 0) {
            this.f3248n = true;
            for (int i = 0; i < size; i++) {
                C0898c cVar = (C0898c) this.f3243i.remove(0);
            }
        }
    }

    /* renamed from: i */
    private void m4807i() {
        try {
            FileInputStream openFileInput = this.f3238b.openFileInput(this.f3239c);
            try {
                XmlPullParser newPullParser = Xml.newPullParser();
                newPullParser.setInput(openFileInput, "UTF-8");
                int i = 0;
                while (i != 1 && i != 2) {
                    i = newPullParser.next();
                }
                if (!"historical-records".equals(newPullParser.getName())) {
                    throw new XmlPullParserException("Share records file does not start with historical-records tag.");
                }
                List<C0898c> list = this.f3243i;
                list.clear();
                while (true) {
                    int next = newPullParser.next();
                    if (next != 1) {
                        if (!(next == 3 || next == 4)) {
                            if (!"historical-record".equals(newPullParser.getName())) {
                                throw new XmlPullParserException("Share records file not well-formed.");
                            }
                            list.add(new C0898c(newPullParser.getAttributeValue(null, "activity"), Long.parseLong(newPullParser.getAttributeValue(null, "time")), Float.parseFloat(newPullParser.getAttributeValue(null, "weight"))));
                        }
                    }
                }
            } catch (XmlPullParserException e) {
                String str = f3235a;
                StringBuilder sb = new StringBuilder();
                sb.append("Error reading historical recrod file: ");
                sb.append(this.f3239c);
                Log.e(str, sb.toString(), e);
            } catch (IOException e2) {
                String str2 = f3235a;
                StringBuilder sb2 = new StringBuilder();
                sb2.append("Error reading historical recrod file: ");
                sb2.append(this.f3239c);
                Log.e(str2, sb2.toString(), e2);
                if (openFileInput != null) {
                    try {
                        openFileInput.close();
                    } catch (IOException unused) {
                    }
                }
            } finally {
                if (openFileInput != null) {
                    try {
                        openFileInput.close();
                    } catch (IOException unused2) {
                    }
                }
            }
        } catch (FileNotFoundException unused3) {
        }
    }

    /* renamed from: a */
    public int mo4502a() {
        int size;
        synchronized (this.f3241g) {
            m4802d();
            size = this.f3242h.size();
        }
        return size;
    }

    /* renamed from: a */
    public int mo4503a(ResolveInfo resolveInfo) {
        synchronized (this.f3241g) {
            m4802d();
            List<C0896a> list = this.f3242h;
            int size = list.size();
            for (int i = 0; i < size; i++) {
                if (((C0896a) list.get(i)).f3251a == resolveInfo) {
                    return i;
                }
            }
            return -1;
        }
    }

    /* renamed from: a */
    public ResolveInfo mo4504a(int i) {
        ResolveInfo resolveInfo;
        synchronized (this.f3241g) {
            m4802d();
            resolveInfo = ((C0896a) this.f3242h.get(i)).f3251a;
        }
        return resolveInfo;
    }

    /* renamed from: b */
    public Intent mo4505b(int i) {
        synchronized (this.f3241g) {
            if (this.f3244j == null) {
                return null;
            }
            m4802d();
            C0896a aVar = (C0896a) this.f3242h.get(i);
            ComponentName componentName = new ComponentName(aVar.f3251a.activityInfo.packageName, aVar.f3251a.activityInfo.name);
            Intent intent = new Intent(this.f3244j);
            intent.setComponent(componentName);
            if (this.f3250p != null) {
                if (this.f3250p.mo4517a(this, new Intent(intent))) {
                    return null;
                }
            }
            m4800a(new C0898c(componentName, System.currentTimeMillis(), 1.0f));
            return intent;
        }
    }

    /* renamed from: b */
    public ResolveInfo mo4506b() {
        synchronized (this.f3241g) {
            m4802d();
            if (this.f3242h.isEmpty()) {
                return null;
            }
            ResolveInfo resolveInfo = ((C0896a) this.f3242h.get(0)).f3251a;
            return resolveInfo;
        }
    }

    /* renamed from: c */
    public void mo4507c(int i) {
        synchronized (this.f3241g) {
            m4802d();
            C0896a aVar = (C0896a) this.f3242h.get(i);
            C0896a aVar2 = (C0896a) this.f3242h.get(0);
            m4800a(new C0898c(new ComponentName(aVar.f3251a.activityInfo.packageName, aVar.f3251a.activityInfo.name), System.currentTimeMillis(), aVar2 != null ? (aVar2.f3252b - aVar.f3252b) + 5.0f : 1.0f));
        }
    }
}
