package android.support.p031v7.widget;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import java.lang.ref.WeakReference;

/* renamed from: android.support.v7.widget.bm */
class C0868bm extends C0850ba {

    /* renamed from: a */
    private final WeakReference<Context> f3142a;

    public C0868bm(Context context, Resources resources) {
        super(resources);
        this.f3142a = new WeakReference<>(context);
    }

    public Drawable getDrawable(int i) {
        Drawable drawable = super.getDrawable(i);
        Context context = (Context) this.f3142a.get();
        if (!(drawable == null || context == null)) {
            C0909k.m4874a();
            C0909k.m4880a(context, i, drawable);
        }
        return drawable;
    }
}
