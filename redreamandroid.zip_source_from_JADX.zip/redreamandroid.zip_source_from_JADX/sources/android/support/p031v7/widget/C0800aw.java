package android.support.p031v7.widget;

import java.util.List;

/* renamed from: android.support.v7.widget.aw */
class C0800aw {

    /* renamed from: a */
    final C0801a f2833a;

    /* renamed from: android.support.v7.widget.aw$a */
    interface C0801a {
        /* renamed from: a */
        C0903b mo3814a(int i, int i2, int i3, Object obj);

        /* renamed from: a */
        void mo3815a(C0903b bVar);
    }

    C0800aw(C0801a aVar) {
        this.f2833a = aVar;
    }

    /* renamed from: a */
    private void m3978a(List<C0903b> list, int i, int i2) {
        C0903b bVar = (C0903b) list.get(i);
        C0903b bVar2 = (C0903b) list.get(i2);
        int i3 = bVar2.f3265a;
        if (i3 != 4) {
            switch (i3) {
                case 1:
                    m3980c(list, i, bVar, i2, bVar2);
                    return;
                case 2:
                    mo3812a(list, i, bVar, i2, bVar2);
                    return;
                default:
                    return;
            }
        } else {
            mo3813b(list, i, bVar, i2, bVar2);
        }
    }

    /* renamed from: b */
    private int m3979b(List<C0903b> list) {
        boolean z = false;
        for (int size = list.size() - 1; size >= 0; size--) {
            if (((C0903b) list.get(size)).f3265a != 8) {
                z = true;
            } else if (z) {
                return size;
            }
        }
        return -1;
    }

    /* renamed from: c */
    private void m3980c(List<C0903b> list, int i, C0903b bVar, int i2, C0903b bVar2) {
        int i3 = bVar.f3268d < bVar2.f3266b ? -1 : 0;
        if (bVar.f3266b < bVar2.f3266b) {
            i3++;
        }
        if (bVar2.f3266b <= bVar.f3266b) {
            bVar.f3266b += bVar2.f3268d;
        }
        if (bVar2.f3266b <= bVar.f3268d) {
            bVar.f3268d += bVar2.f3268d;
        }
        bVar2.f3266b += i3;
        list.set(i, bVar2);
        list.set(i2, bVar);
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo3811a(List<C0903b> list) {
        while (true) {
            int b = m3979b(list);
            if (b != -1) {
                m3978a(list, b, b + 1);
            } else {
                return;
            }
        }
    }

    /* access modifiers changed from: 0000 */
    /* JADX WARNING: Code restructure failed: missing block: B:44:0x00c7, code lost:
        if (r11.f3268d > r13.f3266b) goto L_0x00c9;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:57:0x00fe, code lost:
        if (r11.f3268d >= r13.f3266b) goto L_0x00c9;
     */
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void mo3812a(java.util.List<android.support.p031v7.widget.C0901e.C0903b> r9, int r10, android.support.p031v7.widget.C0901e.C0903b r11, int r12, android.support.p031v7.widget.C0901e.C0903b r13) {
        /*
            r8 = this;
            int r0 = r11.f3266b
            int r1 = r11.f3268d
            r2 = 0
            r3 = 1
            if (r0 >= r1) goto L_0x001c
            int r0 = r13.f3266b
            int r1 = r11.f3266b
            if (r0 != r1) goto L_0x001a
            int r0 = r13.f3268d
            int r1 = r11.f3268d
            int r4 = r11.f3266b
            int r1 = r1 - r4
            if (r0 != r1) goto L_0x001a
            r0 = r2
            r2 = r3
            goto L_0x0030
        L_0x001a:
            r0 = r2
            goto L_0x0030
        L_0x001c:
            int r0 = r13.f3266b
            int r1 = r11.f3268d
            int r1 = r1 + r3
            if (r0 != r1) goto L_0x002f
            int r0 = r13.f3268d
            int r1 = r11.f3266b
            int r4 = r11.f3268d
            int r1 = r1 - r4
            if (r0 != r1) goto L_0x002f
            r0 = r3
            r2 = r0
            goto L_0x0030
        L_0x002f:
            r0 = r3
        L_0x0030:
            int r1 = r11.f3268d
            int r4 = r13.f3266b
            r5 = 2
            if (r1 >= r4) goto L_0x003d
            int r1 = r13.f3266b
            int r1 = r1 - r3
            r13.f3266b = r1
            goto L_0x005c
        L_0x003d:
            int r1 = r11.f3268d
            int r4 = r13.f3266b
            int r6 = r13.f3268d
            int r4 = r4 + r6
            if (r1 >= r4) goto L_0x005c
            int r10 = r13.f3268d
            int r10 = r10 - r3
            r13.f3268d = r10
            r11.f3265a = r5
            r11.f3268d = r3
            int r10 = r13.f3268d
            if (r10 != 0) goto L_0x005b
            r9.remove(r12)
            android.support.v7.widget.aw$a r9 = r8.f2833a
            r9.mo3815a(r13)
        L_0x005b:
            return
        L_0x005c:
            int r1 = r11.f3266b
            int r4 = r13.f3266b
            r6 = 0
            if (r1 > r4) goto L_0x0069
            int r1 = r13.f3266b
            int r1 = r1 + r3
            r13.f3266b = r1
            goto L_0x008a
        L_0x0069:
            int r1 = r11.f3266b
            int r4 = r13.f3266b
            int r7 = r13.f3268d
            int r4 = r4 + r7
            if (r1 >= r4) goto L_0x008a
            int r1 = r13.f3266b
            int r4 = r13.f3268d
            int r1 = r1 + r4
            int r4 = r11.f3266b
            int r1 = r1 - r4
            android.support.v7.widget.aw$a r4 = r8.f2833a
            int r7 = r11.f3266b
            int r7 = r7 + r3
            android.support.v7.widget.e$b r6 = r4.mo3814a(r5, r7, r1, r6)
            int r1 = r11.f3266b
            int r3 = r13.f3266b
            int r1 = r1 - r3
            r13.f3268d = r1
        L_0x008a:
            if (r2 == 0) goto L_0x0098
            r9.set(r10, r13)
            r9.remove(r12)
            android.support.v7.widget.aw$a r9 = r8.f2833a
            r9.mo3815a(r11)
            return
        L_0x0098:
            if (r0 == 0) goto L_0x00d1
            if (r6 == 0) goto L_0x00b6
            int r0 = r11.f3266b
            int r1 = r6.f3266b
            if (r0 <= r1) goto L_0x00a9
            int r0 = r11.f3266b
            int r1 = r6.f3268d
            int r0 = r0 - r1
            r11.f3266b = r0
        L_0x00a9:
            int r0 = r11.f3268d
            int r1 = r6.f3266b
            if (r0 <= r1) goto L_0x00b6
            int r0 = r11.f3268d
            int r1 = r6.f3268d
            int r0 = r0 - r1
            r11.f3268d = r0
        L_0x00b6:
            int r0 = r11.f3266b
            int r1 = r13.f3266b
            if (r0 <= r1) goto L_0x00c3
            int r0 = r11.f3266b
            int r1 = r13.f3268d
            int r0 = r0 - r1
            r11.f3266b = r0
        L_0x00c3:
            int r0 = r11.f3268d
            int r1 = r13.f3266b
            if (r0 <= r1) goto L_0x0101
        L_0x00c9:
            int r0 = r11.f3268d
            int r1 = r13.f3268d
            int r0 = r0 - r1
            r11.f3268d = r0
            goto L_0x0101
        L_0x00d1:
            if (r6 == 0) goto L_0x00ed
            int r0 = r11.f3266b
            int r1 = r6.f3266b
            if (r0 < r1) goto L_0x00e0
            int r0 = r11.f3266b
            int r1 = r6.f3268d
            int r0 = r0 - r1
            r11.f3266b = r0
        L_0x00e0:
            int r0 = r11.f3268d
            int r1 = r6.f3266b
            if (r0 < r1) goto L_0x00ed
            int r0 = r11.f3268d
            int r1 = r6.f3268d
            int r0 = r0 - r1
            r11.f3268d = r0
        L_0x00ed:
            int r0 = r11.f3266b
            int r1 = r13.f3266b
            if (r0 < r1) goto L_0x00fa
            int r0 = r11.f3266b
            int r1 = r13.f3268d
            int r0 = r0 - r1
            r11.f3266b = r0
        L_0x00fa:
            int r0 = r11.f3268d
            int r1 = r13.f3266b
            if (r0 < r1) goto L_0x0101
            goto L_0x00c9
        L_0x0101:
            r9.set(r10, r13)
            int r13 = r11.f3266b
            int r0 = r11.f3268d
            if (r13 == r0) goto L_0x010e
            r9.set(r12, r11)
            goto L_0x0111
        L_0x010e:
            r9.remove(r12)
        L_0x0111:
            if (r6 == 0) goto L_0x0116
            r9.add(r10, r6)
        L_0x0116:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.p031v7.widget.C0800aw.mo3812a(java.util.List, int, android.support.v7.widget.e$b, int, android.support.v7.widget.e$b):void");
    }

    /* access modifiers changed from: 0000 */
    /* JADX WARNING: Removed duplicated region for block: B:10:0x0035  */
    /* JADX WARNING: Removed duplicated region for block: B:15:0x005d  */
    /* JADX WARNING: Removed duplicated region for block: B:16:0x0061  */
    /* JADX WARNING: Removed duplicated region for block: B:18:0x006b  */
    /* JADX WARNING: Removed duplicated region for block: B:20:0x0070  */
    /* JADX WARNING: Removed duplicated region for block: B:22:? A[RETURN, SYNTHETIC] */
    /* JADX WARNING: Removed duplicated region for block: B:9:0x002f  */
    /* renamed from: b */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void mo3813b(java.util.List<android.support.p031v7.widget.C0901e.C0903b> r8, int r9, android.support.p031v7.widget.C0901e.C0903b r10, int r11, android.support.p031v7.widget.C0901e.C0903b r12) {
        /*
            r7 = this;
            int r0 = r10.f3268d
            int r1 = r12.f3266b
            r2 = 4
            r3 = 0
            r4 = 1
            if (r0 >= r1) goto L_0x000f
            int r0 = r12.f3266b
            int r0 = r0 - r4
            r12.f3266b = r0
            goto L_0x0028
        L_0x000f:
            int r0 = r10.f3268d
            int r1 = r12.f3266b
            int r5 = r12.f3268d
            int r1 = r1 + r5
            if (r0 >= r1) goto L_0x0028
            int r0 = r12.f3268d
            int r0 = r0 - r4
            r12.f3268d = r0
            android.support.v7.widget.aw$a r0 = r7.f2833a
            int r1 = r10.f3266b
            java.lang.Object r5 = r12.f3267c
            android.support.v7.widget.e$b r0 = r0.mo3814a(r2, r1, r4, r5)
            goto L_0x0029
        L_0x0028:
            r0 = r3
        L_0x0029:
            int r1 = r10.f3266b
            int r5 = r12.f3266b
            if (r1 > r5) goto L_0x0035
            int r1 = r12.f3266b
            int r1 = r1 + r4
            r12.f3266b = r1
            goto L_0x0056
        L_0x0035:
            int r1 = r10.f3266b
            int r5 = r12.f3266b
            int r6 = r12.f3268d
            int r5 = r5 + r6
            if (r1 >= r5) goto L_0x0056
            int r1 = r12.f3266b
            int r3 = r12.f3268d
            int r1 = r1 + r3
            int r3 = r10.f3266b
            int r1 = r1 - r3
            android.support.v7.widget.aw$a r3 = r7.f2833a
            int r5 = r10.f3266b
            int r5 = r5 + r4
            java.lang.Object r4 = r12.f3267c
            android.support.v7.widget.e$b r3 = r3.mo3814a(r2, r5, r1, r4)
            int r2 = r12.f3268d
            int r2 = r2 - r1
            r12.f3268d = r2
        L_0x0056:
            r8.set(r11, r10)
            int r10 = r12.f3268d
            if (r10 <= 0) goto L_0x0061
            r8.set(r9, r12)
            goto L_0x0069
        L_0x0061:
            r8.remove(r9)
            android.support.v7.widget.aw$a r10 = r7.f2833a
            r10.mo3815a(r12)
        L_0x0069:
            if (r0 == 0) goto L_0x006e
            r8.add(r9, r0)
        L_0x006e:
            if (r3 == 0) goto L_0x0073
            r8.add(r9, r3)
        L_0x0073:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.p031v7.widget.C0800aw.mo3813b(java.util.List, int, android.support.v7.widget.e$b, int, android.support.v7.widget.e$b):void");
    }
}
