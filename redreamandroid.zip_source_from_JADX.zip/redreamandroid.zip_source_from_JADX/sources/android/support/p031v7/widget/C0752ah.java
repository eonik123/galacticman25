package android.support.p031v7.widget;

import android.support.p031v7.widget.C0805ay.C0846x;
import android.view.View;
import android.view.ViewGroup.LayoutParams;
import java.util.ArrayList;
import java.util.List;

/* renamed from: android.support.v7.widget.ah */
class C0752ah {

    /* renamed from: a */
    final C0754b f2622a;

    /* renamed from: b */
    final C0753a f2623b = new C0753a();

    /* renamed from: c */
    final List<View> f2624c = new ArrayList();

    /* renamed from: android.support.v7.widget.ah$a */
    static class C0753a {

        /* renamed from: a */
        long f2625a = 0;

        /* renamed from: b */
        C0753a f2626b;

        C0753a() {
        }

        /* renamed from: b */
        private void m3762b() {
            if (this.f2626b == null) {
                this.f2626b = new C0753a();
            }
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public void mo3593a() {
            this.f2625a = 0;
            if (this.f2626b != null) {
                this.f2626b.mo3593a();
            }
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public void mo3594a(int i) {
            if (i >= 64) {
                m3762b();
                this.f2626b.mo3594a(i - 64);
                return;
            }
            this.f2625a |= 1 << i;
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public void mo3595a(int i, boolean z) {
            if (i >= 64) {
                m3762b();
                this.f2626b.mo3595a(i - 64, z);
                return;
            }
            boolean z2 = (this.f2625a & Long.MIN_VALUE) != 0;
            long j = (1 << i) - 1;
            this.f2625a = (this.f2625a & j) | (((~j) & this.f2625a) << 1);
            if (z) {
                mo3594a(i);
            } else {
                mo3596b(i);
            }
            if (z2 || this.f2626b != null) {
                m3762b();
                this.f2626b.mo3595a(0, z2);
            }
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: b */
        public void mo3596b(int i) {
            if (i < 64) {
                this.f2625a &= ~(1 << i);
            } else if (this.f2626b != null) {
                this.f2626b.mo3596b(i - 64);
            }
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: c */
        public boolean mo3597c(int i) {
            if (i < 64) {
                return (this.f2625a & (1 << i)) != 0;
            }
            m3762b();
            return this.f2626b.mo3597c(i - 64);
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: d */
        public boolean mo3598d(int i) {
            if (i >= 64) {
                m3762b();
                return this.f2626b.mo3598d(i - 64);
            }
            long j = 1 << i;
            boolean z = (this.f2625a & j) != 0;
            this.f2625a &= ~j;
            long j2 = j - 1;
            this.f2625a = (this.f2625a & j2) | Long.rotateRight((~j2) & this.f2625a, 1);
            if (this.f2626b != null) {
                if (this.f2626b.mo3597c(0)) {
                    mo3594a(63);
                }
                this.f2626b.mo3598d(0);
            }
            return z;
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: e */
        public int mo3599e(int i) {
            return this.f2626b == null ? i >= 64 ? Long.bitCount(this.f2625a) : Long.bitCount(this.f2625a & ((1 << i) - 1)) : i < 64 ? Long.bitCount(this.f2625a & ((1 << i) - 1)) : this.f2626b.mo3599e(i - 64) + Long.bitCount(this.f2625a);
        }

        public String toString() {
            if (this.f2626b == null) {
                return Long.toBinaryString(this.f2625a);
            }
            StringBuilder sb = new StringBuilder();
            sb.append(this.f2626b.toString());
            sb.append("xx");
            sb.append(Long.toBinaryString(this.f2625a));
            return sb.toString();
        }
    }

    /* renamed from: android.support.v7.widget.ah$b */
    interface C0754b {
        /* renamed from: a */
        int mo3601a();

        /* renamed from: a */
        int mo3602a(View view);

        /* renamed from: a */
        void mo3603a(int i);

        /* renamed from: a */
        void mo3604a(View view, int i);

        /* renamed from: a */
        void mo3605a(View view, int i, LayoutParams layoutParams);

        /* renamed from: b */
        C0846x mo3606b(View view);

        /* renamed from: b */
        View mo3607b(int i);

        /* renamed from: b */
        void mo3608b();

        /* renamed from: c */
        void mo3609c(int i);

        /* renamed from: c */
        void mo3610c(View view);

        /* renamed from: d */
        void mo3611d(View view);
    }

    C0752ah(C0754b bVar) {
        this.f2622a = bVar;
    }

    /* renamed from: f */
    private int m3742f(int i) {
        if (i < 0) {
            return -1;
        }
        int a = this.f2622a.mo3601a();
        int i2 = i;
        while (i2 < a) {
            int e = i - (i2 - this.f2623b.mo3599e(i2));
            if (e == 0) {
                while (this.f2623b.mo3597c(i2)) {
                    i2++;
                }
                return i2;
            }
            i2 += e;
        }
        return -1;
    }

    /* renamed from: g */
    private void m3743g(View view) {
        this.f2624c.add(view);
        this.f2622a.mo3610c(view);
    }

    /* renamed from: h */
    private boolean m3744h(View view) {
        if (!this.f2624c.remove(view)) {
            return false;
        }
        this.f2622a.mo3611d(view);
        return true;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo3575a() {
        this.f2623b.mo3593a();
        for (int size = this.f2624c.size() - 1; size >= 0; size--) {
            this.f2622a.mo3611d((View) this.f2624c.get(size));
            this.f2624c.remove(size);
        }
        this.f2622a.mo3608b();
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo3576a(int i) {
        int f = m3742f(i);
        View b = this.f2622a.mo3607b(f);
        if (b != null) {
            if (this.f2623b.mo3598d(f)) {
                m3744h(b);
            }
            this.f2622a.mo3603a(f);
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo3577a(View view) {
        int a = this.f2622a.mo3602a(view);
        if (a >= 0) {
            if (this.f2623b.mo3598d(a)) {
                m3744h(view);
            }
            this.f2622a.mo3603a(a);
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo3578a(View view, int i, LayoutParams layoutParams, boolean z) {
        int a = i < 0 ? this.f2622a.mo3601a() : m3742f(i);
        this.f2623b.mo3595a(a, z);
        if (z) {
            m3743g(view);
        }
        this.f2622a.mo3605a(view, a, layoutParams);
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo3579a(View view, int i, boolean z) {
        int a = i < 0 ? this.f2622a.mo3601a() : m3742f(i);
        this.f2623b.mo3595a(a, z);
        if (z) {
            m3743g(view);
        }
        this.f2622a.mo3604a(view, a);
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo3580a(View view, boolean z) {
        mo3579a(view, -1, z);
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: b */
    public int mo3581b() {
        return this.f2622a.mo3601a() - this.f2624c.size();
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: b */
    public int mo3582b(View view) {
        int a = this.f2622a.mo3602a(view);
        if (a != -1 && !this.f2623b.mo3597c(a)) {
            return a - this.f2623b.mo3599e(a);
        }
        return -1;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: b */
    public View mo3583b(int i) {
        return this.f2622a.mo3607b(m3742f(i));
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: c */
    public int mo3584c() {
        return this.f2622a.mo3601a();
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: c */
    public View mo3585c(int i) {
        int size = this.f2624c.size();
        for (int i2 = 0; i2 < size; i2++) {
            View view = (View) this.f2624c.get(i2);
            C0846x b = this.f2622a.mo3606b(view);
            if (b.mo4252d() == i && !b.mo4262n() && !b.mo4265q()) {
                return view;
            }
        }
        return null;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: c */
    public boolean mo3586c(View view) {
        return this.f2624c.contains(view);
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: d */
    public View mo3587d(int i) {
        return this.f2622a.mo3607b(i);
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: d */
    public void mo3588d(View view) {
        int a = this.f2622a.mo3602a(view);
        if (a < 0) {
            StringBuilder sb = new StringBuilder();
            sb.append("view is not a child, cannot hide ");
            sb.append(view);
            throw new IllegalArgumentException(sb.toString());
        }
        this.f2623b.mo3594a(a);
        m3743g(view);
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: e */
    public void mo3589e(int i) {
        int f = m3742f(i);
        this.f2623b.mo3598d(f);
        this.f2622a.mo3609c(f);
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: e */
    public void mo3590e(View view) {
        int a = this.f2622a.mo3602a(view);
        if (a < 0) {
            StringBuilder sb = new StringBuilder();
            sb.append("view is not a child, cannot hide ");
            sb.append(view);
            throw new IllegalArgumentException(sb.toString());
        } else if (!this.f2623b.mo3597c(a)) {
            StringBuilder sb2 = new StringBuilder();
            sb2.append("trying to unhide a view that was not hidden");
            sb2.append(view);
            throw new RuntimeException(sb2.toString());
        } else {
            this.f2623b.mo3596b(a);
            m3744h(view);
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: f */
    public boolean mo3591f(View view) {
        int a = this.f2622a.mo3602a(view);
        if (a == -1) {
            m3744h(view);
            return true;
        } else if (!this.f2623b.mo3597c(a)) {
            return false;
        } else {
            this.f2623b.mo3598d(a);
            m3744h(view);
            this.f2622a.mo3603a(a);
            return true;
        }
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(this.f2623b.toString());
        sb.append(", hidden list:");
        sb.append(this.f2624c.size());
        return sb.toString();
    }
}
