package android.support.p031v7.widget;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.ClassLoaderCreator;
import android.os.Parcelable.Creator;
import android.support.p018v4.p028h.C0457a;
import android.support.p018v4.p028h.C0480d;
import android.support.p018v4.p028h.C0484g;
import android.support.p018v4.p028h.C0495r;
import android.support.p031v7.app.C0565a.C0566a;
import android.support.p031v7.p032a.C0540a.C0541a;
import android.support.p031v7.p032a.C0540a.C0550j;
import android.support.p031v7.p033b.p034a.C0606a;
import android.support.p031v7.view.C0629c;
import android.support.p031v7.view.C0634g;
import android.support.p031v7.view.menu.C0655h;
import android.support.p031v7.view.menu.C0655h.C0656a;
import android.support.p031v7.view.menu.C0659j;
import android.support.p031v7.view.menu.C0671o;
import android.support.p031v7.view.menu.C0671o.C0672a;
import android.support.p031v7.view.menu.C0681u;
import android.support.p031v7.widget.ActionMenuView.C0693e;
import android.text.TextUtils;
import android.text.TextUtils.TruncateAt;
import android.util.AttributeSet;
import android.view.ContextThemeWrapper;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewGroup.MarginLayoutParams;
import android.view.ViewParent;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;

/* renamed from: android.support.v7.widget.Toolbar */
public class Toolbar extends ViewGroup {

    /* renamed from: A */
    private int f2533A;

    /* renamed from: B */
    private int f2534B;

    /* renamed from: C */
    private boolean f2535C;

    /* renamed from: D */
    private boolean f2536D;

    /* renamed from: E */
    private final ArrayList<View> f2537E;

    /* renamed from: F */
    private final ArrayList<View> f2538F;

    /* renamed from: G */
    private final int[] f2539G;

    /* renamed from: H */
    private final C0693e f2540H;

    /* renamed from: I */
    private C0870bo f2541I;

    /* renamed from: J */
    private C0887c f2542J;

    /* renamed from: K */
    private C0735a f2543K;

    /* renamed from: L */
    private C0672a f2544L;

    /* renamed from: M */
    private C0656a f2545M;

    /* renamed from: N */
    private boolean f2546N;

    /* renamed from: O */
    private final Runnable f2547O;

    /* renamed from: a */
    private ActionMenuView f2548a;

    /* renamed from: b */
    ImageButton f2549b;

    /* renamed from: c */
    View f2550c;

    /* renamed from: d */
    int f2551d;

    /* renamed from: e */
    C0737c f2552e;

    /* renamed from: f */
    private TextView f2553f;

    /* renamed from: g */
    private TextView f2554g;

    /* renamed from: h */
    private ImageButton f2555h;

    /* renamed from: i */
    private ImageView f2556i;

    /* renamed from: j */
    private Drawable f2557j;

    /* renamed from: k */
    private CharSequence f2558k;

    /* renamed from: l */
    private Context f2559l;

    /* renamed from: m */
    private int f2560m;

    /* renamed from: n */
    private int f2561n;

    /* renamed from: o */
    private int f2562o;

    /* renamed from: p */
    private int f2563p;

    /* renamed from: q */
    private int f2564q;

    /* renamed from: r */
    private int f2565r;

    /* renamed from: s */
    private int f2566s;

    /* renamed from: t */
    private int f2567t;

    /* renamed from: u */
    private C0854bd f2568u;

    /* renamed from: v */
    private int f2569v;

    /* renamed from: w */
    private int f2570w;

    /* renamed from: x */
    private int f2571x;

    /* renamed from: y */
    private CharSequence f2572y;

    /* renamed from: z */
    private CharSequence f2573z;

    /* renamed from: android.support.v7.widget.Toolbar$a */
    private class C0735a implements C0671o {

        /* renamed from: a */
        C0655h f2577a;

        /* renamed from: b */
        C0659j f2578b;

        C0735a() {
        }

        /* renamed from: a */
        public void mo2637a(Context context, C0655h hVar) {
            if (!(this.f2577a == null || this.f2578b == null)) {
                this.f2577a.mo2739d(this.f2578b);
            }
            this.f2577a = hVar;
        }

        /* renamed from: a */
        public void mo2638a(C0655h hVar, boolean z) {
        }

        /* renamed from: a */
        public void mo2640a(C0672a aVar) {
        }

        /* renamed from: a */
        public boolean mo2643a(C0655h hVar, C0659j jVar) {
            Toolbar.this.mo3460i();
            ViewParent parent = Toolbar.this.f2549b.getParent();
            if (parent != Toolbar.this) {
                if (parent instanceof ViewGroup) {
                    ((ViewGroup) parent).removeView(Toolbar.this.f2549b);
                }
                Toolbar.this.addView(Toolbar.this.f2549b);
            }
            Toolbar.this.f2550c = jVar.getActionView();
            this.f2578b = jVar;
            ViewParent parent2 = Toolbar.this.f2550c.getParent();
            if (parent2 != Toolbar.this) {
                if (parent2 instanceof ViewGroup) {
                    ((ViewGroup) parent2).removeView(Toolbar.this.f2550c);
                }
                C0736b j = Toolbar.this.generateDefaultLayoutParams();
                j.f1689a = 8388611 | (Toolbar.this.f2551d & 112);
                j.f2580b = 2;
                Toolbar.this.f2550c.setLayoutParams(j);
                Toolbar.this.addView(Toolbar.this.f2550c);
            }
            Toolbar.this.mo3462k();
            Toolbar.this.requestLayout();
            jVar.mo2789e(true);
            if (Toolbar.this.f2550c instanceof C0629c) {
                ((C0629c) Toolbar.this.f2550c).mo2501a();
            }
            return true;
        }

        /* renamed from: a */
        public boolean mo2644a(C0681u uVar) {
            return false;
        }

        /* renamed from: b */
        public void mo2647b(boolean z) {
            if (this.f2578b != null) {
                boolean z2 = false;
                if (this.f2577a != null) {
                    int size = this.f2577a.size();
                    int i = 0;
                    while (true) {
                        if (i >= size) {
                            break;
                        } else if (this.f2577a.getItem(i) == this.f2578b) {
                            z2 = true;
                            break;
                        } else {
                            i++;
                        }
                    }
                }
                if (!z2) {
                    mo2649b(this.f2577a, this.f2578b);
                }
            }
        }

        /* renamed from: b */
        public boolean mo2648b() {
            return false;
        }

        /* renamed from: b */
        public boolean mo2649b(C0655h hVar, C0659j jVar) {
            if (Toolbar.this.f2550c instanceof C0629c) {
                ((C0629c) Toolbar.this.f2550c).mo2502b();
            }
            Toolbar.this.removeView(Toolbar.this.f2550c);
            Toolbar.this.removeView(Toolbar.this.f2549b);
            Toolbar.this.f2550c = null;
            Toolbar.this.mo3463l();
            this.f2578b = null;
            Toolbar.this.requestLayout();
            jVar.mo2789e(false);
            return true;
        }
    }

    /* renamed from: android.support.v7.widget.Toolbar$b */
    public static class C0736b extends C0566a {

        /* renamed from: b */
        int f2580b;

        public C0736b(int i, int i2) {
            super(i, i2);
            this.f2580b = 0;
            this.f1689a = 8388627;
        }

        public C0736b(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            this.f2580b = 0;
        }

        public C0736b(C0566a aVar) {
            super(aVar);
            this.f2580b = 0;
        }

        public C0736b(C0736b bVar) {
            super((C0566a) bVar);
            this.f2580b = 0;
            this.f2580b = bVar.f2580b;
        }

        public C0736b(LayoutParams layoutParams) {
            super(layoutParams);
            this.f2580b = 0;
        }

        public C0736b(MarginLayoutParams marginLayoutParams) {
            super((LayoutParams) marginLayoutParams);
            this.f2580b = 0;
            mo3494a(marginLayoutParams);
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public void mo3494a(MarginLayoutParams marginLayoutParams) {
            this.leftMargin = marginLayoutParams.leftMargin;
            this.topMargin = marginLayoutParams.topMargin;
            this.rightMargin = marginLayoutParams.rightMargin;
            this.bottomMargin = marginLayoutParams.bottomMargin;
        }
    }

    /* renamed from: android.support.v7.widget.Toolbar$c */
    public interface C0737c {
        /* renamed from: a */
        boolean mo3495a(MenuItem menuItem);
    }

    /* renamed from: android.support.v7.widget.Toolbar$d */
    public static class C0738d extends C0457a {
        public static final Creator<C0738d> CREATOR = new ClassLoaderCreator<C0738d>() {
            /* renamed from: a */
            public C0738d createFromParcel(Parcel parcel) {
                return new C0738d(parcel, null);
            }

            /* renamed from: a */
            public C0738d createFromParcel(Parcel parcel, ClassLoader classLoader) {
                return new C0738d(parcel, classLoader);
            }

            /* renamed from: a */
            public C0738d[] newArray(int i) {
                return new C0738d[i];
            }
        };

        /* renamed from: a */
        int f2581a;

        /* renamed from: b */
        boolean f2582b;

        public C0738d(Parcel parcel, ClassLoader classLoader) {
            super(parcel, classLoader);
            this.f2581a = parcel.readInt();
            this.f2582b = parcel.readInt() != 0;
        }

        public C0738d(Parcelable parcelable) {
            super(parcelable);
        }

        public void writeToParcel(Parcel parcel, int i) {
            super.writeToParcel(parcel, i);
            parcel.writeInt(this.f2581a);
            parcel.writeInt(this.f2582b ? 1 : 0);
        }
    }

    public Toolbar(Context context) {
        this(context, null);
    }

    public Toolbar(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, C0541a.toolbarStyle);
    }

    public Toolbar(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f2571x = 8388627;
        this.f2537E = new ArrayList<>();
        this.f2538F = new ArrayList<>();
        this.f2539G = new int[2];
        this.f2540H = new C0693e() {
            /* renamed from: a */
            public boolean mo3084a(MenuItem menuItem) {
                if (Toolbar.this.f2552e != null) {
                    return Toolbar.this.f2552e.mo3495a(menuItem);
                }
                return false;
            }
        };
        this.f2547O = new Runnable() {
            public void run() {
                Toolbar.this.mo3426d();
            }
        };
        C0869bn a = C0869bn.m4638a(getContext(), attributeSet, C0550j.Toolbar, i, 0);
        this.f2561n = a.mo4439g(C0550j.Toolbar_titleTextAppearance, 0);
        this.f2562o = a.mo4439g(C0550j.Toolbar_subtitleTextAppearance, 0);
        this.f2571x = a.mo4431c(C0550j.Toolbar_android_gravity, this.f2571x);
        this.f2551d = a.mo4431c(C0550j.Toolbar_buttonGravity, 48);
        int d = a.mo4433d(C0550j.Toolbar_titleMargin, 0);
        if (a.mo4440g(C0550j.Toolbar_titleMargins)) {
            d = a.mo4433d(C0550j.Toolbar_titleMargins, d);
        }
        this.f2567t = d;
        this.f2566s = d;
        this.f2565r = d;
        this.f2564q = d;
        int d2 = a.mo4433d(C0550j.Toolbar_titleMarginStart, -1);
        if (d2 >= 0) {
            this.f2564q = d2;
        }
        int d3 = a.mo4433d(C0550j.Toolbar_titleMarginEnd, -1);
        if (d3 >= 0) {
            this.f2565r = d3;
        }
        int d4 = a.mo4433d(C0550j.Toolbar_titleMarginTop, -1);
        if (d4 >= 0) {
            this.f2566s = d4;
        }
        int d5 = a.mo4433d(C0550j.Toolbar_titleMarginBottom, -1);
        if (d5 >= 0) {
            this.f2567t = d5;
        }
        this.f2563p = a.mo4435e(C0550j.Toolbar_maxButtonHeight, -1);
        int d6 = a.mo4433d(C0550j.Toolbar_contentInsetStart, Integer.MIN_VALUE);
        int d7 = a.mo4433d(C0550j.Toolbar_contentInsetEnd, Integer.MIN_VALUE);
        int e = a.mo4435e(C0550j.Toolbar_contentInsetLeft, 0);
        int e2 = a.mo4435e(C0550j.Toolbar_contentInsetRight, 0);
        m3617s();
        this.f2568u.mo4367b(e, e2);
        if (!(d6 == Integer.MIN_VALUE && d7 == Integer.MIN_VALUE)) {
            this.f2568u.mo4364a(d6, d7);
        }
        this.f2569v = a.mo4433d(C0550j.Toolbar_contentInsetStartWithNavigation, Integer.MIN_VALUE);
        this.f2570w = a.mo4433d(C0550j.Toolbar_contentInsetEndWithActions, Integer.MIN_VALUE);
        this.f2557j = a.mo4426a(C0550j.Toolbar_collapseIcon);
        this.f2558k = a.mo4432c(C0550j.Toolbar_collapseContentDescription);
        CharSequence c = a.mo4432c(C0550j.Toolbar_title);
        if (!TextUtils.isEmpty(c)) {
            setTitle(c);
        }
        CharSequence c2 = a.mo4432c(C0550j.Toolbar_subtitle);
        if (!TextUtils.isEmpty(c2)) {
            setSubtitle(c2);
        }
        this.f2559l = getContext();
        setPopupTheme(a.mo4439g(C0550j.Toolbar_popupTheme, 0));
        Drawable a2 = a.mo4426a(C0550j.Toolbar_navigationIcon);
        if (a2 != null) {
            setNavigationIcon(a2);
        }
        CharSequence c3 = a.mo4432c(C0550j.Toolbar_navigationContentDescription);
        if (!TextUtils.isEmpty(c3)) {
            setNavigationContentDescription(c3);
        }
        Drawable a3 = a.mo4426a(C0550j.Toolbar_logo);
        if (a3 != null) {
            setLogo(a3);
        }
        CharSequence c4 = a.mo4432c(C0550j.Toolbar_logoDescription);
        if (!TextUtils.isEmpty(c4)) {
            setLogoDescription(c4);
        }
        if (a.mo4440g(C0550j.Toolbar_titleTextColor)) {
            setTitleTextColor(a.mo4429b(C0550j.Toolbar_titleTextColor, -1));
        }
        if (a.mo4440g(C0550j.Toolbar_subtitleTextColor)) {
            setSubtitleTextColor(a.mo4429b(C0550j.Toolbar_subtitleTextColor, -1));
        }
        a.mo4427a();
    }

    /* renamed from: a */
    private int m3597a(int i) {
        int i2 = i & 112;
        return (i2 == 16 || i2 == 48 || i2 == 80) ? i2 : this.f2571x & 112;
    }

    /* renamed from: a */
    private int m3598a(View view, int i) {
        C0736b bVar = (C0736b) view.getLayoutParams();
        int measuredHeight = view.getMeasuredHeight();
        int i2 = i > 0 ? (measuredHeight - i) / 2 : 0;
        int a = m3597a(bVar.f1689a);
        if (a == 48) {
            return getPaddingTop() - i2;
        }
        if (a == 80) {
            return (((getHeight() - getPaddingBottom()) - measuredHeight) - bVar.bottomMargin) - i2;
        }
        int paddingTop = getPaddingTop();
        int paddingBottom = getPaddingBottom();
        int height = getHeight();
        int i3 = (((height - paddingTop) - paddingBottom) - measuredHeight) / 2;
        if (i3 < bVar.topMargin) {
            i3 = bVar.topMargin;
        } else {
            int i4 = (((height - paddingBottom) - measuredHeight) - i3) - paddingTop;
            if (i4 < bVar.bottomMargin) {
                i3 = Math.max(0, i3 - (bVar.bottomMargin - i4));
            }
        }
        return paddingTop + i3;
    }

    /* renamed from: a */
    private int m3599a(View view, int i, int i2, int i3, int i4, int[] iArr) {
        MarginLayoutParams marginLayoutParams = (MarginLayoutParams) view.getLayoutParams();
        int i5 = marginLayoutParams.leftMargin - iArr[0];
        int i6 = marginLayoutParams.rightMargin - iArr[1];
        int max = Math.max(0, i5) + Math.max(0, i6);
        iArr[0] = Math.max(0, -i5);
        iArr[1] = Math.max(0, -i6);
        view.measure(getChildMeasureSpec(i, getPaddingLeft() + getPaddingRight() + max + i2, marginLayoutParams.width), getChildMeasureSpec(i3, getPaddingTop() + getPaddingBottom() + marginLayoutParams.topMargin + marginLayoutParams.bottomMargin + i4, marginLayoutParams.height));
        return view.getMeasuredWidth() + max;
    }

    /* renamed from: a */
    private int m3600a(View view, int i, int[] iArr, int i2) {
        C0736b bVar = (C0736b) view.getLayoutParams();
        int i3 = bVar.leftMargin - iArr[0];
        int max = i + Math.max(0, i3);
        iArr[0] = Math.max(0, -i3);
        int a = m3598a(view, i2);
        int measuredWidth = view.getMeasuredWidth();
        view.layout(max, a, max + measuredWidth, view.getMeasuredHeight() + a);
        return max + measuredWidth + bVar.rightMargin;
    }

    /* renamed from: a */
    private int m3601a(List<View> list, int[] iArr) {
        int i = iArr[0];
        int i2 = iArr[1];
        int size = list.size();
        int i3 = i2;
        int i4 = 0;
        int i5 = 0;
        while (i4 < size) {
            View view = (View) list.get(i4);
            C0736b bVar = (C0736b) view.getLayoutParams();
            int i6 = bVar.leftMargin - i;
            int i7 = bVar.rightMargin - i3;
            int max = Math.max(0, i6);
            int max2 = Math.max(0, i7);
            int max3 = Math.max(0, -i6);
            i5 += max + view.getMeasuredWidth() + max2;
            i4++;
            i3 = Math.max(0, -i7);
            i = max3;
        }
        return i5;
    }

    /* renamed from: a */
    private void m3602a(View view, int i, int i2, int i3, int i4, int i5) {
        MarginLayoutParams marginLayoutParams = (MarginLayoutParams) view.getLayoutParams();
        int childMeasureSpec = getChildMeasureSpec(i, getPaddingLeft() + getPaddingRight() + marginLayoutParams.leftMargin + marginLayoutParams.rightMargin + i2, marginLayoutParams.width);
        int childMeasureSpec2 = getChildMeasureSpec(i3, getPaddingTop() + getPaddingBottom() + marginLayoutParams.topMargin + marginLayoutParams.bottomMargin + i4, marginLayoutParams.height);
        int mode = MeasureSpec.getMode(childMeasureSpec2);
        if (mode != 1073741824 && i5 >= 0) {
            if (mode != 0) {
                i5 = Math.min(MeasureSpec.getSize(childMeasureSpec2), i5);
            }
            childMeasureSpec2 = MeasureSpec.makeMeasureSpec(i5, 1073741824);
        }
        view.measure(childMeasureSpec, childMeasureSpec2);
    }

    /* renamed from: a */
    private void m3603a(View view, boolean z) {
        LayoutParams layoutParams = view.getLayoutParams();
        C0736b bVar = layoutParams == null ? generateDefaultLayoutParams() : !checkLayoutParams(layoutParams) ? generateLayoutParams(layoutParams) : (C0736b) layoutParams;
        bVar.f2580b = 1;
        if (!z || this.f2550c == null) {
            addView(view, bVar);
            return;
        }
        view.setLayoutParams(bVar);
        this.f2538F.add(view);
    }

    /* renamed from: a */
    private void m3604a(List<View> list, int i) {
        boolean z = C0495r.m2149f(this) == 1;
        int childCount = getChildCount();
        int a = C0480d.m2070a(i, C0495r.m2149f(this));
        list.clear();
        if (z) {
            for (int i2 = childCount - 1; i2 >= 0; i2--) {
                View childAt = getChildAt(i2);
                C0736b bVar = (C0736b) childAt.getLayoutParams();
                if (bVar.f2580b == 0 && m3605a(childAt) && m3606b(bVar.f1689a) == a) {
                    list.add(childAt);
                }
            }
            return;
        }
        for (int i3 = 0; i3 < childCount; i3++) {
            View childAt2 = getChildAt(i3);
            C0736b bVar2 = (C0736b) childAt2.getLayoutParams();
            if (bVar2.f2580b == 0 && m3605a(childAt2) && m3606b(bVar2.f1689a) == a) {
                list.add(childAt2);
            }
        }
    }

    /* renamed from: a */
    private boolean m3605a(View view) {
        return (view == null || view.getParent() != this || view.getVisibility() == 8) ? false : true;
    }

    /* renamed from: b */
    private int m3606b(int i) {
        int f = C0495r.m2149f(this);
        int a = C0480d.m2070a(i, f) & 7;
        if (a != 1) {
            int i2 = 3;
            if (!(a == 3 || a == 5)) {
                if (f == 1) {
                    i2 = 5;
                }
                return i2;
            }
        }
        return a;
    }

    /* renamed from: b */
    private int m3607b(View view) {
        MarginLayoutParams marginLayoutParams = (MarginLayoutParams) view.getLayoutParams();
        return C0484g.m2081a(marginLayoutParams) + C0484g.m2082b(marginLayoutParams);
    }

    /* renamed from: b */
    private int m3608b(View view, int i, int[] iArr, int i2) {
        C0736b bVar = (C0736b) view.getLayoutParams();
        int i3 = bVar.rightMargin - iArr[1];
        int max = i - Math.max(0, i3);
        iArr[1] = Math.max(0, -i3);
        int a = m3598a(view, i2);
        int measuredWidth = view.getMeasuredWidth();
        view.layout(max - measuredWidth, a, max, view.getMeasuredHeight() + a);
        return max - (measuredWidth + bVar.leftMargin);
    }

    /* renamed from: c */
    private int m3609c(View view) {
        MarginLayoutParams marginLayoutParams = (MarginLayoutParams) view.getLayoutParams();
        return marginLayoutParams.topMargin + marginLayoutParams.bottomMargin;
    }

    /* renamed from: d */
    private boolean m3610d(View view) {
        return view.getParent() == this || this.f2538F.contains(view);
    }

    private MenuInflater getMenuInflater() {
        return new C0634g(getContext());
    }

    /* renamed from: m */
    private void m3611m() {
        if (this.f2556i == null) {
            this.f2556i = new C0919p(getContext());
        }
    }

    /* renamed from: n */
    private void m3612n() {
        m3613o();
        if (this.f2548a.mo3060d() == null) {
            C0655h hVar = (C0655h) this.f2548a.getMenu();
            if (this.f2543K == null) {
                this.f2543K = new C0735a();
            }
            this.f2548a.setExpandedActionViewsExclusive(true);
            hVar.mo2708a((C0671o) this.f2543K, this.f2559l);
        }
    }

    /* renamed from: o */
    private void m3613o() {
        if (this.f2548a == null) {
            this.f2548a = new ActionMenuView(getContext());
            this.f2548a.setPopupTheme(this.f2560m);
            this.f2548a.setOnMenuItemClickListener(this.f2540H);
            this.f2548a.mo3052a(this.f2544L, this.f2545M);
            C0736b j = generateDefaultLayoutParams();
            j.f1689a = 8388613 | (this.f2551d & 112);
            this.f2548a.setLayoutParams(j);
            m3603a((View) this.f2548a, false);
        }
    }

    /* renamed from: p */
    private void m3614p() {
        if (this.f2555h == null) {
            this.f2555h = new C0917n(getContext(), null, C0541a.toolbarNavigationButtonStyle);
            C0736b j = generateDefaultLayoutParams();
            j.f1689a = 8388611 | (this.f2551d & 112);
            this.f2555h.setLayoutParams(j);
        }
    }

    /* renamed from: q */
    private void m3615q() {
        removeCallbacks(this.f2547O);
        post(this.f2547O);
    }

    /* renamed from: r */
    private boolean m3616r() {
        if (!this.f2546N) {
            return false;
        }
        int childCount = getChildCount();
        for (int i = 0; i < childCount; i++) {
            View childAt = getChildAt(i);
            if (m3605a(childAt) && childAt.getMeasuredWidth() > 0 && childAt.getMeasuredHeight() > 0) {
                return false;
            }
        }
        return true;
    }

    /* renamed from: s */
    private void m3617s() {
        if (this.f2568u == null) {
            this.f2568u = new C0854bd();
        }
    }

    /* renamed from: a */
    public C0736b generateLayoutParams(AttributeSet attributeSet) {
        return new C0736b(getContext(), attributeSet);
    }

    /* access modifiers changed from: protected */
    /* renamed from: a */
    public C0736b generateLayoutParams(LayoutParams layoutParams) {
        return layoutParams instanceof C0736b ? new C0736b((C0736b) layoutParams) : layoutParams instanceof C0566a ? new C0736b((C0566a) layoutParams) : layoutParams instanceof MarginLayoutParams ? new C0736b((MarginLayoutParams) layoutParams) : new C0736b(layoutParams);
    }

    /* renamed from: a */
    public void mo3417a(int i, int i2) {
        m3617s();
        this.f2568u.mo4364a(i, i2);
    }

    /* renamed from: a */
    public void mo3418a(Context context, int i) {
        this.f2561n = i;
        if (this.f2553f != null) {
            this.f2553f.setTextAppearance(context, i);
        }
    }

    /* renamed from: a */
    public void mo3419a(C0655h hVar, C0887c cVar) {
        if (hVar != null || this.f2548a != null) {
            m3613o();
            C0655h d = this.f2548a.mo3060d();
            if (d != hVar) {
                if (d != null) {
                    d.mo2727b((C0671o) this.f2542J);
                    d.mo2727b((C0671o) this.f2543K);
                }
                if (this.f2543K == null) {
                    this.f2543K = new C0735a();
                }
                cVar.mo4492d(true);
                if (hVar != null) {
                    hVar.mo2708a((C0671o) cVar, this.f2559l);
                    hVar.mo2708a((C0671o) this.f2543K, this.f2559l);
                } else {
                    cVar.mo2637a(this.f2559l, (C0655h) null);
                    this.f2543K.mo2637a(this.f2559l, (C0655h) null);
                    cVar.mo2647b(true);
                    this.f2543K.mo2647b(true);
                }
                this.f2548a.setPopupTheme(this.f2560m);
                this.f2548a.setPresenter(cVar);
                this.f2542J = cVar;
            }
        }
    }

    /* renamed from: a */
    public void mo3420a(C0672a aVar, C0656a aVar2) {
        this.f2544L = aVar;
        this.f2545M = aVar2;
        if (this.f2548a != null) {
            this.f2548a.mo3052a(aVar, aVar2);
        }
    }

    /* renamed from: a */
    public boolean mo3421a() {
        return getVisibility() == 0 && this.f2548a != null && this.f2548a.mo3053a();
    }

    /* renamed from: b */
    public void mo3422b(Context context, int i) {
        this.f2562o = i;
        if (this.f2554g != null) {
            this.f2554g.setTextAppearance(context, i);
        }
    }

    /* renamed from: b */
    public boolean mo3423b() {
        return this.f2548a != null && this.f2548a.mo3064g();
    }

    /* renamed from: c */
    public boolean mo3424c() {
        return this.f2548a != null && this.f2548a.mo3072h();
    }

    /* access modifiers changed from: protected */
    public boolean checkLayoutParams(LayoutParams layoutParams) {
        return super.checkLayoutParams(layoutParams) && (layoutParams instanceof C0736b);
    }

    /* renamed from: d */
    public boolean mo3426d() {
        return this.f2548a != null && this.f2548a.mo3062e();
    }

    /* renamed from: e */
    public boolean mo3427e() {
        return this.f2548a != null && this.f2548a.mo3063f();
    }

    /* renamed from: f */
    public void mo3428f() {
        if (this.f2548a != null) {
            this.f2548a.mo3073i();
        }
    }

    /* renamed from: g */
    public boolean mo3429g() {
        return (this.f2543K == null || this.f2543K.f2578b == null) ? false : true;
    }

    public int getContentInsetEnd() {
        if (this.f2568u != null) {
            return this.f2568u.mo4369d();
        }
        return 0;
    }

    public int getContentInsetEndWithActions() {
        return this.f2570w != Integer.MIN_VALUE ? this.f2570w : getContentInsetEnd();
    }

    public int getContentInsetLeft() {
        if (this.f2568u != null) {
            return this.f2568u.mo4363a();
        }
        return 0;
    }

    public int getContentInsetRight() {
        if (this.f2568u != null) {
            return this.f2568u.mo4366b();
        }
        return 0;
    }

    public int getContentInsetStart() {
        if (this.f2568u != null) {
            return this.f2568u.mo4368c();
        }
        return 0;
    }

    public int getContentInsetStartWithNavigation() {
        return this.f2569v != Integer.MIN_VALUE ? this.f2569v : getContentInsetStart();
    }

    /* JADX WARNING: Removed duplicated region for block: B:11:0x0027  */
    /* JADX WARNING: Removed duplicated region for block: B:9:0x0018  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public int getCurrentContentInsetEnd() {
        /*
            r3 = this;
            android.support.v7.widget.ActionMenuView r0 = r3.f2548a
            r1 = 0
            if (r0 == 0) goto L_0x0015
            android.support.v7.widget.ActionMenuView r0 = r3.f2548a
            android.support.v7.view.menu.h r0 = r0.mo3060d()
            if (r0 == 0) goto L_0x0015
            boolean r0 = r0.hasVisibleItems()
            if (r0 == 0) goto L_0x0015
            r0 = 1
            goto L_0x0016
        L_0x0015:
            r0 = r1
        L_0x0016:
            if (r0 == 0) goto L_0x0027
            int r0 = r3.getContentInsetEnd()
            int r2 = r3.f2570w
            int r1 = java.lang.Math.max(r2, r1)
            int r0 = java.lang.Math.max(r0, r1)
            return r0
        L_0x0027:
            int r0 = r3.getContentInsetEnd()
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.p031v7.widget.Toolbar.getCurrentContentInsetEnd():int");
    }

    public int getCurrentContentInsetLeft() {
        return C0495r.m2149f(this) == 1 ? getCurrentContentInsetEnd() : getCurrentContentInsetStart();
    }

    public int getCurrentContentInsetRight() {
        return C0495r.m2149f(this) == 1 ? getCurrentContentInsetStart() : getCurrentContentInsetEnd();
    }

    public int getCurrentContentInsetStart() {
        return getNavigationIcon() != null ? Math.max(getContentInsetStart(), Math.max(this.f2569v, 0)) : getContentInsetStart();
    }

    public Drawable getLogo() {
        if (this.f2556i != null) {
            return this.f2556i.getDrawable();
        }
        return null;
    }

    public CharSequence getLogoDescription() {
        if (this.f2556i != null) {
            return this.f2556i.getContentDescription();
        }
        return null;
    }

    public Menu getMenu() {
        m3612n();
        return this.f2548a.getMenu();
    }

    public CharSequence getNavigationContentDescription() {
        if (this.f2555h != null) {
            return this.f2555h.getContentDescription();
        }
        return null;
    }

    public Drawable getNavigationIcon() {
        if (this.f2555h != null) {
            return this.f2555h.getDrawable();
        }
        return null;
    }

    /* access modifiers changed from: 0000 */
    public C0887c getOuterActionMenuPresenter() {
        return this.f2542J;
    }

    public Drawable getOverflowIcon() {
        m3612n();
        return this.f2548a.getOverflowIcon();
    }

    /* access modifiers changed from: 0000 */
    public Context getPopupContext() {
        return this.f2559l;
    }

    public int getPopupTheme() {
        return this.f2560m;
    }

    public CharSequence getSubtitle() {
        return this.f2573z;
    }

    public CharSequence getTitle() {
        return this.f2572y;
    }

    public int getTitleMarginBottom() {
        return this.f2567t;
    }

    public int getTitleMarginEnd() {
        return this.f2565r;
    }

    public int getTitleMarginStart() {
        return this.f2564q;
    }

    public int getTitleMarginTop() {
        return this.f2566s;
    }

    public C0756aj getWrapper() {
        if (this.f2541I == null) {
            this.f2541I = new C0870bo(this, true);
        }
        return this.f2541I;
    }

    /* renamed from: h */
    public void mo3459h() {
        C0659j jVar = this.f2543K == null ? null : this.f2543K.f2578b;
        if (jVar != null) {
            jVar.collapseActionView();
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: i */
    public void mo3460i() {
        if (this.f2549b == null) {
            this.f2549b = new C0917n(getContext(), null, C0541a.toolbarNavigationButtonStyle);
            this.f2549b.setImageDrawable(this.f2557j);
            this.f2549b.setContentDescription(this.f2558k);
            C0736b j = generateDefaultLayoutParams();
            j.f1689a = 8388611 | (this.f2551d & 112);
            j.f2580b = 2;
            this.f2549b.setLayoutParams(j);
            this.f2549b.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    Toolbar.this.mo3459h();
                }
            });
        }
    }

    /* access modifiers changed from: protected */
    /* renamed from: j */
    public C0736b generateDefaultLayoutParams() {
        return new C0736b(-2, -2);
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: k */
    public void mo3462k() {
        for (int childCount = getChildCount() - 1; childCount >= 0; childCount--) {
            View childAt = getChildAt(childCount);
            if (!(((C0736b) childAt.getLayoutParams()).f2580b == 2 || childAt == this.f2548a)) {
                removeViewAt(childCount);
                this.f2538F.add(childAt);
            }
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: l */
    public void mo3463l() {
        for (int size = this.f2538F.size() - 1; size >= 0; size--) {
            addView((View) this.f2538F.get(size));
        }
        this.f2538F.clear();
    }

    /* access modifiers changed from: protected */
    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        removeCallbacks(this.f2547O);
    }

    public boolean onHoverEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 9) {
            this.f2536D = false;
        }
        if (!this.f2536D) {
            boolean onHoverEvent = super.onHoverEvent(motionEvent);
            if (actionMasked == 9 && !onHoverEvent) {
                this.f2536D = true;
            }
        }
        if (actionMasked == 10 || actionMasked == 3) {
            this.f2536D = false;
        }
        return true;
    }

    /* access modifiers changed from: protected */
    /* JADX WARNING: Removed duplicated region for block: B:102:0x02aa A[LOOP:0: B:101:0x02a8->B:102:0x02aa, LOOP_END] */
    /* JADX WARNING: Removed duplicated region for block: B:105:0x02cc A[LOOP:1: B:104:0x02ca->B:105:0x02cc, LOOP_END] */
    /* JADX WARNING: Removed duplicated region for block: B:108:0x02f7  */
    /* JADX WARNING: Removed duplicated region for block: B:113:0x0306 A[LOOP:2: B:112:0x0304->B:113:0x0306, LOOP_END] */
    /* JADX WARNING: Removed duplicated region for block: B:17:0x005f  */
    /* JADX WARNING: Removed duplicated region for block: B:22:0x0076  */
    /* JADX WARNING: Removed duplicated region for block: B:27:0x00b3  */
    /* JADX WARNING: Removed duplicated region for block: B:32:0x00ca  */
    /* JADX WARNING: Removed duplicated region for block: B:37:0x00e7  */
    /* JADX WARNING: Removed duplicated region for block: B:38:0x0100  */
    /* JADX WARNING: Removed duplicated region for block: B:40:0x0105  */
    /* JADX WARNING: Removed duplicated region for block: B:41:0x011d  */
    /* JADX WARNING: Removed duplicated region for block: B:47:0x012d  */
    /* JADX WARNING: Removed duplicated region for block: B:48:0x0130  */
    /* JADX WARNING: Removed duplicated region for block: B:50:0x0134  */
    /* JADX WARNING: Removed duplicated region for block: B:51:0x0137  */
    /* JADX WARNING: Removed duplicated region for block: B:63:0x016a  */
    /* JADX WARNING: Removed duplicated region for block: B:73:0x01a9  */
    /* JADX WARNING: Removed duplicated region for block: B:75:0x01b8  */
    /* JADX WARNING: Removed duplicated region for block: B:88:0x022b  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void onLayout(boolean r25, int r26, int r27, int r28, int r29) {
        /*
            r24 = this;
            r0 = r24
            int r1 = android.support.p018v4.p028h.C0495r.m2149f(r24)
            r2 = 1
            r3 = 0
            if (r1 != r2) goto L_0x000c
            r1 = r2
            goto L_0x000d
        L_0x000c:
            r1 = r3
        L_0x000d:
            int r4 = r24.getWidth()
            int r5 = r24.getHeight()
            int r6 = r24.getPaddingLeft()
            int r7 = r24.getPaddingRight()
            int r8 = r24.getPaddingTop()
            int r9 = r24.getPaddingBottom()
            int r10 = r4 - r7
            int[] r11 = r0.f2539G
            r11[r2] = r3
            r11[r3] = r3
            int r12 = android.support.p018v4.p028h.C0495r.m2155j(r24)
            if (r12 < 0) goto L_0x003a
            int r13 = r29 - r27
            int r12 = java.lang.Math.min(r12, r13)
            goto L_0x003b
        L_0x003a:
            r12 = r3
        L_0x003b:
            android.widget.ImageButton r13 = r0.f2555h
            boolean r13 = r0.m3605a(r13)
            if (r13 == 0) goto L_0x0055
            if (r1 == 0) goto L_0x004d
            android.widget.ImageButton r13 = r0.f2555h
            int r13 = r0.m3608b(r13, r10, r11, r12)
            r14 = r6
            goto L_0x0057
        L_0x004d:
            android.widget.ImageButton r13 = r0.f2555h
            int r13 = r0.m3600a(r13, r6, r11, r12)
            r14 = r13
            goto L_0x0056
        L_0x0055:
            r14 = r6
        L_0x0056:
            r13 = r10
        L_0x0057:
            android.widget.ImageButton r15 = r0.f2549b
            boolean r15 = r0.m3605a(r15)
            if (r15 == 0) goto L_0x006e
            if (r1 == 0) goto L_0x0068
            android.widget.ImageButton r15 = r0.f2549b
            int r13 = r0.m3608b(r15, r13, r11, r12)
            goto L_0x006e
        L_0x0068:
            android.widget.ImageButton r15 = r0.f2549b
            int r14 = r0.m3600a(r15, r14, r11, r12)
        L_0x006e:
            android.support.v7.widget.ActionMenuView r15 = r0.f2548a
            boolean r15 = r0.m3605a(r15)
            if (r15 == 0) goto L_0x0085
            if (r1 == 0) goto L_0x007f
            android.support.v7.widget.ActionMenuView r15 = r0.f2548a
            int r14 = r0.m3600a(r15, r14, r11, r12)
            goto L_0x0085
        L_0x007f:
            android.support.v7.widget.ActionMenuView r15 = r0.f2548a
            int r13 = r0.m3608b(r15, r13, r11, r12)
        L_0x0085:
            int r15 = r24.getCurrentContentInsetLeft()
            int r16 = r24.getCurrentContentInsetRight()
            int r2 = r15 - r14
            int r2 = java.lang.Math.max(r3, r2)
            r11[r3] = r2
            int r2 = r10 - r13
            int r2 = r16 - r2
            int r2 = java.lang.Math.max(r3, r2)
            r17 = 1
            r11[r17] = r2
            int r2 = java.lang.Math.max(r14, r15)
            int r10 = r10 - r16
            int r10 = java.lang.Math.min(r13, r10)
            android.view.View r13 = r0.f2550c
            boolean r13 = r0.m3605a(r13)
            if (r13 == 0) goto L_0x00c2
            if (r1 == 0) goto L_0x00bc
            android.view.View r13 = r0.f2550c
            int r10 = r0.m3608b(r13, r10, r11, r12)
            goto L_0x00c2
        L_0x00bc:
            android.view.View r13 = r0.f2550c
            int r2 = r0.m3600a(r13, r2, r11, r12)
        L_0x00c2:
            android.widget.ImageView r13 = r0.f2556i
            boolean r13 = r0.m3605a(r13)
            if (r13 == 0) goto L_0x00d9
            if (r1 == 0) goto L_0x00d3
            android.widget.ImageView r13 = r0.f2556i
            int r10 = r0.m3608b(r13, r10, r11, r12)
            goto L_0x00d9
        L_0x00d3:
            android.widget.ImageView r13 = r0.f2556i
            int r2 = r0.m3600a(r13, r2, r11, r12)
        L_0x00d9:
            android.widget.TextView r13 = r0.f2553f
            boolean r13 = r0.m3605a(r13)
            android.widget.TextView r14 = r0.f2554g
            boolean r14 = r0.m3605a(r14)
            if (r13 == 0) goto L_0x0100
            android.widget.TextView r15 = r0.f2553f
            android.view.ViewGroup$LayoutParams r15 = r15.getLayoutParams()
            android.support.v7.widget.Toolbar$b r15 = (android.support.p031v7.widget.Toolbar.C0736b) r15
            int r3 = r15.topMargin
            r19 = r7
            android.widget.TextView r7 = r0.f2553f
            int r7 = r7.getMeasuredHeight()
            int r3 = r3 + r7
            int r7 = r15.bottomMargin
            int r3 = r3 + r7
            r7 = 0
            int r3 = r3 + r7
            goto L_0x0103
        L_0x0100:
            r19 = r7
            r3 = 0
        L_0x0103:
            if (r14 == 0) goto L_0x011d
            android.widget.TextView r7 = r0.f2554g
            android.view.ViewGroup$LayoutParams r7 = r7.getLayoutParams()
            android.support.v7.widget.Toolbar$b r7 = (android.support.p031v7.widget.Toolbar.C0736b) r7
            int r15 = r7.topMargin
            r20 = r4
            android.widget.TextView r4 = r0.f2554g
            int r4 = r4.getMeasuredHeight()
            int r15 = r15 + r4
            int r4 = r7.bottomMargin
            int r15 = r15 + r4
            int r3 = r3 + r15
            goto L_0x011f
        L_0x011d:
            r20 = r4
        L_0x011f:
            if (r13 != 0) goto L_0x012b
            if (r14 == 0) goto L_0x0124
            goto L_0x012b
        L_0x0124:
            r21 = r6
            r22 = r12
        L_0x0128:
            r7 = 0
            goto L_0x029a
        L_0x012b:
            if (r13 == 0) goto L_0x0130
            android.widget.TextView r4 = r0.f2553f
            goto L_0x0132
        L_0x0130:
            android.widget.TextView r4 = r0.f2554g
        L_0x0132:
            if (r14 == 0) goto L_0x0137
            android.widget.TextView r7 = r0.f2554g
            goto L_0x0139
        L_0x0137:
            android.widget.TextView r7 = r0.f2553f
        L_0x0139:
            android.view.ViewGroup$LayoutParams r4 = r4.getLayoutParams()
            android.support.v7.widget.Toolbar$b r4 = (android.support.p031v7.widget.Toolbar.C0736b) r4
            android.view.ViewGroup$LayoutParams r7 = r7.getLayoutParams()
            android.support.v7.widget.Toolbar$b r7 = (android.support.p031v7.widget.Toolbar.C0736b) r7
            if (r13 == 0) goto L_0x014f
            android.widget.TextView r15 = r0.f2553f
            int r15 = r15.getMeasuredWidth()
            if (r15 > 0) goto L_0x0159
        L_0x014f:
            if (r14 == 0) goto L_0x015d
            android.widget.TextView r15 = r0.f2554g
            int r15 = r15.getMeasuredWidth()
            if (r15 <= 0) goto L_0x015d
        L_0x0159:
            r21 = r6
            r15 = 1
            goto L_0x0160
        L_0x015d:
            r21 = r6
            r15 = 0
        L_0x0160:
            int r6 = r0.f2571x
            r6 = r6 & 112(0x70, float:1.57E-43)
            r22 = r12
            r12 = 48
            if (r6 == r12) goto L_0x01a9
            r12 = 80
            if (r6 == r12) goto L_0x019d
            int r6 = r5 - r8
            int r6 = r6 - r9
            int r6 = r6 - r3
            int r6 = r6 / 2
            int r12 = r4.topMargin
            r23 = r2
            int r2 = r0.f2566s
            int r12 = r12 + r2
            if (r6 >= r12) goto L_0x0184
            int r2 = r4.topMargin
            int r3 = r0.f2566s
            int r6 = r2 + r3
            goto L_0x019b
        L_0x0184:
            int r5 = r5 - r9
            int r5 = r5 - r3
            int r5 = r5 - r6
            int r5 = r5 - r8
            int r2 = r4.bottomMargin
            int r3 = r0.f2567t
            int r2 = r2 + r3
            if (r5 >= r2) goto L_0x019b
            int r2 = r7.bottomMargin
            int r3 = r0.f2567t
            int r2 = r2 + r3
            int r2 = r2 - r5
            int r6 = r6 - r2
            r2 = 0
            int r6 = java.lang.Math.max(r2, r6)
        L_0x019b:
            int r8 = r8 + r6
            goto L_0x01b6
        L_0x019d:
            r23 = r2
            int r5 = r5 - r9
            int r2 = r7.bottomMargin
            int r5 = r5 - r2
            int r2 = r0.f2567t
            int r5 = r5 - r2
            int r8 = r5 - r3
            goto L_0x01b6
        L_0x01a9:
            r23 = r2
            int r2 = r24.getPaddingTop()
            int r3 = r4.topMargin
            int r2 = r2 + r3
            int r3 = r0.f2566s
            int r8 = r2 + r3
        L_0x01b6:
            if (r1 == 0) goto L_0x022b
            if (r15 == 0) goto L_0x01be
            int r3 = r0.f2564q
            r1 = 1
            goto L_0x01c0
        L_0x01be:
            r1 = 1
            r3 = 0
        L_0x01c0:
            r2 = r11[r1]
            int r3 = r3 - r2
            r2 = 0
            int r4 = java.lang.Math.max(r2, r3)
            int r10 = r10 - r4
            int r3 = -r3
            int r3 = java.lang.Math.max(r2, r3)
            r11[r1] = r3
            if (r13 == 0) goto L_0x01f6
            android.widget.TextView r1 = r0.f2553f
            android.view.ViewGroup$LayoutParams r1 = r1.getLayoutParams()
            android.support.v7.widget.Toolbar$b r1 = (android.support.p031v7.widget.Toolbar.C0736b) r1
            android.widget.TextView r2 = r0.f2553f
            int r2 = r2.getMeasuredWidth()
            int r2 = r10 - r2
            android.widget.TextView r3 = r0.f2553f
            int r3 = r3.getMeasuredHeight()
            int r3 = r3 + r8
            android.widget.TextView r4 = r0.f2553f
            r4.layout(r2, r8, r10, r3)
            int r4 = r0.f2565r
            int r2 = r2 - r4
            int r1 = r1.bottomMargin
            int r8 = r3 + r1
            goto L_0x01f7
        L_0x01f6:
            r2 = r10
        L_0x01f7:
            if (r14 == 0) goto L_0x021f
            android.widget.TextView r1 = r0.f2554g
            android.view.ViewGroup$LayoutParams r1 = r1.getLayoutParams()
            android.support.v7.widget.Toolbar$b r1 = (android.support.p031v7.widget.Toolbar.C0736b) r1
            int r3 = r1.topMargin
            int r8 = r8 + r3
            android.widget.TextView r3 = r0.f2554g
            int r3 = r3.getMeasuredWidth()
            int r3 = r10 - r3
            android.widget.TextView r4 = r0.f2554g
            int r4 = r4.getMeasuredHeight()
            int r4 = r4 + r8
            android.widget.TextView r5 = r0.f2554g
            r5.layout(r3, r8, r10, r4)
            int r3 = r0.f2565r
            int r3 = r10 - r3
            int r1 = r1.bottomMargin
            goto L_0x0220
        L_0x021f:
            r3 = r10
        L_0x0220:
            if (r15 == 0) goto L_0x0227
            int r1 = java.lang.Math.min(r2, r3)
            r10 = r1
        L_0x0227:
            r2 = r23
            goto L_0x0128
        L_0x022b:
            if (r15 == 0) goto L_0x0233
            int r3 = r0.f2564q
            r18 = r3
            r7 = 0
            goto L_0x0236
        L_0x0233:
            r7 = 0
            r18 = 0
        L_0x0236:
            r1 = r11[r7]
            int r1 = r18 - r1
            int r2 = java.lang.Math.max(r7, r1)
            int r2 = r23 + r2
            int r1 = -r1
            int r1 = java.lang.Math.max(r7, r1)
            r11[r7] = r1
            if (r13 == 0) goto L_0x026c
            android.widget.TextView r1 = r0.f2553f
            android.view.ViewGroup$LayoutParams r1 = r1.getLayoutParams()
            android.support.v7.widget.Toolbar$b r1 = (android.support.p031v7.widget.Toolbar.C0736b) r1
            android.widget.TextView r3 = r0.f2553f
            int r3 = r3.getMeasuredWidth()
            int r3 = r3 + r2
            android.widget.TextView r4 = r0.f2553f
            int r4 = r4.getMeasuredHeight()
            int r4 = r4 + r8
            android.widget.TextView r5 = r0.f2553f
            r5.layout(r2, r8, r3, r4)
            int r5 = r0.f2565r
            int r3 = r3 + r5
            int r1 = r1.bottomMargin
            int r8 = r4 + r1
            goto L_0x026d
        L_0x026c:
            r3 = r2
        L_0x026d:
            if (r14 == 0) goto L_0x0293
            android.widget.TextView r1 = r0.f2554g
            android.view.ViewGroup$LayoutParams r1 = r1.getLayoutParams()
            android.support.v7.widget.Toolbar$b r1 = (android.support.p031v7.widget.Toolbar.C0736b) r1
            int r4 = r1.topMargin
            int r8 = r8 + r4
            android.widget.TextView r4 = r0.f2554g
            int r4 = r4.getMeasuredWidth()
            int r4 = r4 + r2
            android.widget.TextView r5 = r0.f2554g
            int r5 = r5.getMeasuredHeight()
            int r5 = r5 + r8
            android.widget.TextView r6 = r0.f2554g
            r6.layout(r2, r8, r4, r5)
            int r5 = r0.f2565r
            int r4 = r4 + r5
            int r1 = r1.bottomMargin
            goto L_0x0294
        L_0x0293:
            r4 = r2
        L_0x0294:
            if (r15 == 0) goto L_0x029a
            int r2 = java.lang.Math.max(r3, r4)
        L_0x029a:
            java.util.ArrayList<android.view.View> r1 = r0.f2537E
            r3 = 3
            r0.m3604a(r1, r3)
            java.util.ArrayList<android.view.View> r1 = r0.f2537E
            int r1 = r1.size()
            r3 = r2
            r2 = r7
        L_0x02a8:
            if (r2 >= r1) goto L_0x02bb
            java.util.ArrayList<android.view.View> r4 = r0.f2537E
            java.lang.Object r4 = r4.get(r2)
            android.view.View r4 = (android.view.View) r4
            r12 = r22
            int r3 = r0.m3600a(r4, r3, r11, r12)
            int r2 = r2 + 1
            goto L_0x02a8
        L_0x02bb:
            r12 = r22
            java.util.ArrayList<android.view.View> r1 = r0.f2537E
            r2 = 5
            r0.m3604a(r1, r2)
            java.util.ArrayList<android.view.View> r1 = r0.f2537E
            int r1 = r1.size()
            r2 = r7
        L_0x02ca:
            if (r2 >= r1) goto L_0x02db
            java.util.ArrayList<android.view.View> r4 = r0.f2537E
            java.lang.Object r4 = r4.get(r2)
            android.view.View r4 = (android.view.View) r4
            int r10 = r0.m3608b(r4, r10, r11, r12)
            int r2 = r2 + 1
            goto L_0x02ca
        L_0x02db:
            java.util.ArrayList<android.view.View> r1 = r0.f2537E
            r2 = 1
            r0.m3604a(r1, r2)
            java.util.ArrayList<android.view.View> r1 = r0.f2537E
            int r1 = r0.m3601a(r1, r11)
            int r4 = r20 - r21
            int r4 = r4 - r19
            int r4 = r4 / 2
            int r6 = r21 + r4
            int r2 = r1 / 2
            int r2 = r6 - r2
            int r1 = r1 + r2
            if (r2 >= r3) goto L_0x02f7
            goto L_0x02fe
        L_0x02f7:
            if (r1 <= r10) goto L_0x02fd
            int r1 = r1 - r10
            int r3 = r2 - r1
            goto L_0x02fe
        L_0x02fd:
            r3 = r2
        L_0x02fe:
            java.util.ArrayList<android.view.View> r1 = r0.f2537E
            int r1 = r1.size()
        L_0x0304:
            if (r7 >= r1) goto L_0x0315
            java.util.ArrayList<android.view.View> r2 = r0.f2537E
            java.lang.Object r2 = r2.get(r7)
            android.view.View r2 = (android.view.View) r2
            int r3 = r0.m3600a(r2, r3, r11, r12)
            int r7 = r7 + 1
            goto L_0x0304
        L_0x0315:
            java.util.ArrayList<android.view.View> r1 = r0.f2537E
            r1.clear()
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.p031v7.widget.Toolbar.onLayout(boolean, int, int, int, int):void");
    }

    /* access modifiers changed from: protected */
    public void onMeasure(int i, int i2) {
        char c;
        char c2;
        int i3;
        int i4;
        int i5;
        int i6;
        int i7;
        int i8;
        int i9;
        int[] iArr = this.f2539G;
        if (C0885bv.m4757a(this)) {
            c2 = 1;
            c = 0;
        } else {
            c = 1;
            c2 = 0;
        }
        if (m3605a((View) this.f2555h)) {
            m3602a((View) this.f2555h, i, 0, i2, 0, this.f2563p);
            i5 = this.f2555h.getMeasuredWidth() + m3607b((View) this.f2555h);
            i4 = Math.max(0, this.f2555h.getMeasuredHeight() + m3609c(this.f2555h));
            i3 = View.combineMeasuredStates(0, this.f2555h.getMeasuredState());
        } else {
            i5 = 0;
            i4 = 0;
            i3 = 0;
        }
        if (m3605a((View) this.f2549b)) {
            m3602a((View) this.f2549b, i, 0, i2, 0, this.f2563p);
            i5 = this.f2549b.getMeasuredWidth() + m3607b((View) this.f2549b);
            i4 = Math.max(i4, this.f2549b.getMeasuredHeight() + m3609c(this.f2549b));
            i3 = View.combineMeasuredStates(i3, this.f2549b.getMeasuredState());
        }
        int currentContentInsetStart = getCurrentContentInsetStart();
        int max = 0 + Math.max(currentContentInsetStart, i5);
        iArr[c2] = Math.max(0, currentContentInsetStart - i5);
        if (m3605a((View) this.f2548a)) {
            m3602a((View) this.f2548a, i, max, i2, 0, this.f2563p);
            i6 = this.f2548a.getMeasuredWidth() + m3607b((View) this.f2548a);
            i4 = Math.max(i4, this.f2548a.getMeasuredHeight() + m3609c(this.f2548a));
            i3 = View.combineMeasuredStates(i3, this.f2548a.getMeasuredState());
        } else {
            i6 = 0;
        }
        int currentContentInsetEnd = getCurrentContentInsetEnd();
        int max2 = max + Math.max(currentContentInsetEnd, i6);
        iArr[c] = Math.max(0, currentContentInsetEnd - i6);
        if (m3605a(this.f2550c)) {
            max2 += m3599a(this.f2550c, i, max2, i2, 0, iArr);
            i4 = Math.max(i4, this.f2550c.getMeasuredHeight() + m3609c(this.f2550c));
            i3 = View.combineMeasuredStates(i3, this.f2550c.getMeasuredState());
        }
        if (m3605a((View) this.f2556i)) {
            max2 += m3599a((View) this.f2556i, i, max2, i2, 0, iArr);
            i4 = Math.max(i4, this.f2556i.getMeasuredHeight() + m3609c(this.f2556i));
            i3 = View.combineMeasuredStates(i3, this.f2556i.getMeasuredState());
        }
        int childCount = getChildCount();
        int i10 = i4;
        int i11 = max2;
        for (int i12 = 0; i12 < childCount; i12++) {
            View childAt = getChildAt(i12);
            if (((C0736b) childAt.getLayoutParams()).f2580b == 0 && m3605a(childAt)) {
                i11 += m3599a(childAt, i, i11, i2, 0, iArr);
                i10 = Math.max(i10, childAt.getMeasuredHeight() + m3609c(childAt));
                i3 = View.combineMeasuredStates(i3, childAt.getMeasuredState());
            }
        }
        int i13 = this.f2566s + this.f2567t;
        int i14 = this.f2564q + this.f2565r;
        if (m3605a((View) this.f2553f)) {
            m3599a((View) this.f2553f, i, i11 + i14, i2, i13, iArr);
            int measuredWidth = this.f2553f.getMeasuredWidth() + m3607b((View) this.f2553f);
            i7 = this.f2553f.getMeasuredHeight() + m3609c(this.f2553f);
            i9 = View.combineMeasuredStates(i3, this.f2553f.getMeasuredState());
            i8 = measuredWidth;
        } else {
            i7 = 0;
            i9 = i3;
            i8 = 0;
        }
        if (m3605a((View) this.f2554g)) {
            int i15 = i7 + i13;
            int i16 = i9;
            i8 = Math.max(i8, m3599a((View) this.f2554g, i, i11 + i14, i2, i15, iArr));
            i7 += this.f2554g.getMeasuredHeight() + m3609c(this.f2554g);
            i9 = View.combineMeasuredStates(i16, this.f2554g.getMeasuredState());
        } else {
            int i17 = i9;
        }
        int i18 = i11 + i8;
        int max3 = Math.max(i10, i7) + getPaddingTop() + getPaddingBottom();
        int i19 = i;
        int resolveSizeAndState = View.resolveSizeAndState(Math.max(i18 + getPaddingLeft() + getPaddingRight(), getSuggestedMinimumWidth()), i19, -16777216 & i9);
        int resolveSizeAndState2 = View.resolveSizeAndState(Math.max(max3, getSuggestedMinimumHeight()), i2, i9 << 16);
        if (m3616r()) {
            resolveSizeAndState2 = 0;
        }
        setMeasuredDimension(resolveSizeAndState, resolveSizeAndState2);
    }

    /* access modifiers changed from: protected */
    public void onRestoreInstanceState(Parcelable parcelable) {
        if (!(parcelable instanceof C0738d)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        C0738d dVar = (C0738d) parcelable;
        super.onRestoreInstanceState(dVar.mo1845a());
        C0655h d = this.f2548a != null ? this.f2548a.mo3060d() : null;
        if (!(dVar.f2581a == 0 || this.f2543K == null || d == null)) {
            MenuItem findItem = d.findItem(dVar.f2581a);
            if (findItem != null) {
                findItem.expandActionView();
            }
        }
        if (dVar.f2582b) {
            m3615q();
        }
    }

    public void onRtlPropertiesChanged(int i) {
        if (VERSION.SDK_INT >= 17) {
            super.onRtlPropertiesChanged(i);
        }
        m3617s();
        C0854bd bdVar = this.f2568u;
        boolean z = true;
        if (i != 1) {
            z = false;
        }
        bdVar.mo4365a(z);
    }

    /* access modifiers changed from: protected */
    public Parcelable onSaveInstanceState() {
        C0738d dVar = new C0738d(super.onSaveInstanceState());
        if (!(this.f2543K == null || this.f2543K.f2578b == null)) {
            dVar.f2581a = this.f2543K.f2578b.getItemId();
        }
        dVar.f2582b = mo3423b();
        return dVar;
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0) {
            this.f2535C = false;
        }
        if (!this.f2535C) {
            boolean onTouchEvent = super.onTouchEvent(motionEvent);
            if (actionMasked == 0 && !onTouchEvent) {
                this.f2535C = true;
            }
        }
        if (actionMasked == 1 || actionMasked == 3) {
            this.f2535C = false;
        }
        return true;
    }

    public void setCollapsible(boolean z) {
        this.f2546N = z;
        requestLayout();
    }

    public void setContentInsetEndWithActions(int i) {
        if (i < 0) {
            i = Integer.MIN_VALUE;
        }
        if (i != this.f2570w) {
            this.f2570w = i;
            if (getNavigationIcon() != null) {
                requestLayout();
            }
        }
    }

    public void setContentInsetStartWithNavigation(int i) {
        if (i < 0) {
            i = Integer.MIN_VALUE;
        }
        if (i != this.f2569v) {
            this.f2569v = i;
            if (getNavigationIcon() != null) {
                requestLayout();
            }
        }
    }

    public void setLogo(int i) {
        setLogo(C0606a.m2714b(getContext(), i));
    }

    public void setLogo(Drawable drawable) {
        if (drawable != null) {
            m3611m();
            if (!m3610d(this.f2556i)) {
                m3603a((View) this.f2556i, true);
            }
        } else if (this.f2556i != null && m3610d(this.f2556i)) {
            removeView(this.f2556i);
            this.f2538F.remove(this.f2556i);
        }
        if (this.f2556i != null) {
            this.f2556i.setImageDrawable(drawable);
        }
    }

    public void setLogoDescription(int i) {
        setLogoDescription(getContext().getText(i));
    }

    public void setLogoDescription(CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence)) {
            m3611m();
        }
        if (this.f2556i != null) {
            this.f2556i.setContentDescription(charSequence);
        }
    }

    public void setNavigationContentDescription(int i) {
        setNavigationContentDescription(i != 0 ? getContext().getText(i) : null);
    }

    public void setNavigationContentDescription(CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence)) {
            m3614p();
        }
        if (this.f2555h != null) {
            this.f2555h.setContentDescription(charSequence);
        }
    }

    public void setNavigationIcon(int i) {
        setNavigationIcon(C0606a.m2714b(getContext(), i));
    }

    public void setNavigationIcon(Drawable drawable) {
        if (drawable != null) {
            m3614p();
            if (!m3610d(this.f2555h)) {
                m3603a((View) this.f2555h, true);
            }
        } else if (this.f2555h != null && m3610d(this.f2555h)) {
            removeView(this.f2555h);
            this.f2538F.remove(this.f2555h);
        }
        if (this.f2555h != null) {
            this.f2555h.setImageDrawable(drawable);
        }
    }

    public void setNavigationOnClickListener(OnClickListener onClickListener) {
        m3614p();
        this.f2555h.setOnClickListener(onClickListener);
    }

    public void setOnMenuItemClickListener(C0737c cVar) {
        this.f2552e = cVar;
    }

    public void setOverflowIcon(Drawable drawable) {
        m3612n();
        this.f2548a.setOverflowIcon(drawable);
    }

    public void setPopupTheme(int i) {
        if (this.f2560m != i) {
            this.f2560m = i;
            if (i == 0) {
                this.f2559l = getContext();
                return;
            }
            this.f2559l = new ContextThemeWrapper(getContext(), i);
        }
    }

    public void setSubtitle(int i) {
        setSubtitle(getContext().getText(i));
    }

    public void setSubtitle(CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence)) {
            if (this.f2554g == null) {
                Context context = getContext();
                this.f2554g = new C0936z(context);
                this.f2554g.setSingleLine();
                this.f2554g.setEllipsize(TruncateAt.END);
                if (this.f2562o != 0) {
                    this.f2554g.setTextAppearance(context, this.f2562o);
                }
                if (this.f2534B != 0) {
                    this.f2554g.setTextColor(this.f2534B);
                }
            }
            if (!m3610d(this.f2554g)) {
                m3603a((View) this.f2554g, true);
            }
        } else if (this.f2554g != null && m3610d(this.f2554g)) {
            removeView(this.f2554g);
            this.f2538F.remove(this.f2554g);
        }
        if (this.f2554g != null) {
            this.f2554g.setText(charSequence);
        }
        this.f2573z = charSequence;
    }

    public void setSubtitleTextColor(int i) {
        this.f2534B = i;
        if (this.f2554g != null) {
            this.f2554g.setTextColor(i);
        }
    }

    public void setTitle(int i) {
        setTitle(getContext().getText(i));
    }

    public void setTitle(CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence)) {
            if (this.f2553f == null) {
                Context context = getContext();
                this.f2553f = new C0936z(context);
                this.f2553f.setSingleLine();
                this.f2553f.setEllipsize(TruncateAt.END);
                if (this.f2561n != 0) {
                    this.f2553f.setTextAppearance(context, this.f2561n);
                }
                if (this.f2533A != 0) {
                    this.f2553f.setTextColor(this.f2533A);
                }
            }
            if (!m3610d(this.f2553f)) {
                m3603a((View) this.f2553f, true);
            }
        } else if (this.f2553f != null && m3610d(this.f2553f)) {
            removeView(this.f2553f);
            this.f2538F.remove(this.f2553f);
        }
        if (this.f2553f != null) {
            this.f2553f.setText(charSequence);
        }
        this.f2572y = charSequence;
    }

    public void setTitleMarginBottom(int i) {
        this.f2567t = i;
        requestLayout();
    }

    public void setTitleMarginEnd(int i) {
        this.f2565r = i;
        requestLayout();
    }

    public void setTitleMarginStart(int i) {
        this.f2564q = i;
        requestLayout();
    }

    public void setTitleMarginTop(int i) {
        this.f2566s = i;
        requestLayout();
    }

    public void setTitleTextColor(int i) {
        this.f2533A = i;
        if (this.f2553f != null) {
            this.f2553f.setTextColor(i);
        }
    }
}
