package android.support.p031v7.widget;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.database.DataSetObserver;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.support.p018v4.p028h.C0477c;
import android.support.p031v7.p032a.C0540a.C0546f;
import android.support.p031v7.p032a.C0540a.C0547g;
import android.support.p031v7.p032a.C0540a.C0548h;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.View.OnClickListener;
import android.view.View.OnLongClickListener;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.view.ViewTreeObserver.OnGlobalLayoutListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.PopupWindow.OnDismissListener;
import android.widget.TextView;

/* renamed from: android.support.v7.widget.ActivityChooserView */
public class ActivityChooserView extends ViewGroup {

    /* renamed from: a */
    final C0694a f2311a;

    /* renamed from: b */
    final FrameLayout f2312b;

    /* renamed from: c */
    final FrameLayout f2313c;

    /* renamed from: d */
    C0477c f2314d;

    /* renamed from: e */
    final DataSetObserver f2315e;

    /* renamed from: f */
    OnDismissListener f2316f;

    /* renamed from: g */
    boolean f2317g;

    /* renamed from: h */
    int f2318h;

    /* renamed from: i */
    private final C0695b f2319i;

    /* renamed from: j */
    private final View f2320j;

    /* renamed from: k */
    private final ImageView f2321k;

    /* renamed from: l */
    private final int f2322l;

    /* renamed from: m */
    private final OnGlobalLayoutListener f2323m;

    /* renamed from: n */
    private C0789at f2324n;

    /* renamed from: o */
    private boolean f2325o;

    /* renamed from: p */
    private int f2326p;

    /* renamed from: android.support.v7.widget.ActivityChooserView$InnerLayout */
    public static class InnerLayout extends LinearLayout {

        /* renamed from: a */
        private static final int[] f2327a = {16842964};

        public InnerLayout(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            C0869bn a = C0869bn.m4637a(context, attributeSet, f2327a);
            setBackgroundDrawable(a.mo4426a(0));
            a.mo4427a();
        }
    }

    /* renamed from: android.support.v7.widget.ActivityChooserView$a */
    private class C0694a extends BaseAdapter {

        /* renamed from: a */
        final /* synthetic */ ActivityChooserView f2328a;

        /* renamed from: b */
        private C0895d f2329b;

        /* renamed from: c */
        private int f2330c;

        /* renamed from: d */
        private boolean f2331d;

        /* renamed from: e */
        private boolean f2332e;

        /* renamed from: f */
        private boolean f2333f;

        /* renamed from: a */
        public int mo3102a() {
            int i = this.f2330c;
            this.f2330c = Integer.MAX_VALUE;
            int makeMeasureSpec = MeasureSpec.makeMeasureSpec(0, 0);
            int makeMeasureSpec2 = MeasureSpec.makeMeasureSpec(0, 0);
            int count = getCount();
            int i2 = 0;
            View view = null;
            for (int i3 = 0; i3 < count; i3++) {
                view = getView(i3, view, null);
                view.measure(makeMeasureSpec, makeMeasureSpec2);
                i2 = Math.max(i2, view.getMeasuredWidth());
            }
            this.f2330c = i;
            return i2;
        }

        /* renamed from: a */
        public void mo3103a(int i) {
            if (this.f2330c != i) {
                this.f2330c = i;
                notifyDataSetChanged();
            }
        }

        /* renamed from: a */
        public void mo3104a(C0895d dVar) {
            C0895d d = this.f2328a.f2311a.mo3109d();
            if (d != null && this.f2328a.isShown()) {
                d.unregisterObserver(this.f2328a.f2315e);
            }
            this.f2329b = dVar;
            if (dVar != null && this.f2328a.isShown()) {
                dVar.registerObserver(this.f2328a.f2315e);
            }
            notifyDataSetChanged();
        }

        /* renamed from: a */
        public void mo3105a(boolean z) {
            if (this.f2333f != z) {
                this.f2333f = z;
                notifyDataSetChanged();
            }
        }

        /* renamed from: a */
        public void mo3106a(boolean z, boolean z2) {
            if (this.f2331d != z || this.f2332e != z2) {
                this.f2331d = z;
                this.f2332e = z2;
                notifyDataSetChanged();
            }
        }

        /* renamed from: b */
        public ResolveInfo mo3107b() {
            return this.f2329b.mo4506b();
        }

        /* renamed from: c */
        public int mo3108c() {
            return this.f2329b.mo4502a();
        }

        /* renamed from: d */
        public C0895d mo3109d() {
            return this.f2329b;
        }

        /* renamed from: e */
        public boolean mo3110e() {
            return this.f2331d;
        }

        public int getCount() {
            int a = this.f2329b.mo4502a();
            if (!this.f2331d && this.f2329b.mo4506b() != null) {
                a--;
            }
            int min = Math.min(a, this.f2330c);
            return this.f2333f ? min + 1 : min;
        }

        public Object getItem(int i) {
            switch (getItemViewType(i)) {
                case 0:
                    if (!this.f2331d && this.f2329b.mo4506b() != null) {
                        i++;
                    }
                    return this.f2329b.mo4504a(i);
                case 1:
                    return null;
                default:
                    throw new IllegalArgumentException();
            }
        }

        public long getItemId(int i) {
            return (long) i;
        }

        public int getItemViewType(int i) {
            return (!this.f2333f || i != getCount() - 1) ? 0 : 1;
        }

        public View getView(int i, View view, ViewGroup viewGroup) {
            switch (getItemViewType(i)) {
                case 0:
                    if (view == null || view.getId() != C0546f.list_item) {
                        view = LayoutInflater.from(this.f2328a.getContext()).inflate(C0547g.abc_activity_chooser_view_list_item, viewGroup, false);
                    }
                    PackageManager packageManager = this.f2328a.getContext().getPackageManager();
                    ResolveInfo resolveInfo = (ResolveInfo) getItem(i);
                    ((ImageView) view.findViewById(C0546f.icon)).setImageDrawable(resolveInfo.loadIcon(packageManager));
                    ((TextView) view.findViewById(C0546f.title)).setText(resolveInfo.loadLabel(packageManager));
                    if (!this.f2331d || i != 0 || !this.f2332e) {
                        view.setActivated(false);
                        return view;
                    }
                    view.setActivated(true);
                    return view;
                case 1:
                    if (view == null || view.getId() != 1) {
                        view = LayoutInflater.from(this.f2328a.getContext()).inflate(C0547g.abc_activity_chooser_view_list_item, viewGroup, false);
                        view.setId(1);
                        ((TextView) view.findViewById(C0546f.title)).setText(this.f2328a.getContext().getString(C0548h.abc_activity_chooser_view_see_all));
                    }
                    return view;
                default:
                    throw new IllegalArgumentException();
            }
        }

        public int getViewTypeCount() {
            return 3;
        }
    }

    /* renamed from: android.support.v7.widget.ActivityChooserView$b */
    private class C0695b implements OnClickListener, OnLongClickListener, OnItemClickListener, OnDismissListener {

        /* renamed from: a */
        final /* synthetic */ ActivityChooserView f2334a;

        /* renamed from: a */
        private void m3242a() {
            if (this.f2334a.f2316f != null) {
                this.f2334a.f2316f.onDismiss();
            }
        }

        public void onClick(View view) {
            if (view == this.f2334a.f2313c) {
                this.f2334a.mo3087b();
                Intent b = this.f2334a.f2311a.mo3109d().mo4505b(this.f2334a.f2311a.mo3109d().mo4503a(this.f2334a.f2311a.mo3107b()));
                if (b != null) {
                    b.addFlags(524288);
                    this.f2334a.getContext().startActivity(b);
                }
            } else if (view == this.f2334a.f2312b) {
                this.f2334a.f2317g = false;
                this.f2334a.mo3085a(this.f2334a.f2318h);
            } else {
                throw new IllegalArgumentException();
            }
        }

        public void onDismiss() {
            m3242a();
            if (this.f2334a.f2314d != null) {
                this.f2334a.f2314d.mo1919a(false);
            }
        }

        public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
            switch (((C0694a) adapterView.getAdapter()).getItemViewType(i)) {
                case 0:
                    this.f2334a.mo3087b();
                    if (!this.f2334a.f2317g) {
                        if (!this.f2334a.f2311a.mo3110e()) {
                            i++;
                        }
                        Intent b = this.f2334a.f2311a.mo3109d().mo4505b(i);
                        if (b != null) {
                            b.addFlags(524288);
                            this.f2334a.getContext().startActivity(b);
                        }
                    } else if (i > 0) {
                        this.f2334a.f2311a.mo3109d().mo4507c(i);
                        return;
                    }
                    return;
                case 1:
                    this.f2334a.mo3085a(Integer.MAX_VALUE);
                    return;
                default:
                    throw new IllegalArgumentException();
            }
        }

        public boolean onLongClick(View view) {
            if (view == this.f2334a.f2313c) {
                if (this.f2334a.f2311a.getCount() > 0) {
                    this.f2334a.f2317g = true;
                    this.f2334a.mo3085a(this.f2334a.f2318h);
                }
                return true;
            }
            throw new IllegalArgumentException();
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo3085a(int i) {
        C0694a aVar;
        if (this.f2311a.mo3109d() == null) {
            throw new IllegalStateException("No data model. Did you call #setDataModel?");
        }
        getViewTreeObserver().addOnGlobalLayoutListener(this.f2323m);
        boolean z = this.f2313c.getVisibility() == 0;
        int c = this.f2311a.mo3108c();
        if (i == Integer.MAX_VALUE || c <= i + (z ? 1 : 0)) {
            this.f2311a.mo3105a(false);
            aVar = this.f2311a;
        } else {
            this.f2311a.mo3105a(true);
            aVar = this.f2311a;
            i--;
        }
        aVar.mo3103a(i);
        C0789at listPopupWindow = getListPopupWindow();
        if (!listPopupWindow.mo2665d()) {
            if (this.f2317g || !z) {
                this.f2311a.mo3106a(true, z);
            } else {
                this.f2311a.mo3106a(false, false);
            }
            listPopupWindow.mo3784g(Math.min(this.f2311a.mo3102a(), this.f2322l));
            listPopupWindow.mo2655a();
            if (this.f2314d != null) {
                this.f2314d.mo1919a(true);
            }
            listPopupWindow.mo2666e().setContentDescription(getContext().getString(C0548h.abc_activitychooserview_choose_application));
            listPopupWindow.mo2666e().setSelector(new ColorDrawable(0));
        }
    }

    /* renamed from: a */
    public boolean mo3086a() {
        if (mo3088c() || !this.f2325o) {
            return false;
        }
        this.f2317g = false;
        mo3085a(this.f2318h);
        return true;
    }

    /* renamed from: b */
    public boolean mo3087b() {
        if (mo3088c()) {
            getListPopupWindow().mo2662c();
            ViewTreeObserver viewTreeObserver = getViewTreeObserver();
            if (viewTreeObserver.isAlive()) {
                viewTreeObserver.removeGlobalOnLayoutListener(this.f2323m);
            }
        }
        return true;
    }

    /* renamed from: c */
    public boolean mo3088c() {
        return getListPopupWindow().mo2665d();
    }

    public C0895d getDataModel() {
        return this.f2311a.mo3109d();
    }

    /* access modifiers changed from: 0000 */
    public C0789at getListPopupWindow() {
        if (this.f2324n == null) {
            this.f2324n = new C0789at(getContext());
            this.f2324n.mo3774a((ListAdapter) this.f2311a);
            this.f2324n.mo3778b((View) this);
            this.f2324n.mo3776a(true);
            this.f2324n.mo3773a((OnItemClickListener) this.f2319i);
            this.f2324n.mo3775a((OnDismissListener) this.f2319i);
        }
        return this.f2324n;
    }

    /* access modifiers changed from: protected */
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        C0895d d = this.f2311a.mo3109d();
        if (d != null) {
            d.registerObserver(this.f2315e);
        }
        this.f2325o = true;
    }

    /* access modifiers changed from: protected */
    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        C0895d d = this.f2311a.mo3109d();
        if (d != null) {
            d.unregisterObserver(this.f2315e);
        }
        ViewTreeObserver viewTreeObserver = getViewTreeObserver();
        if (viewTreeObserver.isAlive()) {
            viewTreeObserver.removeGlobalOnLayoutListener(this.f2323m);
        }
        if (mo3088c()) {
            mo3087b();
        }
        this.f2325o = false;
    }

    /* access modifiers changed from: protected */
    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        this.f2320j.layout(0, 0, i3 - i, i4 - i2);
        if (!mo3088c()) {
            mo3087b();
        }
    }

    /* access modifiers changed from: protected */
    public void onMeasure(int i, int i2) {
        View view = this.f2320j;
        if (this.f2313c.getVisibility() != 0) {
            i2 = MeasureSpec.makeMeasureSpec(MeasureSpec.getSize(i2), 1073741824);
        }
        measureChild(view, i, i2);
        setMeasuredDimension(view.getMeasuredWidth(), view.getMeasuredHeight());
    }

    public void setActivityChooserModel(C0895d dVar) {
        this.f2311a.mo3104a(dVar);
        if (mo3088c()) {
            mo3087b();
            mo3086a();
        }
    }

    public void setDefaultActionButtonContentDescription(int i) {
        this.f2326p = i;
    }

    public void setExpandActivityOverflowButtonContentDescription(int i) {
        this.f2321k.setContentDescription(getContext().getString(i));
    }

    public void setExpandActivityOverflowButtonDrawable(Drawable drawable) {
        this.f2321k.setImageDrawable(drawable);
    }

    public void setInitialActivityCount(int i) {
        this.f2318h = i;
    }

    public void setOnDismissListener(OnDismissListener onDismissListener) {
        this.f2316f = onDismissListener;
    }

    public void setProvider(C0477c cVar) {
        this.f2314d = cVar;
    }
}
