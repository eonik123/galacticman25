package android.support.p031v7.widget;

import android.os.Build.VERSION;
import android.view.View;

/* renamed from: android.support.v7.widget.bp */
public class C0873bp {
    /* renamed from: a */
    public static void m4703a(View view, CharSequence charSequence) {
        if (VERSION.SDK_INT >= 26) {
            view.setTooltipText(charSequence);
        } else {
            C0874bq.m4705a(view, charSequence);
        }
    }
}
