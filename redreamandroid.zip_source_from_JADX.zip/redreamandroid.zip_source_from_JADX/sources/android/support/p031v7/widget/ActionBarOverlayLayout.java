package android.support.p031v7.widget;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.support.p018v4.p028h.C0490m;
import android.support.p018v4.p028h.C0492o;
import android.support.p018v4.p028h.C0495r;
import android.support.p031v7.p032a.C0540a.C0541a;
import android.support.p031v7.p032a.C0540a.C0546f;
import android.support.p031v7.view.menu.C0671o.C0672a;
import android.util.AttributeSet;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewGroup.MarginLayoutParams;
import android.view.ViewPropertyAnimator;
import android.view.Window.Callback;
import android.widget.OverScroller;

/* renamed from: android.support.v7.widget.ActionBarOverlayLayout */
public class ActionBarOverlayLayout extends ViewGroup implements C0490m, C0755ai {

    /* renamed from: e */
    static final int[] f2261e = {C0541a.actionBarSize, 16842841};

    /* renamed from: A */
    private final Runnable f2262A;

    /* renamed from: B */
    private final C0492o f2263B;

    /* renamed from: a */
    ActionBarContainer f2264a;

    /* renamed from: b */
    boolean f2265b;

    /* renamed from: c */
    ViewPropertyAnimator f2266c;

    /* renamed from: d */
    final AnimatorListenerAdapter f2267d;

    /* renamed from: f */
    private int f2268f;

    /* renamed from: g */
    private int f2269g;

    /* renamed from: h */
    private ContentFrameLayout f2270h;

    /* renamed from: i */
    private C0756aj f2271i;

    /* renamed from: j */
    private Drawable f2272j;

    /* renamed from: k */
    private boolean f2273k;

    /* renamed from: l */
    private boolean f2274l;

    /* renamed from: m */
    private boolean f2275m;

    /* renamed from: n */
    private boolean f2276n;

    /* renamed from: o */
    private int f2277o;

    /* renamed from: p */
    private int f2278p;

    /* renamed from: q */
    private final Rect f2279q;

    /* renamed from: r */
    private final Rect f2280r;

    /* renamed from: s */
    private final Rect f2281s;

    /* renamed from: t */
    private final Rect f2282t;

    /* renamed from: u */
    private final Rect f2283u;

    /* renamed from: v */
    private final Rect f2284v;

    /* renamed from: w */
    private final Rect f2285w;

    /* renamed from: x */
    private C0687a f2286x;

    /* renamed from: y */
    private OverScroller f2287y;

    /* renamed from: z */
    private final Runnable f2288z;

    /* renamed from: android.support.v7.widget.ActionBarOverlayLayout$a */
    public interface C0687a {
        /* renamed from: a */
        void mo2339a(int i);

        /* renamed from: g */
        void mo2342g(boolean z);

        /* renamed from: j */
        void mo2347j();

        /* renamed from: k */
        void mo2349k();

        /* renamed from: l */
        void mo2350l();

        /* renamed from: m */
        void mo2351m();
    }

    /* renamed from: android.support.v7.widget.ActionBarOverlayLayout$b */
    public static class C0688b extends MarginLayoutParams {
        public C0688b(int i, int i2) {
            super(i, i2);
        }

        public C0688b(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
        }

        public C0688b(LayoutParams layoutParams) {
            super(layoutParams);
        }
    }

    public ActionBarOverlayLayout(Context context) {
        this(context, null);
    }

    public ActionBarOverlayLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f2269g = 0;
        this.f2279q = new Rect();
        this.f2280r = new Rect();
        this.f2281s = new Rect();
        this.f2282t = new Rect();
        this.f2283u = new Rect();
        this.f2284v = new Rect();
        this.f2285w = new Rect();
        this.f2267d = new AnimatorListenerAdapter() {
            public void onAnimationCancel(Animator animator) {
                ActionBarOverlayLayout.this.f2266c = null;
                ActionBarOverlayLayout.this.f2265b = false;
            }

            public void onAnimationEnd(Animator animator) {
                ActionBarOverlayLayout.this.f2266c = null;
                ActionBarOverlayLayout.this.f2265b = false;
            }
        };
        this.f2288z = new Runnable() {
            public void run() {
                ActionBarOverlayLayout.this.mo3011d();
                ActionBarOverlayLayout.this.f2266c = ActionBarOverlayLayout.this.f2264a.animate().translationY(0.0f).setListener(ActionBarOverlayLayout.this.f2267d);
            }
        };
        this.f2262A = new Runnable() {
            public void run() {
                ActionBarOverlayLayout.this.mo3011d();
                ActionBarOverlayLayout.this.f2266c = ActionBarOverlayLayout.this.f2264a.animate().translationY((float) (-ActionBarOverlayLayout.this.f2264a.getHeight())).setListener(ActionBarOverlayLayout.this.f2267d);
            }
        };
        m3175a(context);
        this.f2263B = new C0492o(this);
    }

    /* renamed from: a */
    private C0756aj m3174a(View view) {
        if (view instanceof C0756aj) {
            return (C0756aj) view;
        }
        if (view instanceof Toolbar) {
            return ((Toolbar) view).getWrapper();
        }
        StringBuilder sb = new StringBuilder();
        sb.append("Can't make a decor toolbar out of ");
        sb.append(view.getClass().getSimpleName());
        throw new IllegalStateException(sb.toString());
    }

    /* renamed from: a */
    private void m3175a(Context context) {
        TypedArray obtainStyledAttributes = getContext().getTheme().obtainStyledAttributes(f2261e);
        boolean z = false;
        this.f2268f = obtainStyledAttributes.getDimensionPixelSize(0, 0);
        this.f2272j = obtainStyledAttributes.getDrawable(1);
        setWillNotDraw(this.f2272j == null);
        obtainStyledAttributes.recycle();
        if (context.getApplicationInfo().targetSdkVersion < 19) {
            z = true;
        }
        this.f2273k = z;
        this.f2287y = new OverScroller(context);
    }

    /* renamed from: a */
    private boolean m3176a(float f, float f2) {
        this.f2287y.fling(0, 0, 0, (int) f2, 0, 0, Integer.MIN_VALUE, Integer.MAX_VALUE);
        return this.f2287y.getFinalY() > this.f2264a.getHeight();
    }

    /* renamed from: a */
    private boolean m3177a(View view, Rect rect, boolean z, boolean z2, boolean z3, boolean z4) {
        boolean z5;
        C0688b bVar = (C0688b) view.getLayoutParams();
        if (!z || bVar.leftMargin == rect.left) {
            z5 = false;
        } else {
            bVar.leftMargin = rect.left;
            z5 = true;
        }
        if (z2 && bVar.topMargin != rect.top) {
            bVar.topMargin = rect.top;
            z5 = true;
        }
        if (z4 && bVar.rightMargin != rect.right) {
            bVar.rightMargin = rect.right;
            z5 = true;
        }
        if (!z3 || bVar.bottomMargin == rect.bottom) {
            return z5;
        }
        bVar.bottomMargin = rect.bottom;
        return true;
    }

    /* renamed from: l */
    private void m3178l() {
        mo3011d();
        postDelayed(this.f2288z, 600);
    }

    /* renamed from: m */
    private void m3179m() {
        mo3011d();
        postDelayed(this.f2262A, 600);
    }

    /* renamed from: n */
    private void m3180n() {
        mo3011d();
        this.f2288z.run();
    }

    /* renamed from: o */
    private void m3181o() {
        mo3011d();
        this.f2262A.run();
    }

    /* renamed from: a */
    public C0688b generateLayoutParams(AttributeSet attributeSet) {
        return new C0688b(getContext(), attributeSet);
    }

    /* renamed from: a */
    public void mo3005a(int i) {
        mo3009c();
        if (i == 2) {
            this.f2271i.mo3630f();
        } else if (i == 5) {
            this.f2271i.mo3631g();
        } else if (i == 109) {
            setOverlayMode(true);
        }
    }

    /* renamed from: a */
    public void mo3006a(Menu menu, C0672a aVar) {
        mo3009c();
        this.f2271i.mo3618a(menu, aVar);
    }

    /* renamed from: a */
    public boolean mo3007a() {
        return this.f2274l;
    }

    /* access modifiers changed from: protected */
    /* renamed from: b */
    public C0688b generateDefaultLayoutParams() {
        return new C0688b(-1, -1);
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: c */
    public void mo3009c() {
        if (this.f2270h == null) {
            this.f2270h = (ContentFrameLayout) findViewById(C0546f.action_bar_activity_content);
            this.f2264a = (ActionBarContainer) findViewById(C0546f.action_bar_container);
            this.f2271i = m3174a(findViewById(C0546f.action_bar));
        }
    }

    /* access modifiers changed from: protected */
    public boolean checkLayoutParams(LayoutParams layoutParams) {
        return layoutParams instanceof C0688b;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: d */
    public void mo3011d() {
        removeCallbacks(this.f2288z);
        removeCallbacks(this.f2262A);
        if (this.f2266c != null) {
            this.f2266c.cancel();
        }
    }

    public void draw(Canvas canvas) {
        super.draw(canvas);
        if (this.f2272j != null && !this.f2273k) {
            int bottom = this.f2264a.getVisibility() == 0 ? (int) (((float) this.f2264a.getBottom()) + this.f2264a.getTranslationY() + 0.5f) : 0;
            this.f2272j.setBounds(0, bottom, getWidth(), this.f2272j.getIntrinsicHeight() + bottom);
            this.f2272j.draw(canvas);
        }
    }

    /* renamed from: e */
    public boolean mo3013e() {
        mo3009c();
        return this.f2271i.mo3632h();
    }

    /* renamed from: f */
    public boolean mo3014f() {
        mo3009c();
        return this.f2271i.mo3633i();
    }

    /* access modifiers changed from: protected */
    public boolean fitSystemWindows(Rect rect) {
        mo3009c();
        int n = C0495r.m2159n(this) & 256;
        boolean a = m3177a(this.f2264a, rect, true, true, false, true);
        this.f2282t.set(rect);
        C0885bv.m4756a(this, this.f2282t, this.f2279q);
        if (!this.f2283u.equals(this.f2282t)) {
            this.f2283u.set(this.f2282t);
            a = true;
        }
        if (!this.f2280r.equals(this.f2279q)) {
            this.f2280r.set(this.f2279q);
            a = true;
        }
        if (a) {
            requestLayout();
        }
        return true;
    }

    /* renamed from: g */
    public boolean mo3016g() {
        mo3009c();
        return this.f2271i.mo3634j();
    }

    /* access modifiers changed from: protected */
    public LayoutParams generateLayoutParams(LayoutParams layoutParams) {
        return new C0688b(layoutParams);
    }

    public int getActionBarHideOffset() {
        if (this.f2264a != null) {
            return -((int) this.f2264a.getTranslationY());
        }
        return 0;
    }

    public int getNestedScrollAxes() {
        return this.f2263B.mo1944a();
    }

    public CharSequence getTitle() {
        mo3009c();
        return this.f2271i.mo3629e();
    }

    /* renamed from: h */
    public boolean mo3023h() {
        mo3009c();
        return this.f2271i.mo3635k();
    }

    /* renamed from: i */
    public boolean mo3024i() {
        mo3009c();
        return this.f2271i.mo3636l();
    }

    /* renamed from: j */
    public void mo3025j() {
        mo3009c();
        this.f2271i.mo3637m();
    }

    /* renamed from: k */
    public void mo3026k() {
        mo3009c();
        this.f2271i.mo3638n();
    }

    /* access modifiers changed from: protected */
    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        m3175a(getContext());
        C0495r.m2160o(this);
    }

    /* access modifiers changed from: protected */
    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        mo3011d();
    }

    /* access modifiers changed from: protected */
    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        int childCount = getChildCount();
        int paddingLeft = getPaddingLeft();
        getPaddingRight();
        int paddingTop = getPaddingTop();
        getPaddingBottom();
        for (int i5 = 0; i5 < childCount; i5++) {
            View childAt = getChildAt(i5);
            if (childAt.getVisibility() != 8) {
                C0688b bVar = (C0688b) childAt.getLayoutParams();
                int i6 = bVar.leftMargin + paddingLeft;
                int i7 = bVar.topMargin + paddingTop;
                childAt.layout(i6, i7, childAt.getMeasuredWidth() + i6, childAt.getMeasuredHeight() + i7);
            }
        }
    }

    /* access modifiers changed from: protected */
    public void onMeasure(int i, int i2) {
        int i3;
        Rect rect;
        mo3009c();
        measureChildWithMargins(this.f2264a, i, 0, i2, 0);
        C0688b bVar = (C0688b) this.f2264a.getLayoutParams();
        int max = Math.max(0, this.f2264a.getMeasuredWidth() + bVar.leftMargin + bVar.rightMargin);
        int max2 = Math.max(0, this.f2264a.getMeasuredHeight() + bVar.topMargin + bVar.bottomMargin);
        int combineMeasuredStates = View.combineMeasuredStates(0, this.f2264a.getMeasuredState());
        boolean z = (C0495r.m2159n(this) & 256) != 0;
        if (z) {
            i3 = this.f2268f;
            if (this.f2275m && this.f2264a.getTabContainer() != null) {
                i3 += this.f2268f;
            }
        } else {
            i3 = this.f2264a.getVisibility() != 8 ? this.f2264a.getMeasuredHeight() : 0;
        }
        this.f2281s.set(this.f2279q);
        this.f2284v.set(this.f2282t);
        if (this.f2274l || z) {
            this.f2284v.top += i3;
            rect = this.f2284v;
        } else {
            this.f2281s.top += i3;
            rect = this.f2281s;
        }
        rect.bottom += 0;
        m3177a(this.f2270h, this.f2281s, true, true, true, true);
        if (!this.f2285w.equals(this.f2284v)) {
            this.f2285w.set(this.f2284v);
            this.f2270h.mo3141a(this.f2284v);
        }
        measureChildWithMargins(this.f2270h, i, 0, i2, 0);
        C0688b bVar2 = (C0688b) this.f2270h.getLayoutParams();
        int max3 = Math.max(max, this.f2270h.getMeasuredWidth() + bVar2.leftMargin + bVar2.rightMargin);
        int max4 = Math.max(max2, this.f2270h.getMeasuredHeight() + bVar2.topMargin + bVar2.bottomMargin);
        int combineMeasuredStates2 = View.combineMeasuredStates(combineMeasuredStates, this.f2270h.getMeasuredState());
        setMeasuredDimension(View.resolveSizeAndState(Math.max(max3 + getPaddingLeft() + getPaddingRight(), getSuggestedMinimumWidth()), i, combineMeasuredStates2), View.resolveSizeAndState(Math.max(max4 + getPaddingTop() + getPaddingBottom(), getSuggestedMinimumHeight()), i2, combineMeasuredStates2 << 16));
    }

    public boolean onNestedFling(View view, float f, float f2, boolean z) {
        if (!this.f2276n || !z) {
            return false;
        }
        if (m3176a(f, f2)) {
            m3181o();
        } else {
            m3180n();
        }
        this.f2265b = true;
        return true;
    }

    public boolean onNestedPreFling(View view, float f, float f2) {
        return false;
    }

    public void onNestedPreScroll(View view, int i, int i2, int[] iArr) {
    }

    public void onNestedScroll(View view, int i, int i2, int i3, int i4) {
        this.f2277o += i2;
        setActionBarHideOffset(this.f2277o);
    }

    public void onNestedScrollAccepted(View view, View view2, int i) {
        this.f2263B.mo1946a(view, view2, i);
        this.f2277o = getActionBarHideOffset();
        mo3011d();
        if (this.f2286x != null) {
            this.f2286x.mo2350l();
        }
    }

    public boolean onStartNestedScroll(View view, View view2, int i) {
        if ((i & 2) == 0 || this.f2264a.getVisibility() != 0) {
            return false;
        }
        return this.f2276n;
    }

    public void onStopNestedScroll(View view) {
        if (this.f2276n && !this.f2265b) {
            if (this.f2277o <= this.f2264a.getHeight()) {
                m3178l();
            } else {
                m3179m();
            }
        }
        if (this.f2286x != null) {
            this.f2286x.mo2351m();
        }
    }

    public void onWindowSystemUiVisibilityChanged(int i) {
        if (VERSION.SDK_INT >= 16) {
            super.onWindowSystemUiVisibilityChanged(i);
        }
        mo3009c();
        int i2 = this.f2278p ^ i;
        this.f2278p = i;
        boolean z = false;
        boolean z2 = (i & 4) == 0;
        if ((i & 256) != 0) {
            z = true;
        }
        if (this.f2286x != null) {
            this.f2286x.mo2342g(!z);
            if (z2 || !z) {
                this.f2286x.mo2347j();
            } else {
                this.f2286x.mo2349k();
            }
        }
        if ((i2 & 256) != 0 && this.f2286x != null) {
            C0495r.m2160o(this);
        }
    }

    /* access modifiers changed from: protected */
    public void onWindowVisibilityChanged(int i) {
        super.onWindowVisibilityChanged(i);
        this.f2269g = i;
        if (this.f2286x != null) {
            this.f2286x.mo2339a(i);
        }
    }

    public void setActionBarHideOffset(int i) {
        mo3011d();
        this.f2264a.setTranslationY((float) (-Math.max(0, Math.min(i, this.f2264a.getHeight()))));
    }

    public void setActionBarVisibilityCallback(C0687a aVar) {
        this.f2286x = aVar;
        if (getWindowToken() != null) {
            this.f2286x.mo2339a(this.f2269g);
            if (this.f2278p != 0) {
                onWindowSystemUiVisibilityChanged(this.f2278p);
                C0495r.m2160o(this);
            }
        }
    }

    public void setHasNonEmbeddedTabs(boolean z) {
        this.f2275m = z;
    }

    public void setHideOnContentScrollEnabled(boolean z) {
        if (z != this.f2276n) {
            this.f2276n = z;
            if (!z) {
                mo3011d();
                setActionBarHideOffset(0);
            }
        }
    }

    public void setIcon(int i) {
        mo3009c();
        this.f2271i.mo3614a(i);
    }

    public void setIcon(Drawable drawable) {
        mo3009c();
        this.f2271i.mo3615a(drawable);
    }

    public void setLogo(int i) {
        mo3009c();
        this.f2271i.mo3623b(i);
    }

    public void setOverlayMode(boolean z) {
        this.f2274l = z;
        this.f2273k = z && getContext().getApplicationInfo().targetSdkVersion < 19;
    }

    public void setShowingForActionMode(boolean z) {
    }

    public void setUiOptions(int i) {
    }

    public void setWindowCallback(Callback callback) {
        mo3009c();
        this.f2271i.mo3619a(callback);
    }

    public void setWindowTitle(CharSequence charSequence) {
        mo3009c();
        this.f2271i.mo3620a(charSequence);
    }

    public boolean shouldDelayChildPressedState() {
        return false;
    }
}
