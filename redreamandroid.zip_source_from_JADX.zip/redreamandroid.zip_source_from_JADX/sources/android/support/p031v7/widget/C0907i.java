package android.support.p031v7.widget;

import android.content.Context;
import android.support.p018v4.widget.C0531m;
import android.support.p031v7.p033b.p034a.C0606a;
import android.util.AttributeSet;
import android.view.ActionMode.Callback;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.widget.CheckedTextView;
import android.widget.TextView;

/* renamed from: android.support.v7.widget.i */
public class C0907i extends CheckedTextView {

    /* renamed from: a */
    private static final int[] f3279a = {16843016};

    /* renamed from: b */
    private final C0934y f3280b;

    public C0907i(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 16843720);
    }

    public C0907i(Context context, AttributeSet attributeSet, int i) {
        super(C0866bk.m4633a(context), attributeSet, i);
        this.f3280b = new C0934y(this);
        this.f3280b.mo4679a(attributeSet, i);
        this.f3280b.mo4674a();
        C0869bn a = C0869bn.m4638a(getContext(), attributeSet, f3279a, i, 0);
        setCheckMarkDrawable(a.mo4426a(0));
        a.mo4427a();
    }

    /* access modifiers changed from: protected */
    public void drawableStateChanged() {
        super.drawableStateChanged();
        if (this.f3280b != null) {
            this.f3280b.mo4674a();
        }
    }

    public InputConnection onCreateInputConnection(EditorInfo editorInfo) {
        return C0916m.m4905a(super.onCreateInputConnection(editorInfo), editorInfo, this);
    }

    public void setCheckMarkDrawable(int i) {
        setCheckMarkDrawable(C0606a.m2714b(getContext(), i));
    }

    public void setCustomSelectionActionModeCallback(Callback callback) {
        super.setCustomSelectionActionModeCallback(C0531m.m2345a((TextView) this, callback));
    }

    public void setTextAppearance(Context context, int i) {
        super.setTextAppearance(context, i);
        if (this.f3280b != null) {
            this.f3280b.mo4678a(context, i);
        }
    }
}
