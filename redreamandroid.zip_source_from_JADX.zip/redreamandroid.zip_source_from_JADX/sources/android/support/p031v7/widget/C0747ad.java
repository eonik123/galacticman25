package android.support.p031v7.widget;

import android.content.res.ColorStateList;

/* renamed from: android.support.v7.widget.ad */
class C0747ad implements C0751ag {
    C0747ad() {
    }

    /* renamed from: j */
    private C0851bb m3692j(C0750af afVar) {
        return (C0851bb) afVar.mo3569a();
    }

    /* renamed from: a */
    public float mo3555a(C0750af afVar) {
        return m3692j(afVar).mo4327a();
    }

    /* renamed from: a */
    public void mo3553a() {
    }

    /* renamed from: a */
    public void mo3556a(C0750af afVar, float f) {
        m3692j(afVar).mo4328a(f);
    }

    /* renamed from: a */
    public void mo3557a(C0750af afVar, ColorStateList colorStateList) {
        m3692j(afVar).mo4330a(colorStateList);
    }

    /* renamed from: b */
    public float mo3558b(C0750af afVar) {
        return mo3562d(afVar) * 2.0f;
    }

    /* renamed from: b */
    public void mo3559b(C0750af afVar, float f) {
        m3692j(afVar).mo4329a(f, afVar.mo3572b(), afVar.mo3573c());
        mo3564f(afVar);
    }

    /* renamed from: c */
    public float mo3560c(C0750af afVar) {
        return mo3562d(afVar) * 2.0f;
    }

    /* renamed from: c */
    public void mo3561c(C0750af afVar, float f) {
        afVar.mo3574d().setElevation(f);
    }

    /* renamed from: d */
    public float mo3562d(C0750af afVar) {
        return m3692j(afVar).mo4331b();
    }

    /* renamed from: e */
    public float mo3563e(C0750af afVar) {
        return afVar.mo3574d().getElevation();
    }

    /* renamed from: f */
    public void mo3564f(C0750af afVar) {
        if (!afVar.mo3572b()) {
            afVar.mo3571a(0, 0, 0, 0);
            return;
        }
        float a = mo3555a(afVar);
        float d = mo3562d(afVar);
        int ceil = (int) Math.ceil((double) C0852bc.m4541b(a, d, afVar.mo3573c()));
        int ceil2 = (int) Math.ceil((double) C0852bc.m4538a(a, d, afVar.mo3573c()));
        afVar.mo3571a(ceil, ceil2, ceil, ceil2);
    }

    /* renamed from: g */
    public void mo3565g(C0750af afVar) {
        mo3559b(afVar, mo3555a(afVar));
    }

    /* renamed from: h */
    public void mo3566h(C0750af afVar) {
        mo3559b(afVar, mo3555a(afVar));
    }

    /* renamed from: i */
    public ColorStateList mo3567i(C0750af afVar) {
        return m3692j(afVar).mo4332c();
    }
}
