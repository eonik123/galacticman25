package android.support.p031v7.widget;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources.NotFoundException;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.support.p018v4.p019a.p020a.C0304f.C0305a;
import android.support.p018v4.widget.C0517b;
import android.support.p018v4.widget.C0531m;
import android.support.p031v7.p032a.C0540a.C0550j;
import android.text.method.PasswordTransformationMethod;
import android.util.AttributeSet;
import android.widget.TextView;
import java.lang.ref.WeakReference;

/* renamed from: android.support.v7.widget.y */
class C0934y {

    /* renamed from: a */
    private final TextView f3352a;

    /* renamed from: b */
    private C0867bl f3353b;

    /* renamed from: c */
    private C0867bl f3354c;

    /* renamed from: d */
    private C0867bl f3355d;

    /* renamed from: e */
    private C0867bl f3356e;

    /* renamed from: f */
    private C0867bl f3357f;

    /* renamed from: g */
    private C0867bl f3358g;

    /* renamed from: h */
    private final C0743aa f3359h;

    /* renamed from: i */
    private int f3360i = 0;

    /* renamed from: j */
    private Typeface f3361j;

    /* renamed from: k */
    private boolean f3362k;

    C0934y(TextView textView) {
        this.f3352a = textView;
        this.f3359h = new C0743aa(this.f3352a);
    }

    /* renamed from: a */
    private static C0867bl m4939a(Context context, C0909k kVar, int i) {
        ColorStateList b = kVar.mo4573b(context, i);
        if (b == null) {
            return null;
        }
        C0867bl blVar = new C0867bl();
        blVar.f3141d = true;
        blVar.f3138a = b;
        return blVar;
    }

    /* renamed from: a */
    private void m4940a(Context context, C0869bn bnVar) {
        Typeface typeface;
        this.f3360i = bnVar.mo4424a(C0550j.TextAppearance_android_textStyle, this.f3360i);
        boolean z = true;
        if (bnVar.mo4440g(C0550j.TextAppearance_android_fontFamily) || bnVar.mo4440g(C0550j.TextAppearance_fontFamily)) {
            this.f3361j = null;
            int i = bnVar.mo4440g(C0550j.TextAppearance_fontFamily) ? C0550j.TextAppearance_fontFamily : C0550j.TextAppearance_android_fontFamily;
            if (!context.isRestricted()) {
                final WeakReference weakReference = new WeakReference(this.f3352a);
                try {
                    this.f3361j = bnVar.mo4425a(i, this.f3360i, (C0305a) new C0305a() {
                        /* renamed from: a */
                        public void mo1122a(int i) {
                        }

                        /* renamed from: a */
                        public void mo1124a(Typeface typeface) {
                            C0934y.this.mo4680a(weakReference, typeface);
                        }
                    });
                    if (this.f3361j != null) {
                        z = false;
                    }
                    this.f3362k = z;
                } catch (NotFoundException | UnsupportedOperationException unused) {
                }
            }
            if (this.f3361j == null) {
                String d = bnVar.mo4434d(i);
                if (d != null) {
                    this.f3361j = Typeface.create(d, this.f3360i);
                }
            }
            return;
        }
        if (bnVar.mo4440g(C0550j.TextAppearance_android_typeface)) {
            this.f3362k = false;
            switch (bnVar.mo4424a(C0550j.TextAppearance_android_typeface, 1)) {
                case 1:
                    typeface = Typeface.SANS_SERIF;
                    break;
                case 2:
                    typeface = Typeface.SERIF;
                    break;
                case 3:
                    typeface = Typeface.MONOSPACE;
                    break;
                default:
                    return;
            }
            this.f3361j = typeface;
        }
    }

    /* renamed from: a */
    private void m4941a(Drawable drawable, C0867bl blVar) {
        if (drawable != null && blVar != null) {
            C0909k.m4877a(drawable, blVar, this.f3352a.getDrawableState());
        }
    }

    /* renamed from: b */
    private void m4942b(int i, float f) {
        this.f3359h.mo3521a(i, f);
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo4674a() {
        if (!(this.f3353b == null && this.f3354c == null && this.f3355d == null && this.f3356e == null)) {
            Drawable[] compoundDrawables = this.f3352a.getCompoundDrawables();
            m4941a(compoundDrawables[0], this.f3353b);
            m4941a(compoundDrawables[1], this.f3354c);
            m4941a(compoundDrawables[2], this.f3355d);
            m4941a(compoundDrawables[3], this.f3356e);
        }
        if (VERSION.SDK_INT < 17) {
            return;
        }
        if (this.f3357f != null || this.f3358g != null) {
            Drawable[] compoundDrawablesRelative = this.f3352a.getCompoundDrawablesRelative();
            m4941a(compoundDrawablesRelative[0], this.f3357f);
            m4941a(compoundDrawablesRelative[2], this.f3358g);
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo4675a(int i) {
        this.f3359h.mo3520a(i);
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo4676a(int i, float f) {
        if (!C0517b.f1510a && !mo4685c()) {
            m4942b(i, f);
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo4677a(int i, int i2, int i3, int i4) {
        this.f3359h.mo3522a(i, i2, i3, i4);
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo4678a(Context context, int i) {
        C0869bn a = C0869bn.m4636a(context, i, C0550j.TextAppearance);
        if (a.mo4440g(C0550j.TextAppearance_textAllCaps)) {
            mo4681a(a.mo4428a(C0550j.TextAppearance_textAllCaps, false));
        }
        if (VERSION.SDK_INT < 23 && a.mo4440g(C0550j.TextAppearance_android_textColor)) {
            ColorStateList e = a.mo4436e(C0550j.TextAppearance_android_textColor);
            if (e != null) {
                this.f3352a.setTextColor(e);
            }
        }
        if (a.mo4440g(C0550j.TextAppearance_android_textSize) && a.mo4435e(C0550j.TextAppearance_android_textSize, -1) == 0) {
            this.f3352a.setTextSize(0, 0.0f);
        }
        m4940a(context, a);
        a.mo4427a();
        if (this.f3361j != null) {
            this.f3352a.setTypeface(this.f3361j, this.f3360i);
        }
    }

    /* access modifiers changed from: 0000 */
    @SuppressLint({"NewApi"})
    /* renamed from: a */
    public void mo4679a(AttributeSet attributeSet, int i) {
        ColorStateList colorStateList;
        ColorStateList colorStateList2;
        boolean z;
        boolean z2;
        AttributeSet attributeSet2 = attributeSet;
        int i2 = i;
        Context context = this.f3352a.getContext();
        C0909k a = C0909k.m4874a();
        C0869bn a2 = C0869bn.m4638a(context, attributeSet2, C0550j.AppCompatTextHelper, i2, 0);
        int g = a2.mo4439g(C0550j.AppCompatTextHelper_android_textAppearance, -1);
        if (a2.mo4440g(C0550j.AppCompatTextHelper_android_drawableLeft)) {
            this.f3353b = m4939a(context, a, a2.mo4439g(C0550j.AppCompatTextHelper_android_drawableLeft, 0));
        }
        if (a2.mo4440g(C0550j.AppCompatTextHelper_android_drawableTop)) {
            this.f3354c = m4939a(context, a, a2.mo4439g(C0550j.AppCompatTextHelper_android_drawableTop, 0));
        }
        if (a2.mo4440g(C0550j.AppCompatTextHelper_android_drawableRight)) {
            this.f3355d = m4939a(context, a, a2.mo4439g(C0550j.AppCompatTextHelper_android_drawableRight, 0));
        }
        if (a2.mo4440g(C0550j.AppCompatTextHelper_android_drawableBottom)) {
            this.f3356e = m4939a(context, a, a2.mo4439g(C0550j.AppCompatTextHelper_android_drawableBottom, 0));
        }
        if (VERSION.SDK_INT >= 17) {
            if (a2.mo4440g(C0550j.AppCompatTextHelper_android_drawableStart)) {
                this.f3357f = m4939a(context, a, a2.mo4439g(C0550j.AppCompatTextHelper_android_drawableStart, 0));
            }
            if (a2.mo4440g(C0550j.AppCompatTextHelper_android_drawableEnd)) {
                this.f3358g = m4939a(context, a, a2.mo4439g(C0550j.AppCompatTextHelper_android_drawableEnd, 0));
            }
        }
        a2.mo4427a();
        boolean z3 = this.f3352a.getTransformationMethod() instanceof PasswordTransformationMethod;
        ColorStateList colorStateList3 = null;
        if (g != -1) {
            C0869bn a3 = C0869bn.m4636a(context, g, C0550j.TextAppearance);
            if (z3 || !a3.mo4440g(C0550j.TextAppearance_textAllCaps)) {
                z2 = false;
                z = false;
            } else {
                z = a3.mo4428a(C0550j.TextAppearance_textAllCaps, false);
                z2 = true;
            }
            m4940a(context, a3);
            if (VERSION.SDK_INT < 23) {
                ColorStateList e = a3.mo4440g(C0550j.TextAppearance_android_textColor) ? a3.mo4436e(C0550j.TextAppearance_android_textColor) : null;
                colorStateList = a3.mo4440g(C0550j.TextAppearance_android_textColorHint) ? a3.mo4436e(C0550j.TextAppearance_android_textColorHint) : null;
                if (a3.mo4440g(C0550j.TextAppearance_android_textColorLink)) {
                    colorStateList3 = a3.mo4436e(C0550j.TextAppearance_android_textColorLink);
                }
                ColorStateList colorStateList4 = e;
                colorStateList2 = colorStateList3;
                colorStateList3 = colorStateList4;
            } else {
                colorStateList2 = null;
                colorStateList = null;
            }
            a3.mo4427a();
        } else {
            z2 = false;
            z = false;
            colorStateList2 = null;
            colorStateList = null;
        }
        C0869bn a4 = C0869bn.m4638a(context, attributeSet2, C0550j.TextAppearance, i2, 0);
        if (!z3 && a4.mo4440g(C0550j.TextAppearance_textAllCaps)) {
            z = a4.mo4428a(C0550j.TextAppearance_textAllCaps, false);
            z2 = true;
        }
        if (VERSION.SDK_INT < 23) {
            if (a4.mo4440g(C0550j.TextAppearance_android_textColor)) {
                colorStateList3 = a4.mo4436e(C0550j.TextAppearance_android_textColor);
            }
            if (a4.mo4440g(C0550j.TextAppearance_android_textColorHint)) {
                colorStateList = a4.mo4436e(C0550j.TextAppearance_android_textColorHint);
            }
            if (a4.mo4440g(C0550j.TextAppearance_android_textColorLink)) {
                colorStateList2 = a4.mo4436e(C0550j.TextAppearance_android_textColorLink);
            }
        }
        if (VERSION.SDK_INT >= 28 && a4.mo4440g(C0550j.TextAppearance_android_textSize) && a4.mo4435e(C0550j.TextAppearance_android_textSize, -1) == 0) {
            this.f3352a.setTextSize(0, 0.0f);
        }
        m4940a(context, a4);
        a4.mo4427a();
        if (colorStateList3 != null) {
            this.f3352a.setTextColor(colorStateList3);
        }
        if (colorStateList != null) {
            this.f3352a.setHintTextColor(colorStateList);
        }
        if (colorStateList2 != null) {
            this.f3352a.setLinkTextColor(colorStateList2);
        }
        if (!z3 && z2) {
            mo4681a(z);
        }
        if (this.f3361j != null) {
            this.f3352a.setTypeface(this.f3361j, this.f3360i);
        }
        this.f3359h.mo3523a(attributeSet2, i2);
        if (C0517b.f1510a && this.f3359h.mo3519a() != 0) {
            int[] e2 = this.f3359h.mo3528e();
            if (e2.length > 0) {
                if (((float) this.f3352a.getAutoSizeStepGranularity()) != -1.0f) {
                    this.f3352a.setAutoSizeTextTypeUniformWithConfiguration(this.f3359h.mo3526c(), this.f3359h.mo3527d(), this.f3359h.mo3525b(), 0);
                } else {
                    this.f3352a.setAutoSizeTextTypeUniformWithPresetSizes(e2, 0);
                }
            }
        }
        C0869bn a5 = C0869bn.m4637a(context, attributeSet2, C0550j.AppCompatTextView);
        int e3 = a5.mo4435e(C0550j.AppCompatTextView_firstBaselineToTopHeight, -1);
        int e4 = a5.mo4435e(C0550j.AppCompatTextView_lastBaselineToBottomHeight, -1);
        int e5 = a5.mo4435e(C0550j.AppCompatTextView_lineHeight, -1);
        a5.mo4427a();
        if (e3 != -1) {
            C0531m.m2351b(this.f3352a, e3);
        }
        if (e4 != -1) {
            C0531m.m2353c(this.f3352a, e4);
        }
        if (e5 != -1) {
            C0531m.m2355d(this.f3352a, e5);
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo4680a(WeakReference<TextView> weakReference, Typeface typeface) {
        if (this.f3362k) {
            this.f3361j = typeface;
            TextView textView = (TextView) weakReference.get();
            if (textView != null) {
                textView.setTypeface(typeface, this.f3360i);
            }
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo4681a(boolean z) {
        this.f3352a.setAllCaps(z);
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo4682a(boolean z, int i, int i2, int i3, int i4) {
        if (!C0517b.f1510a) {
            mo4684b();
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo4683a(int[] iArr, int i) {
        this.f3359h.mo3524a(iArr, i);
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: b */
    public void mo4684b() {
        this.f3359h.mo3529f();
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: c */
    public boolean mo4685c() {
        return this.f3359h.mo3530g();
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: d */
    public int mo4686d() {
        return this.f3359h.mo3519a();
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: e */
    public int mo4687e() {
        return this.f3359h.mo3525b();
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: f */
    public int mo4688f() {
        return this.f3359h.mo3526c();
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: g */
    public int mo4689g() {
        return this.f3359h.mo3527d();
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: h */
    public int[] mo4690h() {
        return this.f3359h.mo3528e();
    }
}
