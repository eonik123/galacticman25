package android.support.p031v7.widget;

import android.content.Context;
import android.support.p018v4.p028h.C0495r;
import android.support.p018v4.p028h.C0502v;
import android.support.p031v7.p032a.C0540a.C0541a;
import android.support.p031v7.p032a.C0540a.C0546f;
import android.support.p031v7.p032a.C0540a.C0547g;
import android.support.p031v7.p032a.C0540a.C0550j;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewGroup.MarginLayoutParams;
import android.view.accessibility.AccessibilityEvent;
import android.widget.LinearLayout;
import android.widget.TextView;

/* renamed from: android.support.v7.widget.ActionBarContextView */
public class ActionBarContextView extends C0741a {

    /* renamed from: g */
    private CharSequence f2248g;

    /* renamed from: h */
    private CharSequence f2249h;

    /* renamed from: i */
    private View f2250i;

    /* renamed from: j */
    private View f2251j;

    /* renamed from: k */
    private LinearLayout f2252k;

    /* renamed from: l */
    private TextView f2253l;

    /* renamed from: m */
    private TextView f2254m;

    /* renamed from: n */
    private int f2255n;

    /* renamed from: o */
    private int f2256o;

    /* renamed from: p */
    private boolean f2257p;

    /* renamed from: q */
    private int f2258q;

    public ActionBarContextView(Context context) {
        this(context, null);
    }

    public ActionBarContextView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, C0541a.actionModeStyle);
    }

    public ActionBarContextView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        C0869bn a = C0869bn.m4638a(context, attributeSet, C0550j.ActionMode, i, 0);
        C0495r.m2131a((View) this, a.mo4426a(C0550j.ActionMode_background));
        this.f2255n = a.mo4439g(C0550j.ActionMode_titleTextStyle, 0);
        this.f2256o = a.mo4439g(C0550j.ActionMode_subtitleTextStyle, 0);
        this.f2592e = a.mo4437f(C0550j.ActionMode_height, 0);
        this.f2258q = a.mo4439g(C0550j.ActionMode_closeItemLayout, C0547g.abc_action_mode_close_item_material);
        a.mo4427a();
    }

    /* renamed from: e */
    private void m3167e() {
        if (this.f2252k == null) {
            LayoutInflater.from(getContext()).inflate(C0547g.abc_action_bar_title_item, this);
            this.f2252k = (LinearLayout) getChildAt(getChildCount() - 1);
            this.f2253l = (TextView) this.f2252k.findViewById(C0546f.action_bar_title);
            this.f2254m = (TextView) this.f2252k.findViewById(C0546f.action_bar_subtitle);
            if (this.f2255n != 0) {
                this.f2253l.setTextAppearance(getContext(), this.f2255n);
            }
            if (this.f2256o != 0) {
                this.f2254m.setTextAppearance(getContext(), this.f2256o);
            }
        }
        this.f2253l.setText(this.f2248g);
        this.f2254m.setText(this.f2249h);
        boolean z = !TextUtils.isEmpty(this.f2248g);
        boolean z2 = !TextUtils.isEmpty(this.f2249h);
        int i = 8;
        this.f2254m.setVisibility(z2 ? 0 : 8);
        LinearLayout linearLayout = this.f2252k;
        if (z || z2) {
            i = 0;
        }
        linearLayout.setVisibility(i);
        if (this.f2252k.getParent() == null) {
            addView(this.f2252k);
        }
    }

    /* renamed from: a */
    public /* bridge */ /* synthetic */ C0502v mo2978a(int i, long j) {
        return super.mo2978a(i, j);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:5:0x0021, code lost:
        if (r3.f2250i.getParent() == null) goto L_0x0015;
     */
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void mo2979a(final android.support.p031v7.view.C0627b r4) {
        /*
            r3 = this;
            android.view.View r0 = r3.f2250i
            if (r0 != 0) goto L_0x001b
            android.content.Context r0 = r3.getContext()
            android.view.LayoutInflater r0 = android.view.LayoutInflater.from(r0)
            int r1 = r3.f2258q
            r2 = 0
            android.view.View r0 = r0.inflate(r1, r3, r2)
            r3.f2250i = r0
        L_0x0015:
            android.view.View r0 = r3.f2250i
            r3.addView(r0)
            goto L_0x0024
        L_0x001b:
            android.view.View r0 = r3.f2250i
            android.view.ViewParent r0 = r0.getParent()
            if (r0 != 0) goto L_0x0024
            goto L_0x0015
        L_0x0024:
            android.view.View r0 = r3.f2250i
            int r1 = android.support.p031v7.p032a.C0540a.C0546f.action_mode_close_button
            android.view.View r0 = r0.findViewById(r1)
            android.support.v7.widget.ActionBarContextView$1 r1 = new android.support.v7.widget.ActionBarContextView$1
            r1.<init>(r4)
            r0.setOnClickListener(r1)
            android.view.Menu r4 = r4.mo2357b()
            android.support.v7.view.menu.h r4 = (android.support.p031v7.view.menu.C0655h) r4
            android.support.v7.widget.c r0 = r3.f2591d
            if (r0 == 0) goto L_0x0043
            android.support.v7.widget.c r0 = r3.f2591d
            r0.mo4495f()
        L_0x0043:
            android.support.v7.widget.c r0 = new android.support.v7.widget.c
            android.content.Context r1 = r3.getContext()
            r0.<init>(r1)
            r3.f2591d = r0
            android.support.v7.widget.c r0 = r3.f2591d
            r1 = 1
            r0.mo4491c(r1)
            android.view.ViewGroup$LayoutParams r0 = new android.view.ViewGroup$LayoutParams
            r1 = -2
            r2 = -1
            r0.<init>(r1, r2)
            android.support.v7.widget.c r1 = r3.f2591d
            android.content.Context r2 = r3.f2589b
            r4.mo2708a(r1, r2)
            android.support.v7.widget.c r4 = r3.f2591d
            android.support.v7.view.menu.p r4 = r4.mo2634a(r3)
            android.support.v7.widget.ActionMenuView r4 = (android.support.p031v7.widget.ActionMenuView) r4
            r3.f2590c = r4
            android.support.v7.widget.ActionMenuView r4 = r3.f2590c
            r1 = 0
            android.support.p018v4.p028h.C0495r.m2131a(r4, r1)
            android.support.v7.widget.ActionMenuView r4 = r3.f2590c
            r3.addView(r4, r0)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.p031v7.widget.ActionBarContextView.mo2979a(android.support.v7.view.b):void");
    }

    /* renamed from: a */
    public boolean mo2980a() {
        if (this.f2591d != null) {
            return this.f2591d.mo4493d();
        }
        return false;
    }

    /* renamed from: b */
    public void mo2981b() {
        if (this.f2250i == null) {
            mo2982c();
        }
    }

    /* renamed from: c */
    public void mo2982c() {
        removeAllViews();
        this.f2251j = null;
        this.f2590c = null;
    }

    /* renamed from: d */
    public boolean mo2983d() {
        return this.f2257p;
    }

    /* access modifiers changed from: protected */
    public LayoutParams generateDefaultLayoutParams() {
        return new MarginLayoutParams(-1, -2);
    }

    public LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new MarginLayoutParams(getContext(), attributeSet);
    }

    public /* bridge */ /* synthetic */ int getAnimatedVisibility() {
        return super.getAnimatedVisibility();
    }

    public /* bridge */ /* synthetic */ int getContentHeight() {
        return super.getContentHeight();
    }

    public CharSequence getSubtitle() {
        return this.f2249h;
    }

    public CharSequence getTitle() {
        return this.f2248g;
    }

    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        if (this.f2591d != null) {
            this.f2591d.mo4494e();
            this.f2591d.mo4496g();
        }
    }

    public /* bridge */ /* synthetic */ boolean onHoverEvent(MotionEvent motionEvent) {
        return super.onHoverEvent(motionEvent);
    }

    public void onInitializeAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        if (accessibilityEvent.getEventType() == 32) {
            accessibilityEvent.setSource(this);
            accessibilityEvent.setClassName(getClass().getName());
            accessibilityEvent.setPackageName(getContext().getPackageName());
            accessibilityEvent.setContentDescription(this.f2248g);
            return;
        }
        super.onInitializeAccessibilityEvent(accessibilityEvent);
    }

    /* access modifiers changed from: protected */
    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        int i5;
        boolean a = C0885bv.m4757a(this);
        int paddingRight = a ? (i3 - i) - getPaddingRight() : getPaddingLeft();
        int paddingTop = getPaddingTop();
        int paddingTop2 = ((i4 - i2) - getPaddingTop()) - getPaddingBottom();
        if (this.f2250i == null || this.f2250i.getVisibility() == 8) {
            i5 = paddingRight;
        } else {
            MarginLayoutParams marginLayoutParams = (MarginLayoutParams) this.f2250i.getLayoutParams();
            int i6 = a ? marginLayoutParams.rightMargin : marginLayoutParams.leftMargin;
            int i7 = a ? marginLayoutParams.leftMargin : marginLayoutParams.rightMargin;
            int a2 = m3653a(paddingRight, i6, a);
            i5 = m3653a(a2 + mo3516a(this.f2250i, a2, paddingTop, paddingTop2, a), i7, a);
        }
        if (!(this.f2252k == null || this.f2251j != null || this.f2252k.getVisibility() == 8)) {
            i5 += mo3516a(this.f2252k, i5, paddingTop, paddingTop2, a);
        }
        int i8 = i5;
        if (this.f2251j != null) {
            mo3516a(this.f2251j, i8, paddingTop, paddingTop2, a);
        }
        int paddingLeft = a ? getPaddingLeft() : (i3 - i) - getPaddingRight();
        if (this.f2590c != null) {
            mo3516a(this.f2590c, paddingLeft, paddingTop, paddingTop2, !a);
        }
    }

    /* access modifiers changed from: protected */
    public void onMeasure(int i, int i2) {
        int i3 = 1073741824;
        if (MeasureSpec.getMode(i) != 1073741824) {
            StringBuilder sb = new StringBuilder();
            sb.append(getClass().getSimpleName());
            sb.append(" can only be used ");
            sb.append("with android:layout_width=\"match_parent\" (or fill_parent)");
            throw new IllegalStateException(sb.toString());
        } else if (MeasureSpec.getMode(i2) == 0) {
            StringBuilder sb2 = new StringBuilder();
            sb2.append(getClass().getSimpleName());
            sb2.append(" can only be used ");
            sb2.append("with android:layout_height=\"wrap_content\"");
            throw new IllegalStateException(sb2.toString());
        } else {
            int size = MeasureSpec.getSize(i);
            int size2 = this.f2592e > 0 ? this.f2592e : MeasureSpec.getSize(i2);
            int paddingTop = getPaddingTop() + getPaddingBottom();
            int paddingLeft = (size - getPaddingLeft()) - getPaddingRight();
            int i4 = size2 - paddingTop;
            int makeMeasureSpec = MeasureSpec.makeMeasureSpec(i4, Integer.MIN_VALUE);
            if (this.f2250i != null) {
                MarginLayoutParams marginLayoutParams = (MarginLayoutParams) this.f2250i.getLayoutParams();
                paddingLeft = mo3515a(this.f2250i, paddingLeft, makeMeasureSpec, 0) - (marginLayoutParams.leftMargin + marginLayoutParams.rightMargin);
            }
            if (this.f2590c != null && this.f2590c.getParent() == this) {
                paddingLeft = mo3515a(this.f2590c, paddingLeft, makeMeasureSpec, 0);
            }
            if (this.f2252k != null && this.f2251j == null) {
                if (this.f2257p) {
                    this.f2252k.measure(MeasureSpec.makeMeasureSpec(0, 0), makeMeasureSpec);
                    int measuredWidth = this.f2252k.getMeasuredWidth();
                    boolean z = measuredWidth <= paddingLeft;
                    if (z) {
                        paddingLeft -= measuredWidth;
                    }
                    this.f2252k.setVisibility(z ? 0 : 8);
                } else {
                    paddingLeft = mo3515a(this.f2252k, paddingLeft, makeMeasureSpec, 0);
                }
            }
            if (this.f2251j != null) {
                LayoutParams layoutParams = this.f2251j.getLayoutParams();
                int i5 = layoutParams.width != -2 ? 1073741824 : Integer.MIN_VALUE;
                if (layoutParams.width >= 0) {
                    paddingLeft = Math.min(layoutParams.width, paddingLeft);
                }
                if (layoutParams.height == -2) {
                    i3 = Integer.MIN_VALUE;
                }
                if (layoutParams.height >= 0) {
                    i4 = Math.min(layoutParams.height, i4);
                }
                this.f2251j.measure(MeasureSpec.makeMeasureSpec(paddingLeft, i5), MeasureSpec.makeMeasureSpec(i4, i3));
            }
            if (this.f2592e <= 0) {
                int childCount = getChildCount();
                int i6 = 0;
                for (int i7 = 0; i7 < childCount; i7++) {
                    int measuredHeight = getChildAt(i7).getMeasuredHeight() + paddingTop;
                    if (measuredHeight > i6) {
                        i6 = measuredHeight;
                    }
                }
                setMeasuredDimension(size, i6);
                return;
            }
            setMeasuredDimension(size, size2);
        }
    }

    public /* bridge */ /* synthetic */ boolean onTouchEvent(MotionEvent motionEvent) {
        return super.onTouchEvent(motionEvent);
    }

    public void setContentHeight(int i) {
        this.f2592e = i;
    }

    public void setCustomView(View view) {
        if (this.f2251j != null) {
            removeView(this.f2251j);
        }
        this.f2251j = view;
        if (!(view == null || this.f2252k == null)) {
            removeView(this.f2252k);
            this.f2252k = null;
        }
        if (view != null) {
            addView(view);
        }
        requestLayout();
    }

    public void setSubtitle(CharSequence charSequence) {
        this.f2249h = charSequence;
        m3167e();
    }

    public void setTitle(CharSequence charSequence) {
        this.f2248g = charSequence;
        m3167e();
    }

    public void setTitleOptional(boolean z) {
        if (z != this.f2257p) {
            requestLayout();
        }
        this.f2257p = z;
    }

    public /* bridge */ /* synthetic */ void setVisibility(int i) {
        super.setVisibility(i);
    }

    public boolean shouldDelayChildPressedState() {
        return false;
    }
}
