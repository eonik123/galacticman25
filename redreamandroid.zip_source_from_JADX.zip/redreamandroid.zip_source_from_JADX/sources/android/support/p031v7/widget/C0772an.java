package android.support.p031v7.widget;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.animation.ValueAnimator.AnimatorUpdateListener;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.StateListDrawable;
import android.support.p018v4.p028h.C0495r;
import android.support.p031v7.widget.C0805ay.C0822h;
import android.support.p031v7.widget.C0805ay.C0831m;
import android.support.p031v7.widget.C0805ay.C0832n;
import android.support.p031v7.widget.C0805ay.C0843u;
import android.view.MotionEvent;

/* renamed from: android.support.v7.widget.an */
class C0772an extends C0822h implements C0831m {

    /* renamed from: k */
    private static final int[] f2696k = {16842919};

    /* renamed from: l */
    private static final int[] f2697l = new int[0];

    /* renamed from: A */
    private int f2698A = 0;

    /* renamed from: B */
    private final int[] f2699B = new int[2];

    /* renamed from: C */
    private final int[] f2700C = new int[2];

    /* renamed from: D */
    private final Runnable f2701D = new Runnable() {
        public void run() {
            C0772an.this.mo3698b(500);
        }
    };

    /* renamed from: E */
    private final C0832n f2702E = new C0832n() {
        /* renamed from: a */
        public void mo3702a(C0805ay ayVar, int i, int i2) {
            C0772an.this.mo3691a(ayVar.computeHorizontalScrollOffset(), ayVar.computeVerticalScrollOffset());
        }
    };

    /* renamed from: a */
    final StateListDrawable f2703a;

    /* renamed from: b */
    final Drawable f2704b;

    /* renamed from: c */
    int f2705c;

    /* renamed from: d */
    int f2706d;

    /* renamed from: e */
    float f2707e;

    /* renamed from: f */
    int f2708f;

    /* renamed from: g */
    int f2709g;

    /* renamed from: h */
    float f2710h;

    /* renamed from: i */
    final ValueAnimator f2711i = ValueAnimator.ofFloat(new float[]{0.0f, 1.0f});

    /* renamed from: j */
    int f2712j = 0;

    /* renamed from: m */
    private final int f2713m;

    /* renamed from: n */
    private final int f2714n;

    /* renamed from: o */
    private final int f2715o;

    /* renamed from: p */
    private final int f2716p;

    /* renamed from: q */
    private final StateListDrawable f2717q;

    /* renamed from: r */
    private final Drawable f2718r;

    /* renamed from: s */
    private final int f2719s;

    /* renamed from: t */
    private final int f2720t;

    /* renamed from: u */
    private int f2721u = 0;

    /* renamed from: v */
    private int f2722v = 0;

    /* renamed from: w */
    private C0805ay f2723w;

    /* renamed from: x */
    private boolean f2724x = false;

    /* renamed from: y */
    private boolean f2725y = false;

    /* renamed from: z */
    private int f2726z = 0;

    /* renamed from: android.support.v7.widget.an$a */
    private class C0775a extends AnimatorListenerAdapter {

        /* renamed from: b */
        private boolean f2730b = false;

        C0775a() {
        }

        public void onAnimationCancel(Animator animator) {
            this.f2730b = true;
        }

        public void onAnimationEnd(Animator animator) {
            if (this.f2730b) {
                this.f2730b = false;
            } else if (((Float) C0772an.this.f2711i.getAnimatedValue()).floatValue() == 0.0f) {
                C0772an.this.f2712j = 0;
                C0772an.this.mo3690a(0);
            } else {
                C0772an.this.f2712j = 2;
                C0772an.this.mo3689a();
            }
        }
    }

    /* renamed from: android.support.v7.widget.an$b */
    private class C0776b implements AnimatorUpdateListener {
        C0776b() {
        }

        public void onAnimationUpdate(ValueAnimator valueAnimator) {
            int floatValue = (int) (255.0f * ((Float) valueAnimator.getAnimatedValue()).floatValue());
            C0772an.this.f2703a.setAlpha(floatValue);
            C0772an.this.f2704b.setAlpha(floatValue);
            C0772an.this.mo3689a();
        }
    }

    C0772an(C0805ay ayVar, StateListDrawable stateListDrawable, Drawable drawable, StateListDrawable stateListDrawable2, Drawable drawable2, int i, int i2, int i3) {
        this.f2703a = stateListDrawable;
        this.f2704b = drawable;
        this.f2717q = stateListDrawable2;
        this.f2718r = drawable2;
        this.f2715o = Math.max(i, stateListDrawable.getIntrinsicWidth());
        this.f2716p = Math.max(i, drawable.getIntrinsicWidth());
        this.f2719s = Math.max(i, stateListDrawable2.getIntrinsicWidth());
        this.f2720t = Math.max(i, drawable2.getIntrinsicWidth());
        this.f2713m = i2;
        this.f2714n = i3;
        this.f2703a.setAlpha(255);
        this.f2704b.setAlpha(255);
        this.f2711i.addListener(new C0775a());
        this.f2711i.addUpdateListener(new C0776b());
        mo3693a(ayVar);
    }

    /* renamed from: a */
    private int m3857a(float f, float f2, int[] iArr, int i, int i2, int i3) {
        int i4 = iArr[1] - iArr[0];
        if (i4 == 0) {
            return 0;
        }
        int i5 = i - i3;
        int i6 = (int) (((f2 - f) / ((float) i4)) * ((float) i5));
        int i7 = i2 + i6;
        if (i7 >= i5 || i7 < 0) {
            return 0;
        }
        return i6;
    }

    /* renamed from: a */
    private void m3858a(float f) {
        int[] g = m3867g();
        float max = Math.max((float) g[0], Math.min((float) g[1], f));
        if (Math.abs(((float) this.f2706d) - max) >= 2.0f) {
            int a = m3857a(this.f2707e, max, g, this.f2723w.computeVerticalScrollRange(), this.f2723w.computeVerticalScrollOffset(), this.f2722v);
            if (a != 0) {
                this.f2723w.scrollBy(0, a);
            }
            this.f2707e = max;
        }
    }

    /* renamed from: a */
    private void m3859a(Canvas canvas) {
        int i = this.f2721u - this.f2715o;
        int i2 = this.f2706d - (this.f2705c / 2);
        this.f2703a.setBounds(0, 0, this.f2715o, this.f2705c);
        this.f2704b.setBounds(0, 0, this.f2716p, this.f2722v);
        if (m3865e()) {
            this.f2704b.draw(canvas);
            canvas.translate((float) this.f2715o, (float) i2);
            canvas.scale(-1.0f, 1.0f);
            this.f2703a.draw(canvas);
            canvas.scale(1.0f, 1.0f);
            i = this.f2715o;
        } else {
            canvas.translate((float) i, 0.0f);
            this.f2704b.draw(canvas);
            canvas.translate(0.0f, (float) i2);
            this.f2703a.draw(canvas);
        }
        canvas.translate((float) (-i), (float) (-i2));
    }

    /* renamed from: b */
    private void m3860b(float f) {
        int[] h = m3868h();
        float max = Math.max((float) h[0], Math.min((float) h[1], f));
        if (Math.abs(((float) this.f2709g) - max) >= 2.0f) {
            int a = m3857a(this.f2710h, max, h, this.f2723w.computeHorizontalScrollRange(), this.f2723w.computeHorizontalScrollOffset(), this.f2721u);
            if (a != 0) {
                this.f2723w.scrollBy(a, 0);
            }
            this.f2710h = max;
        }
    }

    /* renamed from: b */
    private void m3861b(Canvas canvas) {
        int i = this.f2722v - this.f2719s;
        int i2 = this.f2709g - (this.f2708f / 2);
        this.f2717q.setBounds(0, 0, this.f2708f, this.f2719s);
        this.f2718r.setBounds(0, 0, this.f2721u, this.f2720t);
        canvas.translate(0.0f, (float) i);
        this.f2718r.draw(canvas);
        canvas.translate((float) i2, 0.0f);
        this.f2717q.draw(canvas);
        canvas.translate((float) (-i2), (float) (-i));
    }

    /* renamed from: c */
    private void m3862c() {
        this.f2723w.mo3842a((C0822h) this);
        this.f2723w.mo3844a((C0831m) this);
        this.f2723w.mo3845a(this.f2702E);
    }

    /* renamed from: c */
    private void m3863c(int i) {
        m3866f();
        this.f2723w.postDelayed(this.f2701D, (long) i);
    }

    /* renamed from: d */
    private void m3864d() {
        this.f2723w.mo3861b((C0822h) this);
        this.f2723w.mo3862b((C0831m) this);
        this.f2723w.mo3863b(this.f2702E);
        m3866f();
    }

    /* renamed from: e */
    private boolean m3865e() {
        return C0495r.m2149f(this.f2723w) == 1;
    }

    /* renamed from: f */
    private void m3866f() {
        this.f2723w.removeCallbacks(this.f2701D);
    }

    /* renamed from: g */
    private int[] m3867g() {
        this.f2699B[0] = this.f2714n;
        this.f2699B[1] = this.f2722v - this.f2714n;
        return this.f2699B;
    }

    /* renamed from: h */
    private int[] m3868h() {
        this.f2700C[0] = this.f2714n;
        this.f2700C[1] = this.f2721u - this.f2714n;
        return this.f2700C;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo3689a() {
        this.f2723w.invalidate();
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo3690a(int i) {
        int i2;
        if (i == 2 && this.f2726z != 2) {
            this.f2703a.setState(f2696k);
            m3866f();
        }
        if (i == 0) {
            mo3689a();
        } else {
            mo3697b();
        }
        if (this.f2726z != 2 || i == 2) {
            if (i == 1) {
                i2 = 1500;
            }
            this.f2726z = i;
        }
        this.f2703a.setState(f2697l);
        i2 = 1200;
        m3863c(i2);
        this.f2726z = i;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo3691a(int i, int i2) {
        int computeVerticalScrollRange = this.f2723w.computeVerticalScrollRange();
        int i3 = this.f2722v;
        this.f2724x = computeVerticalScrollRange - i3 > 0 && this.f2722v >= this.f2713m;
        int computeHorizontalScrollRange = this.f2723w.computeHorizontalScrollRange();
        int i4 = this.f2721u;
        this.f2725y = computeHorizontalScrollRange - i4 > 0 && this.f2721u >= this.f2713m;
        if (this.f2724x || this.f2725y) {
            if (this.f2724x) {
                float f = (float) i3;
                this.f2706d = (int) ((f * (((float) i2) + (f / 2.0f))) / ((float) computeVerticalScrollRange));
                this.f2705c = Math.min(i3, (i3 * i3) / computeVerticalScrollRange);
            }
            if (this.f2725y) {
                float f2 = (float) i4;
                this.f2709g = (int) ((f2 * (((float) i) + (f2 / 2.0f))) / ((float) computeHorizontalScrollRange));
                this.f2708f = Math.min(i4, (i4 * i4) / computeHorizontalScrollRange);
            }
            if (this.f2726z == 0 || this.f2726z == 1) {
                mo3690a(1);
            }
            return;
        }
        if (this.f2726z != 0) {
            mo3690a(0);
        }
    }

    /* renamed from: a */
    public void mo3692a(Canvas canvas, C0805ay ayVar, C0843u uVar) {
        if (this.f2721u == this.f2723w.getWidth() && this.f2722v == this.f2723w.getHeight()) {
            if (this.f2712j != 0) {
                if (this.f2724x) {
                    m3859a(canvas);
                }
                if (this.f2725y) {
                    m3861b(canvas);
                }
            }
            return;
        }
        this.f2721u = this.f2723w.getWidth();
        this.f2722v = this.f2723w.getHeight();
        mo3690a(0);
    }

    /* renamed from: a */
    public void mo3693a(C0805ay ayVar) {
        if (this.f2723w != ayVar) {
            if (this.f2723w != null) {
                m3864d();
            }
            this.f2723w = ayVar;
            if (this.f2723w != null) {
                m3862c();
            }
        }
    }

    /* renamed from: a */
    public void mo3694a(boolean z) {
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public boolean mo3695a(float f, float f2) {
        if (!m3865e() ? f >= ((float) (this.f2721u - this.f2715o)) : f <= ((float) (this.f2715o / 2))) {
            if (f2 >= ((float) (this.f2706d - (this.f2705c / 2))) && f2 <= ((float) (this.f2706d + (this.f2705c / 2)))) {
                return true;
            }
        }
        return false;
    }

    /* renamed from: a */
    public boolean mo3696a(C0805ay ayVar, MotionEvent motionEvent) {
        if (this.f2726z == 1) {
            boolean a = mo3695a(motionEvent.getX(), motionEvent.getY());
            boolean b = mo3700b(motionEvent.getX(), motionEvent.getY());
            if (motionEvent.getAction() != 0) {
                return false;
            }
            if (!a && !b) {
                return false;
            }
            if (b) {
                this.f2698A = 1;
                this.f2710h = (float) ((int) motionEvent.getX());
            } else if (a) {
                this.f2698A = 2;
                this.f2707e = (float) ((int) motionEvent.getY());
            }
            mo3690a(2);
        } else if (this.f2726z != 2) {
            return false;
        }
        return true;
    }

    /* renamed from: b */
    public void mo3697b() {
        int i = this.f2712j;
        if (i != 0) {
            if (i == 3) {
                this.f2711i.cancel();
            } else {
                return;
            }
        }
        this.f2712j = 1;
        this.f2711i.setFloatValues(new float[]{((Float) this.f2711i.getAnimatedValue()).floatValue(), 1.0f});
        this.f2711i.setDuration(500);
        this.f2711i.setStartDelay(0);
        this.f2711i.start();
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: b */
    public void mo3698b(int i) {
        switch (this.f2712j) {
            case 1:
                this.f2711i.cancel();
                break;
            case 2:
                break;
            default:
                return;
        }
        this.f2712j = 3;
        this.f2711i.setFloatValues(new float[]{((Float) this.f2711i.getAnimatedValue()).floatValue(), 0.0f});
        this.f2711i.setDuration((long) i);
        this.f2711i.start();
    }

    /* renamed from: b */
    public void mo3699b(C0805ay ayVar, MotionEvent motionEvent) {
        if (this.f2726z != 0) {
            if (motionEvent.getAction() == 0) {
                boolean a = mo3695a(motionEvent.getX(), motionEvent.getY());
                boolean b = mo3700b(motionEvent.getX(), motionEvent.getY());
                if (a || b) {
                    if (b) {
                        this.f2698A = 1;
                        this.f2710h = (float) ((int) motionEvent.getX());
                    } else if (a) {
                        this.f2698A = 2;
                        this.f2707e = (float) ((int) motionEvent.getY());
                    }
                    mo3690a(2);
                }
            } else if (motionEvent.getAction() == 1 && this.f2726z == 2) {
                this.f2707e = 0.0f;
                this.f2710h = 0.0f;
                mo3690a(1);
                this.f2698A = 0;
            } else if (motionEvent.getAction() == 2 && this.f2726z == 2) {
                mo3697b();
                if (this.f2698A == 1) {
                    m3860b(motionEvent.getX());
                }
                if (this.f2698A == 2) {
                    m3858a(motionEvent.getY());
                }
            }
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: b */
    public boolean mo3700b(float f, float f2) {
        return f2 >= ((float) (this.f2722v - this.f2719s)) && f >= ((float) (this.f2709g - (this.f2708f / 2))) && f <= ((float) (this.f2709g + (this.f2708f / 2)));
    }
}
