package android.support.p031v7.widget;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.TimeInterpolator;
import android.animation.ValueAnimator;
import android.support.p018v4.p028h.C0495r;
import android.support.p031v7.widget.C0805ay.C0846x;
import android.view.View;
import android.view.ViewPropertyAnimator;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/* renamed from: android.support.v7.widget.ak */
public class C0757ak extends C0861bg {

    /* renamed from: i */
    private static TimeInterpolator f2627i;

    /* renamed from: a */
    ArrayList<ArrayList<C0846x>> f2628a = new ArrayList<>();

    /* renamed from: b */
    ArrayList<ArrayList<C0767b>> f2629b = new ArrayList<>();

    /* renamed from: c */
    ArrayList<ArrayList<C0766a>> f2630c = new ArrayList<>();

    /* renamed from: d */
    ArrayList<C0846x> f2631d = new ArrayList<>();

    /* renamed from: e */
    ArrayList<C0846x> f2632e = new ArrayList<>();

    /* renamed from: f */
    ArrayList<C0846x> f2633f = new ArrayList<>();

    /* renamed from: g */
    ArrayList<C0846x> f2634g = new ArrayList<>();

    /* renamed from: j */
    private ArrayList<C0846x> f2635j = new ArrayList<>();

    /* renamed from: k */
    private ArrayList<C0846x> f2636k = new ArrayList<>();

    /* renamed from: l */
    private ArrayList<C0767b> f2637l = new ArrayList<>();

    /* renamed from: m */
    private ArrayList<C0766a> f2638m = new ArrayList<>();

    /* renamed from: android.support.v7.widget.ak$a */
    private static class C0766a {

        /* renamed from: a */
        public C0846x f2667a;

        /* renamed from: b */
        public C0846x f2668b;

        /* renamed from: c */
        public int f2669c;

        /* renamed from: d */
        public int f2670d;

        /* renamed from: e */
        public int f2671e;

        /* renamed from: f */
        public int f2672f;

        private C0766a(C0846x xVar, C0846x xVar2) {
            this.f2667a = xVar;
            this.f2668b = xVar2;
        }

        C0766a(C0846x xVar, C0846x xVar2, int i, int i2, int i3, int i4) {
            this(xVar, xVar2);
            this.f2669c = i;
            this.f2670d = i2;
            this.f2671e = i3;
            this.f2672f = i4;
        }

        public String toString() {
            StringBuilder sb = new StringBuilder();
            sb.append("ChangeInfo{oldHolder=");
            sb.append(this.f2667a);
            sb.append(", newHolder=");
            sb.append(this.f2668b);
            sb.append(", fromX=");
            sb.append(this.f2669c);
            sb.append(", fromY=");
            sb.append(this.f2670d);
            sb.append(", toX=");
            sb.append(this.f2671e);
            sb.append(", toY=");
            sb.append(this.f2672f);
            sb.append('}');
            return sb.toString();
        }
    }

    /* renamed from: android.support.v7.widget.ak$b */
    private static class C0767b {

        /* renamed from: a */
        public C0846x f2673a;

        /* renamed from: b */
        public int f2674b;

        /* renamed from: c */
        public int f2675c;

        /* renamed from: d */
        public int f2676d;

        /* renamed from: e */
        public int f2677e;

        C0767b(C0846x xVar, int i, int i2, int i3, int i4) {
            this.f2673a = xVar;
            this.f2674b = i;
            this.f2675c = i2;
            this.f2676d = i3;
            this.f2677e = i4;
        }
    }

    /* renamed from: a */
    private void m3820a(List<C0766a> list, C0846x xVar) {
        for (int size = list.size() - 1; size >= 0; size--) {
            C0766a aVar = (C0766a) list.get(size);
            if (m3821a(aVar, xVar) && aVar.f2667a == null && aVar.f2668b == null) {
                list.remove(aVar);
            }
        }
    }

    /* renamed from: a */
    private boolean m3821a(C0766a aVar, C0846x xVar) {
        boolean z = false;
        if (aVar.f2668b == xVar) {
            aVar.f2668b = null;
        } else if (aVar.f2667a != xVar) {
            return false;
        } else {
            aVar.f2667a = null;
            z = true;
        }
        xVar.f3023a.setAlpha(1.0f);
        xVar.f3023a.setTranslationX(0.0f);
        xVar.f3023a.setTranslationY(0.0f);
        mo4394a(xVar, z);
        return true;
    }

    /* renamed from: b */
    private void m3822b(C0766a aVar) {
        if (aVar.f2667a != null) {
            m3821a(aVar, aVar.f2667a);
        }
        if (aVar.f2668b != null) {
            m3821a(aVar, aVar.f2668b);
        }
    }

    /* renamed from: u */
    private void m3823u(final C0846x xVar) {
        final View view = xVar.f3023a;
        final ViewPropertyAnimator animate = view.animate();
        this.f2633f.add(xVar);
        animate.setDuration(mo4036g()).alpha(0.0f).setListener(new AnimatorListenerAdapter() {
            public void onAnimationEnd(Animator animator) {
                animate.setListener(null);
                view.setAlpha(1.0f);
                C0757ak.this.mo4398i(xVar);
                C0757ak.this.f2633f.remove(xVar);
                C0757ak.this.mo3652c();
            }

            public void onAnimationStart(Animator animator) {
                C0757ak.this.mo4401l(xVar);
            }
        }).start();
    }

    /* renamed from: v */
    private void m3824v(C0846x xVar) {
        if (f2627i == null) {
            f2627i = new ValueAnimator().getInterpolator();
        }
        xVar.f3023a.animate().setInterpolator(f2627i);
        mo3655d(xVar);
    }

    /* renamed from: a */
    public void mo3642a() {
        boolean z = !this.f2635j.isEmpty();
        boolean z2 = !this.f2637l.isEmpty();
        boolean z3 = !this.f2638m.isEmpty();
        boolean z4 = !this.f2636k.isEmpty();
        if (z || z2 || z4 || z3) {
            Iterator it = this.f2635j.iterator();
            while (it.hasNext()) {
                m3823u((C0846x) it.next());
            }
            this.f2635j.clear();
            if (z2) {
                final ArrayList arrayList = new ArrayList();
                arrayList.addAll(this.f2637l);
                this.f2629b.add(arrayList);
                this.f2637l.clear();
                C07581 r6 = new Runnable() {
                    public void run() {
                        Iterator it = arrayList.iterator();
                        while (it.hasNext()) {
                            C0767b bVar = (C0767b) it.next();
                            C0757ak.this.mo3649b(bVar.f2673a, bVar.f2674b, bVar.f2675c, bVar.f2676d, bVar.f2677e);
                        }
                        arrayList.clear();
                        C0757ak.this.f2629b.remove(arrayList);
                    }
                };
                if (z) {
                    C0495r.m2135a(((C0767b) arrayList.get(0)).f2673a.f3023a, (Runnable) r6, mo4036g());
                } else {
                    r6.run();
                }
            }
            if (z3) {
                final ArrayList arrayList2 = new ArrayList();
                arrayList2.addAll(this.f2638m);
                this.f2630c.add(arrayList2);
                this.f2638m.clear();
                C07592 r62 = new Runnable() {
                    public void run() {
                        Iterator it = arrayList2.iterator();
                        while (it.hasNext()) {
                            C0757ak.this.mo3643a((C0766a) it.next());
                        }
                        arrayList2.clear();
                        C0757ak.this.f2630c.remove(arrayList2);
                    }
                };
                if (z) {
                    C0495r.m2135a(((C0766a) arrayList2.get(0)).f2667a.f3023a, (Runnable) r62, mo4036g());
                } else {
                    r62.run();
                }
            }
            if (z4) {
                final ArrayList arrayList3 = new ArrayList();
                arrayList3.addAll(this.f2636k);
                this.f2628a.add(arrayList3);
                this.f2636k.clear();
                C07603 r5 = new Runnable() {
                    public void run() {
                        Iterator it = arrayList3.iterator();
                        while (it.hasNext()) {
                            C0757ak.this.mo3653c((C0846x) it.next());
                        }
                        arrayList3.clear();
                        C0757ak.this.f2628a.remove(arrayList3);
                    }
                };
                if (z || z2 || z3) {
                    long j = 0;
                    long g = z ? mo4036g() : 0;
                    long e = z2 ? mo4033e() : 0;
                    if (z3) {
                        j = mo4038h();
                    }
                    C0495r.m2135a(((C0846x) arrayList3.get(0)).f3023a, (Runnable) r5, g + Math.max(e, j));
                } else {
                    r5.run();
                }
            }
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo3643a(final C0766a aVar) {
        C0846x xVar = aVar.f2667a;
        final View view = null;
        final View view2 = xVar == null ? null : xVar.f3023a;
        C0846x xVar2 = aVar.f2668b;
        if (xVar2 != null) {
            view = xVar2.f3023a;
        }
        if (view2 != null) {
            final ViewPropertyAnimator duration = view2.animate().setDuration(mo4038h());
            this.f2634g.add(aVar.f2667a);
            duration.translationX((float) (aVar.f2671e - aVar.f2669c));
            duration.translationY((float) (aVar.f2672f - aVar.f2670d));
            duration.alpha(0.0f).setListener(new AnimatorListenerAdapter() {
                public void onAnimationEnd(Animator animator) {
                    duration.setListener(null);
                    view2.setAlpha(1.0f);
                    view2.setTranslationX(0.0f);
                    view2.setTranslationY(0.0f);
                    C0757ak.this.mo4394a(aVar.f2667a, true);
                    C0757ak.this.f2634g.remove(aVar.f2667a);
                    C0757ak.this.mo3652c();
                }

                public void onAnimationStart(Animator animator) {
                    C0757ak.this.mo4395b(aVar.f2667a, true);
                }
            }).start();
        }
        if (view != null) {
            final ViewPropertyAnimator animate = view.animate();
            this.f2634g.add(aVar.f2668b);
            animate.translationX(0.0f).translationY(0.0f).setDuration(mo4038h()).alpha(1.0f).setListener(new AnimatorListenerAdapter() {
                public void onAnimationEnd(Animator animator) {
                    animate.setListener(null);
                    view.setAlpha(1.0f);
                    view.setTranslationX(0.0f);
                    view.setTranslationY(0.0f);
                    C0757ak.this.mo4394a(aVar.f2668b, false);
                    C0757ak.this.f2634g.remove(aVar.f2668b);
                    C0757ak.this.mo3652c();
                }

                public void onAnimationStart(Animator animator) {
                    C0757ak.this.mo4395b(aVar.f2668b, false);
                }
            }).start();
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo3644a(List<C0846x> list) {
        for (int size = list.size() - 1; size >= 0; size--) {
            ((C0846x) list.get(size)).f3023a.animate().cancel();
        }
    }

    /* renamed from: a */
    public boolean mo3645a(C0846x xVar) {
        m3824v(xVar);
        this.f2635j.add(xVar);
        return true;
    }

    /* renamed from: a */
    public boolean mo3646a(C0846x xVar, int i, int i2, int i3, int i4) {
        View view = xVar.f3023a;
        int translationX = i + ((int) xVar.f3023a.getTranslationX());
        int translationY = i2 + ((int) xVar.f3023a.getTranslationY());
        m3824v(xVar);
        int i5 = i3 - translationX;
        int i6 = i4 - translationY;
        if (i5 == 0 && i6 == 0) {
            mo4399j(xVar);
            return false;
        }
        if (i5 != 0) {
            view.setTranslationX((float) (-i5));
        }
        if (i6 != 0) {
            view.setTranslationY((float) (-i6));
        }
        ArrayList<C0767b> arrayList = this.f2637l;
        C0767b bVar = new C0767b(xVar, translationX, translationY, i3, i4);
        arrayList.add(bVar);
        return true;
    }

    /* renamed from: a */
    public boolean mo3647a(C0846x xVar, C0846x xVar2, int i, int i2, int i3, int i4) {
        if (xVar == xVar2) {
            return mo3646a(xVar, i, i2, i3, i4);
        }
        float translationX = xVar.f3023a.getTranslationX();
        float translationY = xVar.f3023a.getTranslationY();
        float alpha = xVar.f3023a.getAlpha();
        m3824v(xVar);
        int i5 = (int) (((float) (i3 - i)) - translationX);
        int i6 = (int) (((float) (i4 - i2)) - translationY);
        xVar.f3023a.setTranslationX(translationX);
        xVar.f3023a.setTranslationY(translationY);
        xVar.f3023a.setAlpha(alpha);
        if (xVar2 != null) {
            m3824v(xVar2);
            xVar2.f3023a.setTranslationX((float) (-i5));
            xVar2.f3023a.setTranslationY((float) (-i6));
            xVar2.f3023a.setAlpha(0.0f);
        }
        ArrayList<C0766a> arrayList = this.f2638m;
        C0766a aVar = new C0766a(xVar, xVar2, i, i2, i3, i4);
        arrayList.add(aVar);
        return true;
    }

    /* renamed from: a */
    public boolean mo3648a(C0846x xVar, List<Object> list) {
        return !list.isEmpty() || super.mo3648a(xVar, list);
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: b */
    public void mo3649b(C0846x xVar, int i, int i2, int i3, int i4) {
        final View view = xVar.f3023a;
        final int i5 = i3 - i;
        final int i6 = i4 - i2;
        if (i5 != 0) {
            view.animate().translationX(0.0f);
        }
        if (i6 != 0) {
            view.animate().translationY(0.0f);
        }
        final ViewPropertyAnimator animate = view.animate();
        this.f2632e.add(xVar);
        ViewPropertyAnimator duration = animate.setDuration(mo4033e());
        final C0846x xVar2 = xVar;
        C07636 r0 = new AnimatorListenerAdapter() {
            public void onAnimationCancel(Animator animator) {
                if (i5 != 0) {
                    view.setTranslationX(0.0f);
                }
                if (i6 != 0) {
                    view.setTranslationY(0.0f);
                }
            }

            public void onAnimationEnd(Animator animator) {
                animate.setListener(null);
                C0757ak.this.mo4399j(xVar2);
                C0757ak.this.f2632e.remove(xVar2);
                C0757ak.this.mo3652c();
            }

            public void onAnimationStart(Animator animator) {
                C0757ak.this.mo4402m(xVar2);
            }
        };
        duration.setListener(r0).start();
    }

    /* renamed from: b */
    public boolean mo3650b() {
        return !this.f2636k.isEmpty() || !this.f2638m.isEmpty() || !this.f2637l.isEmpty() || !this.f2635j.isEmpty() || !this.f2632e.isEmpty() || !this.f2633f.isEmpty() || !this.f2631d.isEmpty() || !this.f2634g.isEmpty() || !this.f2629b.isEmpty() || !this.f2628a.isEmpty() || !this.f2630c.isEmpty();
    }

    /* renamed from: b */
    public boolean mo3651b(C0846x xVar) {
        m3824v(xVar);
        xVar.f3023a.setAlpha(0.0f);
        this.f2636k.add(xVar);
        return true;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: c */
    public void mo3652c() {
        if (!mo3650b()) {
            mo4040i();
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: c */
    public void mo3653c(final C0846x xVar) {
        final View view = xVar.f3023a;
        final ViewPropertyAnimator animate = view.animate();
        this.f2631d.add(xVar);
        animate.alpha(1.0f).setDuration(mo4034f()).setListener(new AnimatorListenerAdapter() {
            public void onAnimationCancel(Animator animator) {
                view.setAlpha(1.0f);
            }

            public void onAnimationEnd(Animator animator) {
                animate.setListener(null);
                C0757ak.this.mo4400k(xVar);
                C0757ak.this.f2631d.remove(xVar);
                C0757ak.this.mo3652c();
            }

            public void onAnimationStart(Animator animator) {
                C0757ak.this.mo4403n(xVar);
            }
        }).start();
    }

    /* renamed from: d */
    public void mo3654d() {
        int size = this.f2637l.size();
        while (true) {
            size--;
            if (size < 0) {
                break;
            }
            C0767b bVar = (C0767b) this.f2637l.get(size);
            View view = bVar.f2673a.f3023a;
            view.setTranslationY(0.0f);
            view.setTranslationX(0.0f);
            mo4399j(bVar.f2673a);
            this.f2637l.remove(size);
        }
        for (int size2 = this.f2635j.size() - 1; size2 >= 0; size2--) {
            mo4398i((C0846x) this.f2635j.get(size2));
            this.f2635j.remove(size2);
        }
        int size3 = this.f2636k.size();
        while (true) {
            size3--;
            if (size3 < 0) {
                break;
            }
            C0846x xVar = (C0846x) this.f2636k.get(size3);
            xVar.f3023a.setAlpha(1.0f);
            mo4400k(xVar);
            this.f2636k.remove(size3);
        }
        for (int size4 = this.f2638m.size() - 1; size4 >= 0; size4--) {
            m3822b((C0766a) this.f2638m.get(size4));
        }
        this.f2638m.clear();
        if (mo3650b()) {
            for (int size5 = this.f2629b.size() - 1; size5 >= 0; size5--) {
                ArrayList arrayList = (ArrayList) this.f2629b.get(size5);
                for (int size6 = arrayList.size() - 1; size6 >= 0; size6--) {
                    C0767b bVar2 = (C0767b) arrayList.get(size6);
                    View view2 = bVar2.f2673a.f3023a;
                    view2.setTranslationY(0.0f);
                    view2.setTranslationX(0.0f);
                    mo4399j(bVar2.f2673a);
                    arrayList.remove(size6);
                    if (arrayList.isEmpty()) {
                        this.f2629b.remove(arrayList);
                    }
                }
            }
            for (int size7 = this.f2628a.size() - 1; size7 >= 0; size7--) {
                ArrayList arrayList2 = (ArrayList) this.f2628a.get(size7);
                for (int size8 = arrayList2.size() - 1; size8 >= 0; size8--) {
                    C0846x xVar2 = (C0846x) arrayList2.get(size8);
                    xVar2.f3023a.setAlpha(1.0f);
                    mo4400k(xVar2);
                    arrayList2.remove(size8);
                    if (arrayList2.isEmpty()) {
                        this.f2628a.remove(arrayList2);
                    }
                }
            }
            for (int size9 = this.f2630c.size() - 1; size9 >= 0; size9--) {
                ArrayList arrayList3 = (ArrayList) this.f2630c.get(size9);
                for (int size10 = arrayList3.size() - 1; size10 >= 0; size10--) {
                    m3822b((C0766a) arrayList3.get(size10));
                    if (arrayList3.isEmpty()) {
                        this.f2630c.remove(arrayList3);
                    }
                }
            }
            mo3644a((List<C0846x>) this.f2633f);
            mo3644a((List<C0846x>) this.f2632e);
            mo3644a((List<C0846x>) this.f2631d);
            mo3644a((List<C0846x>) this.f2634g);
            mo4040i();
        }
    }

    /* renamed from: d */
    public void mo3655d(C0846x xVar) {
        View view = xVar.f3023a;
        view.animate().cancel();
        int size = this.f2637l.size();
        while (true) {
            size--;
            if (size < 0) {
                break;
            } else if (((C0767b) this.f2637l.get(size)).f2673a == xVar) {
                view.setTranslationY(0.0f);
                view.setTranslationX(0.0f);
                mo4399j(xVar);
                this.f2637l.remove(size);
            }
        }
        m3820a((List<C0766a>) this.f2638m, xVar);
        if (this.f2635j.remove(xVar)) {
            view.setAlpha(1.0f);
            mo4398i(xVar);
        }
        if (this.f2636k.remove(xVar)) {
            view.setAlpha(1.0f);
            mo4400k(xVar);
        }
        for (int size2 = this.f2630c.size() - 1; size2 >= 0; size2--) {
            ArrayList arrayList = (ArrayList) this.f2630c.get(size2);
            m3820a((List<C0766a>) arrayList, xVar);
            if (arrayList.isEmpty()) {
                this.f2630c.remove(size2);
            }
        }
        for (int size3 = this.f2629b.size() - 1; size3 >= 0; size3--) {
            ArrayList arrayList2 = (ArrayList) this.f2629b.get(size3);
            int size4 = arrayList2.size() - 1;
            while (true) {
                if (size4 < 0) {
                    break;
                } else if (((C0767b) arrayList2.get(size4)).f2673a == xVar) {
                    view.setTranslationY(0.0f);
                    view.setTranslationX(0.0f);
                    mo4399j(xVar);
                    arrayList2.remove(size4);
                    if (arrayList2.isEmpty()) {
                        this.f2629b.remove(size3);
                    }
                } else {
                    size4--;
                }
            }
        }
        for (int size5 = this.f2628a.size() - 1; size5 >= 0; size5--) {
            ArrayList arrayList3 = (ArrayList) this.f2628a.get(size5);
            if (arrayList3.remove(xVar)) {
                view.setAlpha(1.0f);
                mo4400k(xVar);
                if (arrayList3.isEmpty()) {
                    this.f2628a.remove(size5);
                }
            }
        }
        this.f2633f.remove(xVar);
        this.f2631d.remove(xVar);
        this.f2634g.remove(xVar);
        this.f2632e.remove(xVar);
        mo3652c();
    }
}
