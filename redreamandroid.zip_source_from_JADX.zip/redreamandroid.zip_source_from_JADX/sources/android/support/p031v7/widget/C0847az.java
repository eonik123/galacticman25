package android.support.p031v7.widget;

import android.os.Bundle;
import android.support.p018v4.p028h.C0471b;
import android.support.p018v4.p028h.p029a.C0464c;
import android.view.View;
import android.view.accessibility.AccessibilityEvent;

/* renamed from: android.support.v7.widget.az */
public class C0847az extends C0471b {

    /* renamed from: a */
    final C0805ay f3041a;

    /* renamed from: b */
    final C0471b f3042b = new C0848a(this);

    /* renamed from: android.support.v7.widget.az$a */
    public static class C0848a extends C0471b {

        /* renamed from: a */
        final C0847az f3043a;

        public C0848a(C0847az azVar) {
            this.f3043a = azVar;
        }

        /* renamed from: a */
        public void mo650a(View view, C0464c cVar) {
            super.mo650a(view, cVar);
            if (!this.f3043a.mo4276b() && this.f3043a.f3041a.getLayoutManager() != null) {
                this.f3043a.f3041a.getLayoutManager().mo4075a(view, cVar);
            }
        }

        /* renamed from: a */
        public boolean mo1899a(View view, int i, Bundle bundle) {
            if (super.mo1899a(view, i, bundle)) {
                return true;
            }
            if (this.f3043a.mo4276b() || this.f3043a.f3041a.getLayoutManager() == null) {
                return false;
            }
            return this.f3043a.f3041a.getLayoutManager().mo4087a(view, i, bundle);
        }
    }

    public C0847az(C0805ay ayVar) {
        this.f3041a = ayVar;
    }

    /* renamed from: a */
    public void mo650a(View view, C0464c cVar) {
        super.mo650a(view, cVar);
        cVar.mo1859a((CharSequence) C0805ay.class.getName());
        if (!mo4276b() && this.f3041a.getLayoutManager() != null) {
            this.f3041a.getLayoutManager().mo4062a(cVar);
        }
    }

    /* renamed from: a */
    public void mo820a(View view, AccessibilityEvent accessibilityEvent) {
        super.mo820a(view, accessibilityEvent);
        accessibilityEvent.setClassName(C0805ay.class.getName());
        if ((view instanceof C0805ay) && !mo4276b()) {
            C0805ay ayVar = (C0805ay) view;
            if (ayVar.getLayoutManager() != null) {
                ayVar.getLayoutManager().mo3197a(accessibilityEvent);
            }
        }
    }

    /* renamed from: a */
    public boolean mo1899a(View view, int i, Bundle bundle) {
        if (super.mo1899a(view, i, bundle)) {
            return true;
        }
        if (mo4276b() || this.f3041a.getLayoutManager() == null) {
            return false;
        }
        return this.f3041a.getLayoutManager().mo4078a(i, bundle);
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: b */
    public boolean mo4276b() {
        return this.f3041a.mo3988v();
    }

    /* renamed from: c */
    public C0471b mo4277c() {
        return this.f3042b;
    }
}
