package android.support.p031v7.widget;

import android.support.p031v7.view.menu.C0655h;
import android.view.MenuItem;

/* renamed from: android.support.v7.widget.au */
public interface C0797au {
    /* renamed from: a */
    void mo2673a(C0655h hVar, MenuItem menuItem);

    /* renamed from: b */
    void mo2674b(C0655h hVar, MenuItem menuItem);
}
