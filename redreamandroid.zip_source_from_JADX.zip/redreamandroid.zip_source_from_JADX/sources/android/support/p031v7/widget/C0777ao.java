package android.support.p031v7.widget;

import android.graphics.Rect;

/* renamed from: android.support.v7.widget.ao */
public interface C0777ao {

    /* renamed from: android.support.v7.widget.ao$a */
    public interface C0778a {
        /* renamed from: a */
        void mo2292a(Rect rect);
    }

    void setOnFitSystemWindowsListener(C0778a aVar);
}
