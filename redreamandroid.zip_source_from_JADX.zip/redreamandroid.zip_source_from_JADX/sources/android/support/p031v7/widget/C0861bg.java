package android.support.p031v7.widget;

import android.support.p031v7.widget.C0805ay.C0817f;
import android.support.p031v7.widget.C0805ay.C0817f.C0820c;
import android.support.p031v7.widget.C0805ay.C0846x;
import android.view.View;

/* renamed from: android.support.v7.widget.bg */
public abstract class C0861bg extends C0817f {

    /* renamed from: h */
    boolean f3103h = true;

    /* renamed from: a */
    public final void mo4394a(C0846x xVar, boolean z) {
        mo4397d(xVar, z);
        mo4035f(xVar);
    }

    /* renamed from: a */
    public abstract boolean mo3645a(C0846x xVar);

    /* renamed from: a */
    public abstract boolean mo3646a(C0846x xVar, int i, int i2, int i3, int i4);

    /* renamed from: a */
    public boolean mo4029a(C0846x xVar, C0820c cVar, C0820c cVar2) {
        int i = cVar.f2934a;
        int i2 = cVar.f2935b;
        View view = xVar.f3023a;
        int left = cVar2 == null ? view.getLeft() : cVar2.f2934a;
        int top = cVar2 == null ? view.getTop() : cVar2.f2935b;
        if (xVar.mo4265q() || (i == left && i2 == top)) {
            return mo3645a(xVar);
        }
        view.layout(left, top, view.getWidth() + left, view.getHeight() + top);
        return mo3646a(xVar, i, i2, left, top);
    }

    /* renamed from: a */
    public abstract boolean mo3647a(C0846x xVar, C0846x xVar2, int i, int i2, int i3, int i4);

    /* renamed from: a */
    public boolean mo4030a(C0846x xVar, C0846x xVar2, C0820c cVar, C0820c cVar2) {
        int i;
        int i2;
        int i3 = cVar.f2934a;
        int i4 = cVar.f2935b;
        if (xVar2.mo4251c()) {
            int i5 = cVar.f2934a;
            i = cVar.f2935b;
            i2 = i5;
        } else {
            i2 = cVar2.f2934a;
            i = cVar2.f2935b;
        }
        return mo3647a(xVar, xVar2, i3, i4, i2, i);
    }

    /* renamed from: b */
    public final void mo4395b(C0846x xVar, boolean z) {
        mo4396c(xVar, z);
    }

    /* renamed from: b */
    public abstract boolean mo3651b(C0846x xVar);

    /* renamed from: b */
    public boolean mo4031b(C0846x xVar, C0820c cVar, C0820c cVar2) {
        if (cVar == null || (cVar.f2934a == cVar2.f2934a && cVar.f2935b == cVar2.f2935b)) {
            return mo3651b(xVar);
        }
        return mo3646a(xVar, cVar.f2934a, cVar.f2935b, cVar2.f2934a, cVar2.f2935b);
    }

    /* renamed from: c */
    public void mo4396c(C0846x xVar, boolean z) {
    }

    /* renamed from: c */
    public boolean mo4032c(C0846x xVar, C0820c cVar, C0820c cVar2) {
        if (cVar.f2934a == cVar2.f2934a && cVar.f2935b == cVar2.f2935b) {
            mo4399j(xVar);
            return false;
        }
        return mo3646a(xVar, cVar.f2934a, cVar.f2935b, cVar2.f2934a, cVar2.f2935b);
    }

    /* renamed from: d */
    public void mo4397d(C0846x xVar, boolean z) {
    }

    /* renamed from: h */
    public boolean mo4039h(C0846x xVar) {
        return !this.f3103h || xVar.mo4262n();
    }

    /* renamed from: i */
    public final void mo4398i(C0846x xVar) {
        mo4405p(xVar);
        mo4035f(xVar);
    }

    /* renamed from: j */
    public final void mo4399j(C0846x xVar) {
        mo4409t(xVar);
        mo4035f(xVar);
    }

    /* renamed from: k */
    public final void mo4400k(C0846x xVar) {
        mo4407r(xVar);
        mo4035f(xVar);
    }

    /* renamed from: l */
    public final void mo4401l(C0846x xVar) {
        mo4404o(xVar);
    }

    /* renamed from: m */
    public final void mo4402m(C0846x xVar) {
        mo4408s(xVar);
    }

    /* renamed from: n */
    public final void mo4403n(C0846x xVar) {
        mo4406q(xVar);
    }

    /* renamed from: o */
    public void mo4404o(C0846x xVar) {
    }

    /* renamed from: p */
    public void mo4405p(C0846x xVar) {
    }

    /* renamed from: q */
    public void mo4406q(C0846x xVar) {
    }

    /* renamed from: r */
    public void mo4407r(C0846x xVar) {
    }

    /* renamed from: s */
    public void mo4408s(C0846x xVar) {
    }

    /* renamed from: t */
    public void mo4409t(C0846x xVar) {
    }
}
