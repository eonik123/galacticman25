package android.support.p031v7.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.PorterDuff.Mode;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.support.p018v4.p028h.C0494q;
import android.support.p018v4.widget.C0534o;
import android.support.p031v7.p032a.C0540a.C0541a;
import android.util.AttributeSet;
import android.widget.ImageButton;

/* renamed from: android.support.v7.widget.n */
public class C0917n extends ImageButton implements C0494q, C0534o {

    /* renamed from: a */
    private final C0905g f3304a;

    /* renamed from: b */
    private final C0918o f3305b;

    public C0917n(Context context) {
        this(context, null);
    }

    public C0917n(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, C0541a.imageButtonStyle);
    }

    public C0917n(Context context, AttributeSet attributeSet, int i) {
        super(C0866bk.m4633a(context), attributeSet, i);
        this.f3304a = new C0905g(this);
        this.f3304a.mo4547a(attributeSet, i);
        this.f3305b = new C0918o(this);
        this.f3305b.mo4595a(attributeSet, i);
    }

    /* access modifiers changed from: protected */
    public void drawableStateChanged() {
        super.drawableStateChanged();
        if (this.f3304a != null) {
            this.f3304a.mo4550c();
        }
        if (this.f3305b != null) {
            this.f3305b.mo4599d();
        }
    }

    public ColorStateList getSupportBackgroundTintList() {
        if (this.f3304a != null) {
            return this.f3304a.mo4542a();
        }
        return null;
    }

    public Mode getSupportBackgroundTintMode() {
        if (this.f3304a != null) {
            return this.f3304a.mo4548b();
        }
        return null;
    }

    public ColorStateList getSupportImageTintList() {
        if (this.f3305b != null) {
            return this.f3305b.mo4597b();
        }
        return null;
    }

    public Mode getSupportImageTintMode() {
        if (this.f3305b != null) {
            return this.f3305b.mo4598c();
        }
        return null;
    }

    public boolean hasOverlappingRendering() {
        return this.f3305b.mo4596a() && super.hasOverlappingRendering();
    }

    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        if (this.f3304a != null) {
            this.f3304a.mo4546a(drawable);
        }
    }

    public void setBackgroundResource(int i) {
        super.setBackgroundResource(i);
        if (this.f3304a != null) {
            this.f3304a.mo4543a(i);
        }
    }

    public void setImageBitmap(Bitmap bitmap) {
        super.setImageBitmap(bitmap);
        if (this.f3305b != null) {
            this.f3305b.mo4599d();
        }
    }

    public void setImageDrawable(Drawable drawable) {
        super.setImageDrawable(drawable);
        if (this.f3305b != null) {
            this.f3305b.mo4599d();
        }
    }

    public void setImageResource(int i) {
        this.f3305b.mo4592a(i);
    }

    public void setImageURI(Uri uri) {
        super.setImageURI(uri);
        if (this.f3305b != null) {
            this.f3305b.mo4599d();
        }
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        if (this.f3304a != null) {
            this.f3304a.mo4544a(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(Mode mode) {
        if (this.f3304a != null) {
            this.f3304a.mo4545a(mode);
        }
    }

    public void setSupportImageTintList(ColorStateList colorStateList) {
        if (this.f3305b != null) {
            this.f3305b.mo4593a(colorStateList);
        }
    }

    public void setSupportImageTintMode(Mode mode) {
        if (this.f3305b != null) {
            this.f3305b.mo4594a(mode);
        }
    }
}
