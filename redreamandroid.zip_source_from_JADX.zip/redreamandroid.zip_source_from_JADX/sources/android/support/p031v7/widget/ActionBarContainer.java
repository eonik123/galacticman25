package android.support.p031v7.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.support.p018v4.p028h.C0495r;
import android.support.p031v7.p032a.C0540a.C0546f;
import android.support.p031v7.p032a.C0540a.C0550j;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.ActionMode.Callback;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.FrameLayout.LayoutParams;

/* renamed from: android.support.v7.widget.ActionBarContainer */
public class ActionBarContainer extends FrameLayout {

    /* renamed from: a */
    Drawable f2238a;

    /* renamed from: b */
    Drawable f2239b;

    /* renamed from: c */
    Drawable f2240c;

    /* renamed from: d */
    boolean f2241d;

    /* renamed from: e */
    boolean f2242e;

    /* renamed from: f */
    private boolean f2243f;

    /* renamed from: g */
    private View f2244g;

    /* renamed from: h */
    private View f2245h;

    /* renamed from: i */
    private View f2246i;

    /* renamed from: j */
    private int f2247j;

    public ActionBarContainer(Context context) {
        this(context, null);
    }

    public ActionBarContainer(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        C0495r.m2131a((View) this, (Drawable) new C0849b(this));
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, C0550j.ActionBar);
        this.f2238a = obtainStyledAttributes.getDrawable(C0550j.ActionBar_background);
        this.f2239b = obtainStyledAttributes.getDrawable(C0550j.ActionBar_backgroundStacked);
        this.f2247j = obtainStyledAttributes.getDimensionPixelSize(C0550j.ActionBar_height, -1);
        if (getId() == C0546f.split_action_bar) {
            this.f2241d = true;
            this.f2240c = obtainStyledAttributes.getDrawable(C0550j.ActionBar_backgroundSplit);
        }
        obtainStyledAttributes.recycle();
        boolean z = false;
        if (!this.f2241d ? this.f2238a == null && this.f2239b == null : this.f2240c == null) {
            z = true;
        }
        setWillNotDraw(z);
    }

    /* renamed from: a */
    private boolean m3165a(View view) {
        return view == null || view.getVisibility() == 8 || view.getMeasuredHeight() == 0;
    }

    /* renamed from: b */
    private int m3166b(View view) {
        LayoutParams layoutParams = (LayoutParams) view.getLayoutParams();
        return view.getMeasuredHeight() + layoutParams.topMargin + layoutParams.bottomMargin;
    }

    /* access modifiers changed from: protected */
    public void drawableStateChanged() {
        super.drawableStateChanged();
        if (this.f2238a != null && this.f2238a.isStateful()) {
            this.f2238a.setState(getDrawableState());
        }
        if (this.f2239b != null && this.f2239b.isStateful()) {
            this.f2239b.setState(getDrawableState());
        }
        if (this.f2240c != null && this.f2240c.isStateful()) {
            this.f2240c.setState(getDrawableState());
        }
    }

    public View getTabContainer() {
        return this.f2244g;
    }

    public void jumpDrawablesToCurrentState() {
        super.jumpDrawablesToCurrentState();
        if (this.f2238a != null) {
            this.f2238a.jumpToCurrentState();
        }
        if (this.f2239b != null) {
            this.f2239b.jumpToCurrentState();
        }
        if (this.f2240c != null) {
            this.f2240c.jumpToCurrentState();
        }
    }

    public void onFinishInflate() {
        super.onFinishInflate();
        this.f2245h = findViewById(C0546f.action_bar);
        this.f2246i = findViewById(C0546f.action_context_bar);
    }

    public boolean onHoverEvent(MotionEvent motionEvent) {
        super.onHoverEvent(motionEvent);
        return true;
    }

    public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        return this.f2243f || super.onInterceptTouchEvent(motionEvent);
    }

    /* JADX WARNING: Removed duplicated region for block: B:35:0x00c0  */
    /* JADX WARNING: Removed duplicated region for block: B:37:? A[RETURN, SYNTHETIC] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void onLayout(boolean r6, int r7, int r8, int r9, int r10) {
        /*
            r5 = this;
            super.onLayout(r6, r7, r8, r9, r10)
            android.view.View r6 = r5.f2244g
            r8 = 8
            r10 = 1
            r0 = 0
            if (r6 == 0) goto L_0x0013
            int r1 = r6.getVisibility()
            if (r1 == r8) goto L_0x0013
            r1 = r10
            goto L_0x0014
        L_0x0013:
            r1 = r0
        L_0x0014:
            if (r6 == 0) goto L_0x0035
            int r2 = r6.getVisibility()
            if (r2 == r8) goto L_0x0035
            int r8 = r5.getMeasuredHeight()
            android.view.ViewGroup$LayoutParams r2 = r6.getLayoutParams()
            android.widget.FrameLayout$LayoutParams r2 = (android.widget.FrameLayout.LayoutParams) r2
            int r3 = r6.getMeasuredHeight()
            int r3 = r8 - r3
            int r4 = r2.bottomMargin
            int r3 = r3 - r4
            int r2 = r2.bottomMargin
            int r8 = r8 - r2
            r6.layout(r7, r3, r9, r8)
        L_0x0035:
            boolean r7 = r5.f2241d
            if (r7 == 0) goto L_0x004e
            android.graphics.drawable.Drawable r6 = r5.f2240c
            if (r6 == 0) goto L_0x004c
            android.graphics.drawable.Drawable r6 = r5.f2240c
            int r7 = r5.getMeasuredWidth()
            int r8 = r5.getMeasuredHeight()
            r6.setBounds(r0, r0, r7, r8)
            goto L_0x00be
        L_0x004c:
            r10 = r0
            goto L_0x00be
        L_0x004e:
            android.graphics.drawable.Drawable r7 = r5.f2238a
            if (r7 == 0) goto L_0x00a1
            android.view.View r7 = r5.f2245h
            int r7 = r7.getVisibility()
            if (r7 != 0) goto L_0x0078
            android.graphics.drawable.Drawable r7 = r5.f2238a
            android.view.View r8 = r5.f2245h
            int r8 = r8.getLeft()
            android.view.View r9 = r5.f2245h
            int r9 = r9.getTop()
            android.view.View r0 = r5.f2245h
            int r0 = r0.getRight()
            android.view.View r2 = r5.f2245h
        L_0x0070:
            int r2 = r2.getBottom()
            r7.setBounds(r8, r9, r0, r2)
            goto L_0x00a0
        L_0x0078:
            android.view.View r7 = r5.f2246i
            if (r7 == 0) goto L_0x009b
            android.view.View r7 = r5.f2246i
            int r7 = r7.getVisibility()
            if (r7 != 0) goto L_0x009b
            android.graphics.drawable.Drawable r7 = r5.f2238a
            android.view.View r8 = r5.f2246i
            int r8 = r8.getLeft()
            android.view.View r9 = r5.f2246i
            int r9 = r9.getTop()
            android.view.View r0 = r5.f2246i
            int r0 = r0.getRight()
            android.view.View r2 = r5.f2246i
            goto L_0x0070
        L_0x009b:
            android.graphics.drawable.Drawable r7 = r5.f2238a
            r7.setBounds(r0, r0, r0, r0)
        L_0x00a0:
            r0 = r10
        L_0x00a1:
            r5.f2242e = r1
            if (r1 == 0) goto L_0x004c
            android.graphics.drawable.Drawable r7 = r5.f2239b
            if (r7 == 0) goto L_0x004c
            android.graphics.drawable.Drawable r7 = r5.f2239b
            int r8 = r6.getLeft()
            int r9 = r6.getTop()
            int r0 = r6.getRight()
            int r6 = r6.getBottom()
            r7.setBounds(r8, r9, r0, r6)
        L_0x00be:
            if (r10 == 0) goto L_0x00c3
            r5.invalidate()
        L_0x00c3:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.p031v7.widget.ActionBarContainer.onLayout(boolean, int, int, int, int):void");
    }

    /* JADX WARNING: Removed duplicated region for block: B:25:0x0059  */
    /* JADX WARNING: Removed duplicated region for block: B:26:0x005e  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void onMeasure(int r4, int r5) {
        /*
            r3 = this;
            android.view.View r0 = r3.f2245h
            r1 = -2147483648(0xffffffff80000000, float:-0.0)
            if (r0 != 0) goto L_0x001e
            int r0 = android.view.View.MeasureSpec.getMode(r5)
            if (r0 != r1) goto L_0x001e
            int r0 = r3.f2247j
            if (r0 < 0) goto L_0x001e
            int r0 = r3.f2247j
            int r5 = android.view.View.MeasureSpec.getSize(r5)
            int r5 = java.lang.Math.min(r0, r5)
            int r5 = android.view.View.MeasureSpec.makeMeasureSpec(r5, r1)
        L_0x001e:
            super.onMeasure(r4, r5)
            android.view.View r4 = r3.f2245h
            if (r4 != 0) goto L_0x0026
            return
        L_0x0026:
            int r4 = android.view.View.MeasureSpec.getMode(r5)
            android.view.View r0 = r3.f2244g
            if (r0 == 0) goto L_0x0073
            android.view.View r0 = r3.f2244g
            int r0 = r0.getVisibility()
            r2 = 8
            if (r0 == r2) goto L_0x0073
            r0 = 1073741824(0x40000000, float:2.0)
            if (r4 == r0) goto L_0x0073
            android.view.View r0 = r3.f2245h
            boolean r0 = r3.m3165a(r0)
            if (r0 != 0) goto L_0x004b
            android.view.View r0 = r3.f2245h
        L_0x0046:
            int r0 = r3.m3166b(r0)
            goto L_0x0057
        L_0x004b:
            android.view.View r0 = r3.f2246i
            boolean r0 = r3.m3165a(r0)
            if (r0 != 0) goto L_0x0056
            android.view.View r0 = r3.f2246i
            goto L_0x0046
        L_0x0056:
            r0 = 0
        L_0x0057:
            if (r4 != r1) goto L_0x005e
            int r4 = android.view.View.MeasureSpec.getSize(r5)
            goto L_0x0061
        L_0x005e:
            r4 = 2147483647(0x7fffffff, float:NaN)
        L_0x0061:
            int r5 = r3.getMeasuredWidth()
            android.view.View r1 = r3.f2244g
            int r1 = r3.m3166b(r1)
            int r0 = r0 + r1
            int r4 = java.lang.Math.min(r0, r4)
            r3.setMeasuredDimension(r5, r4)
        L_0x0073:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.p031v7.widget.ActionBarContainer.onMeasure(int, int):void");
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        super.onTouchEvent(motionEvent);
        return true;
    }

    public void setPrimaryBackground(Drawable drawable) {
        if (this.f2238a != null) {
            this.f2238a.setCallback(null);
            unscheduleDrawable(this.f2238a);
        }
        this.f2238a = drawable;
        if (drawable != null) {
            drawable.setCallback(this);
            if (this.f2245h != null) {
                this.f2238a.setBounds(this.f2245h.getLeft(), this.f2245h.getTop(), this.f2245h.getRight(), this.f2245h.getBottom());
            }
        }
        boolean z = false;
        if (!this.f2241d ? this.f2238a == null && this.f2239b == null : this.f2240c == null) {
            z = true;
        }
        setWillNotDraw(z);
        invalidate();
    }

    public void setSplitBackground(Drawable drawable) {
        if (this.f2240c != null) {
            this.f2240c.setCallback(null);
            unscheduleDrawable(this.f2240c);
        }
        this.f2240c = drawable;
        boolean z = false;
        if (drawable != null) {
            drawable.setCallback(this);
            if (this.f2241d && this.f2240c != null) {
                this.f2240c.setBounds(0, 0, getMeasuredWidth(), getMeasuredHeight());
            }
        }
        if (!this.f2241d ? this.f2238a == null && this.f2239b == null : this.f2240c == null) {
            z = true;
        }
        setWillNotDraw(z);
        invalidate();
    }

    public void setStackedBackground(Drawable drawable) {
        if (this.f2239b != null) {
            this.f2239b.setCallback(null);
            unscheduleDrawable(this.f2239b);
        }
        this.f2239b = drawable;
        if (drawable != null) {
            drawable.setCallback(this);
            if (this.f2242e && this.f2239b != null) {
                this.f2239b.setBounds(this.f2244g.getLeft(), this.f2244g.getTop(), this.f2244g.getRight(), this.f2244g.getBottom());
            }
        }
        boolean z = false;
        if (!this.f2241d ? this.f2238a == null && this.f2239b == null : this.f2240c == null) {
            z = true;
        }
        setWillNotDraw(z);
        invalidate();
    }

    public void setTabContainer(C0856bf bfVar) {
        if (this.f2244g != null) {
            removeView(this.f2244g);
        }
        this.f2244g = bfVar;
        if (bfVar != null) {
            addView(bfVar);
            ViewGroup.LayoutParams layoutParams = bfVar.getLayoutParams();
            layoutParams.width = -1;
            layoutParams.height = -2;
            bfVar.setAllowCollapse(false);
        }
    }

    public void setTransitioning(boolean z) {
        this.f2243f = z;
        setDescendantFocusability(z ? 393216 : 262144);
    }

    public void setVisibility(int i) {
        super.setVisibility(i);
        boolean z = i == 0;
        if (this.f2238a != null) {
            this.f2238a.setVisible(z, false);
        }
        if (this.f2239b != null) {
            this.f2239b.setVisible(z, false);
        }
        if (this.f2240c != null) {
            this.f2240c.setVisible(z, false);
        }
    }

    public ActionMode startActionModeForChild(View view, Callback callback) {
        return null;
    }

    public ActionMode startActionModeForChild(View view, Callback callback, int i) {
        if (i != 0) {
            return super.startActionModeForChild(view, callback, i);
        }
        return null;
    }

    /* access modifiers changed from: protected */
    public boolean verifyDrawable(Drawable drawable) {
        return (drawable == this.f2238a && !this.f2241d) || (drawable == this.f2239b && this.f2242e) || ((drawable == this.f2240c && this.f2241d) || super.verifyDrawable(drawable));
    }
}
