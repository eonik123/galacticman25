package android.support.p031v7.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff.Mode;
import android.graphics.drawable.Drawable;
import android.support.p018v4.widget.C0533n;
import android.support.p031v7.p032a.C0540a.C0541a;
import android.support.p031v7.p033b.p034a.C0606a;
import android.util.AttributeSet;
import android.widget.CheckBox;

/* renamed from: android.support.v7.widget.h */
public class C0906h extends CheckBox implements C0533n {

    /* renamed from: a */
    private final C0908j f3278a;

    public C0906h(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, C0541a.checkboxStyle);
    }

    public C0906h(Context context, AttributeSet attributeSet, int i) {
        super(C0866bk.m4633a(context), attributeSet, i);
        this.f3278a = new C0908j(this);
        this.f3278a.mo4565a(attributeSet, i);
    }

    public int getCompoundPaddingLeft() {
        int compoundPaddingLeft = super.getCompoundPaddingLeft();
        return this.f3278a != null ? this.f3278a.mo4561a(compoundPaddingLeft) : compoundPaddingLeft;
    }

    public ColorStateList getSupportButtonTintList() {
        if (this.f3278a != null) {
            return this.f3278a.mo4562a();
        }
        return null;
    }

    public Mode getSupportButtonTintMode() {
        if (this.f3278a != null) {
            return this.f3278a.mo4566b();
        }
        return null;
    }

    public void setButtonDrawable(int i) {
        setButtonDrawable(C0606a.m2714b(getContext(), i));
    }

    public void setButtonDrawable(Drawable drawable) {
        super.setButtonDrawable(drawable);
        if (this.f3278a != null) {
            this.f3278a.mo4567c();
        }
    }

    public void setSupportButtonTintList(ColorStateList colorStateList) {
        if (this.f3278a != null) {
            this.f3278a.mo4563a(colorStateList);
        }
    }

    public void setSupportButtonTintMode(Mode mode) {
        if (this.f3278a != null) {
            this.f3278a.mo4564a(mode);
        }
    }
}
