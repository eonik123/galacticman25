package android.support.p031v7.widget;

import android.support.p031v7.view.menu.C0671o.C0672a;
import android.view.Menu;
import android.view.Window.Callback;

/* renamed from: android.support.v7.widget.ai */
public interface C0755ai {
    /* renamed from: a */
    void mo3005a(int i);

    /* renamed from: a */
    void mo3006a(Menu menu, C0672a aVar);

    /* renamed from: e */
    boolean mo3013e();

    /* renamed from: f */
    boolean mo3014f();

    /* renamed from: g */
    boolean mo3016g();

    /* renamed from: h */
    boolean mo3023h();

    /* renamed from: i */
    boolean mo3024i();

    /* renamed from: j */
    void mo3025j();

    /* renamed from: k */
    void mo3026k();

    void setWindowCallback(Callback callback);

    void setWindowTitle(CharSequence charSequence);
}
