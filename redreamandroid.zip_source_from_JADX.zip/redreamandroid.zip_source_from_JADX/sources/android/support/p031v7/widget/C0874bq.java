package android.support.p031v7.widget;

import android.support.p018v4.p028h.C0495r;
import android.support.p018v4.p028h.C0499s;
import android.text.TextUtils;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnAttachStateChangeListener;
import android.view.View.OnHoverListener;
import android.view.View.OnLongClickListener;
import android.view.ViewConfiguration;
import android.view.accessibility.AccessibilityManager;

/* renamed from: android.support.v7.widget.bq */
class C0874bq implements OnAttachStateChangeListener, OnHoverListener, OnLongClickListener {

    /* renamed from: j */
    private static C0874bq f3168j;

    /* renamed from: k */
    private static C0874bq f3169k;

    /* renamed from: a */
    private final View f3170a;

    /* renamed from: b */
    private final CharSequence f3171b;

    /* renamed from: c */
    private final int f3172c;

    /* renamed from: d */
    private final Runnable f3173d = new Runnable() {
        public void run() {
            C0874bq.this.mo4451a(false);
        }
    };

    /* renamed from: e */
    private final Runnable f3174e = new Runnable() {
        public void run() {
            C0874bq.this.mo4450a();
        }
    };

    /* renamed from: f */
    private int f3175f;

    /* renamed from: g */
    private int f3176g;

    /* renamed from: h */
    private C0877br f3177h;

    /* renamed from: i */
    private boolean f3178i;

    private C0874bq(View view, CharSequence charSequence) {
        this.f3170a = view;
        this.f3171b = charSequence;
        this.f3172c = C0499s.m2181a(ViewConfiguration.get(this.f3170a.getContext()));
        m4709d();
        this.f3170a.setOnLongClickListener(this);
        this.f3170a.setOnHoverListener(this);
    }

    /* renamed from: a */
    private static void m4704a(C0874bq bqVar) {
        if (f3168j != null) {
            f3168j.m4708c();
        }
        f3168j = bqVar;
        if (f3168j != null) {
            f3168j.m4707b();
        }
    }

    /* renamed from: a */
    public static void m4705a(View view, CharSequence charSequence) {
        if (f3168j != null && f3168j.f3170a == view) {
            m4704a((C0874bq) null);
        }
        if (TextUtils.isEmpty(charSequence)) {
            if (f3169k != null && f3169k.f3170a == view) {
                f3169k.mo4450a();
            }
            view.setOnLongClickListener(null);
            view.setLongClickable(false);
            view.setOnHoverListener(null);
            return;
        }
        new C0874bq(view, charSequence);
    }

    /* renamed from: a */
    private boolean m4706a(MotionEvent motionEvent) {
        int x = (int) motionEvent.getX();
        int y = (int) motionEvent.getY();
        if (Math.abs(x - this.f3175f) <= this.f3172c && Math.abs(y - this.f3176g) <= this.f3172c) {
            return false;
        }
        this.f3175f = x;
        this.f3176g = y;
        return true;
    }

    /* renamed from: b */
    private void m4707b() {
        this.f3170a.postDelayed(this.f3173d, (long) ViewConfiguration.getLongPressTimeout());
    }

    /* renamed from: c */
    private void m4708c() {
        this.f3170a.removeCallbacks(this.f3173d);
    }

    /* renamed from: d */
    private void m4709d() {
        this.f3175f = Integer.MAX_VALUE;
        this.f3176g = Integer.MAX_VALUE;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo4450a() {
        if (f3169k == this) {
            f3169k = null;
            if (this.f3177h != null) {
                this.f3177h.mo4458a();
                this.f3177h = null;
                m4709d();
                this.f3170a.removeOnAttachStateChangeListener(this);
            } else {
                Log.e("TooltipCompatHandler", "sActiveHandler.mPopup == null");
            }
        }
        if (f3168j == this) {
            m4704a((C0874bq) null);
        }
        this.f3170a.removeCallbacks(this.f3174e);
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo4451a(boolean z) {
        long j;
        if (C0495r.m2171z(this.f3170a)) {
            m4704a((C0874bq) null);
            if (f3169k != null) {
                f3169k.mo4450a();
            }
            f3169k = this;
            this.f3178i = z;
            this.f3177h = new C0877br(this.f3170a.getContext());
            this.f3177h.mo4459a(this.f3170a, this.f3175f, this.f3176g, this.f3178i, this.f3171b);
            this.f3170a.addOnAttachStateChangeListener(this);
            if (this.f3178i) {
                j = 2500;
            } else {
                j = ((C0495r.m2159n(this.f3170a) & 1) == 1 ? 3000 : 15000) - ((long) ViewConfiguration.getLongPressTimeout());
            }
            this.f3170a.removeCallbacks(this.f3174e);
            this.f3170a.postDelayed(this.f3174e, j);
        }
    }

    public boolean onHover(View view, MotionEvent motionEvent) {
        if (this.f3177h != null && this.f3178i) {
            return false;
        }
        AccessibilityManager accessibilityManager = (AccessibilityManager) this.f3170a.getContext().getSystemService("accessibility");
        if (accessibilityManager.isEnabled() && accessibilityManager.isTouchExplorationEnabled()) {
            return false;
        }
        int action = motionEvent.getAction();
        if (action == 7) {
            if (this.f3170a.isEnabled() && this.f3177h == null && m4706a(motionEvent)) {
                m4704a(this);
            }
            return false;
        } else if (action != 10) {
            return false;
        } else {
            m4709d();
            mo4450a();
            return false;
        }
    }

    public boolean onLongClick(View view) {
        this.f3175f = view.getWidth() / 2;
        this.f3176g = view.getHeight() / 2;
        mo4451a(true);
        return true;
    }

    public void onViewAttachedToWindow(View view) {
    }

    public void onViewDetachedFromWindow(View view) {
        mo4450a();
    }
}
