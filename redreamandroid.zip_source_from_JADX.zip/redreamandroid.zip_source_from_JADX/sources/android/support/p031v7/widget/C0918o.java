package android.support.p031v7.widget;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff.Mode;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.RippleDrawable;
import android.os.Build.VERSION;
import android.support.p018v4.widget.C0526h;
import android.support.p031v7.p032a.C0540a.C0550j;
import android.support.p031v7.p033b.p034a.C0606a;
import android.util.AttributeSet;
import android.widget.ImageView;

/* renamed from: android.support.v7.widget.o */
public class C0918o {

    /* renamed from: a */
    private final ImageView f3306a;

    /* renamed from: b */
    private C0867bl f3307b;

    /* renamed from: c */
    private C0867bl f3308c;

    /* renamed from: d */
    private C0867bl f3309d;

    public C0918o(ImageView imageView) {
        this.f3306a = imageView;
    }

    /* renamed from: a */
    private boolean m4906a(Drawable drawable) {
        if (this.f3309d == null) {
            this.f3309d = new C0867bl();
        }
        C0867bl blVar = this.f3309d;
        blVar.mo4422a();
        ColorStateList a = C0526h.m2330a(this.f3306a);
        if (a != null) {
            blVar.f3141d = true;
            blVar.f3138a = a;
        }
        Mode b = C0526h.m2333b(this.f3306a);
        if (b != null) {
            blVar.f3140c = true;
            blVar.f3139b = b;
        }
        if (!blVar.f3141d && !blVar.f3140c) {
            return false;
        }
        C0909k.m4877a(drawable, blVar, this.f3306a.getDrawableState());
        return true;
    }

    /* renamed from: e */
    private boolean m4907e() {
        int i = VERSION.SDK_INT;
        boolean z = false;
        if (i <= 21) {
            return i == 21;
        }
        if (this.f3307b != null) {
            z = true;
        }
        return z;
    }

    /* renamed from: a */
    public void mo4592a(int i) {
        if (i != 0) {
            Drawable b = C0606a.m2714b(this.f3306a.getContext(), i);
            if (b != null) {
                C0768al.m3840a(b);
            }
            this.f3306a.setImageDrawable(b);
        } else {
            this.f3306a.setImageDrawable(null);
        }
        mo4599d();
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo4593a(ColorStateList colorStateList) {
        if (this.f3308c == null) {
            this.f3308c = new C0867bl();
        }
        this.f3308c.f3138a = colorStateList;
        this.f3308c.f3141d = true;
        mo4599d();
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo4594a(Mode mode) {
        if (this.f3308c == null) {
            this.f3308c = new C0867bl();
        }
        this.f3308c.f3139b = mode;
        this.f3308c.f3140c = true;
        mo4599d();
    }

    /* renamed from: a */
    public void mo4595a(AttributeSet attributeSet, int i) {
        C0869bn a = C0869bn.m4638a(this.f3306a.getContext(), attributeSet, C0550j.AppCompatImageView, i, 0);
        try {
            Drawable drawable = this.f3306a.getDrawable();
            if (drawable == null) {
                int g = a.mo4439g(C0550j.AppCompatImageView_srcCompat, -1);
                if (g != -1) {
                    drawable = C0606a.m2714b(this.f3306a.getContext(), g);
                    if (drawable != null) {
                        this.f3306a.setImageDrawable(drawable);
                    }
                }
            }
            if (drawable != null) {
                C0768al.m3840a(drawable);
            }
            if (a.mo4440g(C0550j.AppCompatImageView_tint)) {
                C0526h.m2331a(this.f3306a, a.mo4436e(C0550j.AppCompatImageView_tint));
            }
            if (a.mo4440g(C0550j.AppCompatImageView_tintMode)) {
                C0526h.m2332a(this.f3306a, C0768al.m3839a(a.mo4424a(C0550j.AppCompatImageView_tintMode, -1), null));
            }
        } finally {
            a.mo4427a();
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public boolean mo4596a() {
        return VERSION.SDK_INT < 21 || !(this.f3306a.getBackground() instanceof RippleDrawable);
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: b */
    public ColorStateList mo4597b() {
        if (this.f3308c != null) {
            return this.f3308c.f3138a;
        }
        return null;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: c */
    public Mode mo4598c() {
        if (this.f3308c != null) {
            return this.f3308c.f3139b;
        }
        return null;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: d */
    public void mo4599d() {
        C0867bl blVar;
        Drawable drawable = this.f3306a.getDrawable();
        if (drawable != null) {
            C0768al.m3840a(drawable);
        }
        if (drawable != null && (!m4907e() || !m4906a(drawable))) {
            if (this.f3308c != null) {
                blVar = this.f3308c;
            } else {
                if (this.f3307b != null) {
                    blVar = this.f3307b;
                }
                return;
            }
            C0909k.m4877a(drawable, blVar, this.f3306a.getDrawableState());
        }
    }
}
