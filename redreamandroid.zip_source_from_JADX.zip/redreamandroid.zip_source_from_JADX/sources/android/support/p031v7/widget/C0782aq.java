package android.support.p031v7.widget;

import android.support.p018v4.p024d.C0393a;
import android.support.p031v7.widget.C0805ay.C0823i;
import android.support.p031v7.widget.C0805ay.C0823i.C0826a;
import android.support.p031v7.widget.C0805ay.C0835p;
import android.support.p031v7.widget.C0805ay.C0846x;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.concurrent.TimeUnit;

/* renamed from: android.support.v7.widget.aq */
final class C0782aq implements Runnable {

    /* renamed from: a */
    static final ThreadLocal<C0782aq> f2743a = new ThreadLocal<>();

    /* renamed from: e */
    static Comparator<C0785b> f2744e = new Comparator<C0785b>() {
        /* renamed from: a */
        public int compare(C0785b bVar, C0785b bVar2) {
            int i = 1;
            if ((bVar.f2756d == null) != (bVar2.f2756d == null)) {
                return bVar.f2756d == null ? 1 : -1;
            }
            if (bVar.f2753a != bVar2.f2753a) {
                if (bVar.f2753a) {
                    i = -1;
                }
                return i;
            }
            int i2 = bVar2.f2754b - bVar.f2754b;
            if (i2 != 0) {
                return i2;
            }
            int i3 = bVar.f2755c - bVar2.f2755c;
            if (i3 != 0) {
                return i3;
            }
            return 0;
        }
    };

    /* renamed from: b */
    ArrayList<C0805ay> f2745b = new ArrayList<>();

    /* renamed from: c */
    long f2746c;

    /* renamed from: d */
    long f2747d;

    /* renamed from: f */
    private ArrayList<C0785b> f2748f = new ArrayList<>();

    /* renamed from: android.support.v7.widget.aq$a */
    static class C0784a implements C0826a {

        /* renamed from: a */
        int f2749a;

        /* renamed from: b */
        int f2750b;

        /* renamed from: c */
        int[] f2751c;

        /* renamed from: d */
        int f2752d;

        C0784a() {
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public void mo3720a() {
            if (this.f2751c != null) {
                Arrays.fill(this.f2751c, -1);
            }
            this.f2752d = 0;
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public void mo3721a(int i, int i2) {
            this.f2749a = i;
            this.f2750b = i2;
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public void mo3722a(C0805ay ayVar, boolean z) {
            this.f2752d = 0;
            if (this.f2751c != null) {
                Arrays.fill(this.f2751c, -1);
            }
            C0823i iVar = ayVar.f2908n;
            if (ayVar.f2907m != null && iVar != null && iVar.mo4128p()) {
                if (z) {
                    if (!ayVar.f2900f.mo4529d()) {
                        iVar.mo3194a(ayVar.f2907m.mo4007a(), (C0826a) this);
                    }
                } else if (!ayVar.mo3988v()) {
                    iVar.mo3193a(this.f2749a, this.f2750b, ayVar.f2850D, (C0826a) this);
                }
                if (this.f2752d > iVar.f2955x) {
                    iVar.f2955x = this.f2752d;
                    iVar.f2956y = z;
                    ayVar.f2899e.mo4178b();
                }
            }
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public boolean mo3723a(int i) {
            if (this.f2751c != null) {
                int i2 = this.f2752d * 2;
                for (int i3 = 0; i3 < i2; i3 += 2) {
                    if (this.f2751c[i3] == i) {
                        return true;
                    }
                }
            }
            return false;
        }

        /* renamed from: b */
        public void mo3724b(int i, int i2) {
            if (i < 0) {
                throw new IllegalArgumentException("Layout positions must be non-negative");
            } else if (i2 < 0) {
                throw new IllegalArgumentException("Pixel distance must be non-negative");
            } else {
                int i3 = this.f2752d * 2;
                if (this.f2751c == null) {
                    this.f2751c = new int[4];
                    Arrays.fill(this.f2751c, -1);
                } else if (i3 >= this.f2751c.length) {
                    int[] iArr = this.f2751c;
                    this.f2751c = new int[(i3 * 2)];
                    System.arraycopy(iArr, 0, this.f2751c, 0, iArr.length);
                }
                this.f2751c[i3] = i;
                this.f2751c[i3 + 1] = i2;
                this.f2752d++;
            }
        }
    }

    /* renamed from: android.support.v7.widget.aq$b */
    static class C0785b {

        /* renamed from: a */
        public boolean f2753a;

        /* renamed from: b */
        public int f2754b;

        /* renamed from: c */
        public int f2755c;

        /* renamed from: d */
        public C0805ay f2756d;

        /* renamed from: e */
        public int f2757e;

        C0785b() {
        }

        /* renamed from: a */
        public void mo3725a() {
            this.f2753a = false;
            this.f2754b = 0;
            this.f2755c = 0;
            this.f2756d = null;
            this.f2757e = 0;
        }
    }

    C0782aq() {
    }

    /* renamed from: a */
    private C0846x m3893a(C0805ay ayVar, int i, long j) {
        if (m3897a(ayVar, i)) {
            return null;
        }
        C0835p pVar = ayVar.f2899e;
        try {
            ayVar.mo3937l();
            C0846x a = pVar.mo4163a(i, false, j);
            if (a != null) {
                if (!a.mo4264p() || a.mo4262n()) {
                    pVar.mo4173a(a, false);
                } else {
                    pVar.mo4174a(a.f3023a);
                }
            }
            return a;
        } finally {
            ayVar.mo3865b(false);
        }
    }

    /* renamed from: a */
    private void m3894a() {
        C0785b bVar;
        int size = this.f2745b.size();
        int i = 0;
        for (int i2 = 0; i2 < size; i2++) {
            C0805ay ayVar = (C0805ay) this.f2745b.get(i2);
            if (ayVar.getWindowVisibility() == 0) {
                ayVar.f2849C.mo3722a(ayVar, false);
                i += ayVar.f2849C.f2752d;
            }
        }
        this.f2748f.ensureCapacity(i);
        int i3 = 0;
        for (int i4 = 0; i4 < size; i4++) {
            C0805ay ayVar2 = (C0805ay) this.f2745b.get(i4);
            if (ayVar2.getWindowVisibility() == 0) {
                C0784a aVar = ayVar2.f2849C;
                int abs = Math.abs(aVar.f2749a) + Math.abs(aVar.f2750b);
                int i5 = i3;
                for (int i6 = 0; i6 < aVar.f2752d * 2; i6 += 2) {
                    if (i5 >= this.f2748f.size()) {
                        bVar = new C0785b();
                        this.f2748f.add(bVar);
                    } else {
                        bVar = (C0785b) this.f2748f.get(i5);
                    }
                    int i7 = aVar.f2751c[i6 + 1];
                    bVar.f2753a = i7 <= abs;
                    bVar.f2754b = abs;
                    bVar.f2755c = i7;
                    bVar.f2756d = ayVar2;
                    bVar.f2757e = aVar.f2751c[i6];
                    i5++;
                }
                i3 = i5;
            }
        }
        Collections.sort(this.f2748f, f2744e);
    }

    /* renamed from: a */
    private void m3895a(C0785b bVar, long j) {
        C0846x a = m3893a(bVar.f2756d, bVar.f2757e, bVar.f2753a ? Long.MAX_VALUE : j);
        if (a != null && a.f3024b != null && a.mo4264p() && !a.mo4262n()) {
            m3896a((C0805ay) a.f3024b.get(), j);
        }
    }

    /* renamed from: a */
    private void m3896a(C0805ay ayVar, long j) {
        if (ayVar != null) {
            if (ayVar.f2918x && ayVar.f2901g.mo3584c() != 0) {
                ayVar.mo3870c();
            }
            C0784a aVar = ayVar.f2849C;
            aVar.mo3722a(ayVar, true);
            if (aVar.f2752d != 0) {
                try {
                    C0393a.m1731a("RV Nested Prefetch");
                    ayVar.f2850D.mo4222a(ayVar.f2907m);
                    for (int i = 0; i < aVar.f2752d * 2; i += 2) {
                        m3893a(ayVar, aVar.f2751c[i], j);
                    }
                } finally {
                    C0393a.m1730a();
                }
            }
        }
    }

    /* renamed from: a */
    static boolean m3897a(C0805ay ayVar, int i) {
        int c = ayVar.f2901g.mo3584c();
        for (int i2 = 0; i2 < c; i2++) {
            C0846x e = C0805ay.m4066e(ayVar.f2901g.mo3587d(i2));
            if (e.f3025c == i && !e.mo4262n()) {
                return true;
            }
        }
        return false;
    }

    /* renamed from: b */
    private void m3898b(long j) {
        int i = 0;
        while (i < this.f2748f.size()) {
            C0785b bVar = (C0785b) this.f2748f.get(i);
            if (bVar.f2756d != null) {
                m3895a(bVar, j);
                bVar.mo3725a();
                i++;
            } else {
                return;
            }
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo3713a(long j) {
        m3894a();
        m3898b(j);
    }

    /* renamed from: a */
    public void mo3714a(C0805ay ayVar) {
        this.f2745b.add(ayVar);
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo3715a(C0805ay ayVar, int i, int i2) {
        if (ayVar.isAttachedToWindow() && this.f2746c == 0) {
            this.f2746c = ayVar.getNanoTime();
            ayVar.post(this);
        }
        ayVar.f2849C.mo3721a(i, i2);
    }

    /* renamed from: b */
    public void mo3716b(C0805ay ayVar) {
        this.f2745b.remove(ayVar);
    }

    public void run() {
        try {
            C0393a.m1731a("RV Prefetch");
            if (!this.f2745b.isEmpty()) {
                int size = this.f2745b.size();
                long j = 0;
                for (int i = 0; i < size; i++) {
                    C0805ay ayVar = (C0805ay) this.f2745b.get(i);
                    if (ayVar.getWindowVisibility() == 0) {
                        j = Math.max(ayVar.getDrawingTime(), j);
                    }
                }
                if (j != 0) {
                    mo3713a(TimeUnit.MILLISECONDS.toNanos(j) + this.f2747d);
                    this.f2746c = 0;
                    C0393a.m1730a();
                }
            }
        } finally {
            this.f2746c = 0;
            C0393a.m1730a();
        }
    }
}
