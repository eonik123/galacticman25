package android.support.p031v7.widget;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.support.p018v4.p028h.C0502v;
import android.support.p031v7.view.menu.C0655h.C0656a;
import android.support.p031v7.view.menu.C0671o.C0672a;
import android.view.Menu;
import android.view.ViewGroup;
import android.view.Window.Callback;

/* renamed from: android.support.v7.widget.aj */
public interface C0756aj {
    /* renamed from: a */
    C0502v mo3612a(int i, long j);

    /* renamed from: a */
    ViewGroup mo3613a();

    /* renamed from: a */
    void mo3614a(int i);

    /* renamed from: a */
    void mo3615a(Drawable drawable);

    /* renamed from: a */
    void mo3616a(C0672a aVar, C0656a aVar2);

    /* renamed from: a */
    void mo3617a(C0856bf bfVar);

    /* renamed from: a */
    void mo3618a(Menu menu, C0672a aVar);

    /* renamed from: a */
    void mo3619a(Callback callback);

    /* renamed from: a */
    void mo3620a(CharSequence charSequence);

    /* renamed from: a */
    void mo3621a(boolean z);

    /* renamed from: b */
    Context mo3622b();

    /* renamed from: b */
    void mo3623b(int i);

    /* renamed from: b */
    void mo3624b(boolean z);

    /* renamed from: c */
    void mo3625c(int i);

    /* renamed from: c */
    boolean mo3626c();

    /* renamed from: d */
    void mo3627d();

    /* renamed from: d */
    void mo3628d(int i);

    /* renamed from: e */
    CharSequence mo3629e();

    /* renamed from: f */
    void mo3630f();

    /* renamed from: g */
    void mo3631g();

    /* renamed from: h */
    boolean mo3632h();

    /* renamed from: i */
    boolean mo3633i();

    /* renamed from: j */
    boolean mo3634j();

    /* renamed from: k */
    boolean mo3635k();

    /* renamed from: l */
    boolean mo3636l();

    /* renamed from: m */
    void mo3637m();

    /* renamed from: n */
    void mo3638n();

    /* renamed from: o */
    int mo3639o();

    /* renamed from: p */
    int mo3640p();

    /* renamed from: q */
    Menu mo3641q();
}
