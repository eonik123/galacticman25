package android.support.p031v7.widget;

import android.content.res.ColorStateList;

/* renamed from: android.support.v7.widget.ag */
interface C0751ag {
    /* renamed from: a */
    float mo3555a(C0750af afVar);

    /* renamed from: a */
    void mo3553a();

    /* renamed from: a */
    void mo3556a(C0750af afVar, float f);

    /* renamed from: a */
    void mo3557a(C0750af afVar, ColorStateList colorStateList);

    /* renamed from: b */
    float mo3558b(C0750af afVar);

    /* renamed from: b */
    void mo3559b(C0750af afVar, float f);

    /* renamed from: c */
    float mo3560c(C0750af afVar);

    /* renamed from: c */
    void mo3561c(C0750af afVar, float f);

    /* renamed from: d */
    float mo3562d(C0750af afVar);

    /* renamed from: e */
    float mo3563e(C0750af afVar);

    /* renamed from: g */
    void mo3565g(C0750af afVar);

    /* renamed from: h */
    void mo3566h(C0750af afVar);

    /* renamed from: i */
    ColorStateList mo3567i(C0750af afVar);
}
