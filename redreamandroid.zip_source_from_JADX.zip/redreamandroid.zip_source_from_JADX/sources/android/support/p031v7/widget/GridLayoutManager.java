package android.support.p031v7.widget;

import android.content.Context;
import android.graphics.Rect;
import android.support.p018v4.p028h.p029a.C0464c;
import android.support.p018v4.p028h.p029a.C0464c.C0466b;
import android.support.p031v7.widget.C0805ay.C0823i.C0826a;
import android.support.p031v7.widget.C0805ay.C0828j;
import android.support.p031v7.widget.C0805ay.C0835p;
import android.support.p031v7.widget.C0805ay.C0843u;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseIntArray;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewGroup.MarginLayoutParams;
import java.util.Arrays;

/* renamed from: android.support.v7.widget.GridLayoutManager */
public class GridLayoutManager extends LinearLayoutManager {

    /* renamed from: a */
    boolean f2350a = false;

    /* renamed from: b */
    int f2351b = -1;

    /* renamed from: c */
    int[] f2352c;

    /* renamed from: d */
    View[] f2353d;

    /* renamed from: e */
    final SparseIntArray f2354e = new SparseIntArray();

    /* renamed from: f */
    final SparseIntArray f2355f = new SparseIntArray();

    /* renamed from: g */
    C0699c f2356g = new C0697a();

    /* renamed from: h */
    final Rect f2357h = new Rect();

    /* renamed from: android.support.v7.widget.GridLayoutManager$a */
    public static final class C0697a extends C0699c {
        /* renamed from: a */
        public int mo3183a(int i) {
            return 1;
        }

        /* renamed from: a */
        public int mo3184a(int i, int i2) {
            return i % i2;
        }
    }

    /* renamed from: android.support.v7.widget.GridLayoutManager$b */
    public static class C0698b extends C0828j {

        /* renamed from: a */
        int f2358a = -1;

        /* renamed from: b */
        int f2359b = 0;

        public C0698b(int i, int i2) {
            super(i, i2);
        }

        public C0698b(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
        }

        public C0698b(LayoutParams layoutParams) {
            super(layoutParams);
        }

        public C0698b(MarginLayoutParams marginLayoutParams) {
            super(marginLayoutParams);
        }

        /* renamed from: a */
        public int mo3185a() {
            return this.f2358a;
        }

        /* renamed from: b */
        public int mo3186b() {
            return this.f2359b;
        }
    }

    /* renamed from: android.support.v7.widget.GridLayoutManager$c */
    public static abstract class C0699c {

        /* renamed from: a */
        final SparseIntArray f2360a = new SparseIntArray();

        /* renamed from: b */
        private boolean f2361b = false;

        /* renamed from: a */
        public abstract int mo3183a(int i);

        /* JADX WARNING: Removed duplicated region for block: B:12:0x002a  */
        /* JADX WARNING: Removed duplicated region for block: B:20:0x003c A[RETURN] */
        /* JADX WARNING: Removed duplicated region for block: B:21:0x003d A[RETURN] */
        /* renamed from: a */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public int mo3184a(int r6, int r7) {
            /*
                r5 = this;
                int r0 = r5.mo3183a(r6)
                r1 = 0
                if (r0 != r7) goto L_0x0008
                return r1
            L_0x0008:
                boolean r2 = r5.f2361b
                if (r2 == 0) goto L_0x0026
                android.util.SparseIntArray r2 = r5.f2360a
                int r2 = r2.size()
                if (r2 <= 0) goto L_0x0026
                int r2 = r5.mo3188b(r6)
                if (r2 < 0) goto L_0x0026
                android.util.SparseIntArray r3 = r5.f2360a
                int r3 = r3.get(r2)
                int r4 = r5.mo3183a(r2)
                int r3 = r3 + r4
                goto L_0x0036
            L_0x0026:
                r2 = r1
                r3 = r2
            L_0x0028:
                if (r2 >= r6) goto L_0x0039
                int r4 = r5.mo3183a(r2)
                int r3 = r3 + r4
                if (r3 != r7) goto L_0x0033
                r3 = r1
                goto L_0x0036
            L_0x0033:
                if (r3 <= r7) goto L_0x0036
                r3 = r4
            L_0x0036:
                int r2 = r2 + 1
                goto L_0x0028
            L_0x0039:
                int r0 = r0 + r3
                if (r0 > r7) goto L_0x003d
                return r3
            L_0x003d:
                return r1
            */
            throw new UnsupportedOperationException("Method not decompiled: android.support.p031v7.widget.GridLayoutManager.C0699c.mo3184a(int, int):int");
        }

        /* renamed from: a */
        public void mo3187a() {
            this.f2360a.clear();
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: b */
        public int mo3188b(int i) {
            int size = this.f2360a.size() - 1;
            int i2 = 0;
            while (i2 <= size) {
                int i3 = (i2 + size) >>> 1;
                if (this.f2360a.keyAt(i3) < i) {
                    i2 = i3 + 1;
                } else {
                    size = i3 - 1;
                }
            }
            int i4 = i2 - 1;
            if (i4 < 0 || i4 >= this.f2360a.size()) {
                return -1;
            }
            return this.f2360a.keyAt(i4);
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: b */
        public int mo3189b(int i, int i2) {
            if (!this.f2361b) {
                return mo3184a(i, i2);
            }
            int i3 = this.f2360a.get(i, -1);
            if (i3 != -1) {
                return i3;
            }
            int a = mo3184a(i, i2);
            this.f2360a.put(i, a);
            return a;
        }

        /* renamed from: c */
        public int mo3190c(int i, int i2) {
            int a = mo3183a(i);
            int i3 = 0;
            int i4 = 0;
            for (int i5 = 0; i5 < i; i5++) {
                int a2 = mo3183a(i5);
                i3 += a2;
                if (i3 == i2) {
                    i4++;
                    i3 = 0;
                } else if (i3 > i2) {
                    i4++;
                    i3 = a2;
                }
            }
            return i3 + a > i2 ? i4 + 1 : i4;
        }
    }

    public GridLayoutManager(Context context, AttributeSet attributeSet, int i, int i2) {
        super(context, attributeSet, i, i2);
        mo3165a(m4233a(context, attributeSet, i, i2).f2960b);
    }

    /* renamed from: K */
    private void m3253K() {
        this.f2354e.clear();
        this.f2355f.clear();
    }

    /* renamed from: L */
    private void m3254L() {
        int v = mo4134v();
        for (int i = 0; i < v; i++) {
            C0698b bVar = (C0698b) mo4120i(i).getLayoutParams();
            int f = bVar.mo4147f();
            this.f2354e.put(f, bVar.mo3186b());
            this.f2355f.put(f, bVar.mo3185a());
        }
    }

    /* renamed from: M */
    private void m3255M() {
        int z;
        int B;
        if (mo3216g() == 1) {
            z = mo4137y() - mo4053C();
            B = mo4051A();
        } else {
            z = mo4138z() - mo4054D();
            B = mo4052B();
        }
        m3266m(z - B);
    }

    /* renamed from: N */
    private void m3256N() {
        if (this.f2353d == null || this.f2353d.length != this.f2351b) {
            this.f2353d = new View[this.f2351b];
        }
    }

    /* renamed from: a */
    private int m3257a(C0835p pVar, C0843u uVar, int i) {
        if (!uVar.mo4223a()) {
            return this.f2356g.mo3190c(i, this.f2351b);
        }
        int b = pVar.mo4176b(i);
        if (b != -1) {
            return this.f2356g.mo3190c(b, this.f2351b);
        }
        StringBuilder sb = new StringBuilder();
        sb.append("Cannot find span size for pre layout position. ");
        sb.append(i);
        Log.w("GridLayoutManager", sb.toString());
        return 0;
    }

    /* renamed from: a */
    private void m3258a(float f, int i) {
        m3266m(Math.max(Math.round(f * ((float) this.f2351b)), i));
    }

    /* renamed from: a */
    private void m3259a(C0835p pVar, C0843u uVar, int i, int i2, boolean z) {
        int i3;
        int i4;
        int i5 = -1;
        int i6 = 0;
        if (z) {
            i3 = 1;
            i5 = i;
            i4 = 0;
        } else {
            i4 = i - 1;
            i3 = -1;
        }
        while (i4 != i5) {
            View view = this.f2353d[i4];
            C0698b bVar = (C0698b) view.getLayoutParams();
            bVar.f2359b = m3265c(pVar, uVar, mo4104d(view));
            bVar.f2358a = i6;
            i6 += bVar.f2359b;
            i4 += i3;
        }
    }

    /* renamed from: a */
    private void m3260a(View view, int i, int i2, boolean z) {
        C0828j jVar = (C0828j) view.getLayoutParams();
        if (z ? mo4086a(view, i, i2, jVar) : mo4096b(view, i, i2, jVar)) {
            view.measure(i, i2);
        }
    }

    /* renamed from: a */
    private void m3261a(View view, int i, boolean z) {
        int i2;
        int i3;
        C0698b bVar = (C0698b) view.getLayoutParams();
        Rect rect = bVar.f2964d;
        int i4 = rect.top + rect.bottom + bVar.topMargin + bVar.bottomMargin;
        int i5 = rect.left + rect.right + bVar.leftMargin + bVar.rightMargin;
        int a = mo3157a(bVar.f2358a, bVar.f2359b);
        if (this.f2370i == 1) {
            i2 = m4232a(a, i, i5, bVar.width, false);
            i3 = m4232a(this.f2371j.mo3827f(), mo4136x(), i4, bVar.height, true);
        } else {
            int a2 = m4232a(a, i, i4, bVar.height, false);
            int a3 = m4232a(this.f2371j.mo3827f(), mo4135w(), i5, bVar.width, true);
            i3 = a2;
            i2 = a3;
        }
        m3260a(view, i2, i3, z);
    }

    /* renamed from: a */
    static int[] m3262a(int[] iArr, int i, int i2) {
        int i3;
        if (!(iArr != null && iArr.length == i + 1 && iArr[iArr.length - 1] == i2)) {
            iArr = new int[(i + 1)];
        }
        int i4 = 0;
        iArr[0] = 0;
        int i5 = i2 / i;
        int i6 = i2 % i;
        int i7 = 0;
        for (int i8 = 1; i8 <= i; i8++) {
            i4 += i6;
            if (i4 <= 0 || i - i4 >= i6) {
                i3 = i5;
            } else {
                i3 = i5 + 1;
                i4 -= i;
            }
            i7 += i3;
            iArr[i8] = i7;
        }
        return iArr;
    }

    /* renamed from: b */
    private int m3263b(C0835p pVar, C0843u uVar, int i) {
        if (!uVar.mo4223a()) {
            return this.f2356g.mo3189b(i, this.f2351b);
        }
        int i2 = this.f2355f.get(i, -1);
        if (i2 != -1) {
            return i2;
        }
        int b = pVar.mo4176b(i);
        if (b != -1) {
            return this.f2356g.mo3189b(b, this.f2351b);
        }
        StringBuilder sb = new StringBuilder();
        sb.append("Cannot find span size for pre layout position. It is not cached, not in the adapter. Pos:");
        sb.append(i);
        Log.w("GridLayoutManager", sb.toString());
        return 0;
    }

    /* renamed from: b */
    private void m3264b(C0835p pVar, C0843u uVar, C0700a aVar, int i) {
        boolean z = i == 1;
        int b = m3263b(pVar, uVar, aVar.f2378b);
        if (z) {
            while (b > 0 && aVar.f2378b > 0) {
                aVar.f2378b--;
                b = m3263b(pVar, uVar, aVar.f2378b);
            }
            return;
        }
        int e = uVar.mo4227e() - 1;
        int i2 = aVar.f2378b;
        while (i2 < e) {
            int i3 = i2 + 1;
            int b2 = m3263b(pVar, uVar, i3);
            if (b2 <= b) {
                break;
            }
            i2 = i3;
            b = b2;
        }
        aVar.f2378b = i2;
    }

    /* renamed from: c */
    private int m3265c(C0835p pVar, C0843u uVar, int i) {
        if (!uVar.mo4223a()) {
            return this.f2356g.mo3183a(i);
        }
        int i2 = this.f2354e.get(i, -1);
        if (i2 != -1) {
            return i2;
        }
        int b = pVar.mo4176b(i);
        if (b != -1) {
            return this.f2356g.mo3183a(b);
        }
        StringBuilder sb = new StringBuilder();
        sb.append("Cannot find span size for pre layout position. It is not cached, not in the adapter. Pos:");
        sb.append(i);
        Log.w("GridLayoutManager", sb.toString());
        return 1;
    }

    /* renamed from: m */
    private void m3266m(int i) {
        this.f2352c = m3262a(this.f2352c, this.f2351b, i);
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public int mo3157a(int i, int i2) {
        return (this.f2370i != 1 || !mo3219h()) ? this.f2352c[i2 + i] - this.f2352c[i] : this.f2352c[this.f2351b - i] - this.f2352c[(this.f2351b - i) - i2];
    }

    /* renamed from: a */
    public int mo3158a(int i, C0835p pVar, C0843u uVar) {
        m3255M();
        m3256N();
        return super.mo3158a(i, pVar, uVar);
    }

    /* renamed from: a */
    public int mo3159a(C0835p pVar, C0843u uVar) {
        if (this.f2370i == 0) {
            return this.f2351b;
        }
        if (uVar.mo4227e() < 1) {
            return 0;
        }
        return m3257a(pVar, uVar, uVar.mo4227e() - 1) + 1;
    }

    /* renamed from: a */
    public C0828j mo3160a() {
        return this.f2370i == 0 ? new C0698b(-2, -1) : new C0698b(-1, -2);
    }

    /* renamed from: a */
    public C0828j mo3161a(Context context, AttributeSet attributeSet) {
        return new C0698b(context, attributeSet);
    }

    /* renamed from: a */
    public C0828j mo3162a(LayoutParams layoutParams) {
        return layoutParams instanceof MarginLayoutParams ? new C0698b((MarginLayoutParams) layoutParams) : new C0698b(layoutParams);
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public View mo3163a(C0835p pVar, C0843u uVar, int i, int i2, int i3) {
        mo3220i();
        int c = this.f2371j.mo3821c();
        int d = this.f2371j.mo3823d();
        int i4 = i2 > i ? 1 : -1;
        View view = null;
        View view2 = null;
        while (i != i2) {
            View i5 = mo4120i(i);
            int d2 = mo4104d(i5);
            if (d2 >= 0 && d2 < i3 && m3263b(pVar, uVar, d2) == 0) {
                if (((C0828j) i5.getLayoutParams()).mo4145d()) {
                    if (view2 == null) {
                        view2 = i5;
                    }
                } else if (this.f2371j.mo3816a(i5) < d && this.f2371j.mo3820b(i5) >= c) {
                    return i5;
                } else {
                    if (view == null) {
                        view = i5;
                    }
                }
            }
            i += i4;
        }
        return view != null ? view : view2;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:54:0x00d8, code lost:
        if (r13 == (r2 > r8)) goto L_0x00b3;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:64:0x00f5, code lost:
        if (r13 == r10) goto L_0x00bb;
     */
    /* JADX WARNING: Removed duplicated region for block: B:70:0x0104  */
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public android.view.View mo3164a(android.view.View r27, int r28, android.support.p031v7.widget.C0805ay.C0835p r29, android.support.p031v7.widget.C0805ay.C0843u r30) {
        /*
            r26 = this;
            r0 = r26
            r1 = r29
            r2 = r30
            android.view.View r3 = r26.mo4108e(r27)
            r4 = 0
            if (r3 != 0) goto L_0x000e
            return r4
        L_0x000e:
            android.view.ViewGroup$LayoutParams r5 = r3.getLayoutParams()
            android.support.v7.widget.GridLayoutManager$b r5 = (android.support.p031v7.widget.GridLayoutManager.C0698b) r5
            int r6 = r5.f2358a
            int r7 = r5.f2358a
            int r5 = r5.f2359b
            int r7 = r7 + r5
            android.view.View r5 = super.mo3164a(r27, r28, r29, r30)
            if (r5 != 0) goto L_0x0022
            return r4
        L_0x0022:
            r5 = r28
            int r5 = r0.mo3213f(r5)
            r9 = 1
            if (r5 != r9) goto L_0x002d
            r5 = r9
            goto L_0x002e
        L_0x002d:
            r5 = 0
        L_0x002e:
            boolean r10 = r0.f2372k
            if (r5 == r10) goto L_0x0034
            r5 = r9
            goto L_0x0035
        L_0x0034:
            r5 = 0
        L_0x0035:
            r10 = -1
            if (r5 == 0) goto L_0x0040
            int r5 = r26.mo4134v()
            int r5 = r5 - r9
            r11 = r10
            r12 = r11
            goto L_0x0047
        L_0x0040:
            int r5 = r26.mo4134v()
            r11 = r5
            r12 = r9
            r5 = 0
        L_0x0047:
            int r13 = r0.f2370i
            if (r13 != r9) goto L_0x0053
            boolean r13 = r26.mo3219h()
            if (r13 == 0) goto L_0x0053
            r13 = r9
            goto L_0x0054
        L_0x0053:
            r13 = 0
        L_0x0054:
            int r14 = r0.m3257a(r1, r2, r5)
            r8 = r10
            r18 = r8
            r15 = 0
            r17 = 0
            r10 = r4
        L_0x005f:
            if (r5 == r11) goto L_0x0146
            int r9 = r0.m3257a(r1, r2, r5)
            android.view.View r1 = r0.mo4120i(r5)
            if (r1 != r3) goto L_0x006d
            goto L_0x0146
        L_0x006d:
            boolean r20 = r1.hasFocusable()
            if (r20 == 0) goto L_0x0087
            if (r9 == r14) goto L_0x0087
            if (r4 == 0) goto L_0x0079
            goto L_0x0146
        L_0x0079:
            r21 = r3
            r23 = r8
            r24 = r10
            r22 = r11
            r8 = r17
            r11 = r18
            goto L_0x0132
        L_0x0087:
            android.view.ViewGroup$LayoutParams r9 = r1.getLayoutParams()
            android.support.v7.widget.GridLayoutManager$b r9 = (android.support.p031v7.widget.GridLayoutManager.C0698b) r9
            int r2 = r9.f2358a
            r21 = r3
            int r3 = r9.f2358a
            r22 = r11
            int r11 = r9.f2359b
            int r3 = r3 + r11
            boolean r11 = r1.hasFocusable()
            if (r11 == 0) goto L_0x00a3
            if (r2 != r6) goto L_0x00a3
            if (r3 != r7) goto L_0x00a3
            return r1
        L_0x00a3:
            boolean r11 = r1.hasFocusable()
            if (r11 == 0) goto L_0x00ab
            if (r4 == 0) goto L_0x00b3
        L_0x00ab:
            boolean r11 = r1.hasFocusable()
            if (r11 != 0) goto L_0x00be
            if (r10 != 0) goto L_0x00be
        L_0x00b3:
            r23 = r8
            r24 = r10
            r8 = r17
        L_0x00b9:
            r11 = r18
        L_0x00bb:
            r19 = 1
            goto L_0x0102
        L_0x00be:
            int r11 = java.lang.Math.max(r2, r6)
            int r20 = java.lang.Math.min(r3, r7)
            int r11 = r20 - r11
            boolean r20 = r1.hasFocusable()
            if (r20 == 0) goto L_0x00db
            if (r11 <= r15) goto L_0x00d1
            goto L_0x00b3
        L_0x00d1:
            if (r11 != r15) goto L_0x00f8
            if (r2 <= r8) goto L_0x00d7
            r11 = 1
            goto L_0x00d8
        L_0x00d7:
            r11 = 0
        L_0x00d8:
            if (r13 != r11) goto L_0x00f8
            goto L_0x00b3
        L_0x00db:
            if (r4 != 0) goto L_0x00f8
            r23 = r8
            r24 = r10
            r8 = 1
            r10 = 0
            boolean r16 = r0.mo4088a(r1, r10, r8)
            if (r16 == 0) goto L_0x00fc
            r8 = r17
            if (r11 <= r8) goto L_0x00ee
            goto L_0x00b9
        L_0x00ee:
            if (r11 != r8) goto L_0x00fe
            r11 = r18
            if (r2 <= r11) goto L_0x00f5
            r10 = 1
        L_0x00f5:
            if (r13 != r10) goto L_0x0100
            goto L_0x00bb
        L_0x00f8:
            r23 = r8
            r24 = r10
        L_0x00fc:
            r8 = r17
        L_0x00fe:
            r11 = r18
        L_0x0100:
            r19 = 0
        L_0x0102:
            if (r19 == 0) goto L_0x0132
            boolean r10 = r1.hasFocusable()
            if (r10 == 0) goto L_0x011f
            int r4 = r9.f2358a
            int r3 = java.lang.Math.min(r3, r7)
            int r2 = java.lang.Math.max(r2, r6)
            int r3 = r3 - r2
            r15 = r3
            r17 = r8
            r18 = r11
            r10 = r24
            r8 = r4
            r4 = r1
            goto L_0x013a
        L_0x011f:
            int r8 = r9.f2358a
            int r3 = java.lang.Math.min(r3, r7)
            int r2 = java.lang.Math.max(r2, r6)
            int r3 = r3 - r2
            r10 = r1
            r17 = r3
            r18 = r8
            r8 = r23
            goto L_0x013a
        L_0x0132:
            r17 = r8
            r18 = r11
            r8 = r23
            r10 = r24
        L_0x013a:
            int r5 = r5 + r12
            r3 = r21
            r11 = r22
            r1 = r29
            r2 = r30
            r9 = 1
            goto L_0x005f
        L_0x0146:
            r24 = r10
            if (r4 == 0) goto L_0x014c
            r24 = r4
        L_0x014c:
            return r24
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.p031v7.widget.GridLayoutManager.mo3164a(android.view.View, int, android.support.v7.widget.ay$p, android.support.v7.widget.ay$u):android.view.View");
    }

    /* renamed from: a */
    public void mo3165a(int i) {
        if (i != this.f2351b) {
            this.f2350a = true;
            if (i < 1) {
                StringBuilder sb = new StringBuilder();
                sb.append("Span count should be at least 1. Provided ");
                sb.append(i);
                throw new IllegalArgumentException(sb.toString());
            }
            this.f2351b = i;
            this.f2356g.mo3187a();
            mo4127o();
        }
    }

    /* renamed from: a */
    public void mo3166a(Rect rect, int i, int i2) {
        int i3;
        int i4;
        if (this.f2352c == null) {
            super.mo3166a(rect, i, i2);
        }
        int A = mo4051A() + mo4053C();
        int B = mo4052B() + mo4054D();
        if (this.f2370i == 1) {
            i4 = m4231a(i2, rect.height() + B, mo4057G());
            i3 = m4231a(i, this.f2352c[this.f2352c.length - 1] + A, mo4056F());
        } else {
            i3 = m4231a(i, rect.width() + A, mo4056F());
            i4 = m4231a(i2, this.f2352c[this.f2352c.length - 1] + B, mo4057G());
        }
        mo4113f(i3, i4);
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo3167a(C0835p pVar, C0843u uVar, C0700a aVar, int i) {
        super.mo3167a(pVar, uVar, aVar, i);
        m3255M();
        if (uVar.mo4227e() > 0 && !uVar.mo4223a()) {
            m3264b(pVar, uVar, aVar, i);
        }
        m3256N();
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo3168a(C0835p pVar, C0843u uVar, C0702c cVar, C0701b bVar) {
        int i;
        int i2;
        int i3;
        int i4;
        int i5;
        int i6;
        int i7;
        int i8;
        boolean z;
        C0835p pVar2 = pVar;
        C0843u uVar2 = uVar;
        C0702c cVar2 = cVar;
        C0701b bVar2 = bVar;
        int i9 = this.f2371j.mo3831i();
        boolean z2 = i9 != 1073741824;
        int i10 = mo4134v() > 0 ? this.f2352c[this.f2351b] : 0;
        if (z2) {
            m3255M();
        }
        boolean z3 = cVar2.f2390e == 1;
        int i11 = this.f2351b;
        if (!z3) {
            i11 = m3263b(pVar2, uVar2, cVar2.f2389d) + m3265c(pVar2, uVar2, cVar2.f2389d);
        }
        int i12 = 0;
        int i13 = 0;
        while (i13 < this.f2351b && cVar2.mo3236a(uVar2) && i11 > 0) {
            int i14 = cVar2.f2389d;
            int c = m3265c(pVar2, uVar2, i14);
            if (c > this.f2351b) {
                StringBuilder sb = new StringBuilder();
                sb.append("Item at position ");
                sb.append(i14);
                sb.append(" requires ");
                sb.append(c);
                sb.append(" spans but GridLayoutManager has only ");
                sb.append(this.f2351b);
                sb.append(" spans.");
                throw new IllegalArgumentException(sb.toString());
            }
            i11 -= c;
            if (i11 < 0) {
                break;
            }
            View a = cVar2.mo3233a(pVar2);
            if (a == null) {
                break;
            }
            i12 += c;
            this.f2353d[i13] = a;
            i13++;
        }
        if (i13 == 0) {
            bVar2.f2383b = true;
            return;
        }
        float f = 0.0f;
        int i15 = i13;
        m3259a(pVar2, uVar2, i13, i12, z3);
        int i16 = 0;
        for (int i17 = 0; i17 < i15; i17++) {
            View view = this.f2353d[i17];
            if (cVar2.f2396k != null) {
                z = false;
                if (z3) {
                    mo4069a(view);
                } else {
                    mo4070a(view, 0);
                }
            } else if (z3) {
                mo4093b(view);
                z = false;
            } else {
                z = false;
                mo4094b(view, 0);
            }
            mo4095b(view, this.f2357h);
            m3261a(view, i9, z);
            int e = this.f2371j.mo3826e(view);
            if (e > i16) {
                i16 = e;
            }
            float f2 = (1.0f * ((float) this.f2371j.mo3828f(view))) / ((float) ((C0698b) view.getLayoutParams()).f2359b);
            if (f2 > f) {
                f = f2;
            }
        }
        if (z2) {
            m3258a(f, i10);
            i16 = 0;
            for (int i18 = 0; i18 < i15; i18++) {
                View view2 = this.f2353d[i18];
                m3261a(view2, 1073741824, true);
                int e2 = this.f2371j.mo3826e(view2);
                if (e2 > i16) {
                    i16 = e2;
                }
            }
        }
        for (int i19 = 0; i19 < i15; i19++) {
            View view3 = this.f2353d[i19];
            if (this.f2371j.mo3826e(view3) != i16) {
                C0698b bVar3 = (C0698b) view3.getLayoutParams();
                Rect rect = bVar3.f2964d;
                int i20 = rect.top + rect.bottom + bVar3.topMargin + bVar3.bottomMargin;
                int i21 = rect.left + rect.right + bVar3.leftMargin + bVar3.rightMargin;
                int a2 = mo3157a(bVar3.f2358a, bVar3.f2359b);
                if (this.f2370i == 1) {
                    int a3 = m4232a(a2, 1073741824, i21, bVar3.width, false);
                    i8 = MeasureSpec.makeMeasureSpec(i16 - i20, 1073741824);
                    i7 = a3;
                } else {
                    i7 = MeasureSpec.makeMeasureSpec(i16 - i21, 1073741824);
                    i8 = m4232a(a2, 1073741824, i20, bVar3.height, false);
                }
                m3260a(view3, i7, i8, true);
            }
        }
        int i22 = 0;
        bVar2.f2382a = i16;
        if (this.f2370i == 1) {
            if (cVar2.f2391f == -1) {
                int i23 = cVar2.f2387b;
                i = i23;
                i2 = i23 - i16;
            } else {
                int i24 = cVar2.f2387b;
                i2 = i24;
                i = i16 + i24;
            }
            i4 = 0;
            i3 = 0;
        } else if (cVar2.f2391f == -1) {
            int i25 = cVar2.f2387b;
            i2 = 0;
            i = 0;
            int i26 = i25 - i16;
            i3 = i25;
            i4 = i26;
        } else {
            i4 = cVar2.f2387b;
            i3 = i16 + i4;
            i2 = 0;
            i = 0;
        }
        while (i22 < i15) {
            View view4 = this.f2353d[i22];
            C0698b bVar4 = (C0698b) view4.getLayoutParams();
            if (this.f2370i != 1) {
                i2 = mo4052B() + this.f2352c[bVar4.f2358a];
                i = this.f2371j.mo3828f(view4) + i2;
            } else if (mo3219h()) {
                int A = mo4051A() + this.f2352c[this.f2351b - bVar4.f2358a];
                i5 = A;
                i6 = A - this.f2371j.mo3828f(view4);
                int i27 = i2;
                int i28 = i;
                mo4072a(view4, i6, i27, i5, i28);
                if (!bVar4.mo4145d() || bVar4.mo4146e()) {
                    bVar2.f2384c = true;
                }
                bVar2.f2385d |= view4.hasFocusable();
                i22++;
                i4 = i6;
                i2 = i27;
                i3 = i5;
                i = i28;
            } else {
                i4 = mo4051A() + this.f2352c[bVar4.f2358a];
                i3 = this.f2371j.mo3828f(view4) + i4;
            }
            i6 = i4;
            i5 = i3;
            int i272 = i2;
            int i282 = i;
            mo4072a(view4, i6, i272, i5, i282);
            if (!bVar4.mo4145d()) {
            }
            bVar2.f2384c = true;
            bVar2.f2385d |= view4.hasFocusable();
            i22++;
            i4 = i6;
            i2 = i272;
            i3 = i5;
            i = i282;
        }
        Arrays.fill(this.f2353d, null);
    }

    /* renamed from: a */
    public void mo3169a(C0835p pVar, C0843u uVar, View view, C0464c cVar) {
        int i;
        int a;
        int b;
        boolean z;
        boolean z2;
        int i2;
        LayoutParams layoutParams = view.getLayoutParams();
        if (!(layoutParams instanceof C0698b)) {
            super.mo4075a(view, cVar);
            return;
        }
        C0698b bVar = (C0698b) layoutParams;
        int a2 = m3257a(pVar, uVar, bVar.mo4147f());
        if (this.f2370i == 0) {
            int a3 = bVar.mo3185a();
            i = bVar.mo3186b();
            b = 1;
            z = this.f2351b > 1 && bVar.mo3186b() == this.f2351b;
            z2 = false;
            i2 = a3;
            a = a2;
        } else {
            i = 1;
            a = bVar.mo3185a();
            b = bVar.mo3186b();
            z = this.f2351b > 1 && bVar.mo3186b() == this.f2351b;
            z2 = false;
            i2 = a2;
        }
        cVar.mo1864b((Object) C0466b.m2039a(i2, i, a, b, z, z2));
    }

    /* renamed from: a */
    public void mo3170a(C0843u uVar) {
        super.mo3170a(uVar);
        this.f2350a = false;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo3171a(C0843u uVar, C0702c cVar, C0826a aVar) {
        int i = this.f2351b;
        for (int i2 = 0; i2 < this.f2351b && cVar.mo3236a(uVar) && i > 0; i2++) {
            int i3 = cVar.f2389d;
            aVar.mo3724b(i3, Math.max(0, cVar.f2392g));
            i -= this.f2356g.mo3183a(i3);
            cVar.f2389d += cVar.f2390e;
        }
    }

    /* renamed from: a */
    public void mo3172a(C0805ay ayVar) {
        this.f2356g.mo3187a();
    }

    /* renamed from: a */
    public void mo3173a(C0805ay ayVar, int i, int i2) {
        this.f2356g.mo3187a();
    }

    /* renamed from: a */
    public void mo3174a(C0805ay ayVar, int i, int i2, int i3) {
        this.f2356g.mo3187a();
    }

    /* renamed from: a */
    public void mo3175a(C0805ay ayVar, int i, int i2, Object obj) {
        this.f2356g.mo3187a();
    }

    /* renamed from: a */
    public void mo3176a(boolean z) {
        if (z) {
            throw new UnsupportedOperationException("GridLayoutManager does not support stack from end. Consider using reverse layout");
        }
        super.mo3176a(false);
    }

    /* renamed from: a */
    public boolean mo3177a(C0828j jVar) {
        return jVar instanceof C0698b;
    }

    /* renamed from: b */
    public int mo3178b(int i, C0835p pVar, C0843u uVar) {
        m3255M();
        m3256N();
        return super.mo3178b(i, pVar, uVar);
    }

    /* renamed from: b */
    public int mo3179b(C0835p pVar, C0843u uVar) {
        if (this.f2370i == 1) {
            return this.f2351b;
        }
        if (uVar.mo4227e() < 1) {
            return 0;
        }
        return m3257a(pVar, uVar, uVar.mo4227e() - 1) + 1;
    }

    /* renamed from: b */
    public void mo3180b(C0805ay ayVar, int i, int i2) {
        this.f2356g.mo3187a();
    }

    /* renamed from: b */
    public boolean mo3181b() {
        return this.f2375n == null && !this.f2350a;
    }

    /* renamed from: c */
    public void mo3182c(C0835p pVar, C0843u uVar) {
        if (uVar.mo4223a()) {
            m3254L();
        }
        super.mo3182c(pVar, uVar);
        m3253K();
    }
}
