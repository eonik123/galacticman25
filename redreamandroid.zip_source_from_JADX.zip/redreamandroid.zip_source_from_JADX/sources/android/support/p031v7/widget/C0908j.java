package android.support.p031v7.widget;

import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.PorterDuff.Mode;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.support.p018v4.graphics.drawable.C0441a;
import android.support.p018v4.widget.C0518c;
import android.support.p031v7.p032a.C0540a.C0550j;
import android.support.p031v7.p033b.p034a.C0606a;
import android.util.AttributeSet;
import android.widget.CompoundButton;

/* renamed from: android.support.v7.widget.j */
class C0908j {

    /* renamed from: a */
    private final CompoundButton f3281a;

    /* renamed from: b */
    private ColorStateList f3282b = null;

    /* renamed from: c */
    private Mode f3283c = null;

    /* renamed from: d */
    private boolean f3284d = false;

    /* renamed from: e */
    private boolean f3285e = false;

    /* renamed from: f */
    private boolean f3286f;

    C0908j(CompoundButton compoundButton) {
        this.f3281a = compoundButton;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public int mo4561a(int i) {
        if (VERSION.SDK_INT >= 17) {
            return i;
        }
        Drawable a = C0518c.m2301a(this.f3281a);
        return a != null ? i + a.getIntrinsicWidth() : i;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public ColorStateList mo4562a() {
        return this.f3282b;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo4563a(ColorStateList colorStateList) {
        this.f3282b = colorStateList;
        this.f3284d = true;
        mo4568d();
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo4564a(Mode mode) {
        this.f3283c = mode;
        this.f3285e = true;
        mo4568d();
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo4565a(AttributeSet attributeSet, int i) {
        TypedArray obtainStyledAttributes = this.f3281a.getContext().obtainStyledAttributes(attributeSet, C0550j.CompoundButton, i, 0);
        try {
            if (obtainStyledAttributes.hasValue(C0550j.CompoundButton_android_button)) {
                int resourceId = obtainStyledAttributes.getResourceId(C0550j.CompoundButton_android_button, 0);
                if (resourceId != 0) {
                    this.f3281a.setButtonDrawable(C0606a.m2714b(this.f3281a.getContext(), resourceId));
                }
            }
            if (obtainStyledAttributes.hasValue(C0550j.CompoundButton_buttonTint)) {
                C0518c.m2302a(this.f3281a, obtainStyledAttributes.getColorStateList(C0550j.CompoundButton_buttonTint));
            }
            if (obtainStyledAttributes.hasValue(C0550j.CompoundButton_buttonTintMode)) {
                C0518c.m2303a(this.f3281a, C0768al.m3839a(obtainStyledAttributes.getInt(C0550j.CompoundButton_buttonTintMode, -1), null));
            }
        } finally {
            obtainStyledAttributes.recycle();
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: b */
    public Mode mo4566b() {
        return this.f3283c;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: c */
    public void mo4567c() {
        if (this.f3286f) {
            this.f3286f = false;
            return;
        }
        this.f3286f = true;
        mo4568d();
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: d */
    public void mo4568d() {
        Drawable a = C0518c.m2301a(this.f3281a);
        if (a == null) {
            return;
        }
        if (this.f3284d || this.f3285e) {
            Drawable mutate = C0441a.m1938g(a).mutate();
            if (this.f3284d) {
                C0441a.m1927a(mutate, this.f3282b);
            }
            if (this.f3285e) {
                C0441a.m1930a(mutate, this.f3283c);
            }
            if (mutate.isStateful()) {
                mutate.setState(this.f3281a.getDrawableState());
            }
            this.f3281a.setButtonDrawable(mutate);
        }
    }
}
