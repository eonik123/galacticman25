package android.support.p031v7.widget;

import android.content.Context;
import android.os.Build.VERSION;
import android.support.p018v4.widget.C0529k;
import android.support.p031v7.p032a.C0540a.C0550j;
import android.util.AttributeSet;
import android.view.View;
import android.widget.PopupWindow;

/* renamed from: android.support.v7.widget.r */
class C0921r extends PopupWindow {

    /* renamed from: a */
    private static final boolean f3315a = (VERSION.SDK_INT < 21);

    /* renamed from: b */
    private boolean f3316b;

    public C0921r(Context context, AttributeSet attributeSet, int i, int i2) {
        super(context, attributeSet, i, i2);
        m4916a(context, attributeSet, i, i2);
    }

    /* renamed from: a */
    private void m4916a(Context context, AttributeSet attributeSet, int i, int i2) {
        C0869bn a = C0869bn.m4638a(context, attributeSet, C0550j.PopupWindow, i, i2);
        if (a.mo4440g(C0550j.PopupWindow_overlapAnchor)) {
            m4917a(a.mo4428a(C0550j.PopupWindow_overlapAnchor, false));
        }
        setBackgroundDrawable(a.mo4426a(C0550j.PopupWindow_android_popupBackground));
        a.mo4427a();
    }

    /* renamed from: a */
    private void m4917a(boolean z) {
        if (f3315a) {
            this.f3316b = z;
        } else {
            C0529k.m2340a((PopupWindow) this, z);
        }
    }

    public void showAsDropDown(View view, int i, int i2) {
        if (f3315a && this.f3316b) {
            i2 -= view.getHeight();
        }
        super.showAsDropDown(view, i, i2);
    }

    public void showAsDropDown(View view, int i, int i2, int i3) {
        if (f3315a && this.f3316b) {
            i2 -= view.getHeight();
        }
        super.showAsDropDown(view, i, i2, i3);
    }

    public void update(View view, int i, int i2, int i3, int i4) {
        if (f3315a && this.f3316b) {
            i2 -= view.getHeight();
        }
        super.update(view, i, i2, i3, i4);
    }
}
