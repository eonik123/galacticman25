package android.support.p031v7.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff.Mode;
import android.graphics.drawable.Drawable;
import android.support.p018v4.widget.C0533n;
import android.support.p031v7.p032a.C0540a.C0541a;
import android.support.p031v7.p033b.p034a.C0606a;
import android.util.AttributeSet;
import android.widget.RadioButton;

/* renamed from: android.support.v7.widget.t */
public class C0923t extends RadioButton implements C0533n {

    /* renamed from: a */
    private final C0908j f3320a;

    /* renamed from: b */
    private final C0934y f3321b;

    public C0923t(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, C0541a.radioButtonStyle);
    }

    public C0923t(Context context, AttributeSet attributeSet, int i) {
        super(C0866bk.m4633a(context), attributeSet, i);
        this.f3320a = new C0908j(this);
        this.f3320a.mo4565a(attributeSet, i);
        this.f3321b = new C0934y(this);
        this.f3321b.mo4679a(attributeSet, i);
    }

    public int getCompoundPaddingLeft() {
        int compoundPaddingLeft = super.getCompoundPaddingLeft();
        return this.f3320a != null ? this.f3320a.mo4561a(compoundPaddingLeft) : compoundPaddingLeft;
    }

    public ColorStateList getSupportButtonTintList() {
        if (this.f3320a != null) {
            return this.f3320a.mo4562a();
        }
        return null;
    }

    public Mode getSupportButtonTintMode() {
        if (this.f3320a != null) {
            return this.f3320a.mo4566b();
        }
        return null;
    }

    public void setButtonDrawable(int i) {
        setButtonDrawable(C0606a.m2714b(getContext(), i));
    }

    public void setButtonDrawable(Drawable drawable) {
        super.setButtonDrawable(drawable);
        if (this.f3320a != null) {
            this.f3320a.mo4567c();
        }
    }

    public void setSupportButtonTintList(ColorStateList colorStateList) {
        if (this.f3320a != null) {
            this.f3320a.mo4563a(colorStateList);
        }
    }

    public void setSupportButtonTintMode(Mode mode) {
        if (this.f3320a != null) {
            this.f3320a.mo4564a(mode);
        }
    }
}
