package android.support.p031v7.widget;

import android.content.res.ColorStateList;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;

/* renamed from: android.support.v7.widget.ae */
class C0748ae implements C0751ag {

    /* renamed from: a */
    final RectF f2620a = new RectF();

    C0748ae() {
    }

    /* renamed from: j */
    private C0852bc m3707j(C0750af afVar) {
        return (C0852bc) afVar.mo3569a();
    }

    /* renamed from: a */
    public float mo3555a(C0750af afVar) {
        return m3707j(afVar).mo4350c();
    }

    /* renamed from: a */
    public void mo3553a() {
        C0852bc.f3057a = new C0853a() {
            /* renamed from: a */
            public void mo3554a(Canvas canvas, RectF rectF, float f, Paint paint) {
                Canvas canvas2 = canvas;
                RectF rectF2 = rectF;
                float f2 = 2.0f * f;
                float width = (rectF.width() - f2) - 1.0f;
                float height = (rectF.height() - f2) - 1.0f;
                if (f >= 1.0f) {
                    float f3 = f + 0.5f;
                    float f4 = -f3;
                    C0748ae.this.f2620a.set(f4, f4, f3, f3);
                    int save = canvas.save();
                    canvas2.translate(rectF2.left + f3, rectF2.top + f3);
                    canvas2.drawArc(C0748ae.this.f2620a, 180.0f, 90.0f, true, paint);
                    canvas2.translate(width, 0.0f);
                    canvas2.rotate(90.0f);
                    Paint paint2 = paint;
                    canvas2.drawArc(C0748ae.this.f2620a, 180.0f, 90.0f, true, paint2);
                    canvas2.translate(height, 0.0f);
                    canvas2.rotate(90.0f);
                    canvas2.drawArc(C0748ae.this.f2620a, 180.0f, 90.0f, true, paint2);
                    canvas2.translate(width, 0.0f);
                    canvas2.rotate(90.0f);
                    canvas2.drawArc(C0748ae.this.f2620a, 180.0f, 90.0f, true, paint2);
                    canvas2.restoreToCount(save);
                    canvas2.drawRect((rectF2.left + f3) - 1.0f, rectF2.top, (rectF2.right - f3) + 1.0f, rectF2.top + f3, paint);
                    canvas2.drawRect((rectF2.left + f3) - 1.0f, rectF2.bottom - f3, (rectF2.right - f3) + 1.0f, rectF2.bottom, paint);
                }
                canvas2.drawRect(rectF2.left, rectF2.top + f, rectF2.right, rectF2.bottom - f, paint);
            }
        };
    }

    /* renamed from: a */
    public void mo3556a(C0750af afVar, float f) {
        m3707j(afVar).mo4344a(f);
        mo3568f(afVar);
    }

    /* renamed from: a */
    public void mo3557a(C0750af afVar, ColorStateList colorStateList) {
        m3707j(afVar).mo4345a(colorStateList);
    }

    /* renamed from: b */
    public float mo3558b(C0750af afVar) {
        return m3707j(afVar).mo4352d();
    }

    /* renamed from: b */
    public void mo3559b(C0750af afVar, float f) {
        m3707j(afVar).mo4351c(f);
        mo3568f(afVar);
    }

    /* renamed from: c */
    public float mo3560c(C0750af afVar) {
        return m3707j(afVar).mo4354e();
    }

    /* renamed from: c */
    public void mo3561c(C0750af afVar, float f) {
        m3707j(afVar).mo4349b(f);
    }

    /* renamed from: d */
    public float mo3562d(C0750af afVar) {
        return m3707j(afVar).mo4343a();
    }

    /* renamed from: e */
    public float mo3563e(C0750af afVar) {
        return m3707j(afVar).mo4348b();
    }

    /* renamed from: f */
    public void mo3568f(C0750af afVar) {
        Rect rect = new Rect();
        m3707j(afVar).mo4346a(rect);
        afVar.mo3570a((int) Math.ceil((double) mo3558b(afVar)), (int) Math.ceil((double) mo3560c(afVar)));
        afVar.mo3571a(rect.left, rect.top, rect.right, rect.bottom);
    }

    /* renamed from: g */
    public void mo3565g(C0750af afVar) {
    }

    /* renamed from: h */
    public void mo3566h(C0750af afVar) {
        m3707j(afVar).mo4347a(afVar.mo3573c());
        mo3568f(afVar);
    }

    /* renamed from: i */
    public ColorStateList mo3567i(C0750af afVar) {
        return m3707j(afVar).mo4355f();
    }
}
