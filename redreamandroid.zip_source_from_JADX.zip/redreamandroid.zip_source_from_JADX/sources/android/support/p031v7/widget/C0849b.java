package android.support.p031v7.widget;

import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Outline;
import android.graphics.drawable.Drawable;

/* renamed from: android.support.v7.widget.b */
class C0849b extends Drawable {

    /* renamed from: a */
    final ActionBarContainer f3044a;

    public C0849b(ActionBarContainer actionBarContainer) {
        this.f3044a = actionBarContainer;
    }

    public void draw(Canvas canvas) {
        Drawable drawable;
        if (this.f3044a.f2241d) {
            if (this.f3044a.f2240c != null) {
                drawable = this.f3044a.f2240c;
            }
            return;
        }
        if (this.f3044a.f2238a != null) {
            this.f3044a.f2238a.draw(canvas);
        }
        if (this.f3044a.f2239b != null && this.f3044a.f2242e) {
            drawable = this.f3044a.f2239b;
        }
        return;
        drawable.draw(canvas);
    }

    public int getOpacity() {
        return 0;
    }

    public void getOutline(Outline outline) {
        Drawable drawable;
        if (this.f3044a.f2241d) {
            if (this.f3044a.f2240c != null) {
                drawable = this.f3044a.f2240c;
            }
            return;
        }
        if (this.f3044a.f2238a != null) {
            drawable = this.f3044a.f2238a;
        }
        return;
        drawable.getOutline(outline);
    }

    public void setAlpha(int i) {
    }

    public void setColorFilter(ColorFilter colorFilter) {
    }
}
