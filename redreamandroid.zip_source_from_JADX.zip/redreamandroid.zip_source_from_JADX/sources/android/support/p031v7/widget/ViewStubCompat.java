package android.support.p031v7.widget;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.support.p031v7.p032a.C0540a.C0550j;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewParent;
import java.lang.ref.WeakReference;

/* renamed from: android.support.v7.widget.ViewStubCompat */
public final class ViewStubCompat extends View {

    /* renamed from: a */
    private int f2583a;

    /* renamed from: b */
    private int f2584b;

    /* renamed from: c */
    private WeakReference<View> f2585c;

    /* renamed from: d */
    private LayoutInflater f2586d;

    /* renamed from: e */
    private C0740a f2587e;

    /* renamed from: android.support.v7.widget.ViewStubCompat$a */
    public interface C0740a {
        /* renamed from: a */
        void mo3514a(ViewStubCompat viewStubCompat, View view);
    }

    public ViewStubCompat(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public ViewStubCompat(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f2583a = 0;
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, C0550j.ViewStubCompat, i, 0);
        this.f2584b = obtainStyledAttributes.getResourceId(C0550j.ViewStubCompat_android_inflatedId, -1);
        this.f2583a = obtainStyledAttributes.getResourceId(C0550j.ViewStubCompat_android_layout, 0);
        setId(obtainStyledAttributes.getResourceId(C0550j.ViewStubCompat_android_id, -1));
        obtainStyledAttributes.recycle();
        setVisibility(8);
        setWillNotDraw(true);
    }

    /* renamed from: a */
    public View mo3502a() {
        ViewParent parent = getParent();
        if (parent == null || !(parent instanceof ViewGroup)) {
            throw new IllegalStateException("ViewStub must have a non-null ViewGroup viewParent");
        } else if (this.f2583a != 0) {
            ViewGroup viewGroup = (ViewGroup) parent;
            View inflate = (this.f2586d != null ? this.f2586d : LayoutInflater.from(getContext())).inflate(this.f2583a, viewGroup, false);
            if (this.f2584b != -1) {
                inflate.setId(this.f2584b);
            }
            int indexOfChild = viewGroup.indexOfChild(this);
            viewGroup.removeViewInLayout(this);
            LayoutParams layoutParams = getLayoutParams();
            if (layoutParams != null) {
                viewGroup.addView(inflate, indexOfChild, layoutParams);
            } else {
                viewGroup.addView(inflate, indexOfChild);
            }
            this.f2585c = new WeakReference<>(inflate);
            if (this.f2587e != null) {
                this.f2587e.mo3514a(this, inflate);
            }
            return inflate;
        } else {
            throw new IllegalArgumentException("ViewStub must have a valid layoutResource");
        }
    }

    /* access modifiers changed from: protected */
    public void dispatchDraw(Canvas canvas) {
    }

    @SuppressLint({"MissingSuperCall"})
    public void draw(Canvas canvas) {
    }

    public int getInflatedId() {
        return this.f2584b;
    }

    public LayoutInflater getLayoutInflater() {
        return this.f2586d;
    }

    public int getLayoutResource() {
        return this.f2583a;
    }

    /* access modifiers changed from: protected */
    public void onMeasure(int i, int i2) {
        setMeasuredDimension(0, 0);
    }

    public void setInflatedId(int i) {
        this.f2584b = i;
    }

    public void setLayoutInflater(LayoutInflater layoutInflater) {
        this.f2586d = layoutInflater;
    }

    public void setLayoutResource(int i) {
        this.f2583a = i;
    }

    public void setOnInflateListener(C0740a aVar) {
        this.f2587e = aVar;
    }

    public void setVisibility(int i) {
        if (this.f2585c != null) {
            View view = (View) this.f2585c.get();
            if (view != null) {
                view.setVisibility(i);
                return;
            }
            throw new IllegalStateException("setVisibility called on un-referenced view");
        }
        super.setVisibility(i);
        if (i == 0 || i == 4) {
            mo3502a();
        }
    }
}
