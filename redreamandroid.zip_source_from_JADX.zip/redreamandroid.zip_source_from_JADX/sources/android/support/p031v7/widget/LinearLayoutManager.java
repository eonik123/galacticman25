package android.support.p031v7.widget;

import android.content.Context;
import android.graphics.PointF;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.support.p031v7.widget.C0805ay.C0823i;
import android.support.p031v7.widget.C0805ay.C0823i.C0826a;
import android.support.p031v7.widget.C0805ay.C0823i.C0827b;
import android.support.p031v7.widget.C0805ay.C0828j;
import android.support.p031v7.widget.C0805ay.C0835p;
import android.support.p031v7.widget.C0805ay.C0840t.C0842b;
import android.support.p031v7.widget.C0805ay.C0843u;
import android.support.p031v7.widget.C0805ay.C0846x;
import android.util.AttributeSet;
import android.view.View;
import android.view.accessibility.AccessibilityEvent;
import java.util.List;

/* renamed from: android.support.v7.widget.LinearLayoutManager */
public class LinearLayoutManager extends C0823i implements C0842b {

    /* renamed from: a */
    private C0702c f2362a;

    /* renamed from: b */
    private boolean f2363b;

    /* renamed from: c */
    private boolean f2364c = false;

    /* renamed from: d */
    private boolean f2365d = false;

    /* renamed from: e */
    private boolean f2366e = true;

    /* renamed from: f */
    private boolean f2367f;

    /* renamed from: g */
    private final C0701b f2368g = new C0701b();

    /* renamed from: h */
    private int f2369h = 2;

    /* renamed from: i */
    int f2370i = 1;

    /* renamed from: j */
    C0802ax f2371j;

    /* renamed from: k */
    boolean f2372k = false;

    /* renamed from: l */
    int f2373l = -1;

    /* renamed from: m */
    int f2374m = Integer.MIN_VALUE;

    /* renamed from: n */
    C0703d f2375n = null;

    /* renamed from: o */
    final C0700a f2376o = new C0700a();

    /* renamed from: android.support.v7.widget.LinearLayoutManager$a */
    static class C0700a {

        /* renamed from: a */
        C0802ax f2377a;

        /* renamed from: b */
        int f2378b;

        /* renamed from: c */
        int f2379c;

        /* renamed from: d */
        boolean f2380d;

        /* renamed from: e */
        boolean f2381e;

        C0700a() {
            mo3226a();
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public void mo3226a() {
            this.f2378b = -1;
            this.f2379c = Integer.MIN_VALUE;
            this.f2380d = false;
            this.f2381e = false;
        }

        /* renamed from: a */
        public void mo3227a(View view, int i) {
            int b = this.f2377a.mo3819b();
            if (b >= 0) {
                mo3230b(view, i);
                return;
            }
            this.f2378b = i;
            if (this.f2380d) {
                int d = (this.f2377a.mo3823d() - b) - this.f2377a.mo3820b(view);
                this.f2379c = this.f2377a.mo3823d() - d;
                if (d > 0) {
                    int e = this.f2379c - this.f2377a.mo3826e(view);
                    int c = this.f2377a.mo3821c();
                    int min = e - (c + Math.min(this.f2377a.mo3816a(view) - c, 0));
                    if (min < 0) {
                        this.f2379c += Math.min(d, -min);
                    }
                }
            } else {
                int a = this.f2377a.mo3816a(view);
                int c2 = a - this.f2377a.mo3821c();
                this.f2379c = a;
                if (c2 > 0) {
                    int d2 = (this.f2377a.mo3823d() - Math.min(0, (this.f2377a.mo3823d() - b) - this.f2377a.mo3820b(view))) - (a + this.f2377a.mo3826e(view));
                    if (d2 < 0) {
                        this.f2379c -= Math.min(c2, -d2);
                    }
                }
            }
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public boolean mo3228a(View view, C0843u uVar) {
            C0828j jVar = (C0828j) view.getLayoutParams();
            return !jVar.mo4145d() && jVar.mo4147f() >= 0 && jVar.mo4147f() < uVar.mo4227e();
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: b */
        public void mo3229b() {
            this.f2379c = this.f2380d ? this.f2377a.mo3823d() : this.f2377a.mo3821c();
        }

        /* renamed from: b */
        public void mo3230b(View view, int i) {
            this.f2379c = this.f2380d ? this.f2377a.mo3820b(view) + this.f2377a.mo3819b() : this.f2377a.mo3816a(view);
            this.f2378b = i;
        }

        public String toString() {
            StringBuilder sb = new StringBuilder();
            sb.append("AnchorInfo{mPosition=");
            sb.append(this.f2378b);
            sb.append(", mCoordinate=");
            sb.append(this.f2379c);
            sb.append(", mLayoutFromEnd=");
            sb.append(this.f2380d);
            sb.append(", mValid=");
            sb.append(this.f2381e);
            sb.append('}');
            return sb.toString();
        }
    }

    /* renamed from: android.support.v7.widget.LinearLayoutManager$b */
    protected static class C0701b {

        /* renamed from: a */
        public int f2382a;

        /* renamed from: b */
        public boolean f2383b;

        /* renamed from: c */
        public boolean f2384c;

        /* renamed from: d */
        public boolean f2385d;

        protected C0701b() {
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public void mo3232a() {
            this.f2382a = 0;
            this.f2383b = false;
            this.f2384c = false;
            this.f2385d = false;
        }
    }

    /* renamed from: android.support.v7.widget.LinearLayoutManager$c */
    static class C0702c {

        /* renamed from: a */
        boolean f2386a = true;

        /* renamed from: b */
        int f2387b;

        /* renamed from: c */
        int f2388c;

        /* renamed from: d */
        int f2389d;

        /* renamed from: e */
        int f2390e;

        /* renamed from: f */
        int f2391f;

        /* renamed from: g */
        int f2392g;

        /* renamed from: h */
        int f2393h = 0;

        /* renamed from: i */
        boolean f2394i = false;

        /* renamed from: j */
        int f2395j;

        /* renamed from: k */
        List<C0846x> f2396k = null;

        /* renamed from: l */
        boolean f2397l;

        C0702c() {
        }

        /* renamed from: b */
        private View m3387b() {
            int size = this.f2396k.size();
            for (int i = 0; i < size; i++) {
                View view = ((C0846x) this.f2396k.get(i)).f3023a;
                C0828j jVar = (C0828j) view.getLayoutParams();
                if (!jVar.mo4145d() && this.f2389d == jVar.mo4147f()) {
                    mo3235a(view);
                    return view;
                }
            }
            return null;
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public View mo3233a(C0835p pVar) {
            if (this.f2396k != null) {
                return m3387b();
            }
            View c = pVar.mo4182c(this.f2389d);
            this.f2389d += this.f2390e;
            return c;
        }

        /* renamed from: a */
        public void mo3234a() {
            mo3235a((View) null);
        }

        /* renamed from: a */
        public void mo3235a(View view) {
            View b = mo3237b(view);
            this.f2389d = b == null ? -1 : ((C0828j) b.getLayoutParams()).mo4147f();
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public boolean mo3236a(C0843u uVar) {
            return this.f2389d >= 0 && this.f2389d < uVar.mo4227e();
        }

        /* renamed from: b */
        public View mo3237b(View view) {
            int size = this.f2396k.size();
            View view2 = null;
            int i = Integer.MAX_VALUE;
            for (int i2 = 0; i2 < size; i2++) {
                View view3 = ((C0846x) this.f2396k.get(i2)).f3023a;
                C0828j jVar = (C0828j) view3.getLayoutParams();
                if (view3 != view && !jVar.mo4145d()) {
                    int f = (jVar.mo4147f() - this.f2389d) * this.f2390e;
                    if (f >= 0 && f < i) {
                        if (f == 0) {
                            return view3;
                        }
                        view2 = view3;
                        i = f;
                    }
                }
            }
            return view2;
        }
    }

    /* renamed from: android.support.v7.widget.LinearLayoutManager$d */
    public static class C0703d implements Parcelable {
        public static final Creator<C0703d> CREATOR = new Creator<C0703d>() {
            /* renamed from: a */
            public C0703d createFromParcel(Parcel parcel) {
                return new C0703d(parcel);
            }

            /* renamed from: a */
            public C0703d[] newArray(int i) {
                return new C0703d[i];
            }
        };

        /* renamed from: a */
        int f2398a;

        /* renamed from: b */
        int f2399b;

        /* renamed from: c */
        boolean f2400c;

        public C0703d() {
        }

        C0703d(Parcel parcel) {
            this.f2398a = parcel.readInt();
            this.f2399b = parcel.readInt();
            boolean z = true;
            if (parcel.readInt() != 1) {
                z = false;
            }
            this.f2400c = z;
        }

        public C0703d(C0703d dVar) {
            this.f2398a = dVar.f2398a;
            this.f2399b = dVar.f2399b;
            this.f2400c = dVar.f2400c;
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public boolean mo3238a() {
            return this.f2398a >= 0;
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: b */
        public void mo3239b() {
            this.f2398a = -1;
        }

        public int describeContents() {
            return 0;
        }

        public void writeToParcel(Parcel parcel, int i) {
            parcel.writeInt(this.f2398a);
            parcel.writeInt(this.f2399b);
            parcel.writeInt(this.f2400c ? 1 : 0);
        }
    }

    public LinearLayoutManager(Context context, int i, boolean z) {
        mo3201b(i);
        mo3202b(z);
    }

    public LinearLayoutManager(Context context, AttributeSet attributeSet, int i, int i2) {
        C0827b a = m4233a(context, attributeSet, i, i2);
        mo3201b(a.f2959a);
        mo3202b(a.f2961c);
        mo3176a(a.f2962d);
    }

    /* renamed from: K */
    private void m3303K() {
        this.f2372k = (this.f2370i == 1 || !mo3219h()) ? this.f2364c : !this.f2364c;
    }

    /* renamed from: L */
    private View m3304L() {
        return mo4120i(this.f2372k ? mo4134v() - 1 : 0);
    }

    /* renamed from: M */
    private View m3305M() {
        return mo4120i(this.f2372k ? 0 : mo4134v() - 1);
    }

    /* renamed from: a */
    private int m3306a(int i, C0835p pVar, C0843u uVar, boolean z) {
        int d = this.f2371j.mo3823d() - i;
        if (d <= 0) {
            return 0;
        }
        int i2 = -mo3203c(-d, pVar, uVar);
        int i3 = i + i2;
        if (z) {
            int d2 = this.f2371j.mo3823d() - i3;
            if (d2 > 0) {
                this.f2371j.mo3818a(d2);
                return d2 + i2;
            }
        }
        return i2;
    }

    /* renamed from: a */
    private View m3307a(boolean z, boolean z2) {
        int i;
        int v;
        if (this.f2372k) {
            i = mo4134v() - 1;
            v = -1;
        } else {
            i = 0;
            v = mo4134v();
        }
        return mo3192a(i, v, z, z2);
    }

    /* renamed from: a */
    private void mo3157a(int i, int i2) {
        this.f2362a.f2388c = this.f2371j.mo3823d() - i2;
        this.f2362a.f2390e = this.f2372k ? -1 : 1;
        this.f2362a.f2389d = i;
        this.f2362a.f2391f = 1;
        this.f2362a.f2387b = i2;
        this.f2362a.f2392g = Integer.MIN_VALUE;
    }

    /* renamed from: a */
    private void m3309a(int i, int i2, boolean z, C0843u uVar) {
        int i3;
        this.f2362a.f2397l = mo3222k();
        this.f2362a.f2393h = mo3199b(uVar);
        this.f2362a.f2391f = i;
        int i4 = -1;
        if (i == 1) {
            this.f2362a.f2393h += this.f2371j.mo3829g();
            View M = m3305M();
            C0702c cVar = this.f2362a;
            if (!this.f2372k) {
                i4 = 1;
            }
            cVar.f2390e = i4;
            this.f2362a.f2389d = mo4104d(M) + this.f2362a.f2390e;
            this.f2362a.f2387b = this.f2371j.mo3820b(M);
            i3 = this.f2371j.mo3820b(M) - this.f2371j.mo3823d();
        } else {
            View L = m3304L();
            this.f2362a.f2393h += this.f2371j.mo3821c();
            C0702c cVar2 = this.f2362a;
            if (this.f2372k) {
                i4 = 1;
            }
            cVar2.f2390e = i4;
            this.f2362a.f2389d = mo4104d(L) + this.f2362a.f2390e;
            this.f2362a.f2387b = this.f2371j.mo3816a(L);
            i3 = (-this.f2371j.mo3816a(L)) + this.f2371j.mo3821c();
        }
        this.f2362a.f2388c = i2;
        if (z) {
            this.f2362a.f2388c -= i3;
        }
        this.f2362a.f2392g = i3;
    }

    /* renamed from: a */
    private void m3310a(C0700a aVar) {
        mo3157a(aVar.f2378b, aVar.f2379c);
    }

    /* renamed from: a */
    private void m3311a(C0835p pVar, int i) {
        if (i >= 0) {
            int v = mo4134v();
            if (!this.f2372k) {
                int i2 = 0;
                while (true) {
                    if (i2 >= v) {
                        break;
                    }
                    View i3 = mo4120i(i2);
                    if (this.f2371j.mo3820b(i3) > i || this.f2371j.mo3822c(i3) > i) {
                        m3312a(pVar, 0, i2);
                    } else {
                        i2++;
                    }
                }
            } else {
                int i4 = v - 1;
                for (int i5 = i4; i5 >= 0; i5--) {
                    View i6 = mo4120i(i5);
                    if (this.f2371j.mo3820b(i6) > i || this.f2371j.mo3822c(i6) > i) {
                        m3312a(pVar, i4, i5);
                        return;
                    }
                }
            }
        }
    }

    /* renamed from: a */
    private void m3312a(C0835p pVar, int i, int i2) {
        if (i != i2) {
            if (i2 > i) {
                for (int i3 = i2 - 1; i3 >= i; i3--) {
                    mo4061a(i3, pVar);
                }
            } else {
                while (i > i2) {
                    mo4061a(i, pVar);
                    i--;
                }
            }
        }
    }

    /* renamed from: a */
    private void m3313a(C0835p pVar, C0702c cVar) {
        if (cVar.f2386a && !cVar.f2397l) {
            if (cVar.f2391f == -1) {
                m3319b(pVar, cVar.f2392g);
            } else {
                m3311a(pVar, cVar.f2392g);
            }
        }
    }

    /* renamed from: a */
    private void m3314a(C0835p pVar, C0843u uVar, C0700a aVar) {
        if (!m3315a(uVar, aVar) && !m3321b(pVar, uVar, aVar)) {
            aVar.mo3229b();
            aVar.f2378b = this.f2365d ? uVar.mo4227e() - 1 : 0;
        }
    }

    /* renamed from: a */
    private boolean m3315a(C0843u uVar, C0700a aVar) {
        boolean z = false;
        if (uVar.mo4223a() || this.f2373l == -1) {
            return false;
        }
        if (this.f2373l < 0 || this.f2373l >= uVar.mo4227e()) {
            this.f2373l = -1;
            this.f2374m = Integer.MIN_VALUE;
            return false;
        }
        aVar.f2378b = this.f2373l;
        if (this.f2375n != null && this.f2375n.mo3238a()) {
            aVar.f2380d = this.f2375n.f2400c;
            aVar.f2379c = aVar.f2380d ? this.f2371j.mo3823d() - this.f2375n.f2399b : this.f2371j.mo3821c() + this.f2375n.f2399b;
            return true;
        } else if (this.f2374m == Integer.MIN_VALUE) {
            View c = mo3205c(this.f2373l);
            if (c == null) {
                if (mo4134v() > 0) {
                    if ((this.f2373l < mo4104d(mo4120i(0))) == this.f2372k) {
                        z = true;
                    }
                    aVar.f2380d = z;
                }
                aVar.mo3229b();
                return true;
            } else if (this.f2371j.mo3826e(c) > this.f2371j.mo3827f()) {
                aVar.mo3229b();
                return true;
            } else if (this.f2371j.mo3816a(c) - this.f2371j.mo3821c() < 0) {
                aVar.f2379c = this.f2371j.mo3821c();
                aVar.f2380d = false;
                return true;
            } else if (this.f2371j.mo3823d() - this.f2371j.mo3820b(c) < 0) {
                aVar.f2379c = this.f2371j.mo3823d();
                aVar.f2380d = true;
                return true;
            } else {
                aVar.f2379c = aVar.f2380d ? this.f2371j.mo3820b(c) + this.f2371j.mo3819b() : this.f2371j.mo3816a(c);
                return true;
            }
        } else {
            aVar.f2380d = this.f2372k;
            aVar.f2379c = this.f2372k ? this.f2371j.mo3823d() - this.f2374m : this.f2371j.mo3821c() + this.f2374m;
            return true;
        }
    }

    /* renamed from: b */
    private int m3316b(int i, C0835p pVar, C0843u uVar, boolean z) {
        int c = i - this.f2371j.mo3821c();
        if (c <= 0) {
            return 0;
        }
        int i2 = -mo3203c(c, pVar, uVar);
        int i3 = i + i2;
        if (z) {
            int c2 = i3 - this.f2371j.mo3821c();
            if (c2 > 0) {
                this.f2371j.mo3818a(-c2);
                i2 -= c2;
            }
        }
        return i2;
    }

    /* renamed from: b */
    private View m3317b(boolean z, boolean z2) {
        int v;
        int i;
        if (this.f2372k) {
            v = 0;
            i = mo4134v();
        } else {
            v = mo4134v() - 1;
            i = -1;
        }
        return mo3192a(v, i, z, z2);
    }

    /* renamed from: b */
    private void m3318b(C0700a aVar) {
        m3324g(aVar.f2378b, aVar.f2379c);
    }

    /* renamed from: b */
    private void m3319b(C0835p pVar, int i) {
        int v = mo4134v();
        if (i >= 0) {
            int e = this.f2371j.mo3825e() - i;
            if (this.f2372k) {
                for (int i2 = 0; i2 < v; i2++) {
                    View i3 = mo4120i(i2);
                    if (this.f2371j.mo3816a(i3) < e || this.f2371j.mo3824d(i3) < e) {
                        m3312a(pVar, 0, i2);
                        return;
                    }
                }
            } else {
                int i4 = v - 1;
                int i5 = i4;
                while (true) {
                    if (i5 < 0) {
                        break;
                    }
                    View i6 = mo4120i(i5);
                    if (this.f2371j.mo3816a(i6) < e || this.f2371j.mo3824d(i6) < e) {
                        m3312a(pVar, i4, i5);
                    } else {
                        i5--;
                    }
                }
                m3312a(pVar, i4, i5);
            }
        }
    }

    /* renamed from: b */
    private void m3320b(C0835p pVar, C0843u uVar, int i, int i2) {
        C0835p pVar2 = pVar;
        C0843u uVar2 = uVar;
        if (uVar.mo4224b() && mo4134v() != 0 && !uVar.mo4223a() && mo3181b()) {
            List<C0846x> c = pVar.mo4183c();
            int size = c.size();
            int d = mo4104d(mo4120i(0));
            int i3 = 0;
            int i4 = 0;
            for (int i5 = 0; i5 < size; i5++) {
                C0846x xVar = (C0846x) c.get(i5);
                if (!xVar.mo4265q()) {
                    boolean z = true;
                    if ((xVar.mo4252d() < d) != this.f2372k) {
                        z = true;
                    }
                    if (z) {
                        i3 += this.f2371j.mo3826e(xVar.f3023a);
                    } else {
                        i4 += this.f2371j.mo3826e(xVar.f3023a);
                    }
                }
            }
            this.f2362a.f2396k = c;
            if (i3 > 0) {
                m3324g(mo4104d(m3304L()), i);
                this.f2362a.f2393h = i3;
                this.f2362a.f2388c = 0;
                this.f2362a.mo3234a();
                mo3191a(pVar2, this.f2362a, uVar2, false);
            }
            if (i4 > 0) {
                mo3157a(mo4104d(m3305M()), i2);
                this.f2362a.f2393h = i4;
                this.f2362a.f2388c = 0;
                this.f2362a.mo3234a();
                mo3191a(pVar2, this.f2362a, uVar2, false);
            }
            this.f2362a.f2396k = null;
        }
    }

    /* renamed from: b */
    private boolean m3321b(C0835p pVar, C0843u uVar, C0700a aVar) {
        boolean z = false;
        if (mo4134v() == 0) {
            return false;
        }
        View E = mo4055E();
        if (E != null && aVar.mo3228a(E, uVar)) {
            aVar.mo3227a(E, mo4104d(E));
            return true;
        } else if (this.f2363b != this.f2365d) {
            return false;
        } else {
            View f = aVar.f2380d ? m3322f(pVar, uVar) : m3323g(pVar, uVar);
            if (f == null) {
                return false;
            }
            aVar.mo3230b(f, mo4104d(f));
            if (!uVar.mo4223a() && mo3181b()) {
                if (this.f2371j.mo3816a(f) >= this.f2371j.mo3823d() || this.f2371j.mo3820b(f) < this.f2371j.mo3821c()) {
                    z = true;
                }
                if (z) {
                    aVar.f2379c = aVar.f2380d ? this.f2371j.mo3823d() : this.f2371j.mo3821c();
                }
            }
            return true;
        }
    }

    /* renamed from: f */
    private View m3322f(C0835p pVar, C0843u uVar) {
        return this.f2372k ? m3325h(pVar, uVar) : m3327i(pVar, uVar);
    }

    /* renamed from: g */
    private View m3323g(C0835p pVar, C0843u uVar) {
        return this.f2372k ? m3327i(pVar, uVar) : m3325h(pVar, uVar);
    }

    /* renamed from: g */
    private void m3324g(int i, int i2) {
        this.f2362a.f2388c = i2 - this.f2371j.mo3821c();
        this.f2362a.f2389d = i;
        this.f2362a.f2390e = this.f2372k ? 1 : -1;
        this.f2362a.f2391f = -1;
        this.f2362a.f2387b = i2;
        this.f2362a.f2392g = Integer.MIN_VALUE;
    }

    /* renamed from: h */
    private View m3325h(C0835p pVar, C0843u uVar) {
        return mo3163a(pVar, uVar, 0, mo4134v(), uVar.mo4227e());
    }

    /* renamed from: i */
    private int m3326i(C0843u uVar) {
        if (mo4134v() == 0) {
            return 0;
        }
        mo3220i();
        C0802ax axVar = this.f2371j;
        View a = m3307a(!this.f2366e, true);
        return C0855be.m4567a(uVar, axVar, a, m3317b(!this.f2366e, true), this, this.f2366e, this.f2372k);
    }

    /* renamed from: i */
    private View m3327i(C0835p pVar, C0843u uVar) {
        return mo3163a(pVar, uVar, mo4134v() - 1, -1, uVar.mo4227e());
    }

    /* renamed from: j */
    private int m3328j(C0843u uVar) {
        if (mo4134v() == 0) {
            return 0;
        }
        mo3220i();
        C0802ax axVar = this.f2371j;
        View a = m3307a(!this.f2366e, true);
        return C0855be.m4566a(uVar, axVar, a, m3317b(!this.f2366e, true), this, this.f2366e);
    }

    /* renamed from: j */
    private View m3329j(C0835p pVar, C0843u uVar) {
        return this.f2372k ? m3332l(pVar, uVar) : m3333m(pVar, uVar);
    }

    /* renamed from: k */
    private int m3330k(C0843u uVar) {
        if (mo4134v() == 0) {
            return 0;
        }
        mo3220i();
        C0802ax axVar = this.f2371j;
        View a = m3307a(!this.f2366e, true);
        return C0855be.m4568b(uVar, axVar, a, m3317b(!this.f2366e, true), this, this.f2366e);
    }

    /* renamed from: k */
    private View m3331k(C0835p pVar, C0843u uVar) {
        return this.f2372k ? m3333m(pVar, uVar) : m3332l(pVar, uVar);
    }

    /* renamed from: l */
    private View m3332l(C0835p pVar, C0843u uVar) {
        return mo3200b(0, mo4134v());
    }

    /* renamed from: m */
    private View m3333m(C0835p pVar, C0843u uVar) {
        return mo3200b(mo4134v() - 1, -1);
    }

    /* renamed from: a */
    public int mo3158a(int i, C0835p pVar, C0843u uVar) {
        if (this.f2370i == 1) {
            return 0;
        }
        return mo3203c(i, pVar, uVar);
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public int mo3191a(C0835p pVar, C0702c cVar, C0843u uVar, boolean z) {
        int i = cVar.f2388c;
        if (cVar.f2392g != Integer.MIN_VALUE) {
            if (cVar.f2388c < 0) {
                cVar.f2392g += cVar.f2388c;
            }
            m3313a(pVar, cVar);
        }
        int i2 = cVar.f2388c + cVar.f2393h;
        C0701b bVar = this.f2368g;
        while (true) {
            if ((!cVar.f2397l && i2 <= 0) || !cVar.mo3236a(uVar)) {
                break;
            }
            bVar.mo3232a();
            mo3168a(pVar, uVar, cVar, bVar);
            if (!bVar.f2383b) {
                cVar.f2387b += bVar.f2382a * cVar.f2391f;
                if (!bVar.f2384c || this.f2362a.f2396k != null || !uVar.mo4223a()) {
                    cVar.f2388c -= bVar.f2382a;
                    i2 -= bVar.f2382a;
                }
                if (cVar.f2392g != Integer.MIN_VALUE) {
                    cVar.f2392g += bVar.f2382a;
                    if (cVar.f2388c < 0) {
                        cVar.f2392g += cVar.f2388c;
                    }
                    m3313a(pVar, cVar);
                }
                if (z && bVar.f2385d) {
                    break;
                }
            } else {
                break;
            }
        }
        return i - cVar.f2388c;
    }

    /* renamed from: a */
    public C0828j mo3160a() {
        return new C0828j(-2, -2);
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public View mo3192a(int i, int i2, boolean z, boolean z2) {
        mo3220i();
        int i3 = 320;
        int i4 = z ? 24579 : 320;
        if (!z2) {
            i3 = 0;
        }
        return (this.f2370i == 0 ? this.f2949r : this.f2950s).mo4463a(i, i2, i4, i3);
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public View mo3163a(C0835p pVar, C0843u uVar, int i, int i2, int i3) {
        mo3220i();
        int c = this.f2371j.mo3821c();
        int d = this.f2371j.mo3823d();
        int i4 = i2 > i ? 1 : -1;
        View view = null;
        View view2 = null;
        while (i != i2) {
            View i5 = mo4120i(i);
            int d2 = mo4104d(i5);
            if (d2 >= 0 && d2 < i3) {
                if (((C0828j) i5.getLayoutParams()).mo4145d()) {
                    if (view2 == null) {
                        view2 = i5;
                    }
                } else if (this.f2371j.mo3816a(i5) < d && this.f2371j.mo3820b(i5) >= c) {
                    return i5;
                } else {
                    if (view == null) {
                        view = i5;
                    }
                }
            }
            i += i4;
        }
        return view != null ? view : view2;
    }

    /* renamed from: a */
    public View mo3164a(View view, int i, C0835p pVar, C0843u uVar) {
        m3303K();
        if (mo4134v() == 0) {
            return null;
        }
        int f = mo3213f(i);
        if (f == Integer.MIN_VALUE) {
            return null;
        }
        mo3220i();
        mo3220i();
        m3309a(f, (int) (0.33333334f * ((float) this.f2371j.mo3827f())), false, uVar);
        this.f2362a.f2392g = Integer.MIN_VALUE;
        this.f2362a.f2386a = false;
        mo3191a(pVar, this.f2362a, uVar, true);
        View k = f == -1 ? m3331k(pVar, uVar) : m3329j(pVar, uVar);
        View L = f == -1 ? m3304L() : m3305M();
        if (!L.hasFocusable()) {
            return k;
        }
        if (k == null) {
            return null;
        }
        return L;
    }

    /* renamed from: a */
    public void mo3193a(int i, int i2, C0843u uVar, C0826a aVar) {
        if (this.f2370i != 0) {
            i = i2;
        }
        if (mo4134v() != 0 && i != 0) {
            mo3220i();
            m3309a(i > 0 ? 1 : -1, Math.abs(i), true, uVar);
            mo3171a(uVar, this.f2362a, aVar);
        }
    }

    /* renamed from: a */
    public void mo3194a(int i, C0826a aVar) {
        int i2;
        boolean z;
        int i3 = -1;
        if (this.f2375n == null || !this.f2375n.mo3238a()) {
            m3303K();
            z = this.f2372k;
            i2 = this.f2373l == -1 ? z ? i - 1 : 0 : this.f2373l;
        } else {
            z = this.f2375n.f2400c;
            i2 = this.f2375n.f2398a;
        }
        if (!z) {
            i3 = 1;
        }
        for (int i4 = 0; i4 < this.f2369h && i2 >= 0 && i2 < i; i4++) {
            aVar.mo3724b(i2, 0);
            i2 += i3;
        }
    }

    /* renamed from: a */
    public void mo3195a(Parcelable parcelable) {
        if (parcelable instanceof C0703d) {
            this.f2375n = (C0703d) parcelable;
            mo4127o();
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo3167a(C0835p pVar, C0843u uVar, C0700a aVar, int i) {
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo3168a(C0835p pVar, C0843u uVar, C0702c cVar, C0701b bVar) {
        int i;
        int i2;
        int i3;
        int i4;
        int i5;
        View a = cVar.mo3233a(pVar);
        if (a == null) {
            bVar.f2383b = true;
            return;
        }
        C0828j jVar = (C0828j) a.getLayoutParams();
        if (cVar.f2396k == null) {
            if (this.f2372k == (cVar.f2391f == -1)) {
                mo4093b(a);
            } else {
                mo4094b(a, 0);
            }
        } else {
            if (this.f2372k == (cVar.f2391f == -1)) {
                mo4069a(a);
            } else {
                mo4070a(a, 0);
            }
        }
        mo4071a(a, 0, 0);
        bVar.f2382a = this.f2371j.mo3826e(a);
        if (this.f2370i == 1) {
            if (mo3219h()) {
                i5 = mo4137y() - mo4053C();
                i4 = i5 - this.f2371j.mo3828f(a);
            } else {
                i4 = mo4051A();
                i5 = this.f2371j.mo3828f(a) + i4;
            }
            if (cVar.f2391f == -1) {
                i3 = cVar.f2387b - bVar.f2382a;
                i2 = i5;
                i = cVar.f2387b;
            } else {
                i = cVar.f2387b + bVar.f2382a;
                i2 = i5;
                i3 = cVar.f2387b;
            }
        } else {
            int B = mo4052B();
            int f = this.f2371j.mo3828f(a) + B;
            if (cVar.f2391f == -1) {
                i3 = B;
                i2 = cVar.f2387b;
                i = f;
                i4 = cVar.f2387b - bVar.f2382a;
            } else {
                i2 = cVar.f2387b + bVar.f2382a;
                i3 = B;
                i = f;
                i4 = cVar.f2387b;
            }
        }
        mo4072a(a, i4, i3, i2, i);
        if (jVar.mo4145d() || jVar.mo4146e()) {
            bVar.f2384c = true;
        }
        bVar.f2385d = a.hasFocusable();
    }

    /* renamed from: a */
    public void mo3170a(C0843u uVar) {
        super.mo3170a(uVar);
        this.f2375n = null;
        this.f2373l = -1;
        this.f2374m = Integer.MIN_VALUE;
        this.f2376o.mo3226a();
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo3171a(C0843u uVar, C0702c cVar, C0826a aVar) {
        int i = cVar.f2389d;
        if (i >= 0 && i < uVar.mo4227e()) {
            aVar.mo3724b(i, Math.max(0, cVar.f2392g));
        }
    }

    /* renamed from: a */
    public void mo3196a(C0805ay ayVar, C0835p pVar) {
        super.mo3196a(ayVar, pVar);
        if (this.f2367f) {
            mo4098c(pVar);
            pVar.mo4166a();
        }
    }

    /* renamed from: a */
    public void mo3197a(AccessibilityEvent accessibilityEvent) {
        super.mo3197a(accessibilityEvent);
        if (mo4134v() > 0) {
            accessibilityEvent.setFromIndex(mo3224m());
            accessibilityEvent.setToIndex(mo3225n());
        }
    }

    /* renamed from: a */
    public void mo3198a(String str) {
        if (this.f2375n == null) {
            super.mo3198a(str);
        }
    }

    /* renamed from: a */
    public void mo3176a(boolean z) {
        mo3198a((String) null);
        if (this.f2365d != z) {
            this.f2365d = z;
            mo4127o();
        }
    }

    /* renamed from: b */
    public int mo3178b(int i, C0835p pVar, C0843u uVar) {
        if (this.f2370i == 0) {
            return 0;
        }
        return mo3203c(i, pVar, uVar);
    }

    /* access modifiers changed from: protected */
    /* renamed from: b */
    public int mo3199b(C0843u uVar) {
        if (uVar.mo4226d()) {
            return this.f2371j.mo3827f();
        }
        return 0;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: b */
    public View mo3200b(int i, int i2) {
        int i3;
        int i4;
        mo3220i();
        char c = i2 > i ? 1 : i2 < i ? (char) 65535 : 0;
        if (c == 0) {
            return mo4120i(i);
        }
        if (this.f2371j.mo3816a(mo4120i(i)) < this.f2371j.mo3821c()) {
            i4 = 16644;
            i3 = 16388;
        } else {
            i4 = 4161;
            i3 = 4097;
        }
        return (this.f2370i == 0 ? this.f2949r : this.f2950s).mo4463a(i, i2, i4, i3);
    }

    /* renamed from: b */
    public void mo3201b(int i) {
        if (i == 0 || i == 1) {
            mo3198a((String) null);
            if (i != this.f2370i || this.f2371j == null) {
                this.f2371j = C0802ax.m3987a(this, i);
                this.f2376o.f2377a = this.f2371j;
                this.f2370i = i;
                mo4127o();
                return;
            }
            return;
        }
        StringBuilder sb = new StringBuilder();
        sb.append("invalid orientation:");
        sb.append(i);
        throw new IllegalArgumentException(sb.toString());
    }

    /* renamed from: b */
    public void mo3202b(boolean z) {
        mo3198a((String) null);
        if (z != this.f2364c) {
            this.f2364c = z;
            mo4127o();
        }
    }

    /* renamed from: b */
    public boolean mo3181b() {
        return this.f2375n == null && this.f2363b == this.f2365d;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: c */
    public int mo3203c(int i, C0835p pVar, C0843u uVar) {
        if (mo4134v() == 0 || i == 0) {
            return 0;
        }
        this.f2362a.f2386a = true;
        mo3220i();
        int i2 = i > 0 ? 1 : -1;
        int abs = Math.abs(i);
        m3309a(i2, abs, true, uVar);
        int a = this.f2362a.f2392g + mo3191a(pVar, this.f2362a, uVar, false);
        if (a < 0) {
            return 0;
        }
        if (abs > a) {
            i = i2 * a;
        }
        this.f2371j.mo3818a(-i);
        this.f2362a.f2395j = i;
        return i;
    }

    /* renamed from: c */
    public int mo3204c(C0843u uVar) {
        return m3326i(uVar);
    }

    /* renamed from: c */
    public View mo3205c(int i) {
        int v = mo4134v();
        if (v == 0) {
            return null;
        }
        int d = i - mo4104d(mo4120i(0));
        if (d >= 0 && d < v) {
            View i2 = mo4120i(d);
            if (mo4104d(i2) == i) {
                return i2;
            }
        }
        return super.mo3205c(i);
    }

    /* renamed from: c */
    public void mo3182c(C0835p pVar, C0843u uVar) {
        int i;
        int i2;
        int i3;
        int i4;
        int i5;
        int a;
        int a2;
        int i6;
        int i7 = -1;
        if (!(this.f2375n == null && this.f2373l == -1) && uVar.mo4227e() == 0) {
            mo4098c(pVar);
            return;
        }
        if (this.f2375n != null && this.f2375n.mo3238a()) {
            this.f2373l = this.f2375n.f2398a;
        }
        mo3220i();
        this.f2362a.f2386a = false;
        m3303K();
        View E = mo4055E();
        if (!this.f2376o.f2381e || this.f2373l != -1 || this.f2375n != null) {
            this.f2376o.mo3226a();
            this.f2376o.f2380d = this.f2372k ^ this.f2365d;
            m3314a(pVar, uVar, this.f2376o);
            this.f2376o.f2381e = true;
        } else if (E != null && (this.f2371j.mo3816a(E) >= this.f2371j.mo3823d() || this.f2371j.mo3820b(E) <= this.f2371j.mo3821c())) {
            this.f2376o.mo3227a(E, mo4104d(E));
        }
        int b = mo3199b(uVar);
        if (this.f2362a.f2395j >= 0) {
            i = b;
            b = 0;
        } else {
            i = 0;
        }
        int c = b + this.f2371j.mo3821c();
        int g = i + this.f2371j.mo3829g();
        if (!(!uVar.mo4223a() || this.f2373l == -1 || this.f2374m == Integer.MIN_VALUE)) {
            View c2 = mo3205c(this.f2373l);
            if (c2 != null) {
                if (this.f2372k) {
                    i6 = this.f2371j.mo3823d() - this.f2371j.mo3820b(c2);
                    a2 = this.f2374m;
                } else {
                    a2 = this.f2371j.mo3816a(c2) - this.f2371j.mo3821c();
                    i6 = this.f2374m;
                }
                int i8 = i6 - a2;
                if (i8 > 0) {
                    c += i8;
                } else {
                    g -= i8;
                }
            }
        }
        if (!this.f2376o.f2380d ? !this.f2372k : this.f2372k) {
            i7 = 1;
        }
        mo3167a(pVar, uVar, this.f2376o, i7);
        mo4064a(pVar);
        this.f2362a.f2397l = mo3222k();
        this.f2362a.f2394i = uVar.mo4223a();
        if (this.f2376o.f2380d) {
            m3318b(this.f2376o);
            this.f2362a.f2393h = c;
            mo3191a(pVar, this.f2362a, uVar, false);
            i3 = this.f2362a.f2387b;
            int i9 = this.f2362a.f2389d;
            if (this.f2362a.f2388c > 0) {
                g += this.f2362a.f2388c;
            }
            m3310a(this.f2376o);
            this.f2362a.f2393h = g;
            this.f2362a.f2389d += this.f2362a.f2390e;
            mo3191a(pVar, this.f2362a, uVar, false);
            i2 = this.f2362a.f2387b;
            if (this.f2362a.f2388c > 0) {
                int i10 = this.f2362a.f2388c;
                m3324g(i9, i3);
                this.f2362a.f2393h = i10;
                mo3191a(pVar, this.f2362a, uVar, false);
                i3 = this.f2362a.f2387b;
            }
        } else {
            m3310a(this.f2376o);
            this.f2362a.f2393h = g;
            mo3191a(pVar, this.f2362a, uVar, false);
            i2 = this.f2362a.f2387b;
            int i11 = this.f2362a.f2389d;
            if (this.f2362a.f2388c > 0) {
                c += this.f2362a.f2388c;
            }
            m3318b(this.f2376o);
            this.f2362a.f2393h = c;
            this.f2362a.f2389d += this.f2362a.f2390e;
            mo3191a(pVar, this.f2362a, uVar, false);
            i3 = this.f2362a.f2387b;
            if (this.f2362a.f2388c > 0) {
                int i12 = this.f2362a.f2388c;
                mo3157a(i11, i2);
                this.f2362a.f2393h = i12;
                mo3191a(pVar, this.f2362a, uVar, false);
                i2 = this.f2362a.f2387b;
            }
        }
        if (mo4134v() > 0) {
            if (this.f2372k ^ this.f2365d) {
                int a3 = m3306a(i2, pVar, uVar, true);
                i4 = i3 + a3;
                i5 = i2 + a3;
                a = m3316b(i4, pVar, uVar, false);
            } else {
                int b2 = m3316b(i3, pVar, uVar, true);
                i4 = i3 + b2;
                i5 = i2 + b2;
                a = m3306a(i5, pVar, uVar, false);
            }
            i3 = i4 + a;
            i2 = i5 + a;
        }
        m3320b(pVar, uVar, i3, i2);
        if (!uVar.mo4223a()) {
            this.f2371j.mo3817a();
        } else {
            this.f2376o.mo3226a();
        }
        this.f2363b = this.f2365d;
    }

    /* renamed from: c */
    public boolean mo3206c() {
        return true;
    }

    /* renamed from: d */
    public int mo3207d(C0843u uVar) {
        return m3326i(uVar);
    }

    /* renamed from: d */
    public PointF mo3208d(int i) {
        if (mo4134v() == 0) {
            return null;
        }
        boolean z = false;
        int i2 = 1;
        if (i < mo4104d(mo4120i(0))) {
            z = true;
        }
        if (z != this.f2372k) {
            i2 = -1;
        }
        return this.f2370i == 0 ? new PointF((float) i2, 0.0f) : new PointF(0.0f, (float) i2);
    }

    /* renamed from: d */
    public Parcelable mo3209d() {
        if (this.f2375n != null) {
            return new C0703d(this.f2375n);
        }
        C0703d dVar = new C0703d();
        if (mo4134v() > 0) {
            mo3220i();
            boolean z = this.f2363b ^ this.f2372k;
            dVar.f2400c = z;
            if (z) {
                View M = m3305M();
                dVar.f2399b = this.f2371j.mo3823d() - this.f2371j.mo3820b(M);
                dVar.f2398a = mo4104d(M);
                return dVar;
            }
            View L = m3304L();
            dVar.f2398a = mo4104d(L);
            dVar.f2399b = this.f2371j.mo3816a(L) - this.f2371j.mo3821c();
            return dVar;
        }
        dVar.mo3239b();
        return dVar;
    }

    /* renamed from: e */
    public int mo3210e(C0843u uVar) {
        return m3328j(uVar);
    }

    /* renamed from: e */
    public void mo3211e(int i) {
        this.f2373l = i;
        this.f2374m = Integer.MIN_VALUE;
        if (this.f2375n != null) {
            this.f2375n.mo3239b();
        }
        mo4127o();
    }

    /* renamed from: e */
    public boolean mo3212e() {
        return this.f2370i == 0;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: f */
    public int mo3213f(int i) {
        int i2 = Integer.MIN_VALUE;
        if (i == 17) {
            return this.f2370i == 0 ? -1 : Integer.MIN_VALUE;
        }
        if (i == 33) {
            return this.f2370i == 1 ? -1 : Integer.MIN_VALUE;
        }
        if (i == 66) {
            if (this.f2370i == 0) {
                i2 = 1;
            }
            return i2;
        } else if (i != 130) {
            switch (i) {
                case 1:
                    return (this.f2370i != 1 && mo3219h()) ? 1 : -1;
                case 2:
                    return (this.f2370i != 1 && mo3219h()) ? -1 : 1;
                default:
                    return Integer.MIN_VALUE;
            }
        } else {
            if (this.f2370i == 1) {
                i2 = 1;
            }
            return i2;
        }
    }

    /* renamed from: f */
    public int mo3214f(C0843u uVar) {
        return m3328j(uVar);
    }

    /* renamed from: f */
    public boolean mo3215f() {
        return this.f2370i == 1;
    }

    /* renamed from: g */
    public int mo3216g() {
        return this.f2370i;
    }

    /* renamed from: g */
    public int mo3217g(C0843u uVar) {
        return m3330k(uVar);
    }

    /* renamed from: h */
    public int mo3218h(C0843u uVar) {
        return m3330k(uVar);
    }

    /* access modifiers changed from: protected */
    /* renamed from: h */
    public boolean mo3219h() {
        return mo4132t() == 1;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: i */
    public void mo3220i() {
        if (this.f2362a == null) {
            this.f2362a = mo3221j();
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: j */
    public C0702c mo3221j() {
        return new C0702c();
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: k */
    public boolean mo3222k() {
        return this.f2371j.mo3830h() == 0 && this.f2371j.mo3825e() == 0;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: l */
    public boolean mo3223l() {
        return (mo4136x() == 1073741824 || mo4135w() == 1073741824 || !mo4060J()) ? false : true;
    }

    /* renamed from: m */
    public int mo3224m() {
        View a = mo3192a(0, mo4134v(), false, true);
        if (a == null) {
            return -1;
        }
        return mo4104d(a);
    }

    /* renamed from: n */
    public int mo3225n() {
        View a = mo3192a(mo4134v() - 1, -1, false, true);
        if (a == null) {
            return -1;
        }
        return mo4104d(a);
    }
}
