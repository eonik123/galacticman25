package android.support.p031v7.widget;

import android.content.res.ColorStateList;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Outline;
import android.graphics.Paint;
import android.graphics.PorterDuff.Mode;
import android.graphics.PorterDuffColorFilter;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;

/* renamed from: android.support.v7.widget.bb */
class C0851bb extends Drawable {

    /* renamed from: a */
    private float f3046a;

    /* renamed from: b */
    private final Paint f3047b;

    /* renamed from: c */
    private final RectF f3048c;

    /* renamed from: d */
    private final Rect f3049d;

    /* renamed from: e */
    private float f3050e;

    /* renamed from: f */
    private boolean f3051f;

    /* renamed from: g */
    private boolean f3052g;

    /* renamed from: h */
    private ColorStateList f3053h;

    /* renamed from: i */
    private PorterDuffColorFilter f3054i;

    /* renamed from: j */
    private ColorStateList f3055j;

    /* renamed from: k */
    private Mode f3056k;

    /* renamed from: a */
    private PorterDuffColorFilter m4529a(ColorStateList colorStateList, Mode mode) {
        if (colorStateList == null || mode == null) {
            return null;
        }
        return new PorterDuffColorFilter(colorStateList.getColorForState(getState(), 0), mode);
    }

    /* renamed from: a */
    private void m4530a(Rect rect) {
        if (rect == null) {
            rect = getBounds();
        }
        this.f3048c.set((float) rect.left, (float) rect.top, (float) rect.right, (float) rect.bottom);
        this.f3049d.set(rect);
        if (this.f3051f) {
            float a = C0852bc.m4538a(this.f3050e, this.f3046a, this.f3052g);
            this.f3049d.inset((int) Math.ceil((double) C0852bc.m4541b(this.f3050e, this.f3046a, this.f3052g)), (int) Math.ceil((double) a));
            this.f3048c.set(this.f3049d);
        }
    }

    /* renamed from: b */
    private void m4531b(ColorStateList colorStateList) {
        if (colorStateList == null) {
            colorStateList = ColorStateList.valueOf(0);
        }
        this.f3053h = colorStateList;
        this.f3047b.setColor(this.f3053h.getColorForState(getState(), this.f3053h.getDefaultColor()));
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public float mo4327a() {
        return this.f3050e;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo4328a(float f) {
        if (f != this.f3046a) {
            this.f3046a = f;
            m4530a((Rect) null);
            invalidateSelf();
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo4329a(float f, boolean z, boolean z2) {
        if (f != this.f3050e || this.f3051f != z || this.f3052g != z2) {
            this.f3050e = f;
            this.f3051f = z;
            this.f3052g = z2;
            m4530a((Rect) null);
            invalidateSelf();
        }
    }

    /* renamed from: a */
    public void mo4330a(ColorStateList colorStateList) {
        m4531b(colorStateList);
        invalidateSelf();
    }

    /* renamed from: b */
    public float mo4331b() {
        return this.f3046a;
    }

    /* renamed from: c */
    public ColorStateList mo4332c() {
        return this.f3053h;
    }

    public void draw(Canvas canvas) {
        boolean z;
        Paint paint = this.f3047b;
        if (this.f3054i == null || paint.getColorFilter() != null) {
            z = false;
        } else {
            paint.setColorFilter(this.f3054i);
            z = true;
        }
        canvas.drawRoundRect(this.f3048c, this.f3046a, this.f3046a, paint);
        if (z) {
            paint.setColorFilter(null);
        }
    }

    public int getOpacity() {
        return -3;
    }

    public void getOutline(Outline outline) {
        outline.setRoundRect(this.f3049d, this.f3046a);
    }

    public boolean isStateful() {
        return (this.f3055j != null && this.f3055j.isStateful()) || (this.f3053h != null && this.f3053h.isStateful()) || super.isStateful();
    }

    /* access modifiers changed from: protected */
    public void onBoundsChange(Rect rect) {
        super.onBoundsChange(rect);
        m4530a(rect);
    }

    /* access modifiers changed from: protected */
    public boolean onStateChange(int[] iArr) {
        int colorForState = this.f3053h.getColorForState(iArr, this.f3053h.getDefaultColor());
        boolean z = colorForState != this.f3047b.getColor();
        if (z) {
            this.f3047b.setColor(colorForState);
        }
        if (this.f3055j == null || this.f3056k == null) {
            return z;
        }
        this.f3054i = m4529a(this.f3055j, this.f3056k);
        return true;
    }

    public void setAlpha(int i) {
        this.f3047b.setAlpha(i);
    }

    public void setColorFilter(ColorFilter colorFilter) {
        this.f3047b.setColorFilter(colorFilter);
    }

    public void setTintList(ColorStateList colorStateList) {
        this.f3055j = colorStateList;
        this.f3054i = m4529a(this.f3055j, this.f3056k);
        invalidateSelf();
    }

    public void setTintMode(Mode mode) {
        this.f3056k = mode;
        this.f3054i = m4529a(this.f3055j, this.f3056k);
        invalidateSelf();
    }
}
