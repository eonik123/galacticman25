package android.support.p031v7.widget;

import android.content.Context;
import android.graphics.Rect;
import android.support.p031v7.widget.C0777ao.C0778a;
import android.util.AttributeSet;
import android.widget.FrameLayout;

/* renamed from: android.support.v7.widget.FitWindowsFrameLayout */
public class FitWindowsFrameLayout extends FrameLayout implements C0777ao {

    /* renamed from: a */
    private C0778a f2348a;

    public FitWindowsFrameLayout(Context context) {
        super(context);
    }

    public FitWindowsFrameLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    /* access modifiers changed from: protected */
    public boolean fitSystemWindows(Rect rect) {
        if (this.f2348a != null) {
            this.f2348a.mo2292a(rect);
        }
        return super.fitSystemWindows(rect);
    }

    public void setOnFitSystemWindowsListener(C0778a aVar) {
        this.f2348a = aVar;
    }
}
