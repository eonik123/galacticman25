package android.support.p031v7.widget;

import android.view.View;
import android.view.ViewParent;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;

/* renamed from: android.support.v7.widget.m */
class C0916m {
    /* renamed from: a */
    static InputConnection m4905a(InputConnection inputConnection, EditorInfo editorInfo, View view) {
        if (inputConnection != null && editorInfo.hintText == null) {
            for (ViewParent parent = view.getParent(); parent instanceof View; parent = parent.getParent()) {
                if (parent instanceof C0886bw) {
                    editorInfo.hintText = ((C0886bw) parent).mo4486a();
                    return inputConnection;
                }
            }
        }
        return inputConnection;
    }
}
