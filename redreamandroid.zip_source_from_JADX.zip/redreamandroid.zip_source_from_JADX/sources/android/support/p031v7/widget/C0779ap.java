package android.support.p031v7.widget;

import android.os.SystemClock;
import android.support.p031v7.view.menu.C0677s;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnAttachStateChangeListener;
import android.view.View.OnTouchListener;
import android.view.ViewConfiguration;
import android.view.ViewParent;

/* renamed from: android.support.v7.widget.ap */
public abstract class C0779ap implements OnAttachStateChangeListener, OnTouchListener {

    /* renamed from: a */
    private final float f2732a;

    /* renamed from: b */
    private final int f2733b;

    /* renamed from: c */
    final View f2734c;

    /* renamed from: d */
    private final int f2735d;

    /* renamed from: e */
    private Runnable f2736e;

    /* renamed from: f */
    private Runnable f2737f;

    /* renamed from: g */
    private boolean f2738g;

    /* renamed from: h */
    private int f2739h;

    /* renamed from: i */
    private final int[] f2740i = new int[2];

    /* renamed from: android.support.v7.widget.ap$a */
    private class C0780a implements Runnable {
        C0780a() {
        }

        public void run() {
            ViewParent parent = C0779ap.this.f2734c.getParent();
            if (parent != null) {
                parent.requestDisallowInterceptTouchEvent(true);
            }
        }
    }

    /* renamed from: android.support.v7.widget.ap$b */
    private class C0781b implements Runnable {
        C0781b() {
        }

        public void run() {
            C0779ap.this.mo3707d();
        }
    }

    public C0779ap(View view) {
        this.f2734c = view;
        view.setLongClickable(true);
        view.addOnAttachStateChangeListener(this);
        this.f2732a = (float) ViewConfiguration.get(view.getContext()).getScaledTouchSlop();
        this.f2733b = ViewConfiguration.getTapTimeout();
        this.f2735d = (this.f2733b + ViewConfiguration.getLongPressTimeout()) / 2;
    }

    /* renamed from: a */
    private boolean m3883a(MotionEvent motionEvent) {
        View view = this.f2734c;
        if (!view.isEnabled()) {
            return false;
        }
        switch (motionEvent.getActionMasked()) {
            case 0:
                this.f2739h = motionEvent.getPointerId(0);
                if (this.f2736e == null) {
                    this.f2736e = new C0780a();
                }
                view.postDelayed(this.f2736e, (long) this.f2733b);
                if (this.f2737f == null) {
                    this.f2737f = new C0781b();
                }
                view.postDelayed(this.f2737f, (long) this.f2735d);
                break;
            case 1:
            case 3:
                m3888e();
                return false;
            case 2:
                int findPointerIndex = motionEvent.findPointerIndex(this.f2739h);
                if (findPointerIndex >= 0 && !m3884a(view, motionEvent.getX(findPointerIndex), motionEvent.getY(findPointerIndex), this.f2732a)) {
                    m3888e();
                    view.getParent().requestDisallowInterceptTouchEvent(true);
                    return true;
                }
            default:
                return false;
        }
        return false;
    }

    /* renamed from: a */
    private static boolean m3884a(View view, float f, float f2, float f3) {
        float f4 = -f3;
        return f >= f4 && f2 >= f4 && f < ((float) (view.getRight() - view.getLeft())) + f3 && f2 < ((float) (view.getBottom() - view.getTop())) + f3;
    }

    /* renamed from: a */
    private boolean m3885a(View view, MotionEvent motionEvent) {
        int[] iArr = this.f2740i;
        view.getLocationOnScreen(iArr);
        motionEvent.offsetLocation((float) (-iArr[0]), (float) (-iArr[1]));
        return true;
    }

    /* renamed from: b */
    private boolean m3886b(MotionEvent motionEvent) {
        View view = this.f2734c;
        C0677s a = mo2578a();
        if (a == null || !a.mo2665d()) {
            return false;
        }
        C0769am amVar = (C0769am) a.mo2666e();
        if (amVar == null || !amVar.isShown()) {
            return false;
        }
        MotionEvent obtainNoHistory = MotionEvent.obtainNoHistory(motionEvent);
        m3887b(view, obtainNoHistory);
        m3885a(amVar, obtainNoHistory);
        boolean a2 = amVar.mo3673a(obtainNoHistory, this.f2739h);
        obtainNoHistory.recycle();
        int actionMasked = motionEvent.getActionMasked();
        return a2 && (actionMasked != 1 && actionMasked != 3);
    }

    /* renamed from: b */
    private boolean m3887b(View view, MotionEvent motionEvent) {
        int[] iArr = this.f2740i;
        view.getLocationOnScreen(iArr);
        motionEvent.offsetLocation((float) iArr[0], (float) iArr[1]);
        return true;
    }

    /* renamed from: e */
    private void m3888e() {
        if (this.f2737f != null) {
            this.f2734c.removeCallbacks(this.f2737f);
        }
        if (this.f2736e != null) {
            this.f2734c.removeCallbacks(this.f2736e);
        }
    }

    /* renamed from: a */
    public abstract C0677s mo2578a();

    /* access modifiers changed from: protected */
    /* renamed from: b */
    public boolean mo2579b() {
        C0677s a = mo2578a();
        if (a != null && !a.mo2665d()) {
            a.mo2655a();
        }
        return true;
    }

    /* access modifiers changed from: protected */
    /* renamed from: c */
    public boolean mo3706c() {
        C0677s a = mo2578a();
        if (a != null && a.mo2665d()) {
            a.mo2662c();
        }
        return true;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: d */
    public void mo3707d() {
        m3888e();
        View view = this.f2734c;
        if (view.isEnabled() && !view.isLongClickable() && mo2579b()) {
            view.getParent().requestDisallowInterceptTouchEvent(true);
            long uptimeMillis = SystemClock.uptimeMillis();
            MotionEvent obtain = MotionEvent.obtain(uptimeMillis, uptimeMillis, 3, 0.0f, 0.0f, 0);
            view.onTouchEvent(obtain);
            obtain.recycle();
            this.f2738g = true;
        }
    }

    public boolean onTouch(View view, MotionEvent motionEvent) {
        boolean z;
        boolean z2 = this.f2738g;
        boolean z3 = true;
        if (z2) {
            z = m3886b(motionEvent) || !mo3706c();
        } else {
            z = m3883a(motionEvent) && mo2579b();
            if (z) {
                long uptimeMillis = SystemClock.uptimeMillis();
                MotionEvent obtain = MotionEvent.obtain(uptimeMillis, uptimeMillis, 3, 0.0f, 0.0f, 0);
                this.f2734c.onTouchEvent(obtain);
                obtain.recycle();
            }
        }
        this.f2738g = z;
        if (!z) {
            if (z2) {
                return true;
            }
            z3 = false;
        }
        return z3;
    }

    public void onViewAttachedToWindow(View view) {
    }

    public void onViewDetachedFromWindow(View view) {
        this.f2738g = false;
        this.f2739h = -1;
        if (this.f2736e != null) {
            this.f2734c.removeCallbacks(this.f2736e);
        }
    }
}
