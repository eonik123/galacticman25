package android.support.p031v7.widget;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff.Mode;

/* renamed from: android.support.v7.widget.bl */
class C0867bl {

    /* renamed from: a */
    public ColorStateList f3138a;

    /* renamed from: b */
    public Mode f3139b;

    /* renamed from: c */
    public boolean f3140c;

    /* renamed from: d */
    public boolean f3141d;

    C0867bl() {
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo4422a() {
        this.f3138a = null;
        this.f3141d = false;
        this.f3139b = null;
        this.f3140c = false;
    }
}
