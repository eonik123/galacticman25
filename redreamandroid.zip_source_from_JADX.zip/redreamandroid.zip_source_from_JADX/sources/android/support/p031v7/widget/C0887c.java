package android.support.p031v7.widget;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.support.p018v4.graphics.drawable.C0441a;
import android.support.p018v4.p028h.C0477c;
import android.support.p018v4.p028h.C0477c.C0478a;
import android.support.p031v7.p032a.C0540a.C0541a;
import android.support.p031v7.p032a.C0540a.C0547g;
import android.support.p031v7.view.C0626a;
import android.support.p031v7.view.menu.ActionMenuItemView;
import android.support.p031v7.view.menu.ActionMenuItemView.C0641b;
import android.support.p031v7.view.menu.C0643b;
import android.support.p031v7.view.menu.C0655h;
import android.support.p031v7.view.menu.C0659j;
import android.support.p031v7.view.menu.C0669n;
import android.support.p031v7.view.menu.C0671o.C0672a;
import android.support.p031v7.view.menu.C0673p;
import android.support.p031v7.view.menu.C0673p.C0674a;
import android.support.p031v7.view.menu.C0677s;
import android.support.p031v7.view.menu.C0681u;
import android.support.p031v7.widget.ActionMenuView.C0689a;
import android.util.SparseBooleanArray;
import android.view.MenuItem;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import java.util.ArrayList;

/* renamed from: android.support.v7.widget.c */
class C0887c extends C0643b implements C0478a {

    /* renamed from: A */
    private C0889b f3204A;

    /* renamed from: g */
    C0891d f3205g;

    /* renamed from: h */
    C0893e f3206h;

    /* renamed from: i */
    C0888a f3207i;

    /* renamed from: j */
    C0890c f3208j;

    /* renamed from: k */
    final C0894f f3209k = new C0894f();

    /* renamed from: l */
    int f3210l;

    /* renamed from: m */
    private Drawable f3211m;

    /* renamed from: n */
    private boolean f3212n;

    /* renamed from: o */
    private boolean f3213o;

    /* renamed from: p */
    private boolean f3214p;

    /* renamed from: q */
    private int f3215q;

    /* renamed from: r */
    private int f3216r;

    /* renamed from: s */
    private int f3217s;

    /* renamed from: t */
    private boolean f3218t;

    /* renamed from: u */
    private boolean f3219u;

    /* renamed from: v */
    private boolean f3220v;

    /* renamed from: w */
    private boolean f3221w;

    /* renamed from: x */
    private int f3222x;

    /* renamed from: y */
    private final SparseBooleanArray f3223y = new SparseBooleanArray();

    /* renamed from: z */
    private View f3224z;

    /* renamed from: android.support.v7.widget.c$a */
    private class C0888a extends C0669n {
        public C0888a(Context context, C0681u uVar, View view) {
            super(context, uVar, view, false, C0541a.actionOverflowMenuStyle);
            if (!((C0659j) uVar.getItem()).mo2811j()) {
                mo2902a(C0887c.this.f3205g == null ? (View) C0887c.this.f2065f : C0887c.this.f3205g);
            }
            mo2901a((C0672a) C0887c.this.f3209k);
        }

        /* access modifiers changed from: protected */
        /* renamed from: e */
        public void mo2909e() {
            C0887c.this.f3207i = null;
            C0887c.this.f3210l = 0;
            super.mo2909e();
        }
    }

    /* renamed from: android.support.v7.widget.c$b */
    private class C0889b extends C0641b {
        C0889b() {
        }

        /* renamed from: a */
        public C0677s mo2580a() {
            if (C0887c.this.f3207i != null) {
                return C0887c.this.f3207i.mo2906b();
            }
            return null;
        }
    }

    /* renamed from: android.support.v7.widget.c$c */
    private class C0890c implements Runnable {

        /* renamed from: b */
        private C0893e f3228b;

        public C0890c(C0893e eVar) {
            this.f3228b = eVar;
        }

        public void run() {
            if (C0887c.this.f2062c != null) {
                C0887c.this.f2062c.mo2744g();
            }
            View view = (View) C0887c.this.f2065f;
            if (!(view == null || view.getWindowToken() == null || !this.f3228b.mo2907c())) {
                C0887c.this.f3206h = this.f3228b;
            }
            C0887c.this.f3208j = null;
        }
    }

    /* renamed from: android.support.v7.widget.c$d */
    private class C0891d extends C0919p implements C0689a {

        /* renamed from: b */
        private final float[] f3230b = new float[2];

        public C0891d(Context context) {
            super(context, null, C0541a.actionOverflowButtonStyle);
            setClickable(true);
            setFocusable(true);
            setVisibility(0);
            setEnabled(true);
            C0873bp.m4703a(this, getContentDescription());
            setOnTouchListener(new C0779ap(this, C0887c.this) {
                /* renamed from: a */
                public C0677s mo2578a() {
                    if (C0887c.this.f3206h == null) {
                        return null;
                    }
                    return C0887c.this.f3206h.mo2906b();
                }

                /* renamed from: b */
                public boolean mo2579b() {
                    C0887c.this.mo4493d();
                    return true;
                }

                /* renamed from: c */
                public boolean mo3706c() {
                    if (C0887c.this.f3208j != null) {
                        return false;
                    }
                    C0887c.this.mo4494e();
                    return true;
                }
            });
        }

        /* renamed from: c */
        public boolean mo2563c() {
            return false;
        }

        /* renamed from: d */
        public boolean mo2564d() {
            return false;
        }

        public boolean performClick() {
            if (super.performClick()) {
                return true;
            }
            playSoundEffect(0);
            C0887c.this.mo4493d();
            return true;
        }

        /* access modifiers changed from: protected */
        public boolean setFrame(int i, int i2, int i3, int i4) {
            boolean frame = super.setFrame(i, i2, i3, i4);
            Drawable drawable = getDrawable();
            Drawable background = getBackground();
            if (!(drawable == null || background == null)) {
                int width = getWidth();
                int height = getHeight();
                int max = Math.max(width, height) / 2;
                int paddingLeft = (width + (getPaddingLeft() - getPaddingRight())) / 2;
                int paddingTop = (height + (getPaddingTop() - getPaddingBottom())) / 2;
                C0441a.m1926a(background, paddingLeft - max, paddingTop - max, paddingLeft + max, paddingTop + max);
            }
            return frame;
        }
    }

    /* renamed from: android.support.v7.widget.c$e */
    private class C0893e extends C0669n {
        public C0893e(Context context, C0655h hVar, View view, boolean z) {
            super(context, hVar, view, z, C0541a.actionOverflowMenuStyle);
            mo2900a(8388613);
            mo2901a((C0672a) C0887c.this.f3209k);
        }

        /* access modifiers changed from: protected */
        /* renamed from: e */
        public void mo2909e() {
            if (C0887c.this.f2062c != null) {
                C0887c.this.f2062c.close();
            }
            C0887c.this.f3206h = null;
            super.mo2909e();
        }
    }

    /* renamed from: android.support.v7.widget.c$f */
    private class C0894f implements C0672a {
        C0894f() {
        }

        /* renamed from: a */
        public void mo2296a(C0655h hVar, boolean z) {
            if (hVar instanceof C0681u) {
                hVar.mo2759q().mo2711a(false);
            }
            C0672a a = C0887c.this.mo2633a();
            if (a != null) {
                a.mo2296a(hVar, z);
            }
        }

        /* renamed from: a */
        public boolean mo2297a(C0655h hVar) {
            boolean z = false;
            if (hVar == null) {
                return false;
            }
            C0887c.this.f3210l = ((C0681u) hVar).getItem().getItemId();
            C0672a a = C0887c.this.mo2633a();
            if (a != null) {
                z = a.mo2297a(hVar);
            }
            return z;
        }
    }

    public C0887c(Context context) {
        super(context, C0547g.abc_action_menu_layout, C0547g.abc_action_menu_item_layout);
    }

    /* renamed from: a */
    private View m4761a(MenuItem menuItem) {
        ViewGroup viewGroup = (ViewGroup) this.f2065f;
        if (viewGroup == null) {
            return null;
        }
        int childCount = viewGroup.getChildCount();
        for (int i = 0; i < childCount; i++) {
            View childAt = viewGroup.getChildAt(i);
            if ((childAt instanceof C0674a) && ((C0674a) childAt).getItemData() == menuItem) {
                return childAt;
            }
        }
        return null;
    }

    /* renamed from: a */
    public C0673p mo2634a(ViewGroup viewGroup) {
        C0673p pVar = this.f2065f;
        C0673p a = super.mo2634a(viewGroup);
        if (pVar != a) {
            ((ActionMenuView) a).setPresenter(this);
        }
        return a;
    }

    /* renamed from: a */
    public View mo2635a(C0659j jVar, View view, ViewGroup viewGroup) {
        View actionView = jVar.getActionView();
        if (actionView == null || jVar.mo2815n()) {
            actionView = super.mo2635a(jVar, view, viewGroup);
        }
        actionView.setVisibility(jVar.isActionViewExpanded() ? 8 : 0);
        ActionMenuView actionMenuView = (ActionMenuView) viewGroup;
        LayoutParams layoutParams = actionView.getLayoutParams();
        if (!actionMenuView.checkLayoutParams(layoutParams)) {
            actionView.setLayoutParams(actionMenuView.generateLayoutParams(layoutParams));
        }
        return actionView;
    }

    /* renamed from: a */
    public void mo2637a(Context context, C0655h hVar) {
        super.mo2637a(context, hVar);
        Resources resources = context.getResources();
        C0626a a = C0626a.m2803a(context);
        if (!this.f3214p) {
            this.f3213o = a.mo2492b();
        }
        if (!this.f3220v) {
            this.f3215q = a.mo2493c();
        }
        if (!this.f3218t) {
            this.f3217s = a.mo2491a();
        }
        int i = this.f3215q;
        if (this.f3213o) {
            if (this.f3205g == null) {
                this.f3205g = new C0891d(this.f2060a);
                if (this.f3212n) {
                    this.f3205g.setImageDrawable(this.f3211m);
                    this.f3211m = null;
                    this.f3212n = false;
                }
                int makeMeasureSpec = MeasureSpec.makeMeasureSpec(0, 0);
                this.f3205g.measure(makeMeasureSpec, makeMeasureSpec);
            }
            i -= this.f3205g.getMeasuredWidth();
        } else {
            this.f3205g = null;
        }
        this.f3216r = i;
        this.f3222x = (int) (56.0f * resources.getDisplayMetrics().density);
        this.f3224z = null;
    }

    /* renamed from: a */
    public void mo4487a(Configuration configuration) {
        if (!this.f3218t) {
            this.f3217s = C0626a.m2803a(this.f2061b).mo2491a();
        }
        if (this.f2062c != null) {
            this.f2062c.mo2728b(true);
        }
    }

    /* renamed from: a */
    public void mo4488a(Drawable drawable) {
        if (this.f3205g != null) {
            this.f3205g.setImageDrawable(drawable);
            return;
        }
        this.f3212n = true;
        this.f3211m = drawable;
    }

    /* renamed from: a */
    public void mo2638a(C0655h hVar, boolean z) {
        mo4495f();
        super.mo2638a(hVar, z);
    }

    /* renamed from: a */
    public void mo2639a(C0659j jVar, C0674a aVar) {
        aVar.mo636a(jVar, 0);
        ActionMenuItemView actionMenuItemView = (ActionMenuItemView) aVar;
        actionMenuItemView.setItemInvoker((ActionMenuView) this.f2065f);
        if (this.f3204A == null) {
            this.f3204A = new C0889b();
        }
        actionMenuItemView.setPopupCallback(this.f3204A);
    }

    /* renamed from: a */
    public void mo4489a(ActionMenuView actionMenuView) {
        this.f2065f = actionMenuView;
        actionMenuView.mo651a(this.f2062c);
    }

    /* renamed from: a */
    public void mo1925a(boolean z) {
        if (z) {
            super.mo2644a((C0681u) null);
            return;
        }
        if (this.f2062c != null) {
            this.f2062c.mo2711a(false);
        }
    }

    /* renamed from: a */
    public boolean mo2642a(int i, C0659j jVar) {
        return jVar.mo2811j();
    }

    /* renamed from: a */
    public boolean mo2644a(C0681u uVar) {
        boolean z = false;
        if (!uVar.hasVisibleItems()) {
            return false;
        }
        C0681u uVar2 = uVar;
        while (uVar2.mo2949t() != this.f2062c) {
            uVar2 = (C0681u) uVar2.mo2949t();
        }
        View a = m4761a(uVar2.getItem());
        if (a == null) {
            return false;
        }
        this.f3210l = uVar.getItem().getItemId();
        int size = uVar.size();
        int i = 0;
        while (true) {
            if (i >= size) {
                break;
            }
            MenuItem item = uVar.getItem(i);
            if (item.isVisible() && item.getIcon() != null) {
                z = true;
                break;
            }
            i++;
        }
        this.f3207i = new C0888a(this.f2061b, uVar, a);
        this.f3207i.mo2904a(z);
        this.f3207i.mo2899a();
        super.mo2644a(uVar);
        return true;
    }

    /* renamed from: a */
    public boolean mo2645a(ViewGroup viewGroup, int i) {
        if (viewGroup.getChildAt(i) == this.f3205g) {
            return false;
        }
        return super.mo2645a(viewGroup, i);
    }

    /* renamed from: b */
    public void mo2647b(boolean z) {
        super.mo2647b(z);
        ((View) this.f2065f).requestLayout();
        boolean z2 = false;
        if (this.f2062c != null) {
            ArrayList l = this.f2062c.mo2752l();
            int size = l.size();
            for (int i = 0; i < size; i++) {
                C0477c a = ((C0659j) l.get(i)).mo1549a();
                if (a != null) {
                    a.mo1916a((C0478a) this);
                }
            }
        }
        ArrayList m = this.f2062c != null ? this.f2062c.mo2753m() : null;
        if (this.f3213o && m != null) {
            int size2 = m.size();
            if (size2 == 1) {
                z2 = !((C0659j) m.get(0)).isActionViewExpanded();
            } else if (size2 > 0) {
                z2 = true;
            }
        }
        if (z2) {
            if (this.f3205g == null) {
                this.f3205g = new C0891d(this.f2060a);
            }
            ViewGroup viewGroup = (ViewGroup) this.f3205g.getParent();
            if (viewGroup != this.f2065f) {
                if (viewGroup != null) {
                    viewGroup.removeView(this.f3205g);
                }
                ActionMenuView actionMenuView = (ActionMenuView) this.f2065f;
                actionMenuView.addView(this.f3205g, actionMenuView.mo3058c());
            }
        } else if (this.f3205g != null && this.f3205g.getParent() == this.f2065f) {
            ((ViewGroup) this.f2065f).removeView(this.f3205g);
        }
        ((ActionMenuView) this.f2065f).setOverflowReserved(this.f3213o);
    }

    /* renamed from: b */
    public boolean mo2648b() {
        int i;
        ArrayList arrayList;
        int i2;
        int i3;
        int i4;
        boolean z;
        boolean z2;
        C0887c cVar = this;
        boolean z3 = false;
        if (cVar.f2062c != null) {
            arrayList = cVar.f2062c.mo2750j();
            i = arrayList.size();
        } else {
            arrayList = null;
            i = 0;
        }
        int i5 = cVar.f3217s;
        int i6 = cVar.f3216r;
        int makeMeasureSpec = MeasureSpec.makeMeasureSpec(0, 0);
        ViewGroup viewGroup = (ViewGroup) cVar.f2065f;
        int i7 = 0;
        boolean z4 = false;
        int i8 = 0;
        int i9 = i5;
        for (int i10 = 0; i10 < i; i10++) {
            C0659j jVar = (C0659j) arrayList.get(i10);
            if (jVar.mo2813l()) {
                i7++;
            } else if (jVar.mo2812k()) {
                i8++;
            } else {
                z4 = true;
            }
            if (cVar.f3221w && jVar.isActionViewExpanded()) {
                i9 = 0;
            }
        }
        if (cVar.f3213o && (z4 || i8 + i7 > i9)) {
            i9--;
        }
        int i11 = i9 - i7;
        SparseBooleanArray sparseBooleanArray = cVar.f3223y;
        sparseBooleanArray.clear();
        if (cVar.f3219u) {
            i3 = i6 / cVar.f3222x;
            i2 = ((i6 % cVar.f3222x) / i3) + cVar.f3222x;
        } else {
            i3 = 0;
            i2 = 0;
        }
        int i12 = 0;
        int i13 = i6;
        int i14 = 0;
        while (i14 < i) {
            C0659j jVar2 = (C0659j) arrayList.get(i14);
            if (jVar2.mo2813l()) {
                View a = cVar.mo2635a(jVar2, cVar.f3224z, viewGroup);
                if (cVar.f3224z == null) {
                    cVar.f3224z = a;
                }
                if (cVar.f3219u) {
                    i3 -= ActionMenuView.m3202a(a, i2, i3, makeMeasureSpec, z3 ? 1 : 0);
                } else {
                    a.measure(makeMeasureSpec, makeMeasureSpec);
                }
                int measuredWidth = a.getMeasuredWidth();
                i13 -= measuredWidth;
                if (i12 == 0) {
                    i12 = measuredWidth;
                }
                int groupId = jVar2.getGroupId();
                if (groupId != 0) {
                    z2 = true;
                    sparseBooleanArray.put(groupId, true);
                } else {
                    z2 = true;
                }
                jVar2.mo2787d(z2);
                z = z3;
                i4 = i;
            } else if (jVar2.mo2812k()) {
                int groupId2 = jVar2.getGroupId();
                boolean z5 = sparseBooleanArray.get(groupId2);
                boolean z6 = (i11 > 0 || z5) && i13 > 0 && (!cVar.f3219u || i3 > 0);
                if (z6) {
                    boolean z7 = z6;
                    View a2 = cVar.mo2635a(jVar2, cVar.f3224z, viewGroup);
                    i4 = i;
                    if (cVar.f3224z == null) {
                        cVar.f3224z = a2;
                    }
                    if (cVar.f3219u) {
                        int a3 = ActionMenuView.m3202a(a2, i2, i3, makeMeasureSpec, 0);
                        i3 -= a3;
                        if (a3 == 0) {
                            z7 = false;
                        }
                    } else {
                        a2.measure(makeMeasureSpec, makeMeasureSpec);
                    }
                    int measuredWidth2 = a2.getMeasuredWidth();
                    i13 -= measuredWidth2;
                    if (i12 == 0) {
                        i12 = measuredWidth2;
                    }
                    z6 = z7 & (!cVar.f3219u ? i13 + i12 > 0 : i13 >= 0);
                } else {
                    boolean z8 = z6;
                    i4 = i;
                }
                if (z6 && groupId2 != 0) {
                    sparseBooleanArray.put(groupId2, true);
                } else if (z5) {
                    sparseBooleanArray.put(groupId2, false);
                    int i15 = 0;
                    while (i15 < i14) {
                        C0659j jVar3 = (C0659j) arrayList.get(i15);
                        if (jVar3.getGroupId() == groupId2) {
                            if (jVar3.mo2811j()) {
                                i11++;
                            }
                            jVar3.mo2787d(false);
                        }
                        i15++;
                    }
                }
                if (z6) {
                    i11--;
                }
                jVar2.mo2787d(z6);
                z = false;
            } else {
                z = z3;
                i4 = i;
                jVar2.mo2787d(z);
            }
            i14++;
            z3 = z;
            i = i4;
            cVar = this;
        }
        return true;
    }

    /* renamed from: c */
    public Drawable mo4490c() {
        if (this.f3205g != null) {
            return this.f3205g.getDrawable();
        }
        if (this.f3212n) {
            return this.f3211m;
        }
        return null;
    }

    /* renamed from: c */
    public void mo4491c(boolean z) {
        this.f3213o = z;
        this.f3214p = true;
    }

    /* renamed from: d */
    public void mo4492d(boolean z) {
        this.f3221w = z;
    }

    /* renamed from: d */
    public boolean mo4493d() {
        if (!this.f3213o || mo4497h() || this.f2062c == null || this.f2065f == null || this.f3208j != null || this.f2062c.mo2753m().isEmpty()) {
            return false;
        }
        C0893e eVar = new C0893e(this.f2061b, this.f2062c, this.f3205g, true);
        this.f3208j = new C0890c(eVar);
        ((View) this.f2065f).post(this.f3208j);
        super.mo2644a((C0681u) null);
        return true;
    }

    /* renamed from: e */
    public boolean mo4494e() {
        if (this.f3208j == null || this.f2065f == null) {
            C0893e eVar = this.f3206h;
            if (eVar == null) {
                return false;
            }
            eVar.mo2908d();
            return true;
        }
        ((View) this.f2065f).removeCallbacks(this.f3208j);
        this.f3208j = null;
        return true;
    }

    /* renamed from: f */
    public boolean mo4495f() {
        return mo4494e() | mo4496g();
    }

    /* renamed from: g */
    public boolean mo4496g() {
        if (this.f3207i == null) {
            return false;
        }
        this.f3207i.mo2908d();
        return true;
    }

    /* renamed from: h */
    public boolean mo4497h() {
        return this.f3206h != null && this.f3206h.mo2910f();
    }

    /* renamed from: i */
    public boolean mo4498i() {
        return this.f3208j != null || mo4497h();
    }
}
