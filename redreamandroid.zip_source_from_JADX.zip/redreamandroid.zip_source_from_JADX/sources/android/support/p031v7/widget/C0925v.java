package android.support.p031v7.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.support.p031v7.p032a.C0540a.C0541a;
import android.util.AttributeSet;
import android.widget.SeekBar;

/* renamed from: android.support.v7.widget.v */
public class C0925v extends SeekBar {

    /* renamed from: a */
    private final C0926w f3323a;

    public C0925v(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, C0541a.seekBarStyle);
    }

    public C0925v(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f3323a = new C0926w(this);
        this.f3323a.mo4618a(attributeSet, i);
    }

    /* access modifiers changed from: protected */
    public void drawableStateChanged() {
        super.drawableStateChanged();
        this.f3323a.mo4631c();
    }

    public void jumpDrawablesToCurrentState() {
        super.jumpDrawablesToCurrentState();
        this.f3323a.mo4630b();
    }

    /* access modifiers changed from: protected */
    public synchronized void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        this.f3323a.mo4628a(canvas);
    }
}
