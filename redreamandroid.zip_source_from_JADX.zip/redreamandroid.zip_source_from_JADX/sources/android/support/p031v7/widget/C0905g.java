package android.support.p031v7.widget;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff.Mode;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.support.p018v4.p028h.C0495r;
import android.support.p031v7.p032a.C0540a.C0550j;
import android.util.AttributeSet;
import android.view.View;

/* renamed from: android.support.v7.widget.g */
class C0905g {

    /* renamed from: a */
    private final View f3272a;

    /* renamed from: b */
    private final C0909k f3273b;

    /* renamed from: c */
    private int f3274c = -1;

    /* renamed from: d */
    private C0867bl f3275d;

    /* renamed from: e */
    private C0867bl f3276e;

    /* renamed from: f */
    private C0867bl f3277f;

    C0905g(View view) {
        this.f3272a = view;
        this.f3273b = C0909k.m4874a();
    }

    /* renamed from: b */
    private boolean m4849b(Drawable drawable) {
        if (this.f3277f == null) {
            this.f3277f = new C0867bl();
        }
        C0867bl blVar = this.f3277f;
        blVar.mo4422a();
        ColorStateList s = C0495r.m2164s(this.f3272a);
        if (s != null) {
            blVar.f3141d = true;
            blVar.f3138a = s;
        }
        Mode t = C0495r.m2165t(this.f3272a);
        if (t != null) {
            blVar.f3140c = true;
            blVar.f3139b = t;
        }
        if (!blVar.f3141d && !blVar.f3140c) {
            return false;
        }
        C0909k.m4877a(drawable, blVar, this.f3272a.getDrawableState());
        return true;
    }

    /* renamed from: d */
    private boolean m4850d() {
        int i = VERSION.SDK_INT;
        boolean z = false;
        if (i <= 21) {
            return i == 21;
        }
        if (this.f3275d != null) {
            z = true;
        }
        return z;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public ColorStateList mo4542a() {
        if (this.f3276e != null) {
            return this.f3276e.f3138a;
        }
        return null;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo4543a(int i) {
        this.f3274c = i;
        mo4549b(this.f3273b != null ? this.f3273b.mo4573b(this.f3272a.getContext(), i) : null);
        mo4550c();
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo4544a(ColorStateList colorStateList) {
        if (this.f3276e == null) {
            this.f3276e = new C0867bl();
        }
        this.f3276e.f3138a = colorStateList;
        this.f3276e.f3141d = true;
        mo4550c();
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo4545a(Mode mode) {
        if (this.f3276e == null) {
            this.f3276e = new C0867bl();
        }
        this.f3276e.f3139b = mode;
        this.f3276e.f3140c = true;
        mo4550c();
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo4546a(Drawable drawable) {
        this.f3274c = -1;
        mo4549b((ColorStateList) null);
        mo4550c();
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo4547a(AttributeSet attributeSet, int i) {
        C0869bn a = C0869bn.m4638a(this.f3272a.getContext(), attributeSet, C0550j.ViewBackgroundHelper, i, 0);
        try {
            if (a.mo4440g(C0550j.ViewBackgroundHelper_android_background)) {
                this.f3274c = a.mo4439g(C0550j.ViewBackgroundHelper_android_background, -1);
                ColorStateList b = this.f3273b.mo4573b(this.f3272a.getContext(), this.f3274c);
                if (b != null) {
                    mo4549b(b);
                }
            }
            if (a.mo4440g(C0550j.ViewBackgroundHelper_backgroundTint)) {
                C0495r.m2128a(this.f3272a, a.mo4436e(C0550j.ViewBackgroundHelper_backgroundTint));
            }
            if (a.mo4440g(C0550j.ViewBackgroundHelper_backgroundTintMode)) {
                C0495r.m2129a(this.f3272a, C0768al.m3839a(a.mo4424a(C0550j.ViewBackgroundHelper_backgroundTintMode, -1), null));
            }
        } finally {
            a.mo4427a();
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: b */
    public Mode mo4548b() {
        if (this.f3276e != null) {
            return this.f3276e.f3139b;
        }
        return null;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: b */
    public void mo4549b(ColorStateList colorStateList) {
        if (colorStateList != null) {
            if (this.f3275d == null) {
                this.f3275d = new C0867bl();
            }
            this.f3275d.f3138a = colorStateList;
            this.f3275d.f3141d = true;
        } else {
            this.f3275d = null;
        }
        mo4550c();
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: c */
    public void mo4550c() {
        C0867bl blVar;
        Drawable background = this.f3272a.getBackground();
        if (background != null && (!m4850d() || !m4849b(background))) {
            if (this.f3276e != null) {
                blVar = this.f3276e;
            } else {
                if (this.f3275d != null) {
                    blVar = this.f3275d;
                }
                return;
            }
            C0909k.m4877a(background, blVar, this.f3272a.getDrawableState());
        }
    }
}
