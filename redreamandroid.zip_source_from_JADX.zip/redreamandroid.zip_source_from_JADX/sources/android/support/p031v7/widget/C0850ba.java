package android.support.p031v7.widget;

import android.content.res.AssetFileDescriptor;
import android.content.res.ColorStateList;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.Resources.Theme;
import android.content.res.TypedArray;
import android.content.res.XmlResourceParser;
import android.graphics.Movie;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import java.io.InputStream;

/* renamed from: android.support.v7.widget.ba */
class C0850ba extends Resources {

    /* renamed from: a */
    private final Resources f3045a;

    public C0850ba(Resources resources) {
        super(resources.getAssets(), resources.getDisplayMetrics(), resources.getConfiguration());
        this.f3045a = resources;
    }

    public XmlResourceParser getAnimation(int i) {
        return this.f3045a.getAnimation(i);
    }

    public boolean getBoolean(int i) {
        return this.f3045a.getBoolean(i);
    }

    public int getColor(int i) {
        return this.f3045a.getColor(i);
    }

    public ColorStateList getColorStateList(int i) {
        return this.f3045a.getColorStateList(i);
    }

    public Configuration getConfiguration() {
        return this.f3045a.getConfiguration();
    }

    public float getDimension(int i) {
        return this.f3045a.getDimension(i);
    }

    public int getDimensionPixelOffset(int i) {
        return this.f3045a.getDimensionPixelOffset(i);
    }

    public int getDimensionPixelSize(int i) {
        return this.f3045a.getDimensionPixelSize(i);
    }

    public DisplayMetrics getDisplayMetrics() {
        return this.f3045a.getDisplayMetrics();
    }

    public Drawable getDrawable(int i) {
        return this.f3045a.getDrawable(i);
    }

    public Drawable getDrawable(int i, Theme theme) {
        return this.f3045a.getDrawable(i, theme);
    }

    public Drawable getDrawableForDensity(int i, int i2) {
        return this.f3045a.getDrawableForDensity(i, i2);
    }

    public Drawable getDrawableForDensity(int i, int i2, Theme theme) {
        return this.f3045a.getDrawableForDensity(i, i2, theme);
    }

    public float getFraction(int i, int i2, int i3) {
        return this.f3045a.getFraction(i, i2, i3);
    }

    public int getIdentifier(String str, String str2, String str3) {
        return this.f3045a.getIdentifier(str, str2, str3);
    }

    public int[] getIntArray(int i) {
        return this.f3045a.getIntArray(i);
    }

    public int getInteger(int i) {
        return this.f3045a.getInteger(i);
    }

    public XmlResourceParser getLayout(int i) {
        return this.f3045a.getLayout(i);
    }

    public Movie getMovie(int i) {
        return this.f3045a.getMovie(i);
    }

    public String getQuantityString(int i, int i2) {
        return this.f3045a.getQuantityString(i, i2);
    }

    public String getQuantityString(int i, int i2, Object... objArr) {
        return this.f3045a.getQuantityString(i, i2, objArr);
    }

    public CharSequence getQuantityText(int i, int i2) {
        return this.f3045a.getQuantityText(i, i2);
    }

    public String getResourceEntryName(int i) {
        return this.f3045a.getResourceEntryName(i);
    }

    public String getResourceName(int i) {
        return this.f3045a.getResourceName(i);
    }

    public String getResourcePackageName(int i) {
        return this.f3045a.getResourcePackageName(i);
    }

    public String getResourceTypeName(int i) {
        return this.f3045a.getResourceTypeName(i);
    }

    public String getString(int i) {
        return this.f3045a.getString(i);
    }

    public String getString(int i, Object... objArr) {
        return this.f3045a.getString(i, objArr);
    }

    public String[] getStringArray(int i) {
        return this.f3045a.getStringArray(i);
    }

    public CharSequence getText(int i) {
        return this.f3045a.getText(i);
    }

    public CharSequence getText(int i, CharSequence charSequence) {
        return this.f3045a.getText(i, charSequence);
    }

    public CharSequence[] getTextArray(int i) {
        return this.f3045a.getTextArray(i);
    }

    public void getValue(int i, TypedValue typedValue, boolean z) {
        this.f3045a.getValue(i, typedValue, z);
    }

    public void getValue(String str, TypedValue typedValue, boolean z) {
        this.f3045a.getValue(str, typedValue, z);
    }

    public void getValueForDensity(int i, int i2, TypedValue typedValue, boolean z) {
        this.f3045a.getValueForDensity(i, i2, typedValue, z);
    }

    public XmlResourceParser getXml(int i) {
        return this.f3045a.getXml(i);
    }

    public TypedArray obtainAttributes(AttributeSet attributeSet, int[] iArr) {
        return this.f3045a.obtainAttributes(attributeSet, iArr);
    }

    public TypedArray obtainTypedArray(int i) {
        return this.f3045a.obtainTypedArray(i);
    }

    public InputStream openRawResource(int i) {
        return this.f3045a.openRawResource(i);
    }

    public InputStream openRawResource(int i, TypedValue typedValue) {
        return this.f3045a.openRawResource(i, typedValue);
    }

    public AssetFileDescriptor openRawResourceFd(int i) {
        return this.f3045a.openRawResourceFd(i);
    }

    public void parseBundleExtra(String str, AttributeSet attributeSet, Bundle bundle) {
        this.f3045a.parseBundleExtra(str, attributeSet, bundle);
    }

    public void parseBundleExtras(XmlResourceParser xmlResourceParser, Bundle bundle) {
        this.f3045a.parseBundleExtras(xmlResourceParser, bundle);
    }

    public void updateConfiguration(Configuration configuration, DisplayMetrics displayMetrics) {
        super.updateConfiguration(configuration, displayMetrics);
        if (this.f3045a != null) {
            this.f3045a.updateConfiguration(configuration, displayMetrics);
        }
    }
}
