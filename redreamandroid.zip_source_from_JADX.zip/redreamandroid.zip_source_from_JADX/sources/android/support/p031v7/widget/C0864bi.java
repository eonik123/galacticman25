package android.support.p031v7.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.support.p018v4.graphics.C0435a;
import android.util.AttributeSet;
import android.util.TypedValue;

/* renamed from: android.support.v7.widget.bi */
class C0864bi {

    /* renamed from: a */
    static final int[] f3124a = {-16842910};

    /* renamed from: b */
    static final int[] f3125b = {16842908};

    /* renamed from: c */
    static final int[] f3126c = {16843518};

    /* renamed from: d */
    static final int[] f3127d = {16842919};

    /* renamed from: e */
    static final int[] f3128e = {16842912};

    /* renamed from: f */
    static final int[] f3129f = {16842913};

    /* renamed from: g */
    static final int[] f3130g = {-16842919, -16842908};

    /* renamed from: h */
    static final int[] f3131h = new int[0];

    /* renamed from: i */
    private static final ThreadLocal<TypedValue> f3132i = new ThreadLocal<>();

    /* renamed from: j */
    private static final int[] f3133j = new int[1];

    /* renamed from: a */
    public static int m4626a(Context context, int i) {
        f3133j[0] = i;
        C0869bn a = C0869bn.m4637a(context, (AttributeSet) null, f3133j);
        try {
            return a.mo4429b(0, 0);
        } finally {
            a.mo4427a();
        }
    }

    /* renamed from: a */
    static int m4627a(Context context, int i, float f) {
        int a = m4626a(context, i);
        return C0435a.m1892b(a, Math.round(((float) Color.alpha(a)) * f));
    }

    /* renamed from: a */
    private static TypedValue m4628a() {
        TypedValue typedValue = (TypedValue) f3132i.get();
        if (typedValue != null) {
            return typedValue;
        }
        TypedValue typedValue2 = new TypedValue();
        f3132i.set(typedValue2);
        return typedValue2;
    }

    /* renamed from: b */
    public static ColorStateList m4629b(Context context, int i) {
        f3133j[0] = i;
        C0869bn a = C0869bn.m4637a(context, (AttributeSet) null, f3133j);
        try {
            return a.mo4436e(0);
        } finally {
            a.mo4427a();
        }
    }

    /* renamed from: c */
    public static int m4630c(Context context, int i) {
        ColorStateList b = m4629b(context, i);
        if (b != null && b.isStateful()) {
            return b.getColorForState(f3124a, b.getDefaultColor());
        }
        TypedValue a = m4628a();
        context.getTheme().resolveAttribute(16842803, a, true);
        return m4627a(context, i, a.getFloat());
    }
}
