package android.support.p031v7.widget;

import android.support.p031v7.widget.C0805ay.C0835p;
import android.support.p031v7.widget.C0805ay.C0843u;
import android.view.View;

/* renamed from: android.support.v7.widget.ar */
class C0786ar {

    /* renamed from: a */
    boolean f2758a = true;

    /* renamed from: b */
    int f2759b;

    /* renamed from: c */
    int f2760c;

    /* renamed from: d */
    int f2761d;

    /* renamed from: e */
    int f2762e;

    /* renamed from: f */
    int f2763f = 0;

    /* renamed from: g */
    int f2764g = 0;

    /* renamed from: h */
    boolean f2765h;

    /* renamed from: i */
    boolean f2766i;

    C0786ar() {
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public View mo3726a(C0835p pVar) {
        View c = pVar.mo4182c(this.f2760c);
        this.f2760c += this.f2761d;
        return c;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public boolean mo3727a(C0843u uVar) {
        return this.f2760c >= 0 && this.f2760c < uVar.mo4227e();
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("LayoutState{mAvailable=");
        sb.append(this.f2759b);
        sb.append(", mCurrentPosition=");
        sb.append(this.f2760c);
        sb.append(", mItemDirection=");
        sb.append(this.f2761d);
        sb.append(", mLayoutDirection=");
        sb.append(this.f2762e);
        sb.append(", mStartLine=");
        sb.append(this.f2763f);
        sb.append(", mEndLine=");
        sb.append(this.f2764g);
        sb.append('}');
        return sb.toString();
    }
}
