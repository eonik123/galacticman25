package android.support.p031v7.widget;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.RectF;
import android.os.Build.VERSION;
import android.support.p031v7.p032a.C0540a.C0550j;
import android.text.Layout.Alignment;
import android.text.StaticLayout;
import android.text.StaticLayout.Builder;
import android.text.TextDirectionHeuristic;
import android.text.TextDirectionHeuristics;
import android.text.TextPaint;
import android.text.method.TransformationMethod;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.Log;
import android.util.TypedValue;
import android.widget.TextView;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.concurrent.ConcurrentHashMap;

/* renamed from: android.support.v7.widget.aa */
class C0743aa {

    /* renamed from: a */
    private static final RectF f2599a = new RectF();

    /* renamed from: b */
    private static ConcurrentHashMap<String, Method> f2600b = new ConcurrentHashMap<>();

    /* renamed from: c */
    private int f2601c = 0;

    /* renamed from: d */
    private boolean f2602d = false;

    /* renamed from: e */
    private float f2603e = -1.0f;

    /* renamed from: f */
    private float f2604f = -1.0f;

    /* renamed from: g */
    private float f2605g = -1.0f;

    /* renamed from: h */
    private int[] f2606h = new int[0];

    /* renamed from: i */
    private boolean f2607i = false;

    /* renamed from: j */
    private TextPaint f2608j;

    /* renamed from: k */
    private final TextView f2609k;

    /* renamed from: l */
    private final Context f2610l;

    C0743aa(TextView textView) {
        this.f2609k = textView;
        this.f2610l = this.f2609k.getContext();
    }

    /* renamed from: a */
    private int m3664a(RectF rectF) {
        int length = this.f2606h.length;
        if (length == 0) {
            throw new IllegalStateException("No available text sizes to choose from.");
        }
        int i = 0;
        int i2 = 1;
        int i3 = length - 1;
        while (true) {
            int i4 = i2;
            int i5 = i;
            i = i4;
            while (i <= i3) {
                int i6 = (i + i3) / 2;
                if (m3672a(this.f2606h[i6], rectF)) {
                    i2 = i6 + 1;
                } else {
                    i5 = i6 - 1;
                    i3 = i5;
                }
            }
            return this.f2606h[i5];
        }
    }

    /* renamed from: a */
    private StaticLayout m3665a(CharSequence charSequence, Alignment alignment, int i) {
        float floatValue;
        float floatValue2;
        boolean booleanValue;
        if (VERSION.SDK_INT >= 16) {
            floatValue = this.f2609k.getLineSpacingMultiplier();
            floatValue2 = this.f2609k.getLineSpacingExtra();
            booleanValue = this.f2609k.getIncludeFontPadding();
        } else {
            floatValue = ((Float) m3667a((Object) this.f2609k, "getLineSpacingMultiplier", (T) Float.valueOf(1.0f))).floatValue();
            floatValue2 = ((Float) m3667a((Object) this.f2609k, "getLineSpacingExtra", (T) Float.valueOf(0.0f))).floatValue();
            booleanValue = ((Boolean) m3667a((Object) this.f2609k, "getIncludeFontPadding", (T) Boolean.valueOf(true))).booleanValue();
        }
        StaticLayout staticLayout = new StaticLayout(charSequence, this.f2608j, i, alignment, floatValue, floatValue2, booleanValue);
        return staticLayout;
    }

    /* renamed from: a */
    private StaticLayout m3666a(CharSequence charSequence, Alignment alignment, int i, int i2) {
        TextDirectionHeuristic textDirectionHeuristic = (TextDirectionHeuristic) m3667a((Object) this.f2609k, "getTextDirectionHeuristic", (T) TextDirectionHeuristics.FIRSTSTRONG_LTR);
        Builder hyphenationFrequency = Builder.obtain(charSequence, 0, charSequence.length(), this.f2608j, i).setAlignment(alignment).setLineSpacing(this.f2609k.getLineSpacingExtra(), this.f2609k.getLineSpacingMultiplier()).setIncludePad(this.f2609k.getIncludeFontPadding()).setBreakStrategy(this.f2609k.getBreakStrategy()).setHyphenationFrequency(this.f2609k.getHyphenationFrequency());
        if (i2 == -1) {
            i2 = Integer.MAX_VALUE;
        }
        return hyphenationFrequency.setMaxLines(i2).setTextDirection(textDirectionHeuristic).build();
    }

    /* renamed from: a */
    private <T> T m3667a(Object obj, String str, T t) {
        try {
            return m3668a(str).invoke(obj, new Object[0]);
        } catch (Exception e) {
            String str2 = "ACTVAutoSizeHelper";
            StringBuilder sb = new StringBuilder();
            sb.append("Failed to invoke TextView#");
            sb.append(str);
            sb.append("() method");
            Log.w(str2, sb.toString(), e);
            return t;
        }
    }

    /* renamed from: a */
    private Method m3668a(String str) {
        try {
            Method method = (Method) f2600b.get(str);
            if (method == null) {
                method = TextView.class.getDeclaredMethod(str, new Class[0]);
                if (method != null) {
                    method.setAccessible(true);
                    f2600b.put(str, method);
                }
            }
            return method;
        } catch (Exception e) {
            StringBuilder sb = new StringBuilder();
            sb.append("Failed to retrieve TextView#");
            sb.append(str);
            sb.append("() method");
            Log.w("ACTVAutoSizeHelper", sb.toString(), e);
            return null;
        }
    }

    /* renamed from: a */
    private void m3669a(float f) {
        if (f != this.f2609k.getPaint().getTextSize()) {
            this.f2609k.getPaint().setTextSize(f);
            boolean isInLayout = VERSION.SDK_INT >= 18 ? this.f2609k.isInLayout() : false;
            if (this.f2609k.getLayout() != null) {
                this.f2602d = false;
                try {
                    Method a = m3668a("nullLayouts");
                    if (a != null) {
                        a.invoke(this.f2609k, new Object[0]);
                    }
                } catch (Exception e) {
                    Log.w("ACTVAutoSizeHelper", "Failed to invoke TextView#nullLayouts() method", e);
                }
                if (!isInLayout) {
                    this.f2609k.requestLayout();
                } else {
                    this.f2609k.forceLayout();
                }
                this.f2609k.invalidate();
            }
        }
    }

    /* renamed from: a */
    private void m3670a(float f, float f2, float f3) {
        if (f <= 0.0f) {
            StringBuilder sb = new StringBuilder();
            sb.append("Minimum auto-size text size (");
            sb.append(f);
            sb.append("px) is less or equal to (0px)");
            throw new IllegalArgumentException(sb.toString());
        } else if (f2 <= f) {
            StringBuilder sb2 = new StringBuilder();
            sb2.append("Maximum auto-size text size (");
            sb2.append(f2);
            sb2.append("px) is less or equal to minimum auto-size ");
            sb2.append("text size (");
            sb2.append(f);
            sb2.append("px)");
            throw new IllegalArgumentException(sb2.toString());
        } else if (f3 <= 0.0f) {
            StringBuilder sb3 = new StringBuilder();
            sb3.append("The auto-size step granularity (");
            sb3.append(f3);
            sb3.append("px) is less or equal to (0px)");
            throw new IllegalArgumentException(sb3.toString());
        } else {
            this.f2601c = 1;
            this.f2604f = f;
            this.f2605g = f2;
            this.f2603e = f3;
            this.f2607i = false;
        }
    }

    /* renamed from: a */
    private void m3671a(TypedArray typedArray) {
        int length = typedArray.length();
        int[] iArr = new int[length];
        if (length > 0) {
            for (int i = 0; i < length; i++) {
                iArr[i] = typedArray.getDimensionPixelSize(i, -1);
            }
            this.f2606h = m3673a(iArr);
            m3674h();
        }
    }

    /* renamed from: a */
    private boolean m3672a(int i, RectF rectF) {
        CharSequence text = this.f2609k.getText();
        TransformationMethod transformationMethod = this.f2609k.getTransformationMethod();
        if (transformationMethod != null) {
            CharSequence transformation = transformationMethod.getTransformation(text, this.f2609k);
            if (transformation != null) {
                text = transformation;
            }
        }
        int maxLines = VERSION.SDK_INT >= 16 ? this.f2609k.getMaxLines() : -1;
        if (this.f2608j == null) {
            this.f2608j = new TextPaint();
        } else {
            this.f2608j.reset();
        }
        this.f2608j.set(this.f2609k.getPaint());
        this.f2608j.setTextSize((float) i);
        Alignment alignment = (Alignment) m3667a((Object) this.f2609k, "getLayoutAlignment", (T) Alignment.ALIGN_NORMAL);
        StaticLayout a = VERSION.SDK_INT >= 23 ? m3666a(text, alignment, Math.round(rectF.right), maxLines) : m3665a(text, alignment, Math.round(rectF.right));
        return (maxLines == -1 || (a.getLineCount() <= maxLines && a.getLineEnd(a.getLineCount() - 1) == text.length())) && ((float) a.getHeight()) <= rectF.bottom;
    }

    /* renamed from: a */
    private int[] m3673a(int[] iArr) {
        if (r0 == 0) {
            return iArr;
        }
        Arrays.sort(iArr);
        ArrayList arrayList = new ArrayList();
        for (int i : iArr) {
            if (i > 0 && Collections.binarySearch(arrayList, Integer.valueOf(i)) < 0) {
                arrayList.add(Integer.valueOf(i));
            }
        }
        if (r0 == arrayList.size()) {
            return iArr;
        }
        int size = arrayList.size();
        int[] iArr2 = new int[size];
        for (int i2 = 0; i2 < size; i2++) {
            iArr2[i2] = ((Integer) arrayList.get(i2)).intValue();
        }
        return iArr2;
    }

    /* renamed from: h */
    private boolean m3674h() {
        int length = this.f2606h.length;
        this.f2607i = length > 0;
        if (this.f2607i) {
            this.f2601c = 1;
            this.f2604f = (float) this.f2606h[0];
            this.f2605g = (float) this.f2606h[length - 1];
            this.f2603e = -1.0f;
        }
        return this.f2607i;
    }

    /* renamed from: i */
    private boolean m3675i() {
        if (!m3677k() || this.f2601c != 1) {
            this.f2602d = false;
        } else {
            if (!this.f2607i || this.f2606h.length == 0) {
                float round = (float) Math.round(this.f2604f);
                int i = 1;
                while (Math.round(this.f2603e + round) <= Math.round(this.f2605g)) {
                    i++;
                    round += this.f2603e;
                }
                int[] iArr = new int[i];
                float f = this.f2604f;
                for (int i2 = 0; i2 < i; i2++) {
                    iArr[i2] = Math.round(f);
                    f += this.f2603e;
                }
                this.f2606h = m3673a(iArr);
            }
            this.f2602d = true;
        }
        return this.f2602d;
    }

    /* renamed from: j */
    private void m3676j() {
        this.f2601c = 0;
        this.f2604f = -1.0f;
        this.f2605g = -1.0f;
        this.f2603e = -1.0f;
        this.f2606h = new int[0];
        this.f2602d = false;
    }

    /* renamed from: k */
    private boolean m3677k() {
        return !(this.f2609k instanceof C0915l);
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public int mo3519a() {
        return this.f2601c;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo3520a(int i) {
        if (m3677k()) {
            switch (i) {
                case 0:
                    m3676j();
                    break;
                case 1:
                    DisplayMetrics displayMetrics = this.f2610l.getResources().getDisplayMetrics();
                    m3670a(TypedValue.applyDimension(2, 12.0f, displayMetrics), TypedValue.applyDimension(2, 112.0f, displayMetrics), 1.0f);
                    if (m3675i()) {
                        mo3529f();
                        return;
                    }
                    break;
                default:
                    StringBuilder sb = new StringBuilder();
                    sb.append("Unknown auto-size text type: ");
                    sb.append(i);
                    throw new IllegalArgumentException(sb.toString());
            }
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo3521a(int i, float f) {
        m3669a(TypedValue.applyDimension(i, f, (this.f2610l == null ? Resources.getSystem() : this.f2610l.getResources()).getDisplayMetrics()));
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo3522a(int i, int i2, int i3, int i4) {
        if (m3677k()) {
            DisplayMetrics displayMetrics = this.f2610l.getResources().getDisplayMetrics();
            m3670a(TypedValue.applyDimension(i4, (float) i, displayMetrics), TypedValue.applyDimension(i4, (float) i2, displayMetrics), TypedValue.applyDimension(i4, (float) i3, displayMetrics));
            if (m3675i()) {
                mo3529f();
            }
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo3523a(AttributeSet attributeSet, int i) {
        TypedArray obtainStyledAttributes = this.f2610l.obtainStyledAttributes(attributeSet, C0550j.AppCompatTextView, i, 0);
        if (obtainStyledAttributes.hasValue(C0550j.AppCompatTextView_autoSizeTextType)) {
            this.f2601c = obtainStyledAttributes.getInt(C0550j.AppCompatTextView_autoSizeTextType, 0);
        }
        float dimension = obtainStyledAttributes.hasValue(C0550j.AppCompatTextView_autoSizeStepGranularity) ? obtainStyledAttributes.getDimension(C0550j.AppCompatTextView_autoSizeStepGranularity, -1.0f) : -1.0f;
        float dimension2 = obtainStyledAttributes.hasValue(C0550j.AppCompatTextView_autoSizeMinTextSize) ? obtainStyledAttributes.getDimension(C0550j.AppCompatTextView_autoSizeMinTextSize, -1.0f) : -1.0f;
        float dimension3 = obtainStyledAttributes.hasValue(C0550j.AppCompatTextView_autoSizeMaxTextSize) ? obtainStyledAttributes.getDimension(C0550j.AppCompatTextView_autoSizeMaxTextSize, -1.0f) : -1.0f;
        if (obtainStyledAttributes.hasValue(C0550j.AppCompatTextView_autoSizePresetSizes)) {
            int resourceId = obtainStyledAttributes.getResourceId(C0550j.AppCompatTextView_autoSizePresetSizes, 0);
            if (resourceId > 0) {
                TypedArray obtainTypedArray = obtainStyledAttributes.getResources().obtainTypedArray(resourceId);
                m3671a(obtainTypedArray);
                obtainTypedArray.recycle();
            }
        }
        obtainStyledAttributes.recycle();
        if (!m3677k()) {
            this.f2601c = 0;
        } else if (this.f2601c == 1) {
            if (!this.f2607i) {
                DisplayMetrics displayMetrics = this.f2610l.getResources().getDisplayMetrics();
                if (dimension2 == -1.0f) {
                    dimension2 = TypedValue.applyDimension(2, 12.0f, displayMetrics);
                }
                if (dimension3 == -1.0f) {
                    dimension3 = TypedValue.applyDimension(2, 112.0f, displayMetrics);
                }
                if (dimension == -1.0f) {
                    dimension = 1.0f;
                }
                m3670a(dimension2, dimension3, dimension);
            }
            m3675i();
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo3524a(int[] iArr, int i) {
        if (m3677k()) {
            int length = iArr.length;
            if (length > 0) {
                int[] iArr2 = new int[length];
                if (i == 0) {
                    iArr2 = Arrays.copyOf(iArr, length);
                } else {
                    DisplayMetrics displayMetrics = this.f2610l.getResources().getDisplayMetrics();
                    for (int i2 = 0; i2 < length; i2++) {
                        iArr2[i2] = Math.round(TypedValue.applyDimension(i, (float) iArr[i2], displayMetrics));
                    }
                }
                this.f2606h = m3673a(iArr2);
                if (!m3674h()) {
                    StringBuilder sb = new StringBuilder();
                    sb.append("None of the preset sizes is valid: ");
                    sb.append(Arrays.toString(iArr));
                    throw new IllegalArgumentException(sb.toString());
                }
            } else {
                this.f2607i = false;
            }
            if (m3675i()) {
                mo3529f();
            }
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: b */
    public int mo3525b() {
        return Math.round(this.f2603e);
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: c */
    public int mo3526c() {
        return Math.round(this.f2604f);
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: d */
    public int mo3527d() {
        return Math.round(this.f2605g);
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: e */
    public int[] mo3528e() {
        return this.f2606h;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: f */
    public void mo3529f() {
        if (mo3530g()) {
            if (this.f2602d) {
                if (this.f2609k.getMeasuredHeight() > 0 && this.f2609k.getMeasuredWidth() > 0) {
                    int measuredWidth = ((Boolean) m3667a((Object) this.f2609k, "getHorizontallyScrolling", (T) Boolean.valueOf(false))).booleanValue() ? 1048576 : (this.f2609k.getMeasuredWidth() - this.f2609k.getTotalPaddingLeft()) - this.f2609k.getTotalPaddingRight();
                    int height = (this.f2609k.getHeight() - this.f2609k.getCompoundPaddingBottom()) - this.f2609k.getCompoundPaddingTop();
                    if (measuredWidth > 0 && height > 0) {
                        synchronized (f2599a) {
                            f2599a.setEmpty();
                            f2599a.right = (float) measuredWidth;
                            f2599a.bottom = (float) height;
                            float a = (float) m3664a(f2599a);
                            if (a != this.f2609k.getTextSize()) {
                                mo3521a(0, a);
                            }
                        }
                    } else {
                        return;
                    }
                } else {
                    return;
                }
            }
            this.f2602d = true;
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: g */
    public boolean mo3530g() {
        return m3677k() && this.f2601c != 0;
    }
}
