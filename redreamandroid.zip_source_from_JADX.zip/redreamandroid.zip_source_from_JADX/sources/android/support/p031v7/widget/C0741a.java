package android.support.p031v7.widget;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.support.p018v4.p028h.C0495r;
import android.support.p018v4.p028h.C0502v;
import android.support.p018v4.p028h.C0506w;
import android.support.p031v7.p032a.C0540a.C0541a;
import android.support.p031v7.p032a.C0540a.C0550j;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.ContextThemeWrapper;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.ViewGroup;

/* renamed from: android.support.v7.widget.a */
abstract class C0741a extends ViewGroup {

    /* renamed from: a */
    protected final C0742a f2588a;

    /* renamed from: b */
    protected final Context f2589b;

    /* renamed from: c */
    protected ActionMenuView f2590c;

    /* renamed from: d */
    protected C0887c f2591d;

    /* renamed from: e */
    protected int f2592e;

    /* renamed from: f */
    protected C0502v f2593f;

    /* renamed from: g */
    private boolean f2594g;

    /* renamed from: h */
    private boolean f2595h;

    /* renamed from: android.support.v7.widget.a$a */
    protected class C0742a implements C0506w {

        /* renamed from: a */
        int f2596a;

        /* renamed from: c */
        private boolean f2598c = false;

        protected C0742a() {
        }

        /* renamed from: a */
        public C0742a mo3518a(C0502v vVar, int i) {
            C0741a.this.f2593f = vVar;
            this.f2596a = i;
            return this;
        }

        /* renamed from: a */
        public void mo1966a(View view) {
            C0741a.super.setVisibility(0);
            this.f2598c = false;
        }

        /* renamed from: b */
        public void mo1967b(View view) {
            if (!this.f2598c) {
                C0741a.this.f2593f = null;
                C0741a.super.setVisibility(this.f2596a);
            }
        }

        /* renamed from: c */
        public void mo1968c(View view) {
            this.f2598c = true;
        }
    }

    C0741a(Context context) {
        this(context, null);
    }

    C0741a(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    C0741a(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f2588a = new C0742a();
        TypedValue typedValue = new TypedValue();
        if (!context.getTheme().resolveAttribute(C0541a.actionBarPopupTheme, typedValue, true) || typedValue.resourceId == 0) {
            this.f2589b = context;
        } else {
            this.f2589b = new ContextThemeWrapper(context, typedValue.resourceId);
        }
    }

    /* renamed from: a */
    protected static int m3653a(int i, int i2, boolean z) {
        return z ? i - i2 : i + i2;
    }

    /* access modifiers changed from: protected */
    /* renamed from: a */
    public int mo3515a(View view, int i, int i2, int i3) {
        view.measure(MeasureSpec.makeMeasureSpec(i, Integer.MIN_VALUE), i2);
        return Math.max(0, (i - view.getMeasuredWidth()) - i3);
    }

    /* access modifiers changed from: protected */
    /* renamed from: a */
    public int mo3516a(View view, int i, int i2, int i3, boolean z) {
        int measuredWidth = view.getMeasuredWidth();
        int measuredHeight = view.getMeasuredHeight();
        int i4 = i2 + ((i3 - measuredHeight) / 2);
        if (z) {
            view.layout(i - measuredWidth, i4, i, measuredHeight + i4);
        } else {
            view.layout(i, i4, i + measuredWidth, measuredHeight + i4);
        }
        return z ? -measuredWidth : measuredWidth;
    }

    /* renamed from: a */
    public C0502v mo2978a(int i, long j) {
        C0502v a;
        if (this.f2593f != null) {
            this.f2593f.mo1960b();
        }
        if (i == 0) {
            if (getVisibility() != 0) {
                setAlpha(0.0f);
            }
            a = C0495r.m2156k(this).mo1953a(1.0f);
        } else {
            a = C0495r.m2156k(this).mo1953a(0.0f);
        }
        a.mo1954a(j);
        a.mo1955a((C0506w) this.f2588a.mo3518a(a, i));
        return a;
    }

    /* renamed from: a */
    public boolean mo2980a() {
        if (this.f2591d != null) {
            return this.f2591d.mo4493d();
        }
        return false;
    }

    public int getAnimatedVisibility() {
        return this.f2593f != null ? this.f2588a.f2596a : getVisibility();
    }

    public int getContentHeight() {
        return this.f2592e;
    }

    /* access modifiers changed from: protected */
    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        TypedArray obtainStyledAttributes = getContext().obtainStyledAttributes(null, C0550j.ActionBar, C0541a.actionBarStyle, 0);
        setContentHeight(obtainStyledAttributes.getLayoutDimension(C0550j.ActionBar_height, 0));
        obtainStyledAttributes.recycle();
        if (this.f2591d != null) {
            this.f2591d.mo4487a(configuration);
        }
    }

    public boolean onHoverEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 9) {
            this.f2595h = false;
        }
        if (!this.f2595h) {
            boolean onHoverEvent = super.onHoverEvent(motionEvent);
            if (actionMasked == 9 && !onHoverEvent) {
                this.f2595h = true;
            }
        }
        if (actionMasked == 10 || actionMasked == 3) {
            this.f2595h = false;
        }
        return true;
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0) {
            this.f2594g = false;
        }
        if (!this.f2594g) {
            boolean onTouchEvent = super.onTouchEvent(motionEvent);
            if (actionMasked == 0 && !onTouchEvent) {
                this.f2594g = true;
            }
        }
        if (actionMasked == 1 || actionMasked == 3) {
            this.f2594g = false;
        }
        return true;
    }

    public void setContentHeight(int i) {
        this.f2592e = i;
        requestLayout();
    }

    public void setVisibility(int i) {
        if (i != getVisibility()) {
            if (this.f2593f != null) {
                this.f2593f.mo1960b();
            }
            super.setVisibility(i);
        }
    }
}
