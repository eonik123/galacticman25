package android.support.p031v7.widget;

import android.app.PendingIntent;
import android.app.SearchableInfo;
import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.database.Cursor;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.Drawable.ConstantState;
import android.net.Uri;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.ClassLoaderCreator;
import android.os.Parcelable.Creator;
import android.support.p018v4.p028h.C0457a;
import android.support.p018v4.p028h.C0495r;
import android.support.p018v4.widget.C0519d;
import android.support.p031v7.p032a.C0540a.C0541a;
import android.support.p031v7.p032a.C0540a.C0544d;
import android.support.p031v7.p032a.C0540a.C0546f;
import android.support.p031v7.p032a.C0540a.C0547g;
import android.support.p031v7.p032a.C0540a.C0548h;
import android.support.p031v7.p032a.C0540a.C0550j;
import android.support.p031v7.view.C0629c;
import android.text.Editable;
import android.text.SpannableStringBuilder;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.text.style.ImageSpan;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.KeyEvent.DispatcherState;
import android.view.LayoutInflater;
import android.view.TouchDelegate;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnFocusChangeListener;
import android.view.View.OnKeyListener;
import android.view.View.OnLayoutChangeListener;
import android.view.ViewConfiguration;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.AutoCompleteTextView;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.TextView.OnEditorActionListener;
import java.lang.reflect.Method;
import java.util.WeakHashMap;

/* renamed from: android.support.v7.widget.SearchView */
public class SearchView extends C0787as implements C0629c {

    /* renamed from: i */
    static final C0716a f2401i = new C0716a();

    /* renamed from: A */
    private C0718c f2402A;

    /* renamed from: B */
    private C0717b f2403B;

    /* renamed from: C */
    private C0719d f2404C;

    /* renamed from: D */
    private OnClickListener f2405D;

    /* renamed from: E */
    private boolean f2406E;

    /* renamed from: F */
    private boolean f2407F;

    /* renamed from: G */
    private boolean f2408G;

    /* renamed from: H */
    private CharSequence f2409H;

    /* renamed from: I */
    private boolean f2410I;

    /* renamed from: J */
    private boolean f2411J;

    /* renamed from: K */
    private int f2412K;

    /* renamed from: L */
    private boolean f2413L;

    /* renamed from: M */
    private CharSequence f2414M;

    /* renamed from: N */
    private CharSequence f2415N;

    /* renamed from: O */
    private boolean f2416O;

    /* renamed from: P */
    private int f2417P;

    /* renamed from: Q */
    private Bundle f2418Q;

    /* renamed from: R */
    private final Runnable f2419R;

    /* renamed from: S */
    private Runnable f2420S;

    /* renamed from: T */
    private final WeakHashMap<String, ConstantState> f2421T;

    /* renamed from: U */
    private final OnClickListener f2422U;

    /* renamed from: V */
    private final OnEditorActionListener f2423V;

    /* renamed from: W */
    private final OnItemClickListener f2424W;

    /* renamed from: a */
    final SearchAutoComplete f2425a;

    /* renamed from: aa */
    private final OnItemSelectedListener f2426aa;

    /* renamed from: ab */
    private TextWatcher f2427ab;

    /* renamed from: b */
    final ImageView f2428b;

    /* renamed from: c */
    final ImageView f2429c;

    /* renamed from: d */
    final ImageView f2430d;

    /* renamed from: e */
    final ImageView f2431e;

    /* renamed from: f */
    OnFocusChangeListener f2432f;

    /* renamed from: g */
    C0519d f2433g;

    /* renamed from: h */
    SearchableInfo f2434h;

    /* renamed from: j */
    OnKeyListener f2435j;

    /* renamed from: k */
    private final View f2436k;

    /* renamed from: l */
    private final View f2437l;

    /* renamed from: m */
    private final View f2438m;

    /* renamed from: n */
    private final View f2439n;

    /* renamed from: o */
    private C0722f f2440o;

    /* renamed from: p */
    private Rect f2441p;

    /* renamed from: q */
    private Rect f2442q;

    /* renamed from: r */
    private int[] f2443r;

    /* renamed from: s */
    private int[] f2444s;

    /* renamed from: t */
    private final ImageView f2445t;

    /* renamed from: u */
    private final Drawable f2446u;

    /* renamed from: v */
    private final int f2447v;

    /* renamed from: w */
    private final int f2448w;

    /* renamed from: x */
    private final Intent f2449x;

    /* renamed from: y */
    private final Intent f2450y;

    /* renamed from: z */
    private final CharSequence f2451z;

    /* renamed from: android.support.v7.widget.SearchView$SearchAutoComplete */
    public static class SearchAutoComplete extends C0904f {

        /* renamed from: a */
        final Runnable f2462a;

        /* renamed from: b */
        private int f2463b;

        /* renamed from: c */
        private SearchView f2464c;

        /* renamed from: d */
        private boolean f2465d;

        public SearchAutoComplete(Context context) {
            this(context, null);
        }

        public SearchAutoComplete(Context context, AttributeSet attributeSet) {
            this(context, attributeSet, C0541a.autoCompleteTextViewStyle);
        }

        public SearchAutoComplete(Context context, AttributeSet attributeSet, int i) {
            super(context, attributeSet, i);
            this.f2462a = new Runnable() {
                public void run() {
                    SearchAutoComplete.this.mo3306b();
                }
            };
            this.f2463b = getThreshold();
        }

        private int getSearchViewTextMinWidthDp() {
            Configuration configuration = getResources().getConfiguration();
            int i = configuration.screenWidthDp;
            int i2 = configuration.screenHeightDp;
            if (i < 960 || i2 < 720 || configuration.orientation != 2) {
                return (i >= 600 || (i >= 640 && i2 >= 480)) ? 192 : 160;
            }
            return 256;
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public boolean mo3305a() {
            return TextUtils.getTrimmedLength(getText()) == 0;
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: b */
        public void mo3306b() {
            if (this.f2465d) {
                ((InputMethodManager) getContext().getSystemService("input_method")).showSoftInput(this, 0);
                this.f2465d = false;
            }
        }

        public boolean enoughToFilter() {
            return this.f2463b <= 0 || super.enoughToFilter();
        }

        public InputConnection onCreateInputConnection(EditorInfo editorInfo) {
            InputConnection onCreateInputConnection = super.onCreateInputConnection(editorInfo);
            if (this.f2465d) {
                removeCallbacks(this.f2462a);
                post(this.f2462a);
            }
            return onCreateInputConnection;
        }

        /* access modifiers changed from: protected */
        public void onFinishInflate() {
            super.onFinishInflate();
            setMinWidth((int) TypedValue.applyDimension(1, (float) getSearchViewTextMinWidthDp(), getResources().getDisplayMetrics()));
        }

        /* access modifiers changed from: protected */
        public void onFocusChanged(boolean z, int i, Rect rect) {
            super.onFocusChanged(z, i, rect);
            this.f2464c.mo3268i();
        }

        public boolean onKeyPreIme(int i, KeyEvent keyEvent) {
            if (i == 4) {
                if (keyEvent.getAction() == 0 && keyEvent.getRepeatCount() == 0) {
                    DispatcherState keyDispatcherState = getKeyDispatcherState();
                    if (keyDispatcherState != null) {
                        keyDispatcherState.startTracking(keyEvent, this);
                    }
                    return true;
                } else if (keyEvent.getAction() == 1) {
                    DispatcherState keyDispatcherState2 = getKeyDispatcherState();
                    if (keyDispatcherState2 != null) {
                        keyDispatcherState2.handleUpEvent(keyEvent);
                    }
                    if (keyEvent.isTracking() && !keyEvent.isCanceled()) {
                        this.f2464c.clearFocus();
                        setImeVisibility(false);
                        return true;
                    }
                }
            }
            return super.onKeyPreIme(i, keyEvent);
        }

        public void onWindowFocusChanged(boolean z) {
            super.onWindowFocusChanged(z);
            if (z && this.f2464c.hasFocus() && getVisibility() == 0) {
                this.f2465d = true;
                if (SearchView.m3403a(getContext())) {
                    SearchView.f2401i.mo3320a(this, true);
                }
            }
        }

        public void performCompletion() {
        }

        /* access modifiers changed from: protected */
        public void replaceText(CharSequence charSequence) {
        }

        /* access modifiers changed from: 0000 */
        public void setImeVisibility(boolean z) {
            InputMethodManager inputMethodManager = (InputMethodManager) getContext().getSystemService("input_method");
            if (!z) {
                this.f2465d = false;
                removeCallbacks(this.f2462a);
                inputMethodManager.hideSoftInputFromWindow(getWindowToken(), 0);
            } else if (inputMethodManager.isActive(this)) {
                this.f2465d = false;
                removeCallbacks(this.f2462a);
                inputMethodManager.showSoftInput(this, 0);
            } else {
                this.f2465d = true;
            }
        }

        /* access modifiers changed from: 0000 */
        public void setSearchView(SearchView searchView) {
            this.f2464c = searchView;
        }

        public void setThreshold(int i) {
            super.setThreshold(i);
            this.f2463b = i;
        }
    }

    /* renamed from: android.support.v7.widget.SearchView$a */
    private static class C0716a {

        /* renamed from: a */
        private Method f2467a;

        /* renamed from: b */
        private Method f2468b;

        /* renamed from: c */
        private Method f2469c;

        C0716a() {
            try {
                this.f2467a = AutoCompleteTextView.class.getDeclaredMethod("doBeforeTextChanged", new Class[0]);
                this.f2467a.setAccessible(true);
            } catch (NoSuchMethodException unused) {
            }
            try {
                this.f2468b = AutoCompleteTextView.class.getDeclaredMethod("doAfterTextChanged", new Class[0]);
                this.f2468b.setAccessible(true);
            } catch (NoSuchMethodException unused2) {
            }
            try {
                this.f2469c = AutoCompleteTextView.class.getMethod("ensureImeVisible", new Class[]{Boolean.TYPE});
                this.f2469c.setAccessible(true);
            } catch (NoSuchMethodException unused3) {
            }
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public void mo3319a(AutoCompleteTextView autoCompleteTextView) {
            if (this.f2467a != null) {
                try {
                    this.f2467a.invoke(autoCompleteTextView, new Object[0]);
                } catch (Exception unused) {
                }
            }
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public void mo3320a(AutoCompleteTextView autoCompleteTextView, boolean z) {
            if (this.f2469c != null) {
                try {
                    this.f2469c.invoke(autoCompleteTextView, new Object[]{Boolean.valueOf(z)});
                } catch (Exception unused) {
                }
            }
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: b */
        public void mo3321b(AutoCompleteTextView autoCompleteTextView) {
            if (this.f2468b != null) {
                try {
                    this.f2468b.invoke(autoCompleteTextView, new Object[0]);
                } catch (Exception unused) {
                }
            }
        }
    }

    /* renamed from: android.support.v7.widget.SearchView$b */
    public interface C0717b {
        /* renamed from: a */
        boolean mo3322a();
    }

    /* renamed from: android.support.v7.widget.SearchView$c */
    public interface C0718c {
        /* renamed from: a */
        boolean mo3323a(String str);

        /* renamed from: b */
        boolean mo3324b(String str);
    }

    /* renamed from: android.support.v7.widget.SearchView$d */
    public interface C0719d {
        /* renamed from: a */
        boolean mo3325a(int i);

        /* renamed from: b */
        boolean mo3326b(int i);
    }

    /* renamed from: android.support.v7.widget.SearchView$e */
    static class C0720e extends C0457a {
        public static final Creator<C0720e> CREATOR = new ClassLoaderCreator<C0720e>() {
            /* renamed from: a */
            public C0720e createFromParcel(Parcel parcel) {
                return new C0720e(parcel, null);
            }

            /* renamed from: a */
            public C0720e createFromParcel(Parcel parcel, ClassLoader classLoader) {
                return new C0720e(parcel, classLoader);
            }

            /* renamed from: a */
            public C0720e[] newArray(int i) {
                return new C0720e[i];
            }
        };

        /* renamed from: a */
        boolean f2470a;

        public C0720e(Parcel parcel, ClassLoader classLoader) {
            super(parcel, classLoader);
            this.f2470a = ((Boolean) parcel.readValue(null)).booleanValue();
        }

        C0720e(Parcelable parcelable) {
            super(parcelable);
        }

        public String toString() {
            StringBuilder sb = new StringBuilder();
            sb.append("SearchView.SavedState{");
            sb.append(Integer.toHexString(System.identityHashCode(this)));
            sb.append(" isIconified=");
            sb.append(this.f2470a);
            sb.append("}");
            return sb.toString();
        }

        public void writeToParcel(Parcel parcel, int i) {
            super.writeToParcel(parcel, i);
            parcel.writeValue(Boolean.valueOf(this.f2470a));
        }
    }

    /* renamed from: android.support.v7.widget.SearchView$f */
    private static class C0722f extends TouchDelegate {

        /* renamed from: a */
        private final View f2471a;

        /* renamed from: b */
        private final Rect f2472b = new Rect();

        /* renamed from: c */
        private final Rect f2473c = new Rect();

        /* renamed from: d */
        private final Rect f2474d = new Rect();

        /* renamed from: e */
        private final int f2475e;

        /* renamed from: f */
        private boolean f2476f;

        public C0722f(Rect rect, Rect rect2, View view) {
            super(rect, view);
            this.f2475e = ViewConfiguration.get(view.getContext()).getScaledTouchSlop();
            mo3334a(rect, rect2);
            this.f2471a = view;
        }

        /* renamed from: a */
        public void mo3334a(Rect rect, Rect rect2) {
            this.f2472b.set(rect);
            this.f2474d.set(rect);
            this.f2474d.inset(-this.f2475e, -this.f2475e);
            this.f2473c.set(rect2);
        }

        /* Code decompiled incorrectly, please refer to instructions dump. */
        public boolean onTouchEvent(android.view.MotionEvent r7) {
            /*
                r6 = this;
                float r0 = r7.getX()
                int r0 = (int) r0
                float r1 = r7.getY()
                int r1 = (int) r1
                int r2 = r7.getAction()
                r3 = 1
                r4 = 0
                switch(r2) {
                    case 0: goto L_0x0027;
                    case 1: goto L_0x0019;
                    case 2: goto L_0x0019;
                    case 3: goto L_0x0014;
                    default: goto L_0x0013;
                }
            L_0x0013:
                goto L_0x0033
            L_0x0014:
                boolean r2 = r6.f2476f
                r6.f2476f = r4
                goto L_0x0034
            L_0x0019:
                boolean r2 = r6.f2476f
                if (r2 == 0) goto L_0x0034
                android.graphics.Rect r5 = r6.f2474d
                boolean r5 = r5.contains(r0, r1)
                if (r5 != 0) goto L_0x0034
                r3 = r4
                goto L_0x0034
            L_0x0027:
                android.graphics.Rect r2 = r6.f2472b
                boolean r2 = r2.contains(r0, r1)
                if (r2 == 0) goto L_0x0033
                r6.f2476f = r3
                r2 = r3
                goto L_0x0034
            L_0x0033:
                r2 = r4
            L_0x0034:
                if (r2 == 0) goto L_0x0067
                if (r3 == 0) goto L_0x0052
                android.graphics.Rect r2 = r6.f2473c
                boolean r2 = r2.contains(r0, r1)
                if (r2 != 0) goto L_0x0052
                android.view.View r0 = r6.f2471a
                int r0 = r0.getWidth()
                int r0 = r0 / 2
                float r0 = (float) r0
                android.view.View r1 = r6.f2471a
                int r1 = r1.getHeight()
                int r1 = r1 / 2
                goto L_0x005d
            L_0x0052:
                android.graphics.Rect r2 = r6.f2473c
                int r2 = r2.left
                int r0 = r0 - r2
                float r0 = (float) r0
                android.graphics.Rect r2 = r6.f2473c
                int r2 = r2.top
                int r1 = r1 - r2
            L_0x005d:
                float r1 = (float) r1
                r7.setLocation(r0, r1)
                android.view.View r0 = r6.f2471a
                boolean r4 = r0.dispatchTouchEvent(r7)
            L_0x0067:
                return r4
            */
            throw new UnsupportedOperationException("Method not decompiled: android.support.p031v7.widget.SearchView.C0722f.onTouchEvent(android.view.MotionEvent):boolean");
        }
    }

    public SearchView(Context context) {
        this(context, null);
    }

    public SearchView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, C0541a.searchViewStyle);
    }

    public SearchView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f2441p = new Rect();
        this.f2442q = new Rect();
        this.f2443r = new int[2];
        this.f2444s = new int[2];
        this.f2419R = new Runnable() {
            public void run() {
                SearchView.this.mo3255d();
            }
        };
        this.f2420S = new Runnable() {
            public void run() {
                if (SearchView.this.f2433g != null && (SearchView.this.f2433g instanceof C0862bh)) {
                    SearchView.this.f2433g.mo2078a((Cursor) null);
                }
            }
        };
        this.f2421T = new WeakHashMap<>();
        this.f2422U = new OnClickListener() {
            public void onClick(View view) {
                if (view == SearchView.this.f2428b) {
                    SearchView.this.mo3258g();
                } else if (view == SearchView.this.f2430d) {
                    SearchView.this.mo3257f();
                } else if (view == SearchView.this.f2429c) {
                    SearchView.this.mo3256e();
                } else if (view == SearchView.this.f2431e) {
                    SearchView.this.mo3267h();
                } else {
                    if (view == SearchView.this.f2425a) {
                        SearchView.this.mo3270l();
                    }
                }
            }
        };
        this.f2435j = new OnKeyListener() {
            public boolean onKey(View view, int i, KeyEvent keyEvent) {
                if (SearchView.this.f2434h == null) {
                    return false;
                }
                if (SearchView.this.f2425a.isPopupShowing() && SearchView.this.f2425a.getListSelection() != -1) {
                    return SearchView.this.mo3251a(view, i, keyEvent);
                }
                if (SearchView.this.f2425a.mo3305a() || !keyEvent.hasNoModifiers() || keyEvent.getAction() != 1 || i != 66) {
                    return false;
                }
                view.cancelLongPress();
                SearchView.this.mo3246a(0, (String) null, SearchView.this.f2425a.getText().toString());
                return true;
            }
        };
        this.f2423V = new OnEditorActionListener() {
            public boolean onEditorAction(TextView textView, int i, KeyEvent keyEvent) {
                SearchView.this.mo3256e();
                return true;
            }
        };
        this.f2424W = new OnItemClickListener() {
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
                SearchView.this.mo3250a(i, 0, (String) null);
            }
        };
        this.f2426aa = new OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long j) {
                SearchView.this.mo3249a(i);
            }

            public void onNothingSelected(AdapterView<?> adapterView) {
            }
        };
        this.f2427ab = new TextWatcher() {
            public void afterTextChanged(Editable editable) {
            }

            public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            }

            public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
                SearchView.this.mo3252b(charSequence);
            }
        };
        C0869bn a = C0869bn.m4638a(context, attributeSet, C0550j.SearchView, i, 0);
        LayoutInflater.from(context).inflate(a.mo4439g(C0550j.SearchView_layout, C0547g.abc_search_view), this, true);
        this.f2425a = (SearchAutoComplete) findViewById(C0546f.search_src_text);
        this.f2425a.setSearchView(this);
        this.f2436k = findViewById(C0546f.search_edit_frame);
        this.f2437l = findViewById(C0546f.search_plate);
        this.f2438m = findViewById(C0546f.submit_area);
        this.f2428b = (ImageView) findViewById(C0546f.search_button);
        this.f2429c = (ImageView) findViewById(C0546f.search_go_btn);
        this.f2430d = (ImageView) findViewById(C0546f.search_close_btn);
        this.f2431e = (ImageView) findViewById(C0546f.search_voice_btn);
        this.f2445t = (ImageView) findViewById(C0546f.search_mag_icon);
        C0495r.m2131a(this.f2437l, a.mo4426a(C0550j.SearchView_queryBackground));
        C0495r.m2131a(this.f2438m, a.mo4426a(C0550j.SearchView_submitBackground));
        this.f2428b.setImageDrawable(a.mo4426a(C0550j.SearchView_searchIcon));
        this.f2429c.setImageDrawable(a.mo4426a(C0550j.SearchView_goIcon));
        this.f2430d.setImageDrawable(a.mo4426a(C0550j.SearchView_closeIcon));
        this.f2431e.setImageDrawable(a.mo4426a(C0550j.SearchView_voiceIcon));
        this.f2445t.setImageDrawable(a.mo4426a(C0550j.SearchView_searchIcon));
        this.f2446u = a.mo4426a(C0550j.SearchView_searchHintIcon);
        C0873bp.m4703a(this.f2428b, getResources().getString(C0548h.abc_searchview_description_search));
        this.f2447v = a.mo4439g(C0550j.SearchView_suggestionRowLayout, C0547g.abc_search_dropdown_item_icons_2line);
        this.f2448w = a.mo4439g(C0550j.SearchView_commitIcon, 0);
        this.f2428b.setOnClickListener(this.f2422U);
        this.f2430d.setOnClickListener(this.f2422U);
        this.f2429c.setOnClickListener(this.f2422U);
        this.f2431e.setOnClickListener(this.f2422U);
        this.f2425a.setOnClickListener(this.f2422U);
        this.f2425a.addTextChangedListener(this.f2427ab);
        this.f2425a.setOnEditorActionListener(this.f2423V);
        this.f2425a.setOnItemClickListener(this.f2424W);
        this.f2425a.setOnItemSelectedListener(this.f2426aa);
        this.f2425a.setOnKeyListener(this.f2435j);
        this.f2425a.setOnFocusChangeListener(new OnFocusChangeListener() {
            public void onFocusChange(View view, boolean z) {
                if (SearchView.this.f2432f != null) {
                    SearchView.this.f2432f.onFocusChange(SearchView.this, z);
                }
            }
        });
        setIconifiedByDefault(a.mo4428a(C0550j.SearchView_iconifiedByDefault, true));
        int e = a.mo4435e(C0550j.SearchView_android_maxWidth, -1);
        if (e != -1) {
            setMaxWidth(e);
        }
        this.f2451z = a.mo4432c(C0550j.SearchView_defaultQueryHint);
        this.f2409H = a.mo4432c(C0550j.SearchView_queryHint);
        int a2 = a.mo4424a(C0550j.SearchView_android_imeOptions, -1);
        if (a2 != -1) {
            setImeOptions(a2);
        }
        int a3 = a.mo4424a(C0550j.SearchView_android_inputType, -1);
        if (a3 != -1) {
            setInputType(a3);
        }
        setFocusable(a.mo4428a(C0550j.SearchView_android_focusable, true));
        a.mo4427a();
        this.f2449x = new Intent("android.speech.action.WEB_SEARCH");
        this.f2449x.addFlags(268435456);
        this.f2449x.putExtra("android.speech.extra.LANGUAGE_MODEL", "web_search");
        this.f2450y = new Intent("android.speech.action.RECOGNIZE_SPEECH");
        this.f2450y.addFlags(268435456);
        this.f2439n = findViewById(this.f2425a.getDropDownAnchor());
        if (this.f2439n != null) {
            this.f2439n.addOnLayoutChangeListener(new OnLayoutChangeListener() {
                public void onLayoutChange(View view, int i, int i2, int i3, int i4, int i5, int i6, int i7, int i8) {
                    SearchView.this.mo3269k();
                }
            });
        }
        m3402a(this.f2406E);
        m3415r();
    }

    /* renamed from: a */
    private Intent m3397a(Intent intent, SearchableInfo searchableInfo) {
        Intent intent2 = new Intent(intent);
        ComponentName searchActivity = searchableInfo.getSearchActivity();
        intent2.putExtra("calling_package", searchActivity == null ? null : searchActivity.flattenToShortString());
        return intent2;
    }

    /* renamed from: a */
    private Intent m3398a(Cursor cursor, int i, String str) {
        int i2;
        try {
            String a = C0862bh.m4606a(cursor, "suggest_intent_action");
            if (a == null) {
                a = this.f2434h.getSuggestIntentAction();
            }
            if (a == null) {
                a = "android.intent.action.SEARCH";
            }
            String str2 = a;
            String a2 = C0862bh.m4606a(cursor, "suggest_intent_data");
            if (a2 == null) {
                a2 = this.f2434h.getSuggestIntentData();
            }
            if (a2 != null) {
                String a3 = C0862bh.m4606a(cursor, "suggest_intent_data_id");
                if (a3 != null) {
                    StringBuilder sb = new StringBuilder();
                    sb.append(a2);
                    sb.append("/");
                    sb.append(Uri.encode(a3));
                    a2 = sb.toString();
                }
            }
            return m3399a(str2, a2 == null ? null : Uri.parse(a2), C0862bh.m4606a(cursor, "suggest_intent_extra_data"), C0862bh.m4606a(cursor, "suggest_intent_query"), i, str);
        } catch (RuntimeException e) {
            try {
                i2 = cursor.getPosition();
            } catch (RuntimeException unused) {
                i2 = -1;
            }
            StringBuilder sb2 = new StringBuilder();
            sb2.append("Search suggestions cursor at row ");
            sb2.append(i2);
            sb2.append(" returned exception.");
            Log.w("SearchView", sb2.toString(), e);
            return null;
        }
    }

    /* renamed from: a */
    private Intent m3399a(String str, Uri uri, String str2, String str3, int i, String str4) {
        Intent intent = new Intent(str);
        intent.addFlags(268435456);
        if (uri != null) {
            intent.setData(uri);
        }
        intent.putExtra("user_query", this.f2415N);
        if (str3 != null) {
            intent.putExtra("query", str3);
        }
        if (str2 != null) {
            intent.putExtra("intent_extra_data_key", str2);
        }
        if (this.f2418Q != null) {
            intent.putExtra("app_data", this.f2418Q);
        }
        if (i != 0) {
            intent.putExtra("action_key", i);
            intent.putExtra("action_msg", str4);
        }
        intent.setComponent(this.f2434h.getSearchActivity());
        return intent;
    }

    /* renamed from: a */
    private void m3400a(Intent intent) {
        if (intent != null) {
            try {
                getContext().startActivity(intent);
            } catch (RuntimeException e) {
                StringBuilder sb = new StringBuilder();
                sb.append("Failed launch activity: ");
                sb.append(intent);
                Log.e("SearchView", sb.toString(), e);
            }
        }
    }

    /* renamed from: a */
    private void m3401a(View view, Rect rect) {
        view.getLocationInWindow(this.f2443r);
        getLocationInWindow(this.f2444s);
        int i = this.f2443r[1] - this.f2444s[1];
        int i2 = this.f2443r[0] - this.f2444s[0];
        rect.set(i2, i, view.getWidth() + i2, view.getHeight() + i);
    }

    /* renamed from: a */
    private void m3402a(boolean z) {
        this.f2407F = z;
        int i = 8;
        boolean z2 = false;
        boolean z3 = !TextUtils.isEmpty(this.f2425a.getText());
        this.f2428b.setVisibility(z ? 0 : 8);
        m3405b(z3);
        this.f2436k.setVisibility(z ? 8 : 0);
        if (this.f2445t.getDrawable() != null && !this.f2406E) {
            i = 0;
        }
        this.f2445t.setVisibility(i);
        m3413p();
        if (!z3) {
            z2 = true;
        }
        m3408c(z2);
        m3412o();
    }

    /* renamed from: a */
    static boolean m3403a(Context context) {
        return context.getResources().getConfiguration().orientation == 2;
    }

    /* renamed from: b */
    private Intent m3404b(Intent intent, SearchableInfo searchableInfo) {
        ComponentName searchActivity = searchableInfo.getSearchActivity();
        Intent intent2 = new Intent("android.intent.action.SEARCH");
        intent2.setComponent(searchActivity);
        PendingIntent activity = PendingIntent.getActivity(getContext(), 0, intent2, 1073741824);
        Bundle bundle = new Bundle();
        if (this.f2418Q != null) {
            bundle.putParcelable("app_data", this.f2418Q);
        }
        Intent intent3 = new Intent(intent);
        String str = "free_form";
        int i = 1;
        Resources resources = getResources();
        if (searchableInfo.getVoiceLanguageModeId() != 0) {
            str = resources.getString(searchableInfo.getVoiceLanguageModeId());
        }
        String str2 = null;
        String string = searchableInfo.getVoicePromptTextId() != 0 ? resources.getString(searchableInfo.getVoicePromptTextId()) : null;
        String string2 = searchableInfo.getVoiceLanguageId() != 0 ? resources.getString(searchableInfo.getVoiceLanguageId()) : null;
        if (searchableInfo.getVoiceMaxResults() != 0) {
            i = searchableInfo.getVoiceMaxResults();
        }
        intent3.putExtra("android.speech.extra.LANGUAGE_MODEL", str);
        intent3.putExtra("android.speech.extra.PROMPT", string);
        intent3.putExtra("android.speech.extra.LANGUAGE", string2);
        intent3.putExtra("android.speech.extra.MAX_RESULTS", i);
        String str3 = "calling_package";
        if (searchActivity != null) {
            str2 = searchActivity.flattenToShortString();
        }
        intent3.putExtra(str3, str2);
        intent3.putExtra("android.speech.extra.RESULTS_PENDINGINTENT", activity);
        intent3.putExtra("android.speech.extra.RESULTS_PENDINGINTENT_BUNDLE", bundle);
        return intent3;
    }

    /* renamed from: b */
    private void m3405b(boolean z) {
        this.f2429c.setVisibility((!this.f2408G || !m3411n() || !hasFocus() || (!z && this.f2413L)) ? 8 : 0);
    }

    /* renamed from: b */
    private boolean m3406b(int i, int i2, String str) {
        Cursor a = this.f2433g.mo2074a();
        if (a == null || !a.moveToPosition(i)) {
            return false;
        }
        m3400a(m3398a(a, i2, str));
        return true;
    }

    /* renamed from: c */
    private CharSequence m3407c(CharSequence charSequence) {
        if (!this.f2406E || this.f2446u == null) {
            return charSequence;
        }
        int textSize = (int) (((double) this.f2425a.getTextSize()) * 1.25d);
        this.f2446u.setBounds(0, 0, textSize, textSize);
        SpannableStringBuilder spannableStringBuilder = new SpannableStringBuilder("   ");
        spannableStringBuilder.setSpan(new ImageSpan(this.f2446u), 1, 2, 33);
        spannableStringBuilder.append(charSequence);
        return spannableStringBuilder;
    }

    /* renamed from: c */
    private void m3408c(boolean z) {
        int i;
        if (!this.f2413L || mo3253c() || !z) {
            i = 8;
        } else {
            i = 0;
            this.f2429c.setVisibility(8);
        }
        this.f2431e.setVisibility(i);
    }

    /* renamed from: e */
    private void m3409e(int i) {
        Editable text = this.f2425a.getText();
        Cursor a = this.f2433g.mo2074a();
        if (a != null) {
            if (a.moveToPosition(i)) {
                CharSequence c = this.f2433g.mo2083c(a);
                if (c != null) {
                    setQuery(c);
                    return;
                }
            }
            setQuery(text);
        }
    }

    private int getPreferredHeight() {
        return getContext().getResources().getDimensionPixelSize(C0544d.abc_search_view_preferred_height);
    }

    private int getPreferredWidth() {
        return getContext().getResources().getDimensionPixelSize(C0544d.abc_search_view_preferred_width);
    }

    /* renamed from: m */
    private boolean m3410m() {
        if (this.f2434h == null || !this.f2434h.getVoiceSearchEnabled()) {
            return false;
        }
        Intent intent = null;
        if (this.f2434h.getVoiceSearchLaunchWebSearch()) {
            intent = this.f2449x;
        } else if (this.f2434h.getVoiceSearchLaunchRecognizer()) {
            intent = this.f2450y;
        }
        return (intent == null || getContext().getPackageManager().resolveActivity(intent, 65536) == null) ? false : true;
    }

    /* renamed from: n */
    private boolean m3411n() {
        return (this.f2408G || this.f2413L) && !mo3253c();
    }

    /* renamed from: o */
    private void m3412o() {
        this.f2438m.setVisibility((!m3411n() || !(this.f2429c.getVisibility() == 0 || this.f2431e.getVisibility() == 0)) ? 8 : 0);
    }

    /* renamed from: p */
    private void m3413p() {
        boolean z = true;
        boolean z2 = !TextUtils.isEmpty(this.f2425a.getText());
        int i = 0;
        if (!z2 && (!this.f2406E || this.f2416O)) {
            z = false;
        }
        ImageView imageView = this.f2430d;
        if (!z) {
            i = 8;
        }
        imageView.setVisibility(i);
        Drawable drawable = this.f2430d.getDrawable();
        if (drawable != null) {
            drawable.setState(z2 ? ENABLED_STATE_SET : EMPTY_STATE_SET);
        }
    }

    /* renamed from: q */
    private void m3414q() {
        post(this.f2419R);
    }

    /* renamed from: r */
    private void m3415r() {
        CharSequence queryHint = getQueryHint();
        SearchAutoComplete searchAutoComplete = this.f2425a;
        if (queryHint == null) {
            queryHint = "";
        }
        searchAutoComplete.setHint(m3407c(queryHint));
    }

    /* renamed from: s */
    private void m3416s() {
        this.f2425a.setThreshold(this.f2434h.getSuggestThreshold());
        this.f2425a.setImeOptions(this.f2434h.getImeOptions());
        int inputType = this.f2434h.getInputType();
        int i = 1;
        if ((inputType & 15) == 1) {
            inputType &= -65537;
            if (this.f2434h.getSuggestAuthority() != null) {
                inputType = inputType | 65536 | 524288;
            }
        }
        this.f2425a.setInputType(inputType);
        if (this.f2433g != null) {
            this.f2433g.mo2078a((Cursor) null);
        }
        if (this.f2434h.getSuggestAuthority() != null) {
            this.f2433g = new C0862bh(getContext(), this, this.f2434h, this.f2421T);
            this.f2425a.setAdapter(this.f2433g);
            C0862bh bhVar = (C0862bh) this.f2433g;
            if (this.f2410I) {
                i = 2;
            }
            bhVar.mo4412a(i);
        }
    }

    private void setQuery(CharSequence charSequence) {
        this.f2425a.setText(charSequence);
        this.f2425a.setSelection(TextUtils.isEmpty(charSequence) ? 0 : charSequence.length());
    }

    /* renamed from: t */
    private void m3417t() {
        this.f2425a.dismissDropDown();
    }

    /* renamed from: a */
    public void mo2501a() {
        if (!this.f2416O) {
            this.f2416O = true;
            this.f2417P = this.f2425a.getImeOptions();
            this.f2425a.setImeOptions(this.f2417P | 33554432);
            this.f2425a.setText("");
            setIconified(false);
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo3246a(int i, String str, String str2) {
        getContext().startActivity(m3399a("android.intent.action.SEARCH", null, null, str2, i, str));
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo3247a(CharSequence charSequence) {
        setQuery(charSequence);
    }

    /* renamed from: a */
    public void mo3248a(CharSequence charSequence, boolean z) {
        this.f2425a.setText(charSequence);
        if (charSequence != null) {
            this.f2425a.setSelection(this.f2425a.length());
            this.f2415N = charSequence;
        }
        if (z && !TextUtils.isEmpty(charSequence)) {
            mo3256e();
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public boolean mo3249a(int i) {
        if (this.f2404C != null && this.f2404C.mo3325a(i)) {
            return false;
        }
        m3409e(i);
        return true;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public boolean mo3250a(int i, int i2, String str) {
        if (this.f2404C != null && this.f2404C.mo3326b(i)) {
            return false;
        }
        m3406b(i, 0, null);
        this.f2425a.setImeVisibility(false);
        m3417t();
        return true;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public boolean mo3251a(View view, int i, KeyEvent keyEvent) {
        if (this.f2434h != null && this.f2433g != null && keyEvent.getAction() == 0 && keyEvent.hasNoModifiers()) {
            if (i == 66 || i == 84 || i == 61) {
                return mo3250a(this.f2425a.getListSelection(), 0, (String) null);
            }
            if (i == 21 || i == 22) {
                this.f2425a.setSelection(i == 21 ? 0 : this.f2425a.length());
                this.f2425a.setListSelection(0);
                this.f2425a.clearListSelection();
                f2401i.mo3320a(this.f2425a, true);
                return true;
            } else if (i != 19 || this.f2425a.getListSelection() == 0) {
                return false;
            }
        }
        return false;
    }

    /* renamed from: b */
    public void mo2502b() {
        mo3248a((CharSequence) "", false);
        clearFocus();
        m3402a(true);
        this.f2425a.setImeOptions(this.f2417P);
        this.f2416O = false;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: b */
    public void mo3252b(CharSequence charSequence) {
        Editable text = this.f2425a.getText();
        this.f2415N = text;
        boolean z = true;
        boolean z2 = !TextUtils.isEmpty(text);
        m3405b(z2);
        if (z2) {
            z = false;
        }
        m3408c(z);
        m3413p();
        m3412o();
        if (this.f2402A != null && !TextUtils.equals(charSequence, this.f2414M)) {
            this.f2402A.mo3324b(charSequence.toString());
        }
        this.f2414M = charSequence.toString();
    }

    /* renamed from: c */
    public boolean mo3253c() {
        return this.f2407F;
    }

    public void clearFocus() {
        this.f2411J = true;
        super.clearFocus();
        this.f2425a.clearFocus();
        this.f2425a.setImeVisibility(false);
        this.f2411J = false;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: d */
    public void mo3255d() {
        int[] iArr = this.f2425a.hasFocus() ? FOCUSED_STATE_SET : EMPTY_STATE_SET;
        Drawable background = this.f2437l.getBackground();
        if (background != null) {
            background.setState(iArr);
        }
        Drawable background2 = this.f2438m.getBackground();
        if (background2 != null) {
            background2.setState(iArr);
        }
        invalidate();
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: e */
    public void mo3256e() {
        Editable text = this.f2425a.getText();
        if (text != null && TextUtils.getTrimmedLength(text) > 0) {
            if (this.f2402A == null || !this.f2402A.mo3323a(text.toString())) {
                if (this.f2434h != null) {
                    mo3246a(0, (String) null, text.toString());
                }
                this.f2425a.setImeVisibility(false);
                m3417t();
            }
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: f */
    public void mo3257f() {
        if (!TextUtils.isEmpty(this.f2425a.getText())) {
            this.f2425a.setText("");
            this.f2425a.requestFocus();
            this.f2425a.setImeVisibility(true);
        } else if (this.f2406E && (this.f2403B == null || !this.f2403B.mo3322a())) {
            clearFocus();
            m3402a(true);
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: g */
    public void mo3258g() {
        m3402a(false);
        this.f2425a.requestFocus();
        this.f2425a.setImeVisibility(true);
        if (this.f2405D != null) {
            this.f2405D.onClick(this);
        }
    }

    public int getImeOptions() {
        return this.f2425a.getImeOptions();
    }

    public int getInputType() {
        return this.f2425a.getInputType();
    }

    public int getMaxWidth() {
        return this.f2412K;
    }

    public CharSequence getQuery() {
        return this.f2425a.getText();
    }

    public CharSequence getQueryHint() {
        return this.f2409H != null ? this.f2409H : (this.f2434h == null || this.f2434h.getHintId() == 0) ? this.f2451z : getContext().getText(this.f2434h.getHintId());
    }

    /* access modifiers changed from: 0000 */
    public int getSuggestionCommitIconResId() {
        return this.f2448w;
    }

    /* access modifiers changed from: 0000 */
    public int getSuggestionRowLayout() {
        return this.f2447v;
    }

    public C0519d getSuggestionsAdapter() {
        return this.f2433g;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: h */
    public void mo3267h() {
        Intent b;
        if (this.f2434h != null) {
            SearchableInfo searchableInfo = this.f2434h;
            try {
                if (searchableInfo.getVoiceSearchLaunchWebSearch()) {
                    b = m3397a(this.f2449x, searchableInfo);
                } else {
                    if (searchableInfo.getVoiceSearchLaunchRecognizer()) {
                        b = m3404b(this.f2450y, searchableInfo);
                    }
                    return;
                }
                getContext().startActivity(b);
            } catch (ActivityNotFoundException unused) {
                Log.w("SearchView", "Could not find voice search activity");
            }
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: i */
    public void mo3268i() {
        m3402a(mo3253c());
        m3414q();
        if (this.f2425a.hasFocus()) {
            mo3270l();
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: k */
    public void mo3269k() {
        if (this.f2439n.getWidth() > 1) {
            Resources resources = getContext().getResources();
            int paddingLeft = this.f2437l.getPaddingLeft();
            Rect rect = new Rect();
            boolean a = C0885bv.m4757a(this);
            int dimensionPixelSize = this.f2406E ? resources.getDimensionPixelSize(C0544d.abc_dropdownitem_icon_width) + resources.getDimensionPixelSize(C0544d.abc_dropdownitem_text_padding_left) : 0;
            this.f2425a.getDropDownBackground().getPadding(rect);
            this.f2425a.setDropDownHorizontalOffset(a ? -rect.left : paddingLeft - (rect.left + dimensionPixelSize));
            this.f2425a.setDropDownWidth((((this.f2439n.getWidth() + rect.left) + rect.right) + dimensionPixelSize) - paddingLeft);
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: l */
    public void mo3270l() {
        f2401i.mo3319a(this.f2425a);
        f2401i.mo3321b(this.f2425a);
    }

    /* access modifiers changed from: protected */
    public void onDetachedFromWindow() {
        removeCallbacks(this.f2419R);
        post(this.f2420S);
        super.onDetachedFromWindow();
    }

    /* access modifiers changed from: protected */
    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        super.onLayout(z, i, i2, i3, i4);
        if (z) {
            m3401a((View) this.f2425a, this.f2441p);
            this.f2442q.set(this.f2441p.left, 0, this.f2441p.right, i4 - i2);
            if (this.f2440o == null) {
                this.f2440o = new C0722f(this.f2442q, this.f2441p, this.f2425a);
                setTouchDelegate(this.f2440o);
                return;
            }
            this.f2440o.mo3334a(this.f2442q, this.f2441p);
        }
    }

    /* access modifiers changed from: protected */
    /* JADX WARNING: Code restructure failed: missing block: B:9:0x001f, code lost:
        if (r3.f2412K <= 0) goto L_0x003e;
     */
    /* JADX WARNING: Removed duplicated region for block: B:21:0x0048  */
    /* JADX WARNING: Removed duplicated region for block: B:23:0x0050  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void onMeasure(int r4, int r5) {
        /*
            r3 = this;
            boolean r0 = r3.mo3253c()
            if (r0 == 0) goto L_0x000a
            super.onMeasure(r4, r5)
            return
        L_0x000a:
            int r0 = android.view.View.MeasureSpec.getMode(r4)
            int r4 = android.view.View.MeasureSpec.getSize(r4)
            r1 = -2147483648(0xffffffff80000000, float:-0.0)
            r2 = 1073741824(0x40000000, float:2.0)
            if (r0 == r1) goto L_0x002e
            if (r0 == 0) goto L_0x0022
            if (r0 == r2) goto L_0x001d
            goto L_0x003e
        L_0x001d:
            int r0 = r3.f2412K
            if (r0 <= 0) goto L_0x003e
            goto L_0x0032
        L_0x0022:
            int r4 = r3.f2412K
            if (r4 <= 0) goto L_0x0029
            int r4 = r3.f2412K
            goto L_0x003e
        L_0x0029:
            int r4 = r3.getPreferredWidth()
            goto L_0x003e
        L_0x002e:
            int r0 = r3.f2412K
            if (r0 <= 0) goto L_0x0039
        L_0x0032:
            int r0 = r3.f2412K
        L_0x0034:
            int r4 = java.lang.Math.min(r0, r4)
            goto L_0x003e
        L_0x0039:
            int r0 = r3.getPreferredWidth()
            goto L_0x0034
        L_0x003e:
            int r0 = android.view.View.MeasureSpec.getMode(r5)
            int r5 = android.view.View.MeasureSpec.getSize(r5)
            if (r0 == r1) goto L_0x0050
            if (r0 == 0) goto L_0x004b
            goto L_0x0058
        L_0x004b:
            int r5 = r3.getPreferredHeight()
            goto L_0x0058
        L_0x0050:
            int r0 = r3.getPreferredHeight()
            int r5 = java.lang.Math.min(r0, r5)
        L_0x0058:
            int r4 = android.view.View.MeasureSpec.makeMeasureSpec(r4, r2)
            int r5 = android.view.View.MeasureSpec.makeMeasureSpec(r5, r2)
            super.onMeasure(r4, r5)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.p031v7.widget.SearchView.onMeasure(int, int):void");
    }

    /* access modifiers changed from: protected */
    public void onRestoreInstanceState(Parcelable parcelable) {
        if (!(parcelable instanceof C0720e)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        C0720e eVar = (C0720e) parcelable;
        super.onRestoreInstanceState(eVar.mo1845a());
        m3402a(eVar.f2470a);
        requestLayout();
    }

    /* access modifiers changed from: protected */
    public Parcelable onSaveInstanceState() {
        C0720e eVar = new C0720e(super.onSaveInstanceState());
        eVar.f2470a = mo3253c();
        return eVar;
    }

    public void onWindowFocusChanged(boolean z) {
        super.onWindowFocusChanged(z);
        m3414q();
    }

    public boolean requestFocus(int i, Rect rect) {
        if (this.f2411J || !isFocusable()) {
            return false;
        }
        if (mo3253c()) {
            return super.requestFocus(i, rect);
        }
        boolean requestFocus = this.f2425a.requestFocus(i, rect);
        if (requestFocus) {
            m3402a(false);
        }
        return requestFocus;
    }

    public void setAppSearchData(Bundle bundle) {
        this.f2418Q = bundle;
    }

    public void setIconified(boolean z) {
        if (z) {
            mo3257f();
        } else {
            mo3258g();
        }
    }

    public void setIconifiedByDefault(boolean z) {
        if (this.f2406E != z) {
            this.f2406E = z;
            m3402a(z);
            m3415r();
        }
    }

    public void setImeOptions(int i) {
        this.f2425a.setImeOptions(i);
    }

    public void setInputType(int i) {
        this.f2425a.setInputType(i);
    }

    public void setMaxWidth(int i) {
        this.f2412K = i;
        requestLayout();
    }

    public void setOnCloseListener(C0717b bVar) {
        this.f2403B = bVar;
    }

    public void setOnQueryTextFocusChangeListener(OnFocusChangeListener onFocusChangeListener) {
        this.f2432f = onFocusChangeListener;
    }

    public void setOnQueryTextListener(C0718c cVar) {
        this.f2402A = cVar;
    }

    public void setOnSearchClickListener(OnClickListener onClickListener) {
        this.f2405D = onClickListener;
    }

    public void setOnSuggestionListener(C0719d dVar) {
        this.f2404C = dVar;
    }

    public void setQueryHint(CharSequence charSequence) {
        this.f2409H = charSequence;
        m3415r();
    }

    public void setQueryRefinementEnabled(boolean z) {
        this.f2410I = z;
        if (this.f2433g instanceof C0862bh) {
            ((C0862bh) this.f2433g).mo4412a(z ? 2 : 1);
        }
    }

    public void setSearchableInfo(SearchableInfo searchableInfo) {
        this.f2434h = searchableInfo;
        if (this.f2434h != null) {
            m3416s();
            m3415r();
        }
        this.f2413L = m3410m();
        if (this.f2413L) {
            this.f2425a.setPrivateImeOptions("nm");
        }
        m3402a(mo3253c());
    }

    public void setSubmitButtonEnabled(boolean z) {
        this.f2408G = z;
        m3402a(mo3253c());
    }

    public void setSuggestionsAdapter(C0519d dVar) {
        this.f2433g = dVar;
        this.f2425a.setAdapter(this.f2433g);
    }
}
