package android.support.p031v7.widget;

/* renamed from: android.support.v7.widget.bd */
class C0854bd {

    /* renamed from: a */
    private int f3075a = 0;

    /* renamed from: b */
    private int f3076b = 0;

    /* renamed from: c */
    private int f3077c = Integer.MIN_VALUE;

    /* renamed from: d */
    private int f3078d = Integer.MIN_VALUE;

    /* renamed from: e */
    private int f3079e = 0;

    /* renamed from: f */
    private int f3080f = 0;

    /* renamed from: g */
    private boolean f3081g = false;

    /* renamed from: h */
    private boolean f3082h = false;

    C0854bd() {
    }

    /* renamed from: a */
    public int mo4363a() {
        return this.f3075a;
    }

    /* renamed from: a */
    public void mo4364a(int i, int i2) {
        this.f3077c = i;
        this.f3078d = i2;
        this.f3082h = true;
        if (this.f3081g) {
            if (i2 != Integer.MIN_VALUE) {
                this.f3075a = i2;
            }
            if (i != Integer.MIN_VALUE) {
                this.f3076b = i;
            }
        } else {
            if (i != Integer.MIN_VALUE) {
                this.f3075a = i;
            }
            if (i2 != Integer.MIN_VALUE) {
                this.f3076b = i2;
            }
        }
    }

    /* renamed from: a */
    public void mo4365a(boolean z) {
        int i;
        if (z != this.f3081g) {
            this.f3081g = z;
            if (!this.f3082h) {
                this.f3075a = this.f3079e;
            } else if (z) {
                this.f3075a = this.f3078d != Integer.MIN_VALUE ? this.f3078d : this.f3079e;
                if (this.f3077c != Integer.MIN_VALUE) {
                    i = this.f3077c;
                    this.f3076b = i;
                }
            } else {
                this.f3075a = this.f3077c != Integer.MIN_VALUE ? this.f3077c : this.f3079e;
                if (this.f3078d != Integer.MIN_VALUE) {
                    i = this.f3078d;
                    this.f3076b = i;
                }
            }
            i = this.f3080f;
            this.f3076b = i;
        }
    }

    /* renamed from: b */
    public int mo4366b() {
        return this.f3076b;
    }

    /* renamed from: b */
    public void mo4367b(int i, int i2) {
        this.f3082h = false;
        if (i != Integer.MIN_VALUE) {
            this.f3079e = i;
            this.f3075a = i;
        }
        if (i2 != Integer.MIN_VALUE) {
            this.f3080f = i2;
            this.f3076b = i2;
        }
    }

    /* renamed from: c */
    public int mo4368c() {
        return this.f3081g ? this.f3076b : this.f3075a;
    }

    /* renamed from: d */
    public int mo4369d() {
        return this.f3081g ? this.f3075a : this.f3076b;
    }
}
