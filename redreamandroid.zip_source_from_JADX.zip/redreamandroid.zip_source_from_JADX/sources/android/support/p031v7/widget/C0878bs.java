package android.support.p031v7.widget;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import java.lang.ref.WeakReference;

/* renamed from: android.support.v7.widget.bs */
public class C0878bs extends Resources {

    /* renamed from: a */
    private static boolean f3188a = false;

    /* renamed from: b */
    private final WeakReference<Context> f3189b;

    public C0878bs(Context context, Resources resources) {
        super(resources.getAssets(), resources.getDisplayMetrics(), resources.getConfiguration());
        this.f3189b = new WeakReference<>(context);
    }

    /* renamed from: a */
    public static boolean m4717a() {
        return m4718b() && VERSION.SDK_INT <= 20;
    }

    /* renamed from: b */
    public static boolean m4718b() {
        return f3188a;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public final Drawable mo4461a(int i) {
        return super.getDrawable(i);
    }

    public Drawable getDrawable(int i) {
        Context context = (Context) this.f3189b.get();
        return context != null ? C0909k.m4874a().mo4571a(context, this, i) : super.getDrawable(i);
    }
}
