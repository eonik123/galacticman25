package android.support.p031v7.widget;

import android.support.p018v4.p027g.C0412a;
import android.support.p018v4.p027g.C0419f;
import android.support.p018v4.p027g.C0428j.C0429a;
import android.support.p018v4.p027g.C0428j.C0430b;
import android.support.p031v7.widget.C0805ay.C0817f.C0820c;
import android.support.p031v7.widget.C0805ay.C0846x;

/* renamed from: android.support.v7.widget.bu */
class C0882bu {

    /* renamed from: a */
    final C0412a<C0846x, C0883a> f3197a = new C0412a<>();

    /* renamed from: b */
    final C0419f<C0846x> f3198b = new C0419f<>();

    /* renamed from: android.support.v7.widget.bu$a */
    static class C0883a {

        /* renamed from: d */
        static C0429a<C0883a> f3199d = new C0430b(20);

        /* renamed from: a */
        int f3200a;

        /* renamed from: b */
        C0820c f3201b;

        /* renamed from: c */
        C0820c f3202c;

        private C0883a() {
        }

        /* renamed from: a */
        static C0883a m4749a() {
            C0883a aVar = (C0883a) f3199d.mo1743a();
            return aVar == null ? new C0883a() : aVar;
        }

        /* renamed from: a */
        static void m4750a(C0883a aVar) {
            aVar.f3200a = 0;
            aVar.f3201b = null;
            aVar.f3202c = null;
            f3199d.mo1744a(aVar);
        }

        /* renamed from: b */
        static void m4751b() {
            do {
            } while (f3199d.mo1743a() != null);
        }
    }

    /* renamed from: android.support.v7.widget.bu$b */
    interface C0884b {
        /* renamed from: a */
        void mo3994a(C0846x xVar);

        /* renamed from: a */
        void mo3995a(C0846x xVar, C0820c cVar, C0820c cVar2);

        /* renamed from: b */
        void mo3996b(C0846x xVar, C0820c cVar, C0820c cVar2);

        /* renamed from: c */
        void mo3997c(C0846x xVar, C0820c cVar, C0820c cVar2);
    }

    C0882bu() {
    }

    /* renamed from: a */
    private C0820c m4732a(C0846x xVar, int i) {
        C0820c cVar;
        int a = this.f3197a.mo1746a((Object) xVar);
        if (a < 0) {
            return null;
        }
        C0883a aVar = (C0883a) this.f3197a.mo1753c(a);
        if (aVar == null || (aVar.f3200a & i) == 0) {
            return null;
        }
        aVar.f3200a &= ~i;
        if (i == 4) {
            cVar = aVar.f3201b;
        } else if (i == 8) {
            cVar = aVar.f3202c;
        } else {
            throw new IllegalArgumentException("Must provide flag PRE or POST");
        }
        if ((aVar.f3200a & 12) == 0) {
            this.f3197a.mo1757d(a);
            C0883a.m4750a(aVar);
        }
        return cVar;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public C0846x mo4470a(long j) {
        return (C0846x) this.f3198b.mo1661a(j);
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo4471a() {
        this.f3197a.clear();
        this.f3198b.mo1670c();
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo4472a(long j, C0846x xVar) {
        this.f3198b.mo1667b(j, xVar);
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo4473a(C0846x xVar, C0820c cVar) {
        C0883a aVar = (C0883a) this.f3197a.get(xVar);
        if (aVar == null) {
            aVar = C0883a.m4749a();
            this.f3197a.put(xVar, aVar);
        }
        aVar.f3201b = cVar;
        aVar.f3200a |= 4;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo4474a(C0884b bVar) {
        C0820c cVar;
        C0820c cVar2;
        for (int size = this.f3197a.size() - 1; size >= 0; size--) {
            C0846x xVar = (C0846x) this.f3197a.mo1752b(size);
            C0883a aVar = (C0883a) this.f3197a.mo1757d(size);
            if ((aVar.f3200a & 3) != 3) {
                if ((aVar.f3200a & 1) == 0) {
                    if ((aVar.f3200a & 14) != 14) {
                        if ((aVar.f3200a & 12) == 12) {
                            bVar.mo3997c(xVar, aVar.f3201b, aVar.f3202c);
                        } else if ((aVar.f3200a & 4) != 0) {
                            cVar = aVar.f3201b;
                            cVar2 = null;
                        } else if ((aVar.f3200a & 8) == 0) {
                            int i = aVar.f3200a;
                        }
                        C0883a.m4750a(aVar);
                    }
                    bVar.mo3996b(xVar, aVar.f3201b, aVar.f3202c);
                    C0883a.m4750a(aVar);
                } else if (aVar.f3201b != null) {
                    cVar = aVar.f3201b;
                    cVar2 = aVar.f3202c;
                }
                bVar.mo3995a(xVar, cVar, cVar2);
                C0883a.m4750a(aVar);
            }
            bVar.mo3994a(xVar);
            C0883a.m4750a(aVar);
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public boolean mo4475a(C0846x xVar) {
        C0883a aVar = (C0883a) this.f3197a.get(xVar);
        return (aVar == null || (aVar.f3200a & 1) == 0) ? false : true;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: b */
    public C0820c mo4476b(C0846x xVar) {
        return m4732a(xVar, 4);
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: b */
    public void mo4477b() {
        C0883a.m4751b();
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: b */
    public void mo4478b(C0846x xVar, C0820c cVar) {
        C0883a aVar = (C0883a) this.f3197a.get(xVar);
        if (aVar == null) {
            aVar = C0883a.m4749a();
            this.f3197a.put(xVar, aVar);
        }
        aVar.f3200a |= 2;
        aVar.f3201b = cVar;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: c */
    public C0820c mo4479c(C0846x xVar) {
        return m4732a(xVar, 8);
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: c */
    public void mo4480c(C0846x xVar, C0820c cVar) {
        C0883a aVar = (C0883a) this.f3197a.get(xVar);
        if (aVar == null) {
            aVar = C0883a.m4749a();
            this.f3197a.put(xVar, aVar);
        }
        aVar.f3202c = cVar;
        aVar.f3200a |= 8;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: d */
    public boolean mo4481d(C0846x xVar) {
        C0883a aVar = (C0883a) this.f3197a.get(xVar);
        return (aVar == null || (aVar.f3200a & 4) == 0) ? false : true;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: e */
    public void mo4482e(C0846x xVar) {
        C0883a aVar = (C0883a) this.f3197a.get(xVar);
        if (aVar == null) {
            aVar = C0883a.m4749a();
            this.f3197a.put(xVar, aVar);
        }
        aVar.f3200a |= 1;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: f */
    public void mo4483f(C0846x xVar) {
        C0883a aVar = (C0883a) this.f3197a.get(xVar);
        if (aVar != null) {
            aVar.f3200a &= -2;
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: g */
    public void mo4484g(C0846x xVar) {
        int b = this.f3198b.mo1664b() - 1;
        while (true) {
            if (b < 0) {
                break;
            } else if (xVar == this.f3198b.mo1669c(b)) {
                this.f3198b.mo1663a(b);
                break;
            } else {
                b--;
            }
        }
        C0883a aVar = (C0883a) this.f3197a.remove(xVar);
        if (aVar != null) {
            C0883a.m4750a(aVar);
        }
    }

    /* renamed from: h */
    public void mo4485h(C0846x xVar) {
        mo4483f(xVar);
    }
}
