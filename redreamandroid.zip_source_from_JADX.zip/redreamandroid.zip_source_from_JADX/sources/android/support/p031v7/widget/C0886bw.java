package android.support.p031v7.widget;

/* renamed from: android.support.v7.widget.bw */
public interface C0886bw {
    /* renamed from: a */
    CharSequence mo4486a();
}
