package android.support.p031v7.widget;

import android.graphics.Rect;
import android.support.p031v7.widget.C0805ay.C0823i;
import android.support.p031v7.widget.C0805ay.C0828j;
import android.view.View;

/* renamed from: android.support.v7.widget.ax */
public abstract class C0802ax {

    /* renamed from: a */
    protected final C0823i f2834a;

    /* renamed from: b */
    final Rect f2835b;

    /* renamed from: c */
    private int f2836c;

    private C0802ax(C0823i iVar) {
        this.f2836c = Integer.MIN_VALUE;
        this.f2835b = new Rect();
        this.f2834a = iVar;
    }

    /* renamed from: a */
    public static C0802ax m3986a(C0823i iVar) {
        return new C0802ax(iVar) {
            /* renamed from: a */
            public int mo3816a(View view) {
                return this.f2834a.mo4117h(view) - ((C0828j) view.getLayoutParams()).leftMargin;
            }

            /* renamed from: a */
            public void mo3818a(int i) {
                this.f2834a.mo3351j(i);
            }

            /* renamed from: b */
            public int mo3820b(View view) {
                return this.f2834a.mo4121j(view) + ((C0828j) view.getLayoutParams()).rightMargin;
            }

            /* renamed from: c */
            public int mo3821c() {
                return this.f2834a.mo4051A();
            }

            /* renamed from: c */
            public int mo3822c(View view) {
                this.f2834a.mo4077a(view, true, this.f2835b);
                return this.f2835b.right;
            }

            /* renamed from: d */
            public int mo3823d() {
                return this.f2834a.mo4137y() - this.f2834a.mo4053C();
            }

            /* renamed from: d */
            public int mo3824d(View view) {
                this.f2834a.mo4077a(view, true, this.f2835b);
                return this.f2835b.left;
            }

            /* renamed from: e */
            public int mo3825e() {
                return this.f2834a.mo4137y();
            }

            /* renamed from: e */
            public int mo3826e(View view) {
                C0828j jVar = (C0828j) view.getLayoutParams();
                return this.f2834a.mo4112f(view) + jVar.leftMargin + jVar.rightMargin;
            }

            /* renamed from: f */
            public int mo3827f() {
                return (this.f2834a.mo4137y() - this.f2834a.mo4051A()) - this.f2834a.mo4053C();
            }

            /* renamed from: f */
            public int mo3828f(View view) {
                C0828j jVar = (C0828j) view.getLayoutParams();
                return this.f2834a.mo4115g(view) + jVar.topMargin + jVar.bottomMargin;
            }

            /* renamed from: g */
            public int mo3829g() {
                return this.f2834a.mo4053C();
            }

            /* renamed from: h */
            public int mo3830h() {
                return this.f2834a.mo4135w();
            }

            /* renamed from: i */
            public int mo3831i() {
                return this.f2834a.mo4136x();
            }
        };
    }

    /* renamed from: a */
    public static C0802ax m3987a(C0823i iVar, int i) {
        switch (i) {
            case 0:
                return m3986a(iVar);
            case 1:
                return m3988b(iVar);
            default:
                throw new IllegalArgumentException("invalid orientation");
        }
    }

    /* renamed from: b */
    public static C0802ax m3988b(C0823i iVar) {
        return new C0802ax(iVar) {
            /* renamed from: a */
            public int mo3816a(View view) {
                return this.f2834a.mo4119i(view) - ((C0828j) view.getLayoutParams()).topMargin;
            }

            /* renamed from: a */
            public void mo3818a(int i) {
                this.f2834a.mo3354k(i);
            }

            /* renamed from: b */
            public int mo3820b(View view) {
                return this.f2834a.mo4122k(view) + ((C0828j) view.getLayoutParams()).bottomMargin;
            }

            /* renamed from: c */
            public int mo3821c() {
                return this.f2834a.mo4052B();
            }

            /* renamed from: c */
            public int mo3822c(View view) {
                this.f2834a.mo4077a(view, true, this.f2835b);
                return this.f2835b.bottom;
            }

            /* renamed from: d */
            public int mo3823d() {
                return this.f2834a.mo4138z() - this.f2834a.mo4054D();
            }

            /* renamed from: d */
            public int mo3824d(View view) {
                this.f2834a.mo4077a(view, true, this.f2835b);
                return this.f2835b.top;
            }

            /* renamed from: e */
            public int mo3825e() {
                return this.f2834a.mo4138z();
            }

            /* renamed from: e */
            public int mo3826e(View view) {
                C0828j jVar = (C0828j) view.getLayoutParams();
                return this.f2834a.mo4115g(view) + jVar.topMargin + jVar.bottomMargin;
            }

            /* renamed from: f */
            public int mo3827f() {
                return (this.f2834a.mo4138z() - this.f2834a.mo4052B()) - this.f2834a.mo4054D();
            }

            /* renamed from: f */
            public int mo3828f(View view) {
                C0828j jVar = (C0828j) view.getLayoutParams();
                return this.f2834a.mo4112f(view) + jVar.leftMargin + jVar.rightMargin;
            }

            /* renamed from: g */
            public int mo3829g() {
                return this.f2834a.mo4054D();
            }

            /* renamed from: h */
            public int mo3830h() {
                return this.f2834a.mo4136x();
            }

            /* renamed from: i */
            public int mo3831i() {
                return this.f2834a.mo4135w();
            }
        };
    }

    /* renamed from: a */
    public abstract int mo3816a(View view);

    /* renamed from: a */
    public void mo3817a() {
        this.f2836c = mo3827f();
    }

    /* renamed from: a */
    public abstract void mo3818a(int i);

    /* renamed from: b */
    public int mo3819b() {
        if (Integer.MIN_VALUE == this.f2836c) {
            return 0;
        }
        return mo3827f() - this.f2836c;
    }

    /* renamed from: b */
    public abstract int mo3820b(View view);

    /* renamed from: c */
    public abstract int mo3821c();

    /* renamed from: c */
    public abstract int mo3822c(View view);

    /* renamed from: d */
    public abstract int mo3823d();

    /* renamed from: d */
    public abstract int mo3824d(View view);

    /* renamed from: e */
    public abstract int mo3825e();

    /* renamed from: e */
    public abstract int mo3826e(View view);

    /* renamed from: f */
    public abstract int mo3827f();

    /* renamed from: f */
    public abstract int mo3828f(View view);

    /* renamed from: g */
    public abstract int mo3829g();

    /* renamed from: h */
    public abstract int mo3830h();

    /* renamed from: i */
    public abstract int mo3831i();
}
