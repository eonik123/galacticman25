package android.support.p031v7.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff.Mode;
import android.graphics.drawable.Drawable;
import android.support.p018v4.p028h.C0494q;
import android.support.p018v4.widget.C0517b;
import android.support.p018v4.widget.C0531m;
import android.support.p031v7.p032a.C0540a.C0541a;
import android.util.AttributeSet;
import android.view.ActionMode.Callback;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Button;
import android.widget.TextView;

/* renamed from: android.support.v7.widget.AppCompatButton */
public class AppCompatButton extends Button implements C0494q, C0517b {

    /* renamed from: b */
    private final C0905g f2335b;

    /* renamed from: c */
    private final C0934y f2336c;

    public AppCompatButton(Context context) {
        this(context, null);
    }

    public AppCompatButton(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, C0541a.buttonStyle);
    }

    public AppCompatButton(Context context, AttributeSet attributeSet, int i) {
        super(C0866bk.m4633a(context), attributeSet, i);
        this.f2335b = new C0905g(this);
        this.f2335b.mo4547a(attributeSet, i);
        this.f2336c = new C0934y(this);
        this.f2336c.mo4679a(attributeSet, i);
        this.f2336c.mo4674a();
    }

    /* access modifiers changed from: protected */
    public void drawableStateChanged() {
        super.drawableStateChanged();
        if (this.f2335b != null) {
            this.f2335b.mo4550c();
        }
        if (this.f2336c != null) {
            this.f2336c.mo4674a();
        }
    }

    public int getAutoSizeMaxTextSize() {
        if (f1510a) {
            return super.getAutoSizeMaxTextSize();
        }
        if (this.f2336c != null) {
            return this.f2336c.mo4689g();
        }
        return -1;
    }

    public int getAutoSizeMinTextSize() {
        if (f1510a) {
            return super.getAutoSizeMinTextSize();
        }
        if (this.f2336c != null) {
            return this.f2336c.mo4688f();
        }
        return -1;
    }

    public int getAutoSizeStepGranularity() {
        if (f1510a) {
            return super.getAutoSizeStepGranularity();
        }
        if (this.f2336c != null) {
            return this.f2336c.mo4687e();
        }
        return -1;
    }

    public int[] getAutoSizeTextAvailableSizes() {
        return f1510a ? super.getAutoSizeTextAvailableSizes() : this.f2336c != null ? this.f2336c.mo4690h() : new int[0];
    }

    public int getAutoSizeTextType() {
        int i = 0;
        if (f1510a) {
            if (super.getAutoSizeTextType() == 1) {
                i = 1;
            }
            return i;
        } else if (this.f2336c != null) {
            return this.f2336c.mo4686d();
        } else {
            return 0;
        }
    }

    public ColorStateList getSupportBackgroundTintList() {
        if (this.f2335b != null) {
            return this.f2335b.mo4542a();
        }
        return null;
    }

    public Mode getSupportBackgroundTintMode() {
        if (this.f2335b != null) {
            return this.f2335b.mo4548b();
        }
        return null;
    }

    public void onInitializeAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        super.onInitializeAccessibilityEvent(accessibilityEvent);
        accessibilityEvent.setClassName(Button.class.getName());
    }

    public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo accessibilityNodeInfo) {
        super.onInitializeAccessibilityNodeInfo(accessibilityNodeInfo);
        accessibilityNodeInfo.setClassName(Button.class.getName());
    }

    /* access modifiers changed from: protected */
    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        super.onLayout(z, i, i2, i3, i4);
        if (this.f2336c != null) {
            this.f2336c.mo4682a(z, i, i2, i3, i4);
        }
    }

    /* access modifiers changed from: protected */
    public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
        super.onTextChanged(charSequence, i, i2, i3);
        if (this.f2336c != null && !f1510a && this.f2336c.mo4685c()) {
            this.f2336c.mo4684b();
        }
    }

    public void setAutoSizeTextTypeUniformWithConfiguration(int i, int i2, int i3, int i4) {
        if (f1510a) {
            super.setAutoSizeTextTypeUniformWithConfiguration(i, i2, i3, i4);
            return;
        }
        if (this.f2336c != null) {
            this.f2336c.mo4677a(i, i2, i3, i4);
        }
    }

    public void setAutoSizeTextTypeUniformWithPresetSizes(int[] iArr, int i) {
        if (f1510a) {
            super.setAutoSizeTextTypeUniformWithPresetSizes(iArr, i);
            return;
        }
        if (this.f2336c != null) {
            this.f2336c.mo4683a(iArr, i);
        }
    }

    public void setAutoSizeTextTypeWithDefaults(int i) {
        if (f1510a) {
            super.setAutoSizeTextTypeWithDefaults(i);
            return;
        }
        if (this.f2336c != null) {
            this.f2336c.mo4675a(i);
        }
    }

    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        if (this.f2335b != null) {
            this.f2335b.mo4546a(drawable);
        }
    }

    public void setBackgroundResource(int i) {
        super.setBackgroundResource(i);
        if (this.f2335b != null) {
            this.f2335b.mo4543a(i);
        }
    }

    public void setCustomSelectionActionModeCallback(Callback callback) {
        super.setCustomSelectionActionModeCallback(C0531m.m2345a((TextView) this, callback));
    }

    public void setSupportAllCaps(boolean z) {
        if (this.f2336c != null) {
            this.f2336c.mo4681a(z);
        }
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        if (this.f2335b != null) {
            this.f2335b.mo4544a(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(Mode mode) {
        if (this.f2335b != null) {
            this.f2335b.mo4545a(mode);
        }
    }

    public void setTextAppearance(Context context, int i) {
        super.setTextAppearance(context, i);
        if (this.f2336c != null) {
            this.f2336c.mo4678a(context, i);
        }
    }

    public void setTextSize(int i, float f) {
        if (f1510a) {
            super.setTextSize(i, f);
            return;
        }
        if (this.f2336c != null) {
            this.f2336c.mo4676a(i, f);
        }
    }
}
