package android.support.p031v7.widget;

import android.content.res.ColorStateList;
import android.graphics.Canvas;
import android.graphics.PorterDuff.Mode;
import android.graphics.drawable.Drawable;
import android.support.p018v4.graphics.drawable.C0441a;
import android.support.p018v4.p028h.C0495r;
import android.support.p031v7.p032a.C0540a.C0550j;
import android.util.AttributeSet;
import android.widget.SeekBar;

/* renamed from: android.support.v7.widget.w */
class C0926w extends C0922s {

    /* renamed from: a */
    private final SeekBar f3324a;

    /* renamed from: b */
    private Drawable f3325b;

    /* renamed from: c */
    private ColorStateList f3326c = null;

    /* renamed from: d */
    private Mode f3327d = null;

    /* renamed from: e */
    private boolean f3328e = false;

    /* renamed from: f */
    private boolean f3329f = false;

    C0926w(SeekBar seekBar) {
        super(seekBar);
        this.f3324a = seekBar;
    }

    /* renamed from: d */
    private void m4923d() {
        if (this.f3325b == null) {
            return;
        }
        if (this.f3328e || this.f3329f) {
            this.f3325b = C0441a.m1938g(this.f3325b.mutate());
            if (this.f3328e) {
                C0441a.m1927a(this.f3325b, this.f3326c);
            }
            if (this.f3329f) {
                C0441a.m1930a(this.f3325b, this.f3327d);
            }
            if (this.f3325b.isStateful()) {
                this.f3325b.setState(this.f3324a.getDrawableState());
            }
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo4628a(Canvas canvas) {
        if (this.f3325b != null) {
            int max = this.f3324a.getMax();
            int i = 1;
            if (max > 1) {
                int intrinsicWidth = this.f3325b.getIntrinsicWidth();
                int intrinsicHeight = this.f3325b.getIntrinsicHeight();
                int i2 = intrinsicWidth >= 0 ? intrinsicWidth / 2 : 1;
                if (intrinsicHeight >= 0) {
                    i = intrinsicHeight / 2;
                }
                this.f3325b.setBounds(-i2, -i, i2, i);
                float width = ((float) ((this.f3324a.getWidth() - this.f3324a.getPaddingLeft()) - this.f3324a.getPaddingRight())) / ((float) max);
                int save = canvas.save();
                canvas.translate((float) this.f3324a.getPaddingLeft(), (float) (this.f3324a.getHeight() / 2));
                for (int i3 = 0; i3 <= max; i3++) {
                    this.f3325b.draw(canvas);
                    canvas.translate(width, 0.0f);
                }
                canvas.restoreToCount(save);
            }
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo4629a(Drawable drawable) {
        if (this.f3325b != null) {
            this.f3325b.setCallback(null);
        }
        this.f3325b = drawable;
        if (drawable != null) {
            drawable.setCallback(this.f3324a);
            C0441a.m1933b(drawable, C0495r.m2149f(this.f3324a));
            if (drawable.isStateful()) {
                drawable.setState(this.f3324a.getDrawableState());
            }
            m4923d();
        }
        this.f3324a.invalidate();
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo4618a(AttributeSet attributeSet, int i) {
        super.mo4618a(attributeSet, i);
        C0869bn a = C0869bn.m4638a(this.f3324a.getContext(), attributeSet, C0550j.AppCompatSeekBar, i, 0);
        Drawable b = a.mo4430b(C0550j.AppCompatSeekBar_android_thumb);
        if (b != null) {
            this.f3324a.setThumb(b);
        }
        mo4629a(a.mo4426a(C0550j.AppCompatSeekBar_tickMark));
        if (a.mo4440g(C0550j.AppCompatSeekBar_tickMarkTintMode)) {
            this.f3327d = C0768al.m3839a(a.mo4424a(C0550j.AppCompatSeekBar_tickMarkTintMode, -1), this.f3327d);
            this.f3329f = true;
        }
        if (a.mo4440g(C0550j.AppCompatSeekBar_tickMarkTint)) {
            this.f3326c = a.mo4436e(C0550j.AppCompatSeekBar_tickMarkTint);
            this.f3328e = true;
        }
        a.mo4427a();
        m4923d();
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: b */
    public void mo4630b() {
        if (this.f3325b != null) {
            this.f3325b.jumpToCurrentState();
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: c */
    public void mo4631c() {
        Drawable drawable = this.f3325b;
        if (drawable != null && drawable.isStateful() && drawable.setState(this.f3324a.getDrawableState())) {
            this.f3324a.invalidateDrawable(drawable);
        }
    }
}
