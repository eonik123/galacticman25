package android.support.p031v7.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources.Theme;
import android.graphics.PorterDuff.Mode;
import android.graphics.PorterDuffColorFilter;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.Drawable.ConstantState;
import android.graphics.drawable.LayerDrawable;
import android.os.Build.VERSION;
import android.support.p005c.p006a.C0052c;
import android.support.p005c.p006a.C0062i;
import android.support.p018v4.graphics.C0435a;
import android.support.p018v4.graphics.drawable.C0441a;
import android.support.p018v4.p019a.C0293a;
import android.support.p018v4.p027g.C0412a;
import android.support.p018v4.p027g.C0419f;
import android.support.p018v4.p027g.C0420g;
import android.support.p018v4.p027g.C0434m;
import android.support.p031v7.p032a.C0540a.C0541a;
import android.support.p031v7.p032a.C0540a.C0545e;
import android.support.p031v7.p035c.p036a.C0608a;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import java.lang.ref.WeakReference;
import java.util.WeakHashMap;
import org.xmlpull.v1.XmlPullParser;

/* renamed from: android.support.v7.widget.k */
public final class C0909k {

    /* renamed from: a */
    private static final Mode f3287a = Mode.SRC_IN;

    /* renamed from: b */
    private static C0909k f3288b;

    /* renamed from: c */
    private static final C0912c f3289c = new C0912c(6);

    /* renamed from: d */
    private static final int[] f3290d = {C0545e.abc_textfield_search_default_mtrl_alpha, C0545e.abc_textfield_default_mtrl_alpha, C0545e.abc_ab_share_pack_mtrl_alpha};

    /* renamed from: e */
    private static final int[] f3291e = {C0545e.abc_ic_commit_search_api_mtrl_alpha, C0545e.abc_seekbar_tick_mark_material, C0545e.abc_ic_menu_share_mtrl_alpha, C0545e.abc_ic_menu_copy_mtrl_am_alpha, C0545e.abc_ic_menu_cut_mtrl_alpha, C0545e.abc_ic_menu_selectall_mtrl_alpha, C0545e.abc_ic_menu_paste_mtrl_am_alpha};

    /* renamed from: f */
    private static final int[] f3292f = {C0545e.abc_textfield_activated_mtrl_alpha, C0545e.abc_textfield_search_activated_mtrl_alpha, C0545e.abc_cab_background_top_mtrl_alpha, C0545e.abc_text_cursor_material, C0545e.abc_text_select_handle_left_mtrl_dark, C0545e.abc_text_select_handle_middle_mtrl_dark, C0545e.abc_text_select_handle_right_mtrl_dark, C0545e.abc_text_select_handle_left_mtrl_light, C0545e.abc_text_select_handle_middle_mtrl_light, C0545e.abc_text_select_handle_right_mtrl_light};

    /* renamed from: g */
    private static final int[] f3293g = {C0545e.abc_popup_background_mtrl_mult, C0545e.abc_cab_background_internal_bg, C0545e.abc_menu_hardkey_panel_mtrl_mult};

    /* renamed from: h */
    private static final int[] f3294h = {C0545e.abc_tab_indicator_material, C0545e.abc_textfield_search_material};

    /* renamed from: i */
    private static final int[] f3295i = {C0545e.abc_btn_check_material, C0545e.abc_btn_radio_material};

    /* renamed from: j */
    private WeakHashMap<Context, C0434m<ColorStateList>> f3296j;

    /* renamed from: k */
    private C0412a<String, C0913d> f3297k;

    /* renamed from: l */
    private C0434m<String> f3298l;

    /* renamed from: m */
    private final WeakHashMap<Context, C0419f<WeakReference<ConstantState>>> f3299m = new WeakHashMap<>(0);

    /* renamed from: n */
    private TypedValue f3300n;

    /* renamed from: o */
    private boolean f3301o;

    /* renamed from: android.support.v7.widget.k$a */
    static class C0910a implements C0913d {
        C0910a() {
        }

        /* renamed from: a */
        public Drawable mo4574a(Context context, XmlPullParser xmlPullParser, AttributeSet attributeSet, Theme theme) {
            try {
                return C0608a.m2718a(context, context.getResources(), xmlPullParser, attributeSet, theme);
            } catch (Exception e) {
                Log.e("AsldcInflateDelegate", "Exception while inflating <animated-selector>", e);
                return null;
            }
        }
    }

    /* renamed from: android.support.v7.widget.k$b */
    private static class C0911b implements C0913d {
        C0911b() {
        }

        /* renamed from: a */
        public Drawable mo4574a(Context context, XmlPullParser xmlPullParser, AttributeSet attributeSet, Theme theme) {
            try {
                return C0052c.m132a(context, context.getResources(), xmlPullParser, attributeSet, theme);
            } catch (Exception e) {
                Log.e("AvdcInflateDelegate", "Exception while inflating <animated-vector>", e);
                return null;
            }
        }
    }

    /* renamed from: android.support.v7.widget.k$c */
    private static class C0912c extends C0420g<Integer, PorterDuffColorFilter> {
        public C0912c(int i) {
            super(i);
        }

        /* renamed from: b */
        private static int m4900b(int i, Mode mode) {
            return (31 * (i + 31)) + mode.hashCode();
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public PorterDuffColorFilter mo4575a(int i, Mode mode) {
            return (PorterDuffColorFilter) mo1674a(Integer.valueOf(m4900b(i, mode)));
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public PorterDuffColorFilter mo4576a(int i, Mode mode, PorterDuffColorFilter porterDuffColorFilter) {
            return (PorterDuffColorFilter) mo1675a(Integer.valueOf(m4900b(i, mode)), porterDuffColorFilter);
        }
    }

    /* renamed from: android.support.v7.widget.k$d */
    private interface C0913d {
        /* renamed from: a */
        Drawable mo4574a(Context context, XmlPullParser xmlPullParser, AttributeSet attributeSet, Theme theme);
    }

    /* renamed from: android.support.v7.widget.k$e */
    private static class C0914e implements C0913d {
        C0914e() {
        }

        /* renamed from: a */
        public Drawable mo4574a(Context context, XmlPullParser xmlPullParser, AttributeSet attributeSet, Theme theme) {
            try {
                return C0062i.m166a(context.getResources(), xmlPullParser, attributeSet, theme);
            } catch (Exception e) {
                Log.e("VdcInflateDelegate", "Exception while inflating <vector>", e);
                return null;
            }
        }
    }

    /* renamed from: a */
    private static long m4868a(TypedValue typedValue) {
        return (((long) typedValue.assetCookie) << 32) | ((long) typedValue.data);
    }

    /* renamed from: a */
    static Mode m4869a(int i) {
        if (i == C0545e.abc_switch_thumb_material) {
            return Mode.MULTIPLY;
        }
        return null;
    }

    /* renamed from: a */
    public static synchronized PorterDuffColorFilter m4870a(int i, Mode mode) {
        PorterDuffColorFilter a;
        synchronized (C0909k.class) {
            a = f3289c.mo4575a(i, mode);
            if (a == null) {
                a = new PorterDuffColorFilter(i, mode);
                f3289c.mo4576a(i, mode, a);
            }
        }
        return a;
    }

    /* renamed from: a */
    private static PorterDuffColorFilter m4871a(ColorStateList colorStateList, Mode mode, int[] iArr) {
        if (colorStateList == null || mode == null) {
            return null;
        }
        return m4870a(colorStateList.getColorForState(iArr, 0), mode);
    }

    /* renamed from: a */
    private Drawable m4872a(Context context, int i, boolean z, Drawable drawable) {
        LayerDrawable layerDrawable;
        Drawable findDrawableByLayerId;
        int i2;
        ColorStateList b = mo4573b(context, i);
        if (b != null) {
            if (C0768al.m3841b(drawable)) {
                drawable = drawable.mutate();
            }
            drawable = C0441a.m1938g(drawable);
            C0441a.m1927a(drawable, b);
            Mode a = m4869a(i);
            if (a != null) {
                C0441a.m1930a(drawable, a);
                return drawable;
            }
        } else {
            if (i == C0545e.abc_seekbar_track_material) {
                layerDrawable = (LayerDrawable) drawable;
                m4876a(layerDrawable.findDrawableByLayerId(16908288), C0864bi.m4626a(context, C0541a.colorControlNormal), f3287a);
                findDrawableByLayerId = layerDrawable.findDrawableByLayerId(16908303);
                i2 = C0541a.colorControlNormal;
            } else if (i == C0545e.abc_ratingbar_material || i == C0545e.abc_ratingbar_indicator_material || i == C0545e.abc_ratingbar_small_material) {
                layerDrawable = (LayerDrawable) drawable;
                m4876a(layerDrawable.findDrawableByLayerId(16908288), C0864bi.m4630c(context, C0541a.colorControlNormal), f3287a);
                findDrawableByLayerId = layerDrawable.findDrawableByLayerId(16908303);
                i2 = C0541a.colorControlActivated;
            } else if (!m4880a(context, i, drawable) && z) {
                return null;
            }
            m4876a(findDrawableByLayerId, C0864bi.m4626a(context, i2), f3287a);
            m4876a(layerDrawable.findDrawableByLayerId(16908301), C0864bi.m4626a(context, C0541a.colorControlActivated), f3287a);
            return drawable;
        }
        return drawable;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:18:0x002c, code lost:
        return null;
     */
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private synchronized android.graphics.drawable.Drawable m4873a(android.content.Context r4, long r5) {
        /*
            r3 = this;
            monitor-enter(r3)
            java.util.WeakHashMap<android.content.Context, android.support.v4.g.f<java.lang.ref.WeakReference<android.graphics.drawable.Drawable$ConstantState>>> r0 = r3.f3299m     // Catch:{ all -> 0x002d }
            java.lang.Object r0 = r0.get(r4)     // Catch:{ all -> 0x002d }
            android.support.v4.g.f r0 = (android.support.p018v4.p027g.C0419f) r0     // Catch:{ all -> 0x002d }
            r1 = 0
            if (r0 != 0) goto L_0x000e
            monitor-exit(r3)
            return r1
        L_0x000e:
            java.lang.Object r2 = r0.mo1661a(r5)     // Catch:{ all -> 0x002d }
            java.lang.ref.WeakReference r2 = (java.lang.ref.WeakReference) r2     // Catch:{ all -> 0x002d }
            if (r2 == 0) goto L_0x002b
            java.lang.Object r2 = r2.get()     // Catch:{ all -> 0x002d }
            android.graphics.drawable.Drawable$ConstantState r2 = (android.graphics.drawable.Drawable.ConstantState) r2     // Catch:{ all -> 0x002d }
            if (r2 == 0) goto L_0x0028
            android.content.res.Resources r4 = r4.getResources()     // Catch:{ all -> 0x002d }
            android.graphics.drawable.Drawable r4 = r2.newDrawable(r4)     // Catch:{ all -> 0x002d }
            monitor-exit(r3)
            return r4
        L_0x0028:
            r0.mo1666b(r5)     // Catch:{ all -> 0x002d }
        L_0x002b:
            monitor-exit(r3)
            return r1
        L_0x002d:
            r4 = move-exception
            monitor-exit(r3)
            throw r4
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.p031v7.widget.C0909k.m4873a(android.content.Context, long):android.graphics.drawable.Drawable");
    }

    /* renamed from: a */
    public static synchronized C0909k m4874a() {
        C0909k kVar;
        synchronized (C0909k.class) {
            if (f3288b == null) {
                f3288b = new C0909k();
                m4878a(f3288b);
            }
            kVar = f3288b;
        }
        return kVar;
    }

    /* renamed from: a */
    private void m4875a(Context context, int i, ColorStateList colorStateList) {
        if (this.f3296j == null) {
            this.f3296j = new WeakHashMap<>();
        }
        C0434m mVar = (C0434m) this.f3296j.get(context);
        if (mVar == null) {
            mVar = new C0434m();
            this.f3296j.put(context, mVar);
        }
        mVar.mo1774c(i, colorStateList);
    }

    /* renamed from: a */
    private static void m4876a(Drawable drawable, int i, Mode mode) {
        if (C0768al.m3841b(drawable)) {
            drawable = drawable.mutate();
        }
        if (mode == null) {
            mode = f3287a;
        }
        drawable.setColorFilter(m4870a(i, mode));
    }

    /* renamed from: a */
    static void m4877a(Drawable drawable, C0867bl blVar, int[] iArr) {
        if (!C0768al.m3841b(drawable) || drawable.mutate() == drawable) {
            if (blVar.f3141d || blVar.f3140c) {
                drawable.setColorFilter(m4871a(blVar.f3141d ? blVar.f3138a : null, blVar.f3140c ? blVar.f3139b : f3287a, iArr));
            } else {
                drawable.clearColorFilter();
            }
            if (VERSION.SDK_INT <= 23) {
                drawable.invalidateSelf();
            }
            return;
        }
        Log.d("AppCompatDrawableManag", "Mutated drawable is not the same instance as the input.");
    }

    /* renamed from: a */
    private static void m4878a(C0909k kVar) {
        if (VERSION.SDK_INT < 24) {
            kVar.m4879a("vector", (C0913d) new C0914e());
            kVar.m4879a("animated-vector", (C0913d) new C0911b());
            kVar.m4879a("animated-selector", (C0913d) new C0910a());
        }
    }

    /* renamed from: a */
    private void m4879a(String str, C0913d dVar) {
        if (this.f3297k == null) {
            this.f3297k = new C0412a<>();
        }
        this.f3297k.put(str, dVar);
    }

    /* JADX WARNING: Removed duplicated region for block: B:18:0x0045  */
    /* JADX WARNING: Removed duplicated region for block: B:25:0x0060 A[RETURN] */
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    static boolean m4880a(android.content.Context r6, int r7, android.graphics.drawable.Drawable r8) {
        /*
            android.graphics.PorterDuff$Mode r0 = f3287a
            int[] r1 = f3290d
            boolean r1 = m4883a(r1, r7)
            r2 = 16842801(0x1010031, float:2.3693695E-38)
            r3 = -1
            r4 = 0
            r5 = 1
            if (r1 == 0) goto L_0x0015
            int r2 = android.support.p031v7.p032a.C0540a.C0541a.colorControlNormal
        L_0x0012:
            r1 = r3
        L_0x0013:
            r7 = r5
            goto L_0x0043
        L_0x0015:
            int[] r1 = f3292f
            boolean r1 = m4883a(r1, r7)
            if (r1 == 0) goto L_0x0020
            int r2 = android.support.p031v7.p032a.C0540a.C0541a.colorControlActivated
            goto L_0x0012
        L_0x0020:
            int[] r1 = f3293g
            boolean r1 = m4883a(r1, r7)
            if (r1 == 0) goto L_0x002b
            android.graphics.PorterDuff$Mode r0 = android.graphics.PorterDuff.Mode.MULTIPLY
            goto L_0x0012
        L_0x002b:
            int r1 = android.support.p031v7.p032a.C0540a.C0545e.abc_list_divider_mtrl_alpha
            if (r7 != r1) goto L_0x003b
            r2 = 16842800(0x1010030, float:2.3693693E-38)
            r7 = 1109603123(0x42233333, float:40.8)
            int r7 = java.lang.Math.round(r7)
            r1 = r7
            goto L_0x0013
        L_0x003b:
            int r1 = android.support.p031v7.p032a.C0540a.C0545e.abc_dialog_material_background
            if (r7 != r1) goto L_0x0040
            goto L_0x0012
        L_0x0040:
            r1 = r3
            r7 = r4
            r2 = r7
        L_0x0043:
            if (r7 == 0) goto L_0x0060
            boolean r7 = android.support.p031v7.widget.C0768al.m3841b(r8)
            if (r7 == 0) goto L_0x004f
            android.graphics.drawable.Drawable r8 = r8.mutate()
        L_0x004f:
            int r6 = android.support.p031v7.widget.C0864bi.m4626a(r6, r2)
            android.graphics.PorterDuffColorFilter r6 = m4870a(r6, r0)
            r8.setColorFilter(r6)
            if (r1 == r3) goto L_0x005f
            r8.setAlpha(r1)
        L_0x005f:
            return r5
        L_0x0060:
            return r4
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.p031v7.widget.C0909k.m4880a(android.content.Context, int, android.graphics.drawable.Drawable):boolean");
    }

    /* renamed from: a */
    private synchronized boolean m4881a(Context context, long j, Drawable drawable) {
        boolean z;
        ConstantState constantState = drawable.getConstantState();
        if (constantState != null) {
            C0419f fVar = (C0419f) this.f3299m.get(context);
            if (fVar == null) {
                fVar = new C0419f();
                this.f3299m.put(context, fVar);
            }
            fVar.mo1667b(j, new WeakReference(constantState));
            z = true;
        } else {
            z = false;
        }
        return z;
    }

    /* renamed from: a */
    private static boolean m4882a(Drawable drawable) {
        return (drawable instanceof C0062i) || "android.graphics.drawable.VectorDrawable".equals(drawable.getClass().getName());
    }

    /* renamed from: a */
    private static boolean m4883a(int[] iArr, int i) {
        for (int i2 : iArr) {
            if (i2 == i) {
                return true;
            }
        }
        return false;
    }

    /* renamed from: b */
    private ColorStateList m4884b(Context context) {
        return m4891f(context, C0864bi.m4626a(context, C0541a.colorButtonNormal));
    }

    /* renamed from: c */
    private ColorStateList m4885c(Context context) {
        return m4891f(context, 0);
    }

    /* renamed from: c */
    private Drawable m4886c(Context context, int i) {
        if (this.f3300n == null) {
            this.f3300n = new TypedValue();
        }
        TypedValue typedValue = this.f3300n;
        context.getResources().getValue(i, typedValue, true);
        long a = m4868a(typedValue);
        Drawable a2 = m4873a(context, a);
        if (a2 != null) {
            return a2;
        }
        if (i == C0545e.abc_cab_background_top_material) {
            a2 = new LayerDrawable(new Drawable[]{mo4569a(context, C0545e.abc_cab_background_internal_bg), mo4569a(context, C0545e.abc_cab_background_top_mtrl_alpha)});
        }
        if (a2 != null) {
            a2.setChangingConfigurations(typedValue.changingConfigurations);
            m4881a(context, a, a2);
        }
        return a2;
    }

    /* renamed from: d */
    private ColorStateList m4887d(Context context) {
        return m4891f(context, C0864bi.m4626a(context, C0541a.colorAccent));
    }

    /* JADX WARNING: Removed duplicated region for block: B:30:0x0079 A[Catch:{ Exception -> 0x00a8 }] */
    /* JADX WARNING: Removed duplicated region for block: B:32:0x0081 A[Catch:{ Exception -> 0x00a8 }] */
    /* renamed from: d */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private android.graphics.drawable.Drawable m4888d(android.content.Context r10, int r11) {
        /*
            r9 = this;
            android.support.v4.g.a<java.lang.String, android.support.v7.widget.k$d> r0 = r9.f3297k
            r1 = 0
            if (r0 == 0) goto L_0x00ba
            android.support.v4.g.a<java.lang.String, android.support.v7.widget.k$d> r0 = r9.f3297k
            boolean r0 = r0.isEmpty()
            if (r0 != 0) goto L_0x00ba
            android.support.v4.g.m<java.lang.String> r0 = r9.f3298l
            if (r0 == 0) goto L_0x002c
            android.support.v4.g.m<java.lang.String> r0 = r9.f3298l
            java.lang.Object r0 = r0.mo1767a(r11)
            java.lang.String r0 = (java.lang.String) r0
            java.lang.String r2 = "appcompat_skip_skip"
            boolean r2 = r2.equals(r0)
            if (r2 != 0) goto L_0x002b
            if (r0 == 0) goto L_0x0033
            android.support.v4.g.a<java.lang.String, android.support.v7.widget.k$d> r2 = r9.f3297k
            java.lang.Object r0 = r2.get(r0)
            if (r0 != 0) goto L_0x0033
        L_0x002b:
            return r1
        L_0x002c:
            android.support.v4.g.m r0 = new android.support.v4.g.m
            r0.<init>()
            r9.f3298l = r0
        L_0x0033:
            android.util.TypedValue r0 = r9.f3300n
            if (r0 != 0) goto L_0x003e
            android.util.TypedValue r0 = new android.util.TypedValue
            r0.<init>()
            r9.f3300n = r0
        L_0x003e:
            android.util.TypedValue r0 = r9.f3300n
            android.content.res.Resources r1 = r10.getResources()
            r2 = 1
            r1.getValue(r11, r0, r2)
            long r3 = m4868a(r0)
            android.graphics.drawable.Drawable r5 = r9.m4873a(r10, r3)
            if (r5 == 0) goto L_0x0053
            return r5
        L_0x0053:
            java.lang.CharSequence r6 = r0.string
            if (r6 == 0) goto L_0x00b0
            java.lang.CharSequence r6 = r0.string
            java.lang.String r6 = r6.toString()
            java.lang.String r7 = ".xml"
            boolean r6 = r6.endsWith(r7)
            if (r6 == 0) goto L_0x00b0
            android.content.res.XmlResourceParser r1 = r1.getXml(r11)     // Catch:{ Exception -> 0x00a8 }
            android.util.AttributeSet r6 = android.util.Xml.asAttributeSet(r1)     // Catch:{ Exception -> 0x00a8 }
        L_0x006d:
            int r7 = r1.next()     // Catch:{ Exception -> 0x00a8 }
            r8 = 2
            if (r7 == r8) goto L_0x0077
            if (r7 == r2) goto L_0x0077
            goto L_0x006d
        L_0x0077:
            if (r7 == r8) goto L_0x0081
            org.xmlpull.v1.XmlPullParserException r10 = new org.xmlpull.v1.XmlPullParserException     // Catch:{ Exception -> 0x00a8 }
            java.lang.String r0 = "No start tag found"
            r10.<init>(r0)     // Catch:{ Exception -> 0x00a8 }
            throw r10     // Catch:{ Exception -> 0x00a8 }
        L_0x0081:
            java.lang.String r2 = r1.getName()     // Catch:{ Exception -> 0x00a8 }
            android.support.v4.g.m<java.lang.String> r7 = r9.f3298l     // Catch:{ Exception -> 0x00a8 }
            r7.mo1774c(r11, r2)     // Catch:{ Exception -> 0x00a8 }
            android.support.v4.g.a<java.lang.String, android.support.v7.widget.k$d> r7 = r9.f3297k     // Catch:{ Exception -> 0x00a8 }
            java.lang.Object r2 = r7.get(r2)     // Catch:{ Exception -> 0x00a8 }
            android.support.v7.widget.k$d r2 = (android.support.p031v7.widget.C0909k.C0913d) r2     // Catch:{ Exception -> 0x00a8 }
            if (r2 == 0) goto L_0x009d
            android.content.res.Resources$Theme r7 = r10.getTheme()     // Catch:{ Exception -> 0x00a8 }
            android.graphics.drawable.Drawable r1 = r2.mo4574a(r10, r1, r6, r7)     // Catch:{ Exception -> 0x00a8 }
            r5 = r1
        L_0x009d:
            if (r5 == 0) goto L_0x00b0
            int r0 = r0.changingConfigurations     // Catch:{ Exception -> 0x00a8 }
            r5.setChangingConfigurations(r0)     // Catch:{ Exception -> 0x00a8 }
            r9.m4881a(r10, r3, r5)     // Catch:{ Exception -> 0x00a8 }
            goto L_0x00b0
        L_0x00a8:
            r10 = move-exception
            java.lang.String r0 = "AppCompatDrawableManag"
            java.lang.String r1 = "Exception while inflating drawable"
            android.util.Log.e(r0, r1, r10)
        L_0x00b0:
            if (r5 != 0) goto L_0x00b9
            android.support.v4.g.m<java.lang.String> r10 = r9.f3298l
            java.lang.String r0 = "appcompat_skip_skip"
            r10.mo1774c(r11, r0)
        L_0x00b9:
            return r5
        L_0x00ba:
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.p031v7.widget.C0909k.m4888d(android.content.Context, int):android.graphics.drawable.Drawable");
    }

    /* renamed from: e */
    private ColorStateList m4889e(Context context) {
        int[][] iArr = new int[3][];
        int[] iArr2 = new int[3];
        ColorStateList b = C0864bi.m4629b(context, C0541a.colorSwitchThumbNormal);
        if (b == null || !b.isStateful()) {
            iArr[0] = C0864bi.f3124a;
            iArr2[0] = C0864bi.m4630c(context, C0541a.colorSwitchThumbNormal);
            iArr[1] = C0864bi.f3128e;
            iArr2[1] = C0864bi.m4626a(context, C0541a.colorControlActivated);
            iArr[2] = C0864bi.f3131h;
            iArr2[2] = C0864bi.m4626a(context, C0541a.colorSwitchThumbNormal);
        } else {
            iArr[0] = C0864bi.f3124a;
            iArr2[0] = b.getColorForState(iArr[0], 0);
            iArr[1] = C0864bi.f3128e;
            iArr2[1] = C0864bi.m4626a(context, C0541a.colorControlActivated);
            iArr[2] = C0864bi.f3131h;
            iArr2[2] = b.getDefaultColor();
        }
        return new ColorStateList(iArr, iArr2);
    }

    /* renamed from: e */
    private ColorStateList m4890e(Context context, int i) {
        if (this.f3296j == null) {
            return null;
        }
        C0434m mVar = (C0434m) this.f3296j.get(context);
        if (mVar != null) {
            return (ColorStateList) mVar.mo1767a(i);
        }
        return null;
    }

    /* renamed from: f */
    private ColorStateList m4891f(Context context, int i) {
        int a = C0864bi.m4626a(context, C0541a.colorControlHighlight);
        return new ColorStateList(new int[][]{C0864bi.f3124a, C0864bi.f3127d, C0864bi.f3125b, C0864bi.f3131h}, new int[]{C0864bi.m4630c(context, C0541a.colorButtonNormal), C0435a.m1890a(a, i), C0435a.m1890a(a, i), i});
    }

    /* renamed from: f */
    private void m4892f(Context context) {
        if (!this.f3301o) {
            this.f3301o = true;
            Drawable a = mo4569a(context, C0545e.abc_vector_test);
            if (a == null || !m4882a(a)) {
                this.f3301o = false;
                throw new IllegalStateException("This app has been built with an incorrect configuration. Please configure your build for VectorDrawableCompat.");
            }
        }
    }

    /* renamed from: a */
    public synchronized Drawable mo4569a(Context context, int i) {
        return mo4570a(context, i, false);
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public synchronized Drawable mo4570a(Context context, int i, boolean z) {
        Drawable d;
        m4892f(context);
        d = m4888d(context, i);
        if (d == null) {
            d = m4886c(context, i);
        }
        if (d == null) {
            d = C0293a.m1186a(context, i);
        }
        if (d != null) {
            d = m4872a(context, i, z, d);
        }
        if (d != null) {
            C0768al.m3840a(d);
        }
        return d;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public synchronized Drawable mo4571a(Context context, C0878bs bsVar, int i) {
        Drawable d = m4888d(context, i);
        if (d == null) {
            d = bsVar.mo4461a(i);
        }
        if (d == null) {
            return null;
        }
        return m4872a(context, i, false, d);
    }

    /* renamed from: a */
    public synchronized void mo4572a(Context context) {
        C0419f fVar = (C0419f) this.f3299m.get(context);
        if (fVar != null) {
            fVar.mo1670c();
        }
    }

    /* access modifiers changed from: 0000 */
    /* JADX WARNING: Removed duplicated region for block: B:42:0x0078  */
    /* renamed from: b */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public synchronized android.content.res.ColorStateList mo4573b(android.content.Context r3, int r4) {
        /*
            r2 = this;
            monitor-enter(r2)
            android.content.res.ColorStateList r0 = r2.m4890e(r3, r4)     // Catch:{ all -> 0x007d }
            if (r0 != 0) goto L_0x007b
            int r1 = android.support.p031v7.p032a.C0540a.C0545e.abc_edit_text_material     // Catch:{ all -> 0x007d }
            if (r4 != r1) goto L_0x0013
            int r0 = android.support.p031v7.p032a.C0540a.C0543c.abc_tint_edittext     // Catch:{ all -> 0x007d }
        L_0x000d:
            android.content.res.ColorStateList r0 = android.support.p031v7.p033b.p034a.C0606a.m2711a(r3, r0)     // Catch:{ all -> 0x007d }
            goto L_0x0076
        L_0x0013:
            int r1 = android.support.p031v7.p032a.C0540a.C0545e.abc_switch_track_mtrl_alpha     // Catch:{ all -> 0x007d }
            if (r4 != r1) goto L_0x001a
            int r0 = android.support.p031v7.p032a.C0540a.C0543c.abc_tint_switch_track     // Catch:{ all -> 0x007d }
            goto L_0x000d
        L_0x001a:
            int r1 = android.support.p031v7.p032a.C0540a.C0545e.abc_switch_thumb_material     // Catch:{ all -> 0x007d }
            if (r4 != r1) goto L_0x0023
            android.content.res.ColorStateList r0 = r2.m4889e(r3)     // Catch:{ all -> 0x007d }
            goto L_0x0076
        L_0x0023:
            int r1 = android.support.p031v7.p032a.C0540a.C0545e.abc_btn_default_mtrl_shape     // Catch:{ all -> 0x007d }
            if (r4 != r1) goto L_0x002c
            android.content.res.ColorStateList r0 = r2.m4884b(r3)     // Catch:{ all -> 0x007d }
            goto L_0x0076
        L_0x002c:
            int r1 = android.support.p031v7.p032a.C0540a.C0545e.abc_btn_borderless_material     // Catch:{ all -> 0x007d }
            if (r4 != r1) goto L_0x0035
            android.content.res.ColorStateList r0 = r2.m4885c(r3)     // Catch:{ all -> 0x007d }
            goto L_0x0076
        L_0x0035:
            int r1 = android.support.p031v7.p032a.C0540a.C0545e.abc_btn_colored_material     // Catch:{ all -> 0x007d }
            if (r4 != r1) goto L_0x003e
            android.content.res.ColorStateList r0 = r2.m4887d(r3)     // Catch:{ all -> 0x007d }
            goto L_0x0076
        L_0x003e:
            int r1 = android.support.p031v7.p032a.C0540a.C0545e.abc_spinner_mtrl_am_alpha     // Catch:{ all -> 0x007d }
            if (r4 == r1) goto L_0x0073
            int r1 = android.support.p031v7.p032a.C0540a.C0545e.abc_spinner_textfield_background_material     // Catch:{ all -> 0x007d }
            if (r4 != r1) goto L_0x0047
            goto L_0x0073
        L_0x0047:
            int[] r1 = f3291e     // Catch:{ all -> 0x007d }
            boolean r1 = m4883a(r1, r4)     // Catch:{ all -> 0x007d }
            if (r1 == 0) goto L_0x0056
            int r0 = android.support.p031v7.p032a.C0540a.C0541a.colorControlNormal     // Catch:{ all -> 0x007d }
            android.content.res.ColorStateList r0 = android.support.p031v7.widget.C0864bi.m4629b(r3, r0)     // Catch:{ all -> 0x007d }
            goto L_0x0076
        L_0x0056:
            int[] r1 = f3294h     // Catch:{ all -> 0x007d }
            boolean r1 = m4883a(r1, r4)     // Catch:{ all -> 0x007d }
            if (r1 == 0) goto L_0x0061
            int r0 = android.support.p031v7.p032a.C0540a.C0543c.abc_tint_default     // Catch:{ all -> 0x007d }
            goto L_0x000d
        L_0x0061:
            int[] r1 = f3295i     // Catch:{ all -> 0x007d }
            boolean r1 = m4883a(r1, r4)     // Catch:{ all -> 0x007d }
            if (r1 == 0) goto L_0x006c
            int r0 = android.support.p031v7.p032a.C0540a.C0543c.abc_tint_btn_checkable     // Catch:{ all -> 0x007d }
            goto L_0x000d
        L_0x006c:
            int r1 = android.support.p031v7.p032a.C0540a.C0545e.abc_seekbar_thumb_material     // Catch:{ all -> 0x007d }
            if (r4 != r1) goto L_0x0076
            int r0 = android.support.p031v7.p032a.C0540a.C0543c.abc_tint_seek_thumb     // Catch:{ all -> 0x007d }
            goto L_0x000d
        L_0x0073:
            int r0 = android.support.p031v7.p032a.C0540a.C0543c.abc_tint_spinner     // Catch:{ all -> 0x007d }
            goto L_0x000d
        L_0x0076:
            if (r0 == 0) goto L_0x007b
            r2.m4875a(r3, r4, r0)     // Catch:{ all -> 0x007d }
        L_0x007b:
            monitor-exit(r2)
            return r0
        L_0x007d:
            r3 = move-exception
            monitor-exit(r2)
            throw r3
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.p031v7.widget.C0909k.mo4573b(android.content.Context, int):android.content.res.ColorStateList");
    }
}
