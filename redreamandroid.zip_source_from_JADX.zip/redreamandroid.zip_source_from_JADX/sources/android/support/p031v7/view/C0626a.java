package android.support.p031v7.view;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.os.Build.VERSION;
import android.support.p031v7.p032a.C0540a.C0541a;
import android.support.p031v7.p032a.C0540a.C0542b;
import android.support.p031v7.p032a.C0540a.C0544d;
import android.support.p031v7.p032a.C0540a.C0550j;
import android.view.ViewConfiguration;

/* renamed from: android.support.v7.view.a */
public class C0626a {

    /* renamed from: a */
    private Context f1933a;

    private C0626a(Context context) {
        this.f1933a = context;
    }

    /* renamed from: a */
    public static C0626a m2803a(Context context) {
        return new C0626a(context);
    }

    /* renamed from: a */
    public int mo2491a() {
        Configuration configuration = this.f1933a.getResources().getConfiguration();
        int i = configuration.screenWidthDp;
        int i2 = configuration.screenHeightDp;
        if (configuration.smallestScreenWidthDp > 600 || i > 600 || ((i > 960 && i2 > 720) || (i > 720 && i2 > 960))) {
            return 5;
        }
        if (i >= 500 || ((i > 640 && i2 > 480) || (i > 480 && i2 > 640))) {
            return 4;
        }
        return i >= 360 ? 3 : 2;
    }

    /* renamed from: b */
    public boolean mo2492b() {
        if (VERSION.SDK_INT >= 19) {
            return true;
        }
        return !ViewConfiguration.get(this.f1933a).hasPermanentMenuKey();
    }

    /* renamed from: c */
    public int mo2493c() {
        return this.f1933a.getResources().getDisplayMetrics().widthPixels / 2;
    }

    /* renamed from: d */
    public boolean mo2494d() {
        return this.f1933a.getResources().getBoolean(C0542b.abc_action_bar_embed_tabs);
    }

    /* renamed from: e */
    public int mo2495e() {
        TypedArray obtainStyledAttributes = this.f1933a.obtainStyledAttributes(null, C0550j.ActionBar, C0541a.actionBarStyle, 0);
        int layoutDimension = obtainStyledAttributes.getLayoutDimension(C0550j.ActionBar_height, 0);
        Resources resources = this.f1933a.getResources();
        if (!mo2494d()) {
            layoutDimension = Math.min(layoutDimension, resources.getDimensionPixelSize(C0544d.abc_action_bar_stacked_max_height));
        }
        obtainStyledAttributes.recycle();
        return layoutDimension;
    }

    /* renamed from: f */
    public boolean mo2496f() {
        return this.f1933a.getApplicationInfo().targetSdkVersion < 14;
    }

    /* renamed from: g */
    public int mo2497g() {
        return this.f1933a.getResources().getDimensionPixelSize(C0544d.abc_action_bar_stacked_tab_max_width);
    }
}
