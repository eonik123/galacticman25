package android.support.p031v7.view.menu;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.support.p031v7.view.menu.C0655h.C0656a;
import android.view.Menu;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;

/* renamed from: android.support.v7.view.menu.u */
public class C0681u extends C0655h implements SubMenu {

    /* renamed from: d */
    private C0655h f2236d;

    /* renamed from: e */
    private C0659j f2237e;

    public C0681u(Context context, C0655h hVar, C0659j jVar) {
        super(context);
        this.f2236d = hVar;
        this.f2237e = jVar;
    }

    /* renamed from: a */
    public String mo2703a() {
        int itemId = this.f2237e != null ? this.f2237e.getItemId() : 0;
        if (itemId == 0) {
            return null;
        }
        StringBuilder sb = new StringBuilder();
        sb.append(super.mo2703a());
        sb.append(":");
        sb.append(itemId);
        return sb.toString();
    }

    /* renamed from: a */
    public void mo2705a(C0656a aVar) {
        this.f2236d.mo2705a(aVar);
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public boolean mo2712a(C0655h hVar, MenuItem menuItem) {
        return super.mo2712a(hVar, menuItem) || this.f2236d.mo2712a(hVar, menuItem);
    }

    /* renamed from: b */
    public boolean mo2729b() {
        return this.f2236d.mo2729b();
    }

    /* renamed from: c */
    public boolean mo2732c() {
        return this.f2236d.mo2732c();
    }

    /* renamed from: c */
    public boolean mo2733c(C0659j jVar) {
        return this.f2236d.mo2733c(jVar);
    }

    /* renamed from: d */
    public boolean mo2738d() {
        return this.f2236d.mo2738d();
    }

    /* renamed from: d */
    public boolean mo2739d(C0659j jVar) {
        return this.f2236d.mo2739d(jVar);
    }

    public MenuItem getItem() {
        return this.f2237e;
    }

    /* renamed from: q */
    public C0655h mo2759q() {
        return this.f2236d.mo2759q();
    }

    public void setGroupDividerEnabled(boolean z) {
        this.f2236d.setGroupDividerEnabled(z);
    }

    public SubMenu setHeaderIcon(int i) {
        return (SubMenu) super.mo2741e(i);
    }

    public SubMenu setHeaderIcon(Drawable drawable) {
        return (SubMenu) super.mo2698a(drawable);
    }

    public SubMenu setHeaderTitle(int i) {
        return (SubMenu) super.mo2737d(i);
    }

    public SubMenu setHeaderTitle(CharSequence charSequence) {
        return (SubMenu) super.mo2700a(charSequence);
    }

    public SubMenu setHeaderView(View view) {
        return (SubMenu) super.mo2699a(view);
    }

    public SubMenu setIcon(int i) {
        this.f2237e.setIcon(i);
        return this;
    }

    public SubMenu setIcon(Drawable drawable) {
        this.f2237e.setIcon(drawable);
        return this;
    }

    public void setQwertyMode(boolean z) {
        this.f2236d.setQwertyMode(z);
    }

    /* renamed from: t */
    public Menu mo2949t() {
        return this.f2236d;
    }
}
