package android.support.p031v7.view.menu;

import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.DialogInterface.OnDismissListener;
import android.content.DialogInterface.OnKeyListener;
import android.os.IBinder;
import android.support.p031v7.app.C0569b;
import android.support.p031v7.app.C0569b.C0570a;
import android.support.p031v7.p032a.C0540a.C0547g;
import android.support.p031v7.view.menu.C0671o.C0672a;
import android.view.KeyEvent;
import android.view.KeyEvent.DispatcherState;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager.LayoutParams;

/* renamed from: android.support.v7.view.menu.i */
class C0658i implements OnClickListener, OnDismissListener, OnKeyListener, C0672a {

    /* renamed from: a */
    C0652f f2155a;

    /* renamed from: b */
    private C0655h f2156b;

    /* renamed from: c */
    private C0569b f2157c;

    /* renamed from: d */
    private C0672a f2158d;

    public C0658i(C0655h hVar) {
        this.f2156b = hVar;
    }

    /* renamed from: a */
    public void mo2770a() {
        if (this.f2157c != null) {
            this.f2157c.dismiss();
        }
    }

    /* renamed from: a */
    public void mo2771a(IBinder iBinder) {
        C0655h hVar = this.f2156b;
        C0570a aVar = new C0570a(hVar.mo2742f());
        this.f2155a = new C0652f(aVar.mo2204a(), C0547g.abc_list_menu_item_layout);
        this.f2155a.mo2640a((C0672a) this);
        this.f2156b.mo2707a((C0671o) this.f2155a);
        aVar.mo2208a(this.f2155a.mo2678a(), this);
        View p = hVar.mo2756p();
        if (p != null) {
            aVar.mo2207a(p);
        } else {
            aVar.mo2206a(hVar.mo2755o()).mo2209a(hVar.mo2754n());
        }
        aVar.mo2205a((OnKeyListener) this);
        this.f2157c = aVar.mo2210b();
        this.f2157c.setOnDismissListener(this);
        LayoutParams attributes = this.f2157c.getWindow().getAttributes();
        attributes.type = 1003;
        if (iBinder != null) {
            attributes.token = iBinder;
        }
        attributes.flags |= 131072;
        this.f2157c.show();
    }

    /* renamed from: a */
    public void mo2296a(C0655h hVar, boolean z) {
        if (z || hVar == this.f2156b) {
            mo2770a();
        }
        if (this.f2158d != null) {
            this.f2158d.mo2296a(hVar, z);
        }
    }

    /* renamed from: a */
    public boolean mo2297a(C0655h hVar) {
        if (this.f2158d != null) {
            return this.f2158d.mo2297a(hVar);
        }
        return false;
    }

    public void onClick(DialogInterface dialogInterface, int i) {
        this.f2156b.mo2713a((MenuItem) (C0659j) this.f2155a.mo2678a().getItem(i), 0);
    }

    public void onDismiss(DialogInterface dialogInterface) {
        this.f2155a.mo2638a(this.f2156b, true);
    }

    public boolean onKey(DialogInterface dialogInterface, int i, KeyEvent keyEvent) {
        if (i == 82 || i == 4) {
            if (keyEvent.getAction() == 0 && keyEvent.getRepeatCount() == 0) {
                Window window = this.f2157c.getWindow();
                if (window != null) {
                    View decorView = window.getDecorView();
                    if (decorView != null) {
                        DispatcherState keyDispatcherState = decorView.getKeyDispatcherState();
                        if (keyDispatcherState != null) {
                            keyDispatcherState.startTracking(keyEvent, this);
                            return true;
                        }
                    }
                }
            } else if (keyEvent.getAction() == 1 && !keyEvent.isCanceled()) {
                Window window2 = this.f2157c.getWindow();
                if (window2 != null) {
                    View decorView2 = window2.getDecorView();
                    if (decorView2 != null) {
                        DispatcherState keyDispatcherState2 = decorView2.getKeyDispatcherState();
                        if (keyDispatcherState2 != null && keyDispatcherState2.isTracking(keyEvent)) {
                            this.f2156b.mo2711a(true);
                            dialogInterface.dismiss();
                            return true;
                        }
                    }
                }
            }
        }
        return this.f2156b.performShortcut(i, keyEvent, 0);
    }
}
