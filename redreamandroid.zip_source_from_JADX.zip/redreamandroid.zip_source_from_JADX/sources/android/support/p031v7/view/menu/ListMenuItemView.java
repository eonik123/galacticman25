package android.support.p031v7.view.menu;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.support.p018v4.p028h.C0495r;
import android.support.p031v7.p032a.C0540a.C0541a;
import android.support.p031v7.p032a.C0540a.C0546f;
import android.support.p031v7.p032a.C0540a.C0547g;
import android.support.p031v7.p032a.C0540a.C0550j;
import android.support.p031v7.view.menu.C0673p.C0674a;
import android.support.p031v7.widget.C0869bn;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView.SelectionBoundsAdjuster;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.RadioButton;
import android.widget.TextView;

/* renamed from: android.support.v7.view.menu.ListMenuItemView */
public class ListMenuItemView extends LinearLayout implements C0674a, SelectionBoundsAdjuster {

    /* renamed from: a */
    private C0659j f2020a;

    /* renamed from: b */
    private ImageView f2021b;

    /* renamed from: c */
    private RadioButton f2022c;

    /* renamed from: d */
    private TextView f2023d;

    /* renamed from: e */
    private CheckBox f2024e;

    /* renamed from: f */
    private TextView f2025f;

    /* renamed from: g */
    private ImageView f2026g;

    /* renamed from: h */
    private ImageView f2027h;

    /* renamed from: i */
    private LinearLayout f2028i;

    /* renamed from: j */
    private Drawable f2029j;

    /* renamed from: k */
    private int f2030k;

    /* renamed from: l */
    private Context f2031l;

    /* renamed from: m */
    private boolean f2032m;

    /* renamed from: n */
    private Drawable f2033n;

    /* renamed from: o */
    private boolean f2034o;

    /* renamed from: p */
    private int f2035p;

    /* renamed from: q */
    private LayoutInflater f2036q;

    /* renamed from: r */
    private boolean f2037r;

    public ListMenuItemView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, C0541a.listMenuViewStyle);
    }

    public ListMenuItemView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet);
        C0869bn a = C0869bn.m4638a(getContext(), attributeSet, C0550j.MenuView, i, 0);
        this.f2029j = a.mo4426a(C0550j.MenuView_android_itemBackground);
        this.f2030k = a.mo4439g(C0550j.MenuView_android_itemTextAppearance, -1);
        this.f2032m = a.mo4428a(C0550j.MenuView_preserveIconSpacing, false);
        this.f2031l = context;
        this.f2033n = a.mo4426a(C0550j.MenuView_subMenuArrow);
        TypedArray obtainStyledAttributes = context.getTheme().obtainStyledAttributes(null, new int[]{16843049}, C0541a.dropDownListViewStyle, 0);
        this.f2034o = obtainStyledAttributes.hasValue(0);
        a.mo4427a();
        obtainStyledAttributes.recycle();
    }

    /* renamed from: a */
    private void m2895a(View view) {
        m2896a(view, -1);
    }

    /* renamed from: a */
    private void m2896a(View view, int i) {
        if (this.f2028i != null) {
            this.f2028i.addView(view, i);
        } else {
            addView(view, i);
        }
    }

    /* renamed from: b */
    private void m2897b() {
        this.f2021b = (ImageView) getInflater().inflate(C0547g.abc_list_menu_item_icon, this, false);
        m2896a((View) this.f2021b, 0);
    }

    /* renamed from: c */
    private void m2898c() {
        this.f2022c = (RadioButton) getInflater().inflate(C0547g.abc_list_menu_item_radio, this, false);
        m2895a(this.f2022c);
    }

    /* renamed from: d */
    private void m2899d() {
        this.f2024e = (CheckBox) getInflater().inflate(C0547g.abc_list_menu_item_checkbox, this, false);
        m2895a(this.f2024e);
    }

    private LayoutInflater getInflater() {
        if (this.f2036q == null) {
            this.f2036q = LayoutInflater.from(getContext());
        }
        return this.f2036q;
    }

    private void setSubMenuArrowVisible(boolean z) {
        if (this.f2026g != null) {
            this.f2026g.setVisibility(z ? 0 : 8);
        }
    }

    /* renamed from: a */
    public void mo636a(C0659j jVar, int i) {
        this.f2020a = jVar;
        this.f2035p = i;
        setVisibility(jVar.isVisible() ? 0 : 8);
        setTitle(jVar.mo2777a((C0674a) this));
        setCheckable(jVar.isCheckable());
        mo2585a(jVar.mo2790f(), jVar.mo2786d());
        setIcon(jVar.getIcon());
        setEnabled(jVar.isEnabled());
        setSubMenuArrowVisible(jVar.hasSubMenu());
        setContentDescription(jVar.getContentDescription());
    }

    /* renamed from: a */
    public void mo2585a(boolean z, char c) {
        int i = (!z || !this.f2020a.mo2790f()) ? 8 : 0;
        if (i == 0) {
            this.f2025f.setText(this.f2020a.mo2788e());
        }
        if (this.f2025f.getVisibility() != i) {
            this.f2025f.setVisibility(i);
        }
    }

    /* renamed from: a */
    public boolean mo637a() {
        return false;
    }

    public void adjustListItemSelectionBounds(Rect rect) {
        if (this.f2027h != null && this.f2027h.getVisibility() == 0) {
            LayoutParams layoutParams = (LayoutParams) this.f2027h.getLayoutParams();
            rect.top += this.f2027h.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin;
        }
    }

    public C0659j getItemData() {
        return this.f2020a;
    }

    /* access modifiers changed from: protected */
    public void onFinishInflate() {
        super.onFinishInflate();
        C0495r.m2131a((View) this, this.f2029j);
        this.f2023d = (TextView) findViewById(C0546f.title);
        if (this.f2030k != -1) {
            this.f2023d.setTextAppearance(this.f2031l, this.f2030k);
        }
        this.f2025f = (TextView) findViewById(C0546f.shortcut);
        this.f2026g = (ImageView) findViewById(C0546f.submenuarrow);
        if (this.f2026g != null) {
            this.f2026g.setImageDrawable(this.f2033n);
        }
        this.f2027h = (ImageView) findViewById(C0546f.group_divider);
        this.f2028i = (LinearLayout) findViewById(C0546f.content);
    }

    /* access modifiers changed from: protected */
    public void onMeasure(int i, int i2) {
        if (this.f2021b != null && this.f2032m) {
            ViewGroup.LayoutParams layoutParams = getLayoutParams();
            LayoutParams layoutParams2 = (LayoutParams) this.f2021b.getLayoutParams();
            if (layoutParams.height > 0 && layoutParams2.width <= 0) {
                layoutParams2.width = layoutParams.height;
            }
        }
        super.onMeasure(i, i2);
    }

    public void setCheckable(boolean z) {
        CompoundButton compoundButton;
        CompoundButton compoundButton2;
        if (z || this.f2022c != null || this.f2024e != null) {
            if (this.f2020a.mo2791g()) {
                if (this.f2022c == null) {
                    m2898c();
                }
                compoundButton2 = this.f2022c;
                compoundButton = this.f2024e;
            } else {
                if (this.f2024e == null) {
                    m2899d();
                }
                compoundButton2 = this.f2024e;
                compoundButton = this.f2022c;
            }
            if (z) {
                compoundButton2.setChecked(this.f2020a.isChecked());
                if (compoundButton2.getVisibility() != 0) {
                    compoundButton2.setVisibility(0);
                }
                if (!(compoundButton == null || compoundButton.getVisibility() == 8)) {
                    compoundButton.setVisibility(8);
                }
            } else {
                if (this.f2024e != null) {
                    this.f2024e.setVisibility(8);
                }
                if (this.f2022c != null) {
                    this.f2022c.setVisibility(8);
                }
            }
        }
    }

    public void setChecked(boolean z) {
        CompoundButton compoundButton;
        if (this.f2020a.mo2791g()) {
            if (this.f2022c == null) {
                m2898c();
            }
            compoundButton = this.f2022c;
        } else {
            if (this.f2024e == null) {
                m2899d();
            }
            compoundButton = this.f2024e;
        }
        compoundButton.setChecked(z);
    }

    public void setForceShowIcon(boolean z) {
        this.f2037r = z;
        this.f2032m = z;
    }

    public void setGroupDividerEnabled(boolean z) {
        if (this.f2027h != null) {
            this.f2027h.setVisibility((this.f2034o || !z) ? 8 : 0);
        }
    }

    public void setIcon(Drawable drawable) {
        boolean z = this.f2020a.mo2806i() || this.f2037r;
        if (!z && !this.f2032m) {
            return;
        }
        if (this.f2021b != null || drawable != null || this.f2032m) {
            if (this.f2021b == null) {
                m2897b();
            }
            if (drawable != null || this.f2032m) {
                ImageView imageView = this.f2021b;
                if (!z) {
                    drawable = null;
                }
                imageView.setImageDrawable(drawable);
                if (this.f2021b.getVisibility() != 0) {
                    this.f2021b.setVisibility(0);
                }
                return;
            }
            this.f2021b.setVisibility(8);
        }
    }

    public void setTitle(CharSequence charSequence) {
        int i;
        TextView textView;
        if (charSequence != null) {
            this.f2023d.setText(charSequence);
            if (this.f2023d.getVisibility() != 0) {
                textView = this.f2023d;
                i = 0;
            }
            return;
        }
        i = 8;
        if (this.f2023d.getVisibility() != 8) {
            textView = this.f2023d;
        }
        return;
        textView.setVisibility(i);
    }
}
