package android.support.p031v7.view.menu;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Rect;
import android.os.Build.VERSION;
import android.os.Handler;
import android.os.SystemClock;
import android.support.p018v4.p028h.C0480d;
import android.support.p018v4.p028h.C0495r;
import android.support.p031v7.p032a.C0540a.C0544d;
import android.support.p031v7.p032a.C0540a.C0547g;
import android.support.p031v7.view.menu.C0671o.C0672a;
import android.support.p031v7.widget.C0797au;
import android.support.p031v7.widget.C0798av;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnAttachStateChangeListener;
import android.view.View.OnKeyListener;
import android.view.ViewTreeObserver;
import android.view.ViewTreeObserver.OnGlobalLayoutListener;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.FrameLayout;
import android.widget.HeaderViewListAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.PopupWindow.OnDismissListener;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;

/* renamed from: android.support.v7.view.menu.e */
final class C0646e extends C0668m implements C0671o, OnKeyListener, OnDismissListener {

    /* renamed from: g */
    private static final int f2074g = C0547g.abc_cascading_menu_item_layout;

    /* renamed from: A */
    private OnDismissListener f2075A;

    /* renamed from: a */
    final Handler f2076a;

    /* renamed from: b */
    final List<C0651a> f2077b = new ArrayList();

    /* renamed from: c */
    final OnGlobalLayoutListener f2078c = new OnGlobalLayoutListener() {
        public void onGlobalLayout() {
            if (C0646e.this.mo2665d() && C0646e.this.f2077b.size() > 0 && !((C0651a) C0646e.this.f2077b.get(0)).f2108a.mo3785g()) {
                View view = C0646e.this.f2079d;
                if (view == null || !view.isShown()) {
                    C0646e.this.mo2662c();
                    return;
                }
                for (C0651a aVar : C0646e.this.f2077b) {
                    aVar.f2108a.mo2655a();
                }
            }
        }
    };

    /* renamed from: d */
    View f2079d;

    /* renamed from: e */
    ViewTreeObserver f2080e;

    /* renamed from: f */
    boolean f2081f;

    /* renamed from: h */
    private final Context f2082h;

    /* renamed from: i */
    private final int f2083i;

    /* renamed from: j */
    private final int f2084j;

    /* renamed from: k */
    private final int f2085k;

    /* renamed from: l */
    private final boolean f2086l;

    /* renamed from: m */
    private final List<C0655h> f2087m = new ArrayList();

    /* renamed from: n */
    private final OnAttachStateChangeListener f2088n = new OnAttachStateChangeListener() {
        public void onViewAttachedToWindow(View view) {
        }

        public void onViewDetachedFromWindow(View view) {
            if (C0646e.this.f2080e != null) {
                if (!C0646e.this.f2080e.isAlive()) {
                    C0646e.this.f2080e = view.getViewTreeObserver();
                }
                C0646e.this.f2080e.removeGlobalOnLayoutListener(C0646e.this.f2078c);
            }
            view.removeOnAttachStateChangeListener(this);
        }
    };

    /* renamed from: o */
    private final C0797au f2089o = new C0797au() {
        /* renamed from: a */
        public void mo2673a(C0655h hVar, MenuItem menuItem) {
            C0646e.this.f2076a.removeCallbacksAndMessages(hVar);
        }

        /* renamed from: b */
        public void mo2674b(final C0655h hVar, final MenuItem menuItem) {
            final C0651a aVar = null;
            C0646e.this.f2076a.removeCallbacksAndMessages(null);
            int size = C0646e.this.f2077b.size();
            int i = 0;
            while (true) {
                if (i >= size) {
                    i = -1;
                    break;
                } else if (hVar == ((C0651a) C0646e.this.f2077b.get(i)).f2109b) {
                    break;
                } else {
                    i++;
                }
            }
            if (i != -1) {
                int i2 = i + 1;
                if (i2 < C0646e.this.f2077b.size()) {
                    aVar = (C0651a) C0646e.this.f2077b.get(i2);
                }
                C0646e.this.f2076a.postAtTime(new Runnable() {
                    public void run() {
                        if (aVar != null) {
                            C0646e.this.f2081f = true;
                            aVar.f2109b.mo2711a(false);
                            C0646e.this.f2081f = false;
                        }
                        if (menuItem.isEnabled() && menuItem.hasSubMenu()) {
                            hVar.mo2713a(menuItem, 4);
                        }
                    }
                }, hVar, SystemClock.uptimeMillis() + 200);
            }
        }
    };

    /* renamed from: p */
    private int f2090p = 0;

    /* renamed from: q */
    private int f2091q = 0;

    /* renamed from: r */
    private View f2092r;

    /* renamed from: s */
    private int f2093s;

    /* renamed from: t */
    private boolean f2094t;

    /* renamed from: u */
    private boolean f2095u;

    /* renamed from: v */
    private int f2096v;

    /* renamed from: w */
    private int f2097w;

    /* renamed from: x */
    private boolean f2098x;

    /* renamed from: y */
    private boolean f2099y;

    /* renamed from: z */
    private C0672a f2100z;

    /* renamed from: android.support.v7.view.menu.e$a */
    private static class C0651a {

        /* renamed from: a */
        public final C0798av f2108a;

        /* renamed from: b */
        public final C0655h f2109b;

        /* renamed from: c */
        public final int f2110c;

        public C0651a(C0798av avVar, C0655h hVar, int i) {
            this.f2108a = avVar;
            this.f2109b = hVar;
            this.f2110c = i;
        }

        /* renamed from: a */
        public ListView mo2676a() {
            return this.f2108a.mo2666e();
        }
    }

    public C0646e(Context context, View view, int i, int i2, boolean z) {
        this.f2082h = context;
        this.f2092r = view;
        this.f2084j = i;
        this.f2085k = i2;
        this.f2086l = z;
        this.f2098x = false;
        this.f2093s = m2939i();
        Resources resources = context.getResources();
        this.f2083i = Math.max(resources.getDisplayMetrics().widthPixels / 2, resources.getDimensionPixelSize(C0544d.abc_config_prefDialogWidth));
        this.f2076a = new Handler();
    }

    /* renamed from: a */
    private MenuItem m2933a(C0655h hVar, C0655h hVar2) {
        int size = hVar.size();
        for (int i = 0; i < size; i++) {
            MenuItem item = hVar.getItem(i);
            if (item.hasSubMenu() && hVar2 == item.getSubMenu()) {
                return item;
            }
        }
        return null;
    }

    /* renamed from: a */
    private View m2934a(C0651a aVar, C0655h hVar) {
        int i;
        C0654g gVar;
        MenuItem a = m2933a(aVar.f2109b, hVar);
        if (a == null) {
            return null;
        }
        ListView a2 = aVar.mo2676a();
        ListAdapter adapter = a2.getAdapter();
        int i2 = 0;
        if (adapter instanceof HeaderViewListAdapter) {
            HeaderViewListAdapter headerViewListAdapter = (HeaderViewListAdapter) adapter;
            i = headerViewListAdapter.getHeadersCount();
            gVar = (C0654g) headerViewListAdapter.getWrappedAdapter();
        } else {
            gVar = (C0654g) adapter;
            i = 0;
        }
        int count = gVar.getCount();
        while (true) {
            if (i2 >= count) {
                i2 = -1;
                break;
            } else if (a == gVar.getItem(i2)) {
                break;
            } else {
                i2++;
            }
        }
        if (i2 == -1) {
            return null;
        }
        int firstVisiblePosition = (i2 + i) - a2.getFirstVisiblePosition();
        if (firstVisiblePosition < 0 || firstVisiblePosition >= a2.getChildCount()) {
            return null;
        }
        return a2.getChildAt(firstVisiblePosition);
    }

    /* renamed from: c */
    private void m2935c(C0655h hVar) {
        View view;
        C0651a aVar;
        int i;
        int i2;
        int i3;
        LayoutInflater from = LayoutInflater.from(this.f2082h);
        C0654g gVar = new C0654g(hVar, from, this.f2086l, f2074g);
        if (!mo2665d() && this.f2098x) {
            gVar.mo2689a(true);
        } else if (mo2665d()) {
            gVar.mo2689a(C0668m.m3087b(hVar));
        }
        int a = m3085a(gVar, null, this.f2082h, this.f2083i);
        C0798av h = m2938h();
        h.mo3774a((ListAdapter) gVar);
        h.mo3784g(a);
        h.mo3782e(this.f2091q);
        if (this.f2077b.size() > 0) {
            aVar = (C0651a) this.f2077b.get(this.f2077b.size() - 1);
            view = m2934a(aVar, hVar);
        } else {
            aVar = null;
            view = null;
        }
        if (view != null) {
            h.mo3808c(false);
            h.mo3806a((Object) null);
            int d = m2936d(a);
            boolean z = d == 1;
            this.f2093s = d;
            if (VERSION.SDK_INT >= 26) {
                h.mo3778b(view);
                i2 = 0;
                i = 0;
            } else {
                int[] iArr = new int[2];
                this.f2092r.getLocationOnScreen(iArr);
                int[] iArr2 = new int[2];
                view.getLocationOnScreen(iArr2);
                if ((this.f2091q & 7) == 5) {
                    iArr[0] = iArr[0] + this.f2092r.getWidth();
                    iArr2[0] = iArr2[0] + view.getWidth();
                }
                i = iArr2[0] - iArr[0];
                i2 = iArr2[1] - iArr[1];
            }
            if ((this.f2091q & 5) != 5) {
                if (z) {
                    a = view.getWidth();
                }
                i3 = i - a;
                h.mo3780c(i3);
                h.mo3779b(true);
                h.mo3781d(i2);
            } else if (!z) {
                a = view.getWidth();
                i3 = i - a;
                h.mo3780c(i3);
                h.mo3779b(true);
                h.mo3781d(i2);
            }
            i3 = i + a;
            h.mo3780c(i3);
            h.mo3779b(true);
            h.mo3781d(i2);
        } else {
            if (this.f2094t) {
                h.mo3780c(this.f2096v);
            }
            if (this.f2095u) {
                h.mo3781d(this.f2097w);
            }
            h.mo3771a(mo2897g());
        }
        this.f2077b.add(new C0651a(h, hVar, this.f2093s));
        h.mo2655a();
        ListView e = h.mo2666e();
        e.setOnKeyListener(this);
        if (aVar == null && this.f2099y && hVar.mo2754n() != null) {
            FrameLayout frameLayout = (FrameLayout) from.inflate(C0547g.abc_popup_menu_header_item_layout, e, false);
            TextView textView = (TextView) frameLayout.findViewById(16908310);
            frameLayout.setEnabled(false);
            textView.setText(hVar.mo2754n());
            e.addHeaderView(frameLayout, null, false);
            h.mo2655a();
        }
    }

    /* renamed from: d */
    private int m2936d(int i) {
        ListView a = ((C0651a) this.f2077b.get(this.f2077b.size() - 1)).mo2676a();
        int[] iArr = new int[2];
        a.getLocationOnScreen(iArr);
        Rect rect = new Rect();
        this.f2079d.getWindowVisibleDisplayFrame(rect);
        return this.f2093s == 1 ? (iArr[0] + a.getWidth()) + i > rect.right ? 0 : 1 : iArr[0] - i < 0 ? 1 : 0;
    }

    /* renamed from: d */
    private int m2937d(C0655h hVar) {
        int size = this.f2077b.size();
        for (int i = 0; i < size; i++) {
            if (hVar == ((C0651a) this.f2077b.get(i)).f2109b) {
                return i;
            }
        }
        return -1;
    }

    /* renamed from: h */
    private C0798av m2938h() {
        C0798av avVar = new C0798av(this.f2082h, null, this.f2084j, this.f2085k);
        avVar.mo3805a(this.f2089o);
        avVar.mo3773a((OnItemClickListener) this);
        avVar.mo3775a((OnDismissListener) this);
        avVar.mo3778b(this.f2092r);
        avVar.mo3782e(this.f2091q);
        avVar.mo3776a(true);
        avVar.mo3787h(2);
        return avVar;
    }

    /* renamed from: i */
    private int m2939i() {
        return C0495r.m2149f(this.f2092r) == 1 ? 0 : 1;
    }

    /* renamed from: a */
    public void mo2655a() {
        if (!mo2665d()) {
            for (C0655h c : this.f2087m) {
                m2935c(c);
            }
            this.f2087m.clear();
            this.f2079d = this.f2092r;
            if (this.f2079d != null) {
                boolean z = this.f2080e == null;
                this.f2080e = this.f2079d.getViewTreeObserver();
                if (z) {
                    this.f2080e.addOnGlobalLayoutListener(this.f2078c);
                }
                this.f2079d.addOnAttachStateChangeListener(this.f2088n);
            }
        }
    }

    /* renamed from: a */
    public void mo2656a(int i) {
        if (this.f2090p != i) {
            this.f2090p = i;
            this.f2091q = C0480d.m2070a(i, C0495r.m2149f(this.f2092r));
        }
    }

    /* renamed from: a */
    public void mo2657a(C0655h hVar) {
        hVar.mo2708a((C0671o) this, this.f2082h);
        if (mo2665d()) {
            m2935c(hVar);
        } else {
            this.f2087m.add(hVar);
        }
    }

    /* renamed from: a */
    public void mo2638a(C0655h hVar, boolean z) {
        int d = m2937d(hVar);
        if (d >= 0) {
            int i = d + 1;
            if (i < this.f2077b.size()) {
                ((C0651a) this.f2077b.get(i)).f2109b.mo2711a(false);
            }
            C0651a aVar = (C0651a) this.f2077b.remove(d);
            aVar.f2109b.mo2727b((C0671o) this);
            if (this.f2081f) {
                aVar.f2108a.mo3807b(null);
                aVar.f2108a.mo3777b(0);
            }
            aVar.f2108a.mo2662c();
            int size = this.f2077b.size();
            this.f2093s = size > 0 ? ((C0651a) this.f2077b.get(size - 1)).f2110c : m2939i();
            if (size == 0) {
                mo2662c();
                if (this.f2100z != null) {
                    this.f2100z.mo2296a(hVar, true);
                }
                if (this.f2080e != null) {
                    if (this.f2080e.isAlive()) {
                        this.f2080e.removeGlobalOnLayoutListener(this.f2078c);
                    }
                    this.f2080e = null;
                }
                this.f2079d.removeOnAttachStateChangeListener(this.f2088n);
                this.f2075A.onDismiss();
                return;
            }
            if (z) {
                ((C0651a) this.f2077b.get(0)).f2109b.mo2711a(false);
            }
        }
    }

    /* renamed from: a */
    public void mo2640a(C0672a aVar) {
        this.f2100z = aVar;
    }

    /* renamed from: a */
    public void mo2658a(View view) {
        if (this.f2092r != view) {
            this.f2092r = view;
            this.f2091q = C0480d.m2070a(this.f2090p, C0495r.m2149f(this.f2092r));
        }
    }

    /* renamed from: a */
    public void mo2659a(OnDismissListener onDismissListener) {
        this.f2075A = onDismissListener;
    }

    /* renamed from: a */
    public void mo2660a(boolean z) {
        this.f2098x = z;
    }

    /* renamed from: a */
    public boolean mo2644a(C0681u uVar) {
        for (C0651a aVar : this.f2077b) {
            if (uVar == aVar.f2109b) {
                aVar.mo2676a().requestFocus();
                return true;
            }
        }
        if (!uVar.hasVisibleItems()) {
            return false;
        }
        mo2657a((C0655h) uVar);
        if (this.f2100z != null) {
            this.f2100z.mo2297a(uVar);
        }
        return true;
    }

    /* renamed from: b */
    public void mo2661b(int i) {
        this.f2094t = true;
        this.f2096v = i;
    }

    /* renamed from: b */
    public void mo2647b(boolean z) {
        for (C0651a a : this.f2077b) {
            m3086a(a.mo2676a().getAdapter()).notifyDataSetChanged();
        }
    }

    /* renamed from: b */
    public boolean mo2648b() {
        return false;
    }

    /* renamed from: c */
    public void mo2662c() {
        int size = this.f2077b.size();
        if (size > 0) {
            C0651a[] aVarArr = (C0651a[]) this.f2077b.toArray(new C0651a[size]);
            for (int i = size - 1; i >= 0; i--) {
                C0651a aVar = aVarArr[i];
                if (aVar.f2108a.mo2665d()) {
                    aVar.f2108a.mo2662c();
                }
            }
        }
    }

    /* renamed from: c */
    public void mo2663c(int i) {
        this.f2095u = true;
        this.f2097w = i;
    }

    /* renamed from: c */
    public void mo2664c(boolean z) {
        this.f2099y = z;
    }

    /* renamed from: d */
    public boolean mo2665d() {
        return this.f2077b.size() > 0 && ((C0651a) this.f2077b.get(0)).f2108a.mo2665d();
    }

    /* renamed from: e */
    public ListView mo2666e() {
        if (this.f2077b.isEmpty()) {
            return null;
        }
        return ((C0651a) this.f2077b.get(this.f2077b.size() - 1)).mo2676a();
    }

    /* access modifiers changed from: protected */
    /* renamed from: f */
    public boolean mo2667f() {
        return false;
    }

    public void onDismiss() {
        C0651a aVar;
        int size = this.f2077b.size();
        int i = 0;
        while (true) {
            if (i >= size) {
                aVar = null;
                break;
            }
            aVar = (C0651a) this.f2077b.get(i);
            if (!aVar.f2108a.mo2665d()) {
                break;
            }
            i++;
        }
        if (aVar != null) {
            aVar.f2109b.mo2711a(false);
        }
    }

    public boolean onKey(View view, int i, KeyEvent keyEvent) {
        if (keyEvent.getAction() != 1 || i != 82) {
            return false;
        }
        mo2662c();
        return true;
    }
}
