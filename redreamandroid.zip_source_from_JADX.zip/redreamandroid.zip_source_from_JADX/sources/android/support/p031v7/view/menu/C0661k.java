package android.support.p031v7.view.menu;

import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff.Mode;
import android.graphics.drawable.Drawable;
import android.support.p018v4.p021b.p022a.C0390b;
import android.support.p018v4.p028h.C0477c;
import android.support.p031v7.view.C0629c;
import android.util.Log;
import android.view.ActionProvider;
import android.view.CollapsibleActionView;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.MenuItem;
import android.view.MenuItem.OnActionExpandListener;
import android.view.MenuItem.OnMenuItemClickListener;
import android.view.SubMenu;
import android.view.View;
import android.widget.FrameLayout;
import java.lang.reflect.Method;

/* renamed from: android.support.v7.view.menu.k */
public class C0661k extends C0644c<C0390b> implements MenuItem {

    /* renamed from: c */
    private Method f2191c;

    /* renamed from: android.support.v7.view.menu.k$a */
    class C0662a extends C0477c {

        /* renamed from: a */
        final ActionProvider f2192a;

        public C0662a(Context context, ActionProvider actionProvider) {
            super(context);
            this.f2192a = actionProvider;
        }

        /* renamed from: a */
        public View mo1914a() {
            return this.f2192a.onCreateActionView();
        }

        /* renamed from: a */
        public void mo1918a(SubMenu subMenu) {
            this.f2192a.onPrepareSubMenu(C0661k.this.mo2651a(subMenu));
        }

        /* renamed from: d */
        public boolean mo1922d() {
            return this.f2192a.onPerformDefaultAction();
        }

        /* renamed from: e */
        public boolean mo1923e() {
            return this.f2192a.hasSubMenu();
        }
    }

    /* renamed from: android.support.v7.view.menu.k$b */
    static class C0663b extends FrameLayout implements C0629c {

        /* renamed from: a */
        final CollapsibleActionView f2194a;

        C0663b(View view) {
            super(view.getContext());
            this.f2194a = (CollapsibleActionView) view;
            addView(view);
        }

        /* renamed from: a */
        public void mo2501a() {
            this.f2194a.onActionViewExpanded();
        }

        /* renamed from: b */
        public void mo2502b() {
            this.f2194a.onActionViewCollapsed();
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: c */
        public View mo2891c() {
            return (View) this.f2194a;
        }
    }

    /* renamed from: android.support.v7.view.menu.k$c */
    private class C0664c extends C0645d<OnActionExpandListener> implements OnActionExpandListener {
        C0664c(OnActionExpandListener onActionExpandListener) {
            super(onActionExpandListener);
        }

        public boolean onMenuItemActionCollapse(MenuItem menuItem) {
            return ((OnActionExpandListener) this.f2073b).onMenuItemActionCollapse(C0661k.this.mo2650a(menuItem));
        }

        public boolean onMenuItemActionExpand(MenuItem menuItem) {
            return ((OnActionExpandListener) this.f2073b).onMenuItemActionExpand(C0661k.this.mo2650a(menuItem));
        }
    }

    /* renamed from: android.support.v7.view.menu.k$d */
    private class C0665d extends C0645d<OnMenuItemClickListener> implements OnMenuItemClickListener {
        C0665d(OnMenuItemClickListener onMenuItemClickListener) {
            super(onMenuItemClickListener);
        }

        public boolean onMenuItemClick(MenuItem menuItem) {
            return ((OnMenuItemClickListener) this.f2073b).onMenuItemClick(C0661k.this.mo2650a(menuItem));
        }
    }

    C0661k(Context context, C0390b bVar) {
        super(context, bVar);
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public C0662a mo2835a(ActionProvider actionProvider) {
        return new C0662a(this.f2070a, actionProvider);
    }

    /* renamed from: a */
    public void mo2836a(boolean z) {
        try {
            if (this.f2191c == null) {
                this.f2191c = ((C0390b) this.f2073b).getClass().getDeclaredMethod("setExclusiveCheckable", new Class[]{Boolean.TYPE});
            }
            this.f2191c.invoke(this.f2073b, new Object[]{Boolean.valueOf(z)});
        } catch (Exception e) {
            Log.w("MenuItemWrapper", "Error while calling setExclusiveCheckable", e);
        }
    }

    public boolean collapseActionView() {
        return ((C0390b) this.f2073b).collapseActionView();
    }

    public boolean expandActionView() {
        return ((C0390b) this.f2073b).expandActionView();
    }

    public ActionProvider getActionProvider() {
        C0477c a = ((C0390b) this.f2073b).mo1549a();
        if (a instanceof C0662a) {
            return ((C0662a) a).f2192a;
        }
        return null;
    }

    public View getActionView() {
        View actionView = ((C0390b) this.f2073b).getActionView();
        return actionView instanceof C0663b ? ((C0663b) actionView).mo2891c() : actionView;
    }

    public int getAlphabeticModifiers() {
        return ((C0390b) this.f2073b).getAlphabeticModifiers();
    }

    public char getAlphabeticShortcut() {
        return ((C0390b) this.f2073b).getAlphabeticShortcut();
    }

    public CharSequence getContentDescription() {
        return ((C0390b) this.f2073b).getContentDescription();
    }

    public int getGroupId() {
        return ((C0390b) this.f2073b).getGroupId();
    }

    public Drawable getIcon() {
        return ((C0390b) this.f2073b).getIcon();
    }

    public ColorStateList getIconTintList() {
        return ((C0390b) this.f2073b).getIconTintList();
    }

    public Mode getIconTintMode() {
        return ((C0390b) this.f2073b).getIconTintMode();
    }

    public Intent getIntent() {
        return ((C0390b) this.f2073b).getIntent();
    }

    public int getItemId() {
        return ((C0390b) this.f2073b).getItemId();
    }

    public ContextMenuInfo getMenuInfo() {
        return ((C0390b) this.f2073b).getMenuInfo();
    }

    public int getNumericModifiers() {
        return ((C0390b) this.f2073b).getNumericModifiers();
    }

    public char getNumericShortcut() {
        return ((C0390b) this.f2073b).getNumericShortcut();
    }

    public int getOrder() {
        return ((C0390b) this.f2073b).getOrder();
    }

    public SubMenu getSubMenu() {
        return mo2651a(((C0390b) this.f2073b).getSubMenu());
    }

    public CharSequence getTitle() {
        return ((C0390b) this.f2073b).getTitle();
    }

    public CharSequence getTitleCondensed() {
        return ((C0390b) this.f2073b).getTitleCondensed();
    }

    public CharSequence getTooltipText() {
        return ((C0390b) this.f2073b).getTooltipText();
    }

    public boolean hasSubMenu() {
        return ((C0390b) this.f2073b).hasSubMenu();
    }

    public boolean isActionViewExpanded() {
        return ((C0390b) this.f2073b).isActionViewExpanded();
    }

    public boolean isCheckable() {
        return ((C0390b) this.f2073b).isCheckable();
    }

    public boolean isChecked() {
        return ((C0390b) this.f2073b).isChecked();
    }

    public boolean isEnabled() {
        return ((C0390b) this.f2073b).isEnabled();
    }

    public boolean isVisible() {
        return ((C0390b) this.f2073b).isVisible();
    }

    public MenuItem setActionProvider(ActionProvider actionProvider) {
        ((C0390b) this.f2073b).mo1547a((C0477c) actionProvider != null ? mo2835a(actionProvider) : null);
        return this;
    }

    public MenuItem setActionView(int i) {
        ((C0390b) this.f2073b).setActionView(i);
        View actionView = ((C0390b) this.f2073b).getActionView();
        if (actionView instanceof CollapsibleActionView) {
            ((C0390b) this.f2073b).setActionView((View) new C0663b(actionView));
        }
        return this;
    }

    public MenuItem setActionView(View view) {
        if (view instanceof CollapsibleActionView) {
            view = new C0663b(view);
        }
        ((C0390b) this.f2073b).setActionView(view);
        return this;
    }

    public MenuItem setAlphabeticShortcut(char c) {
        ((C0390b) this.f2073b).setAlphabeticShortcut(c);
        return this;
    }

    public MenuItem setAlphabeticShortcut(char c, int i) {
        ((C0390b) this.f2073b).setAlphabeticShortcut(c, i);
        return this;
    }

    public MenuItem setCheckable(boolean z) {
        ((C0390b) this.f2073b).setCheckable(z);
        return this;
    }

    public MenuItem setChecked(boolean z) {
        ((C0390b) this.f2073b).setChecked(z);
        return this;
    }

    public MenuItem setContentDescription(CharSequence charSequence) {
        ((C0390b) this.f2073b).mo1548a(charSequence);
        return this;
    }

    public MenuItem setEnabled(boolean z) {
        ((C0390b) this.f2073b).setEnabled(z);
        return this;
    }

    public MenuItem setIcon(int i) {
        ((C0390b) this.f2073b).setIcon(i);
        return this;
    }

    public MenuItem setIcon(Drawable drawable) {
        ((C0390b) this.f2073b).setIcon(drawable);
        return this;
    }

    public MenuItem setIconTintList(ColorStateList colorStateList) {
        ((C0390b) this.f2073b).setIconTintList(colorStateList);
        return this;
    }

    public MenuItem setIconTintMode(Mode mode) {
        ((C0390b) this.f2073b).setIconTintMode(mode);
        return this;
    }

    public MenuItem setIntent(Intent intent) {
        ((C0390b) this.f2073b).setIntent(intent);
        return this;
    }

    public MenuItem setNumericShortcut(char c) {
        ((C0390b) this.f2073b).setNumericShortcut(c);
        return this;
    }

    public MenuItem setNumericShortcut(char c, int i) {
        ((C0390b) this.f2073b).setNumericShortcut(c, i);
        return this;
    }

    public MenuItem setOnActionExpandListener(OnActionExpandListener onActionExpandListener) {
        ((C0390b) this.f2073b).setOnActionExpandListener(onActionExpandListener != null ? new C0664c(onActionExpandListener) : null);
        return this;
    }

    public MenuItem setOnMenuItemClickListener(OnMenuItemClickListener onMenuItemClickListener) {
        ((C0390b) this.f2073b).setOnMenuItemClickListener(onMenuItemClickListener != null ? new C0665d(onMenuItemClickListener) : null);
        return this;
    }

    public MenuItem setShortcut(char c, char c2) {
        ((C0390b) this.f2073b).setShortcut(c, c2);
        return this;
    }

    public MenuItem setShortcut(char c, char c2, int i, int i2) {
        ((C0390b) this.f2073b).setShortcut(c, c2, i, i2);
        return this;
    }

    public void setShowAsAction(int i) {
        ((C0390b) this.f2073b).setShowAsAction(i);
    }

    public MenuItem setShowAsActionFlags(int i) {
        ((C0390b) this.f2073b).setShowAsActionFlags(i);
        return this;
    }

    public MenuItem setTitle(int i) {
        ((C0390b) this.f2073b).setTitle(i);
        return this;
    }

    public MenuItem setTitle(CharSequence charSequence) {
        ((C0390b) this.f2073b).setTitle(charSequence);
        return this;
    }

    public MenuItem setTitleCondensed(CharSequence charSequence) {
        ((C0390b) this.f2073b).setTitleCondensed(charSequence);
        return this;
    }

    public MenuItem setTooltipText(CharSequence charSequence) {
        ((C0390b) this.f2073b).mo1550b(charSequence);
        return this;
    }

    public MenuItem setVisible(boolean z) {
        return ((C0390b) this.f2073b).setVisible(z);
    }
}
