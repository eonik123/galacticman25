package android.support.p031v7.view.menu;

/* renamed from: android.support.v7.view.menu.p */
public interface C0673p {

    /* renamed from: android.support.v7.view.menu.p$a */
    public interface C0674a {
        /* renamed from: a */
        void mo636a(C0659j jVar, int i);

        /* renamed from: a */
        boolean mo637a();

        C0659j getItemData();
    }

    /* renamed from: a */
    void mo651a(C0655h hVar);
}
