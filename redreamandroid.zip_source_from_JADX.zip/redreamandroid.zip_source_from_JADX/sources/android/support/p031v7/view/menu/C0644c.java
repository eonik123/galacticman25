package android.support.p031v7.view.menu;

import android.content.Context;
import android.support.p018v4.p021b.p022a.C0390b;
import android.support.p018v4.p021b.p022a.C0391c;
import android.support.p018v4.p027g.C0412a;
import android.view.MenuItem;
import android.view.SubMenu;
import java.util.Iterator;
import java.util.Map;

/* renamed from: android.support.v7.view.menu.c */
abstract class C0644c<T> extends C0645d<T> {

    /* renamed from: a */
    final Context f2070a;

    /* renamed from: c */
    private Map<C0390b, MenuItem> f2071c;

    /* renamed from: d */
    private Map<C0391c, SubMenu> f2072d;

    C0644c(Context context, T t) {
        super(t);
        this.f2070a = context;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public final MenuItem mo2650a(MenuItem menuItem) {
        if (!(menuItem instanceof C0390b)) {
            return menuItem;
        }
        C0390b bVar = (C0390b) menuItem;
        if (this.f2071c == null) {
            this.f2071c = new C0412a();
        }
        MenuItem menuItem2 = (MenuItem) this.f2071c.get(menuItem);
        if (menuItem2 != null) {
            return menuItem2;
        }
        MenuItem a = C0675q.m3130a(this.f2070a, bVar);
        this.f2071c.put(bVar, a);
        return a;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public final SubMenu mo2651a(SubMenu subMenu) {
        if (!(subMenu instanceof C0391c)) {
            return subMenu;
        }
        C0391c cVar = (C0391c) subMenu;
        if (this.f2072d == null) {
            this.f2072d = new C0412a();
        }
        SubMenu subMenu2 = (SubMenu) this.f2072d.get(cVar);
        if (subMenu2 == null) {
            subMenu2 = C0675q.m3131a(this.f2070a, cVar);
            this.f2072d.put(cVar, subMenu2);
        }
        return subMenu2;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public final void mo2652a() {
        if (this.f2071c != null) {
            this.f2071c.clear();
        }
        if (this.f2072d != null) {
            this.f2072d.clear();
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public final void mo2653a(int i) {
        if (this.f2071c != null) {
            Iterator it = this.f2071c.keySet().iterator();
            while (it.hasNext()) {
                if (i == ((MenuItem) it.next()).getGroupId()) {
                    it.remove();
                }
            }
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: b */
    public final void mo2654b(int i) {
        if (this.f2071c != null) {
            Iterator it = this.f2071c.keySet().iterator();
            while (true) {
                if (it.hasNext()) {
                    if (i == ((MenuItem) it.next()).getItemId()) {
                        it.remove();
                        break;
                    }
                } else {
                    break;
                }
            }
        }
    }
}
