package android.support.p031v7.view.menu;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.PorterDuff.Mode;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.support.p018v4.graphics.drawable.C0441a;
import android.support.p018v4.p021b.p022a.C0390b;
import android.support.p018v4.p028h.C0477c;
import android.support.p018v4.p028h.C0477c.C0479b;
import android.support.p031v7.p032a.C0540a.C0548h;
import android.support.p031v7.p033b.p034a.C0606a;
import android.support.p031v7.view.menu.C0673p.C0674a;
import android.util.Log;
import android.view.ActionProvider;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.MenuItem.OnActionExpandListener;
import android.view.MenuItem.OnMenuItemClickListener;
import android.view.SubMenu;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewDebug.CapturedViewProperty;
import android.widget.LinearLayout;

/* renamed from: android.support.v7.view.menu.j */
public final class C0659j implements C0390b {

    /* renamed from: A */
    private View f2159A;

    /* renamed from: B */
    private C0477c f2160B;

    /* renamed from: C */
    private OnActionExpandListener f2161C;

    /* renamed from: D */
    private boolean f2162D = false;

    /* renamed from: E */
    private ContextMenuInfo f2163E;

    /* renamed from: a */
    C0655h f2164a;

    /* renamed from: b */
    private final int f2165b;

    /* renamed from: c */
    private final int f2166c;

    /* renamed from: d */
    private final int f2167d;

    /* renamed from: e */
    private final int f2168e;

    /* renamed from: f */
    private CharSequence f2169f;

    /* renamed from: g */
    private CharSequence f2170g;

    /* renamed from: h */
    private Intent f2171h;

    /* renamed from: i */
    private char f2172i;

    /* renamed from: j */
    private int f2173j = 4096;

    /* renamed from: k */
    private char f2174k;

    /* renamed from: l */
    private int f2175l = 4096;

    /* renamed from: m */
    private Drawable f2176m;

    /* renamed from: n */
    private int f2177n = 0;

    /* renamed from: o */
    private C0681u f2178o;

    /* renamed from: p */
    private Runnable f2179p;

    /* renamed from: q */
    private OnMenuItemClickListener f2180q;

    /* renamed from: r */
    private CharSequence f2181r;

    /* renamed from: s */
    private CharSequence f2182s;

    /* renamed from: t */
    private ColorStateList f2183t = null;

    /* renamed from: u */
    private Mode f2184u = null;

    /* renamed from: v */
    private boolean f2185v = false;

    /* renamed from: w */
    private boolean f2186w = false;

    /* renamed from: x */
    private boolean f2187x = false;

    /* renamed from: y */
    private int f2188y = 16;

    /* renamed from: z */
    private int f2189z = 0;

    C0659j(C0655h hVar, int i, int i2, int i3, int i4, CharSequence charSequence, int i5) {
        this.f2164a = hVar;
        this.f2165b = i2;
        this.f2166c = i;
        this.f2167d = i3;
        this.f2168e = i4;
        this.f2169f = charSequence;
        this.f2189z = i5;
    }

    /* renamed from: a */
    private Drawable m3040a(Drawable drawable) {
        if (drawable != null && this.f2187x && (this.f2185v || this.f2186w)) {
            drawable = C0441a.m1938g(drawable).mutate();
            if (this.f2185v) {
                C0441a.m1927a(drawable, this.f2183t);
            }
            if (this.f2186w) {
                C0441a.m1930a(drawable, this.f2184u);
            }
            this.f2187x = false;
        }
        return drawable;
    }

    /* renamed from: a */
    private static void m3041a(StringBuilder sb, int i, int i2, String str) {
        if ((i & i2) == i2) {
            sb.append(str);
        }
    }

    /* renamed from: a */
    public C0390b setActionView(int i) {
        Context f = this.f2164a.mo2742f();
        setActionView(LayoutInflater.from(f).inflate(i, new LinearLayout(f), false));
        return this;
    }

    /* renamed from: a */
    public C0390b mo1547a(C0477c cVar) {
        if (this.f2160B != null) {
            this.f2160B.mo1924f();
        }
        this.f2159A = null;
        this.f2160B = cVar;
        this.f2164a.mo2728b(true);
        if (this.f2160B != null) {
            this.f2160B.mo1917a((C0479b) new C0479b() {
                /* renamed from: a */
                public void mo1926a(boolean z) {
                    C0659j.this.f2164a.mo2706a(C0659j.this);
                }
            });
        }
        return this;
    }

    /* renamed from: a */
    public C0390b setActionView(View view) {
        this.f2159A = view;
        this.f2160B = null;
        if (view != null && view.getId() == -1 && this.f2165b > 0) {
            view.setId(this.f2165b);
        }
        this.f2164a.mo2726b(this);
        return this;
    }

    /* renamed from: a */
    public C0390b setContentDescription(CharSequence charSequence) {
        this.f2181r = charSequence;
        this.f2164a.mo2728b(false);
        return this;
    }

    /* renamed from: a */
    public C0477c mo1549a() {
        return this.f2160B;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public CharSequence mo2777a(C0674a aVar) {
        return (aVar == null || !aVar.mo637a()) ? getTitle() : getTitleCondensed();
    }

    /* renamed from: a */
    public void mo2778a(C0681u uVar) {
        this.f2178o = uVar;
        uVar.setHeaderTitle(getTitle());
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo2779a(ContextMenuInfo contextMenuInfo) {
        this.f2163E = contextMenuInfo;
    }

    /* renamed from: a */
    public void mo2780a(boolean z) {
        this.f2188y = (z ? 4 : 0) | (this.f2188y & -5);
    }

    /* renamed from: b */
    public C0390b setShowAsActionFlags(int i) {
        setShowAsAction(i);
        return this;
    }

    /* renamed from: b */
    public C0390b setTooltipText(CharSequence charSequence) {
        this.f2182s = charSequence;
        this.f2164a.mo2728b(false);
        return this;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: b */
    public void mo2782b(boolean z) {
        int i = this.f2188y;
        this.f2188y = (z ? 2 : 0) | (this.f2188y & -3);
        if (i != this.f2188y) {
            this.f2164a.mo2728b(false);
        }
    }

    /* renamed from: b */
    public boolean mo2783b() {
        if ((this.f2180q != null && this.f2180q.onMenuItemClick(this)) || this.f2164a.mo2712a(this.f2164a, (MenuItem) this)) {
            return true;
        }
        if (this.f2179p != null) {
            this.f2179p.run();
            return true;
        }
        if (this.f2171h != null) {
            try {
                this.f2164a.mo2742f().startActivity(this.f2171h);
                return true;
            } catch (ActivityNotFoundException e) {
                Log.e("MenuItemImpl", "Can't find activity to handle intent; ignoring", e);
            }
        }
        return this.f2160B != null && this.f2160B.mo1922d();
    }

    /* renamed from: c */
    public int mo2784c() {
        return this.f2168e;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: c */
    public boolean mo2785c(boolean z) {
        int i = this.f2188y;
        this.f2188y = (z ? 0 : 8) | (this.f2188y & -9);
        return i != this.f2188y;
    }

    public boolean collapseActionView() {
        if ((this.f2189z & 8) == 0) {
            return false;
        }
        if (this.f2159A == null) {
            return true;
        }
        if (this.f2161C == null || this.f2161C.onMenuItemActionCollapse(this)) {
            return this.f2164a.mo2739d(this);
        }
        return false;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: d */
    public char mo2786d() {
        return this.f2164a.mo2732c() ? this.f2174k : this.f2172i;
    }

    /* renamed from: d */
    public void mo2787d(boolean z) {
        this.f2188y = z ? this.f2188y | 32 : this.f2188y & -33;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: e */
    public String mo2788e() {
        int i;
        char d = mo2786d();
        if (d == 0) {
            return "";
        }
        Resources resources = this.f2164a.mo2742f().getResources();
        StringBuilder sb = new StringBuilder();
        if (ViewConfiguration.get(this.f2164a.mo2742f()).hasPermanentMenuKey()) {
            sb.append(resources.getString(C0548h.abc_prepend_shortcut_label));
        }
        int i2 = this.f2164a.mo2732c() ? this.f2175l : this.f2173j;
        m3041a(sb, i2, 65536, resources.getString(C0548h.abc_menu_meta_shortcut_label));
        m3041a(sb, i2, 4096, resources.getString(C0548h.abc_menu_ctrl_shortcut_label));
        m3041a(sb, i2, 2, resources.getString(C0548h.abc_menu_alt_shortcut_label));
        m3041a(sb, i2, 1, resources.getString(C0548h.abc_menu_shift_shortcut_label));
        m3041a(sb, i2, 4, resources.getString(C0548h.abc_menu_sym_shortcut_label));
        m3041a(sb, i2, 8, resources.getString(C0548h.abc_menu_function_shortcut_label));
        if (d == 8) {
            i = C0548h.abc_menu_delete_shortcut_label;
        } else if (d == 10) {
            i = C0548h.abc_menu_enter_shortcut_label;
        } else if (d != ' ') {
            sb.append(d);
            return sb.toString();
        } else {
            i = C0548h.abc_menu_space_shortcut_label;
        }
        sb.append(resources.getString(i));
        return sb.toString();
    }

    /* renamed from: e */
    public void mo2789e(boolean z) {
        this.f2162D = z;
        this.f2164a.mo2728b(false);
    }

    public boolean expandActionView() {
        if (!mo2815n()) {
            return false;
        }
        if (this.f2161C == null || this.f2161C.onMenuItemActionExpand(this)) {
            return this.f2164a.mo2733c(this);
        }
        return false;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: f */
    public boolean mo2790f() {
        return this.f2164a.mo2738d() && mo2786d() != 0;
    }

    /* renamed from: g */
    public boolean mo2791g() {
        return (this.f2188y & 4) != 0;
    }

    public ActionProvider getActionProvider() {
        throw new UnsupportedOperationException("This is not supported, use MenuItemCompat.getActionProvider()");
    }

    public View getActionView() {
        if (this.f2159A != null) {
            return this.f2159A;
        }
        if (this.f2160B == null) {
            return null;
        }
        this.f2159A = this.f2160B.mo1915a((MenuItem) this);
        return this.f2159A;
    }

    public int getAlphabeticModifiers() {
        return this.f2175l;
    }

    public char getAlphabeticShortcut() {
        return this.f2174k;
    }

    public CharSequence getContentDescription() {
        return this.f2181r;
    }

    public int getGroupId() {
        return this.f2166c;
    }

    public Drawable getIcon() {
        Drawable b;
        if (this.f2176m != null) {
            b = this.f2176m;
        } else if (this.f2177n == 0) {
            return null;
        } else {
            b = C0606a.m2714b(this.f2164a.mo2742f(), this.f2177n);
            this.f2177n = 0;
            this.f2176m = b;
        }
        return m3040a(b);
    }

    public ColorStateList getIconTintList() {
        return this.f2183t;
    }

    public Mode getIconTintMode() {
        return this.f2184u;
    }

    public Intent getIntent() {
        return this.f2171h;
    }

    @CapturedViewProperty
    public int getItemId() {
        return this.f2165b;
    }

    public ContextMenuInfo getMenuInfo() {
        return this.f2163E;
    }

    public int getNumericModifiers() {
        return this.f2173j;
    }

    public char getNumericShortcut() {
        return this.f2172i;
    }

    public int getOrder() {
        return this.f2167d;
    }

    public SubMenu getSubMenu() {
        return this.f2178o;
    }

    @CapturedViewProperty
    public CharSequence getTitle() {
        return this.f2169f;
    }

    public CharSequence getTitleCondensed() {
        CharSequence charSequence = this.f2170g != null ? this.f2170g : this.f2169f;
        return (VERSION.SDK_INT >= 18 || charSequence == null || (charSequence instanceof String)) ? charSequence : charSequence.toString();
    }

    public CharSequence getTooltipText() {
        return this.f2182s;
    }

    /* renamed from: h */
    public void mo2804h() {
        this.f2164a.mo2726b(this);
    }

    public boolean hasSubMenu() {
        return this.f2178o != null;
    }

    /* renamed from: i */
    public boolean mo2806i() {
        return this.f2164a.mo2760r();
    }

    public boolean isActionViewExpanded() {
        return this.f2162D;
    }

    public boolean isCheckable() {
        return (this.f2188y & 1) == 1;
    }

    public boolean isChecked() {
        return (this.f2188y & 2) == 2;
    }

    public boolean isEnabled() {
        return (this.f2188y & 16) != 0;
    }

    public boolean isVisible() {
        boolean z = false;
        if (this.f2160B == null || !this.f2160B.mo1920b()) {
            if ((this.f2188y & 8) == 0) {
                z = true;
            }
            return z;
        }
        if ((this.f2188y & 8) == 0 && this.f2160B.mo1921c()) {
            z = true;
        }
        return z;
    }

    /* renamed from: j */
    public boolean mo2811j() {
        return (this.f2188y & 32) == 32;
    }

    /* renamed from: k */
    public boolean mo2812k() {
        return (this.f2189z & 1) == 1;
    }

    /* renamed from: l */
    public boolean mo2813l() {
        return (this.f2189z & 2) == 2;
    }

    /* renamed from: m */
    public boolean mo2814m() {
        return (this.f2189z & 4) == 4;
    }

    /* renamed from: n */
    public boolean mo2815n() {
        if ((this.f2189z & 8) == 0) {
            return false;
        }
        if (this.f2159A == null && this.f2160B != null) {
            this.f2159A = this.f2160B.mo1915a((MenuItem) this);
        }
        return this.f2159A != null;
    }

    public MenuItem setActionProvider(ActionProvider actionProvider) {
        throw new UnsupportedOperationException("This is not supported, use MenuItemCompat.setActionProvider()");
    }

    public MenuItem setAlphabeticShortcut(char c) {
        if (this.f2174k == c) {
            return this;
        }
        this.f2174k = Character.toLowerCase(c);
        this.f2164a.mo2728b(false);
        return this;
    }

    public MenuItem setAlphabeticShortcut(char c, int i) {
        if (this.f2174k == c && this.f2175l == i) {
            return this;
        }
        this.f2174k = Character.toLowerCase(c);
        this.f2175l = KeyEvent.normalizeMetaState(i);
        this.f2164a.mo2728b(false);
        return this;
    }

    public MenuItem setCheckable(boolean z) {
        int i = this.f2188y;
        this.f2188y = z | (this.f2188y & true) ? 1 : 0;
        if (i != this.f2188y) {
            this.f2164a.mo2728b(false);
        }
        return this;
    }

    public MenuItem setChecked(boolean z) {
        if ((this.f2188y & 4) != 0) {
            this.f2164a.mo2709a((MenuItem) this);
            return this;
        }
        mo2782b(z);
        return this;
    }

    public MenuItem setEnabled(boolean z) {
        this.f2188y = z ? this.f2188y | 16 : this.f2188y & -17;
        this.f2164a.mo2728b(false);
        return this;
    }

    public MenuItem setIcon(int i) {
        this.f2176m = null;
        this.f2177n = i;
        this.f2187x = true;
        this.f2164a.mo2728b(false);
        return this;
    }

    public MenuItem setIcon(Drawable drawable) {
        this.f2177n = 0;
        this.f2176m = drawable;
        this.f2187x = true;
        this.f2164a.mo2728b(false);
        return this;
    }

    public MenuItem setIconTintList(ColorStateList colorStateList) {
        this.f2183t = colorStateList;
        this.f2185v = true;
        this.f2187x = true;
        this.f2164a.mo2728b(false);
        return this;
    }

    public MenuItem setIconTintMode(Mode mode) {
        this.f2184u = mode;
        this.f2186w = true;
        this.f2187x = true;
        this.f2164a.mo2728b(false);
        return this;
    }

    public MenuItem setIntent(Intent intent) {
        this.f2171h = intent;
        return this;
    }

    public MenuItem setNumericShortcut(char c) {
        if (this.f2172i == c) {
            return this;
        }
        this.f2172i = c;
        this.f2164a.mo2728b(false);
        return this;
    }

    public MenuItem setNumericShortcut(char c, int i) {
        if (this.f2172i == c && this.f2173j == i) {
            return this;
        }
        this.f2172i = c;
        this.f2173j = KeyEvent.normalizeMetaState(i);
        this.f2164a.mo2728b(false);
        return this;
    }

    public MenuItem setOnActionExpandListener(OnActionExpandListener onActionExpandListener) {
        this.f2161C = onActionExpandListener;
        return this;
    }

    public MenuItem setOnMenuItemClickListener(OnMenuItemClickListener onMenuItemClickListener) {
        this.f2180q = onMenuItemClickListener;
        return this;
    }

    public MenuItem setShortcut(char c, char c2) {
        this.f2172i = c;
        this.f2174k = Character.toLowerCase(c2);
        this.f2164a.mo2728b(false);
        return this;
    }

    public MenuItem setShortcut(char c, char c2, int i, int i2) {
        this.f2172i = c;
        this.f2173j = KeyEvent.normalizeMetaState(i);
        this.f2174k = Character.toLowerCase(c2);
        this.f2175l = KeyEvent.normalizeMetaState(i2);
        this.f2164a.mo2728b(false);
        return this;
    }

    public void setShowAsAction(int i) {
        switch (i & 3) {
            case 0:
            case 1:
            case 2:
                this.f2189z = i;
                this.f2164a.mo2726b(this);
                return;
            default:
                throw new IllegalArgumentException("SHOW_AS_ACTION_ALWAYS, SHOW_AS_ACTION_IF_ROOM, and SHOW_AS_ACTION_NEVER are mutually exclusive.");
        }
    }

    public MenuItem setTitle(int i) {
        return setTitle((CharSequence) this.f2164a.mo2742f().getString(i));
    }

    public MenuItem setTitle(CharSequence charSequence) {
        this.f2169f = charSequence;
        this.f2164a.mo2728b(false);
        if (this.f2178o != null) {
            this.f2178o.setHeaderTitle(charSequence);
        }
        return this;
    }

    public MenuItem setTitleCondensed(CharSequence charSequence) {
        this.f2170g = charSequence;
        if (charSequence == null) {
            CharSequence charSequence2 = this.f2169f;
        }
        this.f2164a.mo2728b(false);
        return this;
    }

    public MenuItem setVisible(boolean z) {
        if (mo2785c(z)) {
            this.f2164a.mo2706a(this);
        }
        return this;
    }

    public String toString() {
        if (this.f2169f != null) {
            return this.f2169f.toString();
        }
        return null;
    }
}
