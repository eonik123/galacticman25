package android.support.p031v7.view.menu;

import android.content.Context;
import android.graphics.Rect;
import android.support.p018v4.p028h.C0480d;
import android.support.p018v4.p028h.C0495r;
import android.support.p031v7.view.menu.C0671o.C0672a;
import android.view.View;
import android.widget.PopupWindow.OnDismissListener;

/* renamed from: android.support.v7.view.menu.n */
public class C0669n {

    /* renamed from: a */
    private final Context f2200a;

    /* renamed from: b */
    private final C0655h f2201b;

    /* renamed from: c */
    private final boolean f2202c;

    /* renamed from: d */
    private final int f2203d;

    /* renamed from: e */
    private final int f2204e;

    /* renamed from: f */
    private View f2205f;

    /* renamed from: g */
    private int f2206g;

    /* renamed from: h */
    private boolean f2207h;

    /* renamed from: i */
    private C0672a f2208i;

    /* renamed from: j */
    private C0668m f2209j;

    /* renamed from: k */
    private OnDismissListener f2210k;

    /* renamed from: l */
    private final OnDismissListener f2211l;

    public C0669n(Context context, C0655h hVar, View view, boolean z, int i) {
        this(context, hVar, view, z, i, 0);
    }

    public C0669n(Context context, C0655h hVar, View view, boolean z, int i, int i2) {
        this.f2206g = 8388611;
        this.f2211l = new OnDismissListener() {
            public void onDismiss() {
                C0669n.this.mo2909e();
            }
        };
        this.f2200a = context;
        this.f2201b = hVar;
        this.f2205f = view;
        this.f2202c = z;
        this.f2203d = i;
        this.f2204e = i2;
    }

    /* renamed from: a */
    private void m3102a(int i, int i2, boolean z, boolean z2) {
        C0668m b = mo2906b();
        b.mo2664c(z2);
        if (z) {
            if ((C0480d.m2070a(this.f2206g, C0495r.m2149f(this.f2205f)) & 7) == 5) {
                i -= this.f2205f.getWidth();
            }
            b.mo2661b(i);
            b.mo2663c(i2);
            int i3 = (int) ((48.0f * this.f2200a.getResources().getDisplayMetrics().density) / 2.0f);
            b.mo2896a(new Rect(i - i3, i2 - i3, i + i3, i2 + i3));
        }
        b.mo2655a();
    }

    /* JADX WARNING: type inference failed for: r0v7, types: [android.support.v7.view.menu.m] */
    /* JADX WARNING: type inference failed for: r7v0, types: [android.support.v7.view.menu.t] */
    /* JADX WARNING: type inference failed for: r1v12, types: [android.support.v7.view.menu.e] */
    /* JADX WARNING: type inference failed for: r7v1, types: [android.support.v7.view.menu.t] */
    /* JADX WARNING: type inference failed for: r1v13, types: [android.support.v7.view.menu.e] */
    /* JADX WARNING: Multi-variable type inference failed. Error: jadx.core.utils.exceptions.JadxRuntimeException: No candidate types for var: r7v1, types: [android.support.v7.view.menu.t]
      assigns: [android.support.v7.view.menu.t, android.support.v7.view.menu.e]
      uses: [android.support.v7.view.menu.t, android.support.v7.view.menu.m, android.support.v7.view.menu.e]
      mth insns count: 49
    	at jadx.core.dex.visitors.typeinference.TypeSearch.fillTypeCandidates(TypeSearch.java:237)
    	at java.base/java.util.ArrayList.forEach(ArrayList.java:1540)
    	at jadx.core.dex.visitors.typeinference.TypeSearch.run(TypeSearch.java:53)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.runMultiVariableSearch(TypeInferenceVisitor.java:99)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.visit(TypeInferenceVisitor.java:92)
    	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:27)
    	at jadx.core.dex.visitors.DepthTraversal.lambda$visit$1(DepthTraversal.java:14)
    	at java.base/java.util.ArrayList.forEach(ArrayList.java:1540)
    	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:14)
    	at jadx.core.ProcessClass.process(ProcessClass.java:30)
    	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:311)
    	at jadx.api.JavaClass.decompile(JavaClass.java:62)
    	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:217)
     */
    /* JADX WARNING: Unknown variable types count: 3 */
    /* renamed from: g */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private android.support.p031v7.view.menu.C0668m m3103g() {
        /*
            r14 = this;
            android.content.Context r0 = r14.f2200a
            java.lang.String r1 = "window"
            java.lang.Object r0 = r0.getSystemService(r1)
            android.view.WindowManager r0 = (android.view.WindowManager) r0
            android.view.Display r0 = r0.getDefaultDisplay()
            android.graphics.Point r1 = new android.graphics.Point
            r1.<init>()
            int r2 = android.os.Build.VERSION.SDK_INT
            r3 = 17
            if (r2 < r3) goto L_0x001d
            r0.getRealSize(r1)
            goto L_0x0020
        L_0x001d:
            r0.getSize(r1)
        L_0x0020:
            int r0 = r1.x
            int r1 = r1.y
            int r0 = java.lang.Math.min(r0, r1)
            android.content.Context r1 = r14.f2200a
            android.content.res.Resources r1 = r1.getResources()
            int r2 = android.support.p031v7.p032a.C0540a.C0544d.abc_cascading_menus_min_smallest_width
            int r1 = r1.getDimensionPixelSize(r2)
            if (r0 < r1) goto L_0x0038
            r0 = 1
            goto L_0x0039
        L_0x0038:
            r0 = 0
        L_0x0039:
            if (r0 == 0) goto L_0x004c
            android.support.v7.view.menu.e r0 = new android.support.v7.view.menu.e
            android.content.Context r2 = r14.f2200a
            android.view.View r3 = r14.f2205f
            int r4 = r14.f2203d
            int r5 = r14.f2204e
            boolean r6 = r14.f2202c
            r1 = r0
            r1.<init>(r2, r3, r4, r5, r6)
            goto L_0x005e
        L_0x004c:
            android.support.v7.view.menu.t r0 = new android.support.v7.view.menu.t
            android.content.Context r8 = r14.f2200a
            android.support.v7.view.menu.h r9 = r14.f2201b
            android.view.View r10 = r14.f2205f
            int r11 = r14.f2203d
            int r12 = r14.f2204e
            boolean r13 = r14.f2202c
            r7 = r0
            r7.<init>(r8, r9, r10, r11, r12, r13)
        L_0x005e:
            android.support.v7.view.menu.h r1 = r14.f2201b
            r0.mo2657a(r1)
            android.widget.PopupWindow$OnDismissListener r1 = r14.f2211l
            r0.mo2659a(r1)
            android.view.View r1 = r14.f2205f
            r0.mo2658a(r1)
            android.support.v7.view.menu.o$a r1 = r14.f2208i
            r0.mo2640a(r1)
            boolean r1 = r14.f2207h
            r0.mo2660a(r1)
            int r1 = r14.f2206g
            r0.mo2656a(r1)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.p031v7.view.menu.C0669n.m3103g():android.support.v7.view.menu.m");
    }

    /* renamed from: a */
    public void mo2899a() {
        if (!mo2907c()) {
            throw new IllegalStateException("MenuPopupHelper cannot be used without an anchor");
        }
    }

    /* renamed from: a */
    public void mo2900a(int i) {
        this.f2206g = i;
    }

    /* renamed from: a */
    public void mo2901a(C0672a aVar) {
        this.f2208i = aVar;
        if (this.f2209j != null) {
            this.f2209j.mo2640a(aVar);
        }
    }

    /* renamed from: a */
    public void mo2902a(View view) {
        this.f2205f = view;
    }

    /* renamed from: a */
    public void mo2903a(OnDismissListener onDismissListener) {
        this.f2210k = onDismissListener;
    }

    /* renamed from: a */
    public void mo2904a(boolean z) {
        this.f2207h = z;
        if (this.f2209j != null) {
            this.f2209j.mo2660a(z);
        }
    }

    /* renamed from: a */
    public boolean mo2905a(int i, int i2) {
        if (mo2910f()) {
            return true;
        }
        if (this.f2205f == null) {
            return false;
        }
        m3102a(i, i2, true, true);
        return true;
    }

    /* renamed from: b */
    public C0668m mo2906b() {
        if (this.f2209j == null) {
            this.f2209j = m3103g();
        }
        return this.f2209j;
    }

    /* renamed from: c */
    public boolean mo2907c() {
        if (mo2910f()) {
            return true;
        }
        if (this.f2205f == null) {
            return false;
        }
        m3102a(0, 0, false, false);
        return true;
    }

    /* renamed from: d */
    public void mo2908d() {
        if (mo2910f()) {
            this.f2209j.mo2662c();
        }
    }

    /* access modifiers changed from: protected */
    /* renamed from: e */
    public void mo2909e() {
        this.f2209j = null;
        if (this.f2210k != null) {
            this.f2210k.onDismiss();
        }
    }

    /* renamed from: f */
    public boolean mo2910f() {
        return this.f2209j != null && this.f2209j.mo2665d();
    }
}
