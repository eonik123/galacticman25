package android.support.p031v7.view.menu;

import android.content.Context;

/* renamed from: android.support.v7.view.menu.o */
public interface C0671o {

    /* renamed from: android.support.v7.view.menu.o$a */
    public interface C0672a {
        /* renamed from: a */
        void mo2296a(C0655h hVar, boolean z);

        /* renamed from: a */
        boolean mo2297a(C0655h hVar);
    }

    /* renamed from: a */
    void mo2637a(Context context, C0655h hVar);

    /* renamed from: a */
    void mo2638a(C0655h hVar, boolean z);

    /* renamed from: a */
    void mo2640a(C0672a aVar);

    /* renamed from: a */
    boolean mo2643a(C0655h hVar, C0659j jVar);

    /* renamed from: a */
    boolean mo2644a(C0681u uVar);

    /* renamed from: b */
    void mo2647b(boolean z);

    /* renamed from: b */
    boolean mo2648b();

    /* renamed from: b */
    boolean mo2649b(C0655h hVar, C0659j jVar);
}
