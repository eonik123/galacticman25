package android.support.p031v7.view.menu;

import android.content.Context;
import android.os.IBinder;
import android.support.p031v7.p032a.C0540a.C0547g;
import android.support.p031v7.view.menu.C0671o.C0672a;
import android.support.p031v7.view.menu.C0673p.C0674a;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.ListAdapter;
import java.util.ArrayList;

/* renamed from: android.support.v7.view.menu.f */
public class C0652f implements C0671o, OnItemClickListener {

    /* renamed from: a */
    Context f2111a;

    /* renamed from: b */
    LayoutInflater f2112b;

    /* renamed from: c */
    C0655h f2113c;

    /* renamed from: d */
    ExpandedMenuView f2114d;

    /* renamed from: e */
    int f2115e;

    /* renamed from: f */
    int f2116f;

    /* renamed from: g */
    int f2117g;

    /* renamed from: h */
    C0653a f2118h;

    /* renamed from: i */
    private C0672a f2119i;

    /* renamed from: android.support.v7.view.menu.f$a */
    private class C0653a extends BaseAdapter {

        /* renamed from: b */
        private int f2121b = -1;

        public C0653a() {
            mo2681a();
        }

        /* renamed from: a */
        public C0659j getItem(int i) {
            ArrayList m = C0652f.this.f2113c.mo2753m();
            int i2 = i + C0652f.this.f2115e;
            if (this.f2121b >= 0 && i2 >= this.f2121b) {
                i2++;
            }
            return (C0659j) m.get(i2);
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public void mo2681a() {
            C0659j s = C0652f.this.f2113c.mo2763s();
            if (s != null) {
                ArrayList m = C0652f.this.f2113c.mo2753m();
                int size = m.size();
                for (int i = 0; i < size; i++) {
                    if (((C0659j) m.get(i)) == s) {
                        this.f2121b = i;
                        return;
                    }
                }
            }
            this.f2121b = -1;
        }

        public int getCount() {
            int size = C0652f.this.f2113c.mo2753m().size() - C0652f.this.f2115e;
            return this.f2121b < 0 ? size : size - 1;
        }

        public long getItemId(int i) {
            return (long) i;
        }

        public View getView(int i, View view, ViewGroup viewGroup) {
            if (view == null) {
                view = C0652f.this.f2112b.inflate(C0652f.this.f2117g, viewGroup, false);
            }
            ((C0674a) view).mo636a(getItem(i), 0);
            return view;
        }

        public void notifyDataSetChanged() {
            mo2681a();
            super.notifyDataSetChanged();
        }
    }

    public C0652f(int i, int i2) {
        this.f2117g = i;
        this.f2116f = i2;
    }

    public C0652f(Context context, int i) {
        this(i, 0);
        this.f2111a = context;
        this.f2112b = LayoutInflater.from(this.f2111a);
    }

    /* renamed from: a */
    public C0673p mo2677a(ViewGroup viewGroup) {
        if (this.f2114d == null) {
            this.f2114d = (ExpandedMenuView) this.f2112b.inflate(C0547g.abc_expanded_menu_layout, viewGroup, false);
            if (this.f2118h == null) {
                this.f2118h = new C0653a();
            }
            this.f2114d.setAdapter(this.f2118h);
            this.f2114d.setOnItemClickListener(this);
        }
        return this.f2114d;
    }

    /* renamed from: a */
    public ListAdapter mo2678a() {
        if (this.f2118h == null) {
            this.f2118h = new C0653a();
        }
        return this.f2118h;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:7:0x001e, code lost:
        if (r2.f2112b == null) goto L_0x000d;
     */
    /* JADX WARNING: Removed duplicated region for block: B:10:0x0027  */
    /* JADX WARNING: Removed duplicated region for block: B:12:? A[RETURN, SYNTHETIC] */
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void mo2637a(android.content.Context r3, android.support.p031v7.view.menu.C0655h r4) {
        /*
            r2 = this;
            int r0 = r2.f2116f
            if (r0 == 0) goto L_0x0016
            android.view.ContextThemeWrapper r0 = new android.view.ContextThemeWrapper
            int r1 = r2.f2116f
            r0.<init>(r3, r1)
            r2.f2111a = r0
        L_0x000d:
            android.content.Context r3 = r2.f2111a
            android.view.LayoutInflater r3 = android.view.LayoutInflater.from(r3)
            r2.f2112b = r3
            goto L_0x0021
        L_0x0016:
            android.content.Context r0 = r2.f2111a
            if (r0 == 0) goto L_0x0021
            r2.f2111a = r3
            android.view.LayoutInflater r3 = r2.f2112b
            if (r3 != 0) goto L_0x0021
            goto L_0x000d
        L_0x0021:
            r2.f2113c = r4
            android.support.v7.view.menu.f$a r3 = r2.f2118h
            if (r3 == 0) goto L_0x002c
            android.support.v7.view.menu.f$a r3 = r2.f2118h
            r3.notifyDataSetChanged()
        L_0x002c:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.p031v7.view.menu.C0652f.mo2637a(android.content.Context, android.support.v7.view.menu.h):void");
    }

    /* renamed from: a */
    public void mo2638a(C0655h hVar, boolean z) {
        if (this.f2119i != null) {
            this.f2119i.mo2296a(hVar, z);
        }
    }

    /* renamed from: a */
    public void mo2640a(C0672a aVar) {
        this.f2119i = aVar;
    }

    /* renamed from: a */
    public boolean mo2643a(C0655h hVar, C0659j jVar) {
        return false;
    }

    /* renamed from: a */
    public boolean mo2644a(C0681u uVar) {
        if (!uVar.hasVisibleItems()) {
            return false;
        }
        new C0658i(uVar).mo2771a((IBinder) null);
        if (this.f2119i != null) {
            this.f2119i.mo2297a(uVar);
        }
        return true;
    }

    /* renamed from: b */
    public void mo2647b(boolean z) {
        if (this.f2118h != null) {
            this.f2118h.notifyDataSetChanged();
        }
    }

    /* renamed from: b */
    public boolean mo2648b() {
        return false;
    }

    /* renamed from: b */
    public boolean mo2649b(C0655h hVar, C0659j jVar) {
        return false;
    }

    public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
        this.f2113c.mo2714a((MenuItem) this.f2118h.getItem(i), (C0671o) this, 0);
    }
}
