package android.support.p031v7.view.menu;

/* renamed from: android.support.v7.view.menu.d */
class C0645d<T> {

    /* renamed from: b */
    final T f2073b;

    C0645d(T t) {
        if (t == null) {
            throw new IllegalArgumentException("Wrapped Object can not be null.");
        }
        this.f2073b = t;
    }
}
