package android.support.p031v7.view.menu;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.support.p018v4.p021b.p022a.C0389a;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.SubMenu;

/* renamed from: android.support.v7.view.menu.r */
class C0676r extends C0644c<C0389a> implements Menu {
    C0676r(Context context, C0389a aVar) {
        super(context, aVar);
    }

    public MenuItem add(int i) {
        return mo2650a(((C0389a) this.f2073b).add(i));
    }

    public MenuItem add(int i, int i2, int i3, int i4) {
        return mo2650a(((C0389a) this.f2073b).add(i, i2, i3, i4));
    }

    public MenuItem add(int i, int i2, int i3, CharSequence charSequence) {
        return mo2650a(((C0389a) this.f2073b).add(i, i2, i3, charSequence));
    }

    public MenuItem add(CharSequence charSequence) {
        return mo2650a(((C0389a) this.f2073b).add(charSequence));
    }

    public int addIntentOptions(int i, int i2, int i3, ComponentName componentName, Intent[] intentArr, Intent intent, int i4, MenuItem[] menuItemArr) {
        MenuItem[] menuItemArr2 = menuItemArr;
        MenuItem[] menuItemArr3 = menuItemArr2 != null ? new MenuItem[menuItemArr2.length] : null;
        int addIntentOptions = ((C0389a) this.f2073b).addIntentOptions(i, i2, i3, componentName, intentArr, intent, i4, menuItemArr3);
        if (menuItemArr3 != null) {
            int length = menuItemArr3.length;
            for (int i5 = 0; i5 < length; i5++) {
                menuItemArr2[i5] = mo2650a(menuItemArr3[i5]);
            }
        }
        return addIntentOptions;
    }

    public SubMenu addSubMenu(int i) {
        return mo2651a(((C0389a) this.f2073b).addSubMenu(i));
    }

    public SubMenu addSubMenu(int i, int i2, int i3, int i4) {
        return mo2651a(((C0389a) this.f2073b).addSubMenu(i, i2, i3, i4));
    }

    public SubMenu addSubMenu(int i, int i2, int i3, CharSequence charSequence) {
        return mo2651a(((C0389a) this.f2073b).addSubMenu(i, i2, i3, charSequence));
    }

    public SubMenu addSubMenu(CharSequence charSequence) {
        return mo2651a(((C0389a) this.f2073b).addSubMenu(charSequence));
    }

    public void clear() {
        mo2652a();
        ((C0389a) this.f2073b).clear();
    }

    public void close() {
        ((C0389a) this.f2073b).close();
    }

    public MenuItem findItem(int i) {
        return mo2650a(((C0389a) this.f2073b).findItem(i));
    }

    public MenuItem getItem(int i) {
        return mo2650a(((C0389a) this.f2073b).getItem(i));
    }

    public boolean hasVisibleItems() {
        return ((C0389a) this.f2073b).hasVisibleItems();
    }

    public boolean isShortcutKey(int i, KeyEvent keyEvent) {
        return ((C0389a) this.f2073b).isShortcutKey(i, keyEvent);
    }

    public boolean performIdentifierAction(int i, int i2) {
        return ((C0389a) this.f2073b).performIdentifierAction(i, i2);
    }

    public boolean performShortcut(int i, KeyEvent keyEvent, int i2) {
        return ((C0389a) this.f2073b).performShortcut(i, keyEvent, i2);
    }

    public void removeGroup(int i) {
        mo2653a(i);
        ((C0389a) this.f2073b).removeGroup(i);
    }

    public void removeItem(int i) {
        mo2654b(i);
        ((C0389a) this.f2073b).removeItem(i);
    }

    public void setGroupCheckable(int i, boolean z, boolean z2) {
        ((C0389a) this.f2073b).setGroupCheckable(i, z, z2);
    }

    public void setGroupEnabled(int i, boolean z) {
        ((C0389a) this.f2073b).setGroupEnabled(i, z);
    }

    public void setGroupVisible(int i, boolean z) {
        ((C0389a) this.f2073b).setGroupVisible(i, z);
    }

    public void setQwertyMode(boolean z) {
        ((C0389a) this.f2073b).setQwertyMode(z);
    }

    public int size() {
        return ((C0389a) this.f2073b).size();
    }
}
