package android.support.p031v7.view.menu;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.support.p018v4.p021b.p022a.C0391c;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;

/* renamed from: android.support.v7.view.menu.v */
class C0682v extends C0676r implements SubMenu {
    C0682v(Context context, C0391c cVar) {
        super(context, cVar);
    }

    /* renamed from: b */
    public C0391c mo2950b() {
        return (C0391c) this.f2073b;
    }

    public void clearHeader() {
        mo2950b().clearHeader();
    }

    public MenuItem getItem() {
        return mo2650a(mo2950b().getItem());
    }

    public SubMenu setHeaderIcon(int i) {
        mo2950b().setHeaderIcon(i);
        return this;
    }

    public SubMenu setHeaderIcon(Drawable drawable) {
        mo2950b().setHeaderIcon(drawable);
        return this;
    }

    public SubMenu setHeaderTitle(int i) {
        mo2950b().setHeaderTitle(i);
        return this;
    }

    public SubMenu setHeaderTitle(CharSequence charSequence) {
        mo2950b().setHeaderTitle(charSequence);
        return this;
    }

    public SubMenu setHeaderView(View view) {
        mo2950b().setHeaderView(view);
        return this;
    }

    public SubMenu setIcon(int i) {
        mo2950b().setIcon(i);
        return this;
    }

    public SubMenu setIcon(Drawable drawable) {
        mo2950b().setIcon(drawable);
        return this;
    }
}
