package android.support.p031v7.view.menu;

import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff.Mode;
import android.graphics.drawable.Drawable;
import android.support.p018v4.graphics.drawable.C0441a;
import android.support.p018v4.p019a.C0293a;
import android.support.p018v4.p021b.p022a.C0390b;
import android.support.p018v4.p028h.C0477c;
import android.view.ActionProvider;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.MenuItem.OnActionExpandListener;
import android.view.MenuItem.OnMenuItemClickListener;
import android.view.SubMenu;
import android.view.View;

/* renamed from: android.support.v7.view.menu.a */
public class C0642a implements C0390b {

    /* renamed from: a */
    private final int f2038a;

    /* renamed from: b */
    private final int f2039b;

    /* renamed from: c */
    private final int f2040c;

    /* renamed from: d */
    private final int f2041d;

    /* renamed from: e */
    private CharSequence f2042e;

    /* renamed from: f */
    private CharSequence f2043f;

    /* renamed from: g */
    private Intent f2044g;

    /* renamed from: h */
    private char f2045h;

    /* renamed from: i */
    private int f2046i = 4096;

    /* renamed from: j */
    private char f2047j;

    /* renamed from: k */
    private int f2048k = 4096;

    /* renamed from: l */
    private Drawable f2049l;

    /* renamed from: m */
    private int f2050m = 0;

    /* renamed from: n */
    private Context f2051n;

    /* renamed from: o */
    private OnMenuItemClickListener f2052o;

    /* renamed from: p */
    private CharSequence f2053p;

    /* renamed from: q */
    private CharSequence f2054q;

    /* renamed from: r */
    private ColorStateList f2055r = null;

    /* renamed from: s */
    private Mode f2056s = null;

    /* renamed from: t */
    private boolean f2057t = false;

    /* renamed from: u */
    private boolean f2058u = false;

    /* renamed from: v */
    private int f2059v = 16;

    public C0642a(Context context, int i, int i2, int i3, int i4, CharSequence charSequence) {
        this.f2051n = context;
        this.f2038a = i2;
        this.f2039b = i;
        this.f2040c = i3;
        this.f2041d = i4;
        this.f2042e = charSequence;
    }

    /* renamed from: b */
    private void m2903b() {
        if (this.f2049l == null) {
            return;
        }
        if (this.f2057t || this.f2058u) {
            this.f2049l = C0441a.m1938g(this.f2049l);
            this.f2049l = this.f2049l.mutate();
            if (this.f2057t) {
                C0441a.m1927a(this.f2049l, this.f2055r);
            }
            if (this.f2058u) {
                C0441a.m1930a(this.f2049l, this.f2056s);
            }
        }
    }

    /* renamed from: a */
    public C0390b setActionView(int i) {
        throw new UnsupportedOperationException();
    }

    /* renamed from: a */
    public C0390b mo1547a(C0477c cVar) {
        throw new UnsupportedOperationException();
    }

    /* renamed from: a */
    public C0390b setActionView(View view) {
        throw new UnsupportedOperationException();
    }

    /* renamed from: a */
    public C0390b setContentDescription(CharSequence charSequence) {
        this.f2053p = charSequence;
        return this;
    }

    /* renamed from: a */
    public C0477c mo1549a() {
        return null;
    }

    /* renamed from: b */
    public C0390b setShowAsActionFlags(int i) {
        setShowAsAction(i);
        return this;
    }

    /* renamed from: b */
    public C0390b setTooltipText(CharSequence charSequence) {
        this.f2054q = charSequence;
        return this;
    }

    public boolean collapseActionView() {
        return false;
    }

    public boolean expandActionView() {
        return false;
    }

    public ActionProvider getActionProvider() {
        throw new UnsupportedOperationException();
    }

    public View getActionView() {
        return null;
    }

    public int getAlphabeticModifiers() {
        return this.f2048k;
    }

    public char getAlphabeticShortcut() {
        return this.f2047j;
    }

    public CharSequence getContentDescription() {
        return this.f2053p;
    }

    public int getGroupId() {
        return this.f2039b;
    }

    public Drawable getIcon() {
        return this.f2049l;
    }

    public ColorStateList getIconTintList() {
        return this.f2055r;
    }

    public Mode getIconTintMode() {
        return this.f2056s;
    }

    public Intent getIntent() {
        return this.f2044g;
    }

    public int getItemId() {
        return this.f2038a;
    }

    public ContextMenuInfo getMenuInfo() {
        return null;
    }

    public int getNumericModifiers() {
        return this.f2046i;
    }

    public char getNumericShortcut() {
        return this.f2045h;
    }

    public int getOrder() {
        return this.f2041d;
    }

    public SubMenu getSubMenu() {
        return null;
    }

    public CharSequence getTitle() {
        return this.f2042e;
    }

    public CharSequence getTitleCondensed() {
        return this.f2043f != null ? this.f2043f : this.f2042e;
    }

    public CharSequence getTooltipText() {
        return this.f2054q;
    }

    public boolean hasSubMenu() {
        return false;
    }

    public boolean isActionViewExpanded() {
        return false;
    }

    public boolean isCheckable() {
        return (this.f2059v & 1) != 0;
    }

    public boolean isChecked() {
        return (this.f2059v & 2) != 0;
    }

    public boolean isEnabled() {
        return (this.f2059v & 16) != 0;
    }

    public boolean isVisible() {
        return (this.f2059v & 8) == 0;
    }

    public MenuItem setActionProvider(ActionProvider actionProvider) {
        throw new UnsupportedOperationException();
    }

    public MenuItem setAlphabeticShortcut(char c) {
        this.f2047j = Character.toLowerCase(c);
        return this;
    }

    public MenuItem setAlphabeticShortcut(char c, int i) {
        this.f2047j = Character.toLowerCase(c);
        this.f2048k = KeyEvent.normalizeMetaState(i);
        return this;
    }

    public MenuItem setCheckable(boolean z) {
        this.f2059v = z | (this.f2059v & true) ? 1 : 0;
        return this;
    }

    public MenuItem setChecked(boolean z) {
        this.f2059v = (z ? 2 : 0) | (this.f2059v & -3);
        return this;
    }

    public MenuItem setEnabled(boolean z) {
        this.f2059v = (z ? 16 : 0) | (this.f2059v & -17);
        return this;
    }

    public MenuItem setIcon(int i) {
        this.f2050m = i;
        this.f2049l = C0293a.m1186a(this.f2051n, i);
        m2903b();
        return this;
    }

    public MenuItem setIcon(Drawable drawable) {
        this.f2049l = drawable;
        this.f2050m = 0;
        m2903b();
        return this;
    }

    public MenuItem setIconTintList(ColorStateList colorStateList) {
        this.f2055r = colorStateList;
        this.f2057t = true;
        m2903b();
        return this;
    }

    public MenuItem setIconTintMode(Mode mode) {
        this.f2056s = mode;
        this.f2058u = true;
        m2903b();
        return this;
    }

    public MenuItem setIntent(Intent intent) {
        this.f2044g = intent;
        return this;
    }

    public MenuItem setNumericShortcut(char c) {
        this.f2045h = c;
        return this;
    }

    public MenuItem setNumericShortcut(char c, int i) {
        this.f2045h = c;
        this.f2046i = KeyEvent.normalizeMetaState(i);
        return this;
    }

    public MenuItem setOnActionExpandListener(OnActionExpandListener onActionExpandListener) {
        throw new UnsupportedOperationException();
    }

    public MenuItem setOnMenuItemClickListener(OnMenuItemClickListener onMenuItemClickListener) {
        this.f2052o = onMenuItemClickListener;
        return this;
    }

    public MenuItem setShortcut(char c, char c2) {
        this.f2045h = c;
        this.f2047j = Character.toLowerCase(c2);
        return this;
    }

    public MenuItem setShortcut(char c, char c2, int i, int i2) {
        this.f2045h = c;
        this.f2046i = KeyEvent.normalizeMetaState(i);
        this.f2047j = Character.toLowerCase(c2);
        this.f2048k = KeyEvent.normalizeMetaState(i2);
        return this;
    }

    public void setShowAsAction(int i) {
    }

    public MenuItem setTitle(int i) {
        this.f2042e = this.f2051n.getResources().getString(i);
        return this;
    }

    public MenuItem setTitle(CharSequence charSequence) {
        this.f2042e = charSequence;
        return this;
    }

    public MenuItem setTitleCondensed(CharSequence charSequence) {
        this.f2043f = charSequence;
        return this;
    }

    public MenuItem setVisible(boolean z) {
        int i = 8;
        int i2 = this.f2059v & 8;
        if (z) {
            i = 0;
        }
        this.f2059v = i2 | i;
        return this;
    }
}
