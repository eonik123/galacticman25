package android.support.p031v7.view.menu;

import android.widget.ListView;

/* renamed from: android.support.v7.view.menu.s */
public interface C0677s {
    /* renamed from: a */
    void mo2655a();

    /* renamed from: c */
    void mo2662c();

    /* renamed from: d */
    boolean mo2665d();

    /* renamed from: e */
    ListView mo2666e();
}
