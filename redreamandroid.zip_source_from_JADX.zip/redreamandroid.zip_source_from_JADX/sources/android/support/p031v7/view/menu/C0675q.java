package android.support.p031v7.view.menu;

import android.content.Context;
import android.os.Build.VERSION;
import android.support.p018v4.p021b.p022a.C0389a;
import android.support.p018v4.p021b.p022a.C0390b;
import android.support.p018v4.p021b.p022a.C0391c;
import android.view.Menu;
import android.view.MenuItem;
import android.view.SubMenu;

/* renamed from: android.support.v7.view.menu.q */
public final class C0675q {
    /* renamed from: a */
    public static Menu m3129a(Context context, C0389a aVar) {
        return new C0676r(context, aVar);
    }

    /* renamed from: a */
    public static MenuItem m3130a(Context context, C0390b bVar) {
        return VERSION.SDK_INT >= 16 ? new C0666l(context, bVar) : new C0661k(context, bVar);
    }

    /* renamed from: a */
    public static SubMenu m3131a(Context context, C0391c cVar) {
        return new C0682v(context, cVar);
    }
}
