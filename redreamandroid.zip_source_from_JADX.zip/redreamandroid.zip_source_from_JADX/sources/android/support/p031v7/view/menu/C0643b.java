package android.support.p031v7.view.menu;

import android.content.Context;
import android.support.p031v7.view.menu.C0671o.C0672a;
import android.support.p031v7.view.menu.C0673p.C0674a;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import java.util.ArrayList;

/* renamed from: android.support.v7.view.menu.b */
public abstract class C0643b implements C0671o {

    /* renamed from: a */
    protected Context f2060a;

    /* renamed from: b */
    protected Context f2061b;

    /* renamed from: c */
    protected C0655h f2062c;

    /* renamed from: d */
    protected LayoutInflater f2063d;

    /* renamed from: e */
    protected LayoutInflater f2064e;

    /* renamed from: f */
    protected C0673p f2065f;

    /* renamed from: g */
    private C0672a f2066g;

    /* renamed from: h */
    private int f2067h;

    /* renamed from: i */
    private int f2068i;

    /* renamed from: j */
    private int f2069j;

    public C0643b(Context context, int i, int i2) {
        this.f2060a = context;
        this.f2063d = LayoutInflater.from(context);
        this.f2067h = i;
        this.f2068i = i2;
    }

    /* renamed from: a */
    public C0672a mo2633a() {
        return this.f2066g;
    }

    /* renamed from: a */
    public C0673p mo2634a(ViewGroup viewGroup) {
        if (this.f2065f == null) {
            this.f2065f = (C0673p) this.f2063d.inflate(this.f2067h, viewGroup, false);
            this.f2065f.mo651a(this.f2062c);
            mo2647b(true);
        }
        return this.f2065f;
    }

    /* renamed from: a */
    public View mo2635a(C0659j jVar, View view, ViewGroup viewGroup) {
        C0674a b = view instanceof C0674a ? (C0674a) view : mo2646b(viewGroup);
        mo2639a(jVar, b);
        return (View) b;
    }

    /* renamed from: a */
    public void mo2636a(int i) {
        this.f2069j = i;
    }

    /* renamed from: a */
    public void mo2637a(Context context, C0655h hVar) {
        this.f2061b = context;
        this.f2064e = LayoutInflater.from(this.f2061b);
        this.f2062c = hVar;
    }

    /* renamed from: a */
    public void mo2638a(C0655h hVar, boolean z) {
        if (this.f2066g != null) {
            this.f2066g.mo2296a(hVar, z);
        }
    }

    /* renamed from: a */
    public abstract void mo2639a(C0659j jVar, C0674a aVar);

    /* renamed from: a */
    public void mo2640a(C0672a aVar) {
        this.f2066g = aVar;
    }

    /* access modifiers changed from: protected */
    /* renamed from: a */
    public void mo2641a(View view, int i) {
        ViewGroup viewGroup = (ViewGroup) view.getParent();
        if (viewGroup != null) {
            viewGroup.removeView(view);
        }
        ((ViewGroup) this.f2065f).addView(view, i);
    }

    /* renamed from: a */
    public boolean mo2642a(int i, C0659j jVar) {
        return true;
    }

    /* renamed from: a */
    public boolean mo2643a(C0655h hVar, C0659j jVar) {
        return false;
    }

    /* renamed from: a */
    public boolean mo2644a(C0681u uVar) {
        if (this.f2066g != null) {
            return this.f2066g.mo2297a(uVar);
        }
        return false;
    }

    /* access modifiers changed from: protected */
    /* renamed from: a */
    public boolean mo2645a(ViewGroup viewGroup, int i) {
        viewGroup.removeViewAt(i);
        return true;
    }

    /* renamed from: b */
    public C0674a mo2646b(ViewGroup viewGroup) {
        return (C0674a) this.f2063d.inflate(this.f2068i, viewGroup, false);
    }

    /* renamed from: b */
    public void mo2647b(boolean z) {
        ViewGroup viewGroup = (ViewGroup) this.f2065f;
        if (viewGroup != null) {
            int i = 0;
            if (this.f2062c != null) {
                this.f2062c.mo2751k();
                ArrayList j = this.f2062c.mo2750j();
                int size = j.size();
                int i2 = 0;
                for (int i3 = 0; i3 < size; i3++) {
                    C0659j jVar = (C0659j) j.get(i3);
                    if (mo2642a(i2, jVar)) {
                        View childAt = viewGroup.getChildAt(i2);
                        C0659j itemData = childAt instanceof C0674a ? ((C0674a) childAt).getItemData() : null;
                        View a = mo2635a(jVar, childAt, viewGroup);
                        if (jVar != itemData) {
                            a.setPressed(false);
                            a.jumpDrawablesToCurrentState();
                        }
                        if (a != childAt) {
                            mo2641a(a, i2);
                        }
                        i2++;
                    }
                }
                i = i2;
            }
            while (i < viewGroup.getChildCount()) {
                if (!mo2645a(viewGroup, i)) {
                    i++;
                }
            }
        }
    }

    /* renamed from: b */
    public boolean mo2648b() {
        return false;
    }

    /* renamed from: b */
    public boolean mo2649b(C0655h hVar, C0659j jVar) {
        return false;
    }
}
