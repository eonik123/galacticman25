package android.support.p031v7.view.menu;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Parcelable;
import android.support.p031v7.p032a.C0540a.C0550j;
import android.support.p031v7.view.menu.C0655h.C0657b;
import android.support.p031v7.view.menu.C0673p.C0674a;
import android.support.p031v7.widget.ActionMenuView.C0689a;
import android.support.p031v7.widget.C0779ap;
import android.support.p031v7.widget.C0873bp;
import android.support.p031v7.widget.C0936z;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.View.OnClickListener;

/* renamed from: android.support.v7.view.menu.ActionMenuItemView */
public class ActionMenuItemView extends C0936z implements C0674a, C0689a, OnClickListener {

    /* renamed from: b */
    C0659j f2005b;

    /* renamed from: c */
    C0657b f2006c;

    /* renamed from: d */
    C0641b f2007d;

    /* renamed from: e */
    private CharSequence f2008e;

    /* renamed from: f */
    private Drawable f2009f;

    /* renamed from: g */
    private C0779ap f2010g;

    /* renamed from: h */
    private boolean f2011h;

    /* renamed from: i */
    private boolean f2012i;

    /* renamed from: j */
    private int f2013j;

    /* renamed from: k */
    private int f2014k;

    /* renamed from: l */
    private int f2015l;

    /* renamed from: android.support.v7.view.menu.ActionMenuItemView$a */
    private class C0640a extends C0779ap {
        public C0640a() {
            super(ActionMenuItemView.this);
        }

        /* renamed from: a */
        public C0677s mo2578a() {
            if (ActionMenuItemView.this.f2007d != null) {
                return ActionMenuItemView.this.f2007d.mo2580a();
            }
            return null;
        }

        /* access modifiers changed from: protected */
        /* renamed from: b */
        public boolean mo2579b() {
            if (ActionMenuItemView.this.f2006c == null || !ActionMenuItemView.this.f2006c.mo2581a(ActionMenuItemView.this.f2005b)) {
                return false;
            }
            C0677s a = mo2578a();
            return a != null && a.mo2665d();
        }
    }

    /* renamed from: android.support.v7.view.menu.ActionMenuItemView$b */
    public static abstract class C0641b {
        /* renamed from: a */
        public abstract C0677s mo2580a();
    }

    public ActionMenuItemView(Context context) {
        this(context, null);
    }

    public ActionMenuItemView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public ActionMenuItemView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        Resources resources = context.getResources();
        this.f2011h = m2883e();
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, C0550j.ActionMenuItemView, i, 0);
        this.f2013j = obtainStyledAttributes.getDimensionPixelSize(C0550j.ActionMenuItemView_android_minWidth, 0);
        obtainStyledAttributes.recycle();
        this.f2015l = (int) ((32.0f * resources.getDisplayMetrics().density) + 0.5f);
        setOnClickListener(this);
        this.f2014k = -1;
        setSaveEnabled(false);
    }

    /* renamed from: e */
    private boolean m2883e() {
        Configuration configuration = getContext().getResources().getConfiguration();
        int i = configuration.screenWidthDp;
        return i >= 480 || (i >= 640 && configuration.screenHeightDp >= 480) || configuration.orientation == 2;
    }

    /* renamed from: f */
    private void m2884f() {
        boolean z = true;
        boolean z2 = !TextUtils.isEmpty(this.f2008e);
        if (this.f2009f != null && (!this.f2005b.mo2814m() || (!this.f2011h && !this.f2012i))) {
            z = false;
        }
        boolean z3 = z2 & z;
        CharSequence charSequence = null;
        setText(z3 ? this.f2008e : null);
        CharSequence contentDescription = this.f2005b.getContentDescription();
        if (TextUtils.isEmpty(contentDescription)) {
            contentDescription = z3 ? null : this.f2005b.getTitle();
        }
        setContentDescription(contentDescription);
        CharSequence tooltipText = this.f2005b.getTooltipText();
        if (TextUtils.isEmpty(tooltipText)) {
            if (!z3) {
                charSequence = this.f2005b.getTitle();
            }
            C0873bp.m4703a(this, charSequence);
            return;
        }
        C0873bp.m4703a(this, tooltipText);
    }

    /* renamed from: a */
    public void mo636a(C0659j jVar, int i) {
        this.f2005b = jVar;
        setIcon(jVar.getIcon());
        setTitle(jVar.mo2777a((C0674a) this));
        setId(jVar.getItemId());
        setVisibility(jVar.isVisible() ? 0 : 8);
        setEnabled(jVar.isEnabled());
        if (jVar.hasSubMenu() && this.f2010g == null) {
            this.f2010g = new C0640a();
        }
    }

    /* renamed from: a */
    public boolean mo637a() {
        return true;
    }

    /* renamed from: b */
    public boolean mo2562b() {
        return !TextUtils.isEmpty(getText());
    }

    /* renamed from: c */
    public boolean mo2563c() {
        return mo2562b() && this.f2005b.getIcon() == null;
    }

    /* renamed from: d */
    public boolean mo2564d() {
        return mo2562b();
    }

    public C0659j getItemData() {
        return this.f2005b;
    }

    public void onClick(View view) {
        if (this.f2006c != null) {
            this.f2006c.mo2581a(this.f2005b);
        }
    }

    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        this.f2011h = m2883e();
        m2884f();
    }

    /* access modifiers changed from: protected */
    public void onMeasure(int i, int i2) {
        boolean b = mo2562b();
        if (b && this.f2014k >= 0) {
            super.setPadding(this.f2014k, getPaddingTop(), getPaddingRight(), getPaddingBottom());
        }
        super.onMeasure(i, i2);
        int mode = MeasureSpec.getMode(i);
        int size = MeasureSpec.getSize(i);
        int measuredWidth = getMeasuredWidth();
        int min = mode == Integer.MIN_VALUE ? Math.min(size, this.f2013j) : this.f2013j;
        if (mode != 1073741824 && this.f2013j > 0 && measuredWidth < min) {
            super.onMeasure(MeasureSpec.makeMeasureSpec(min, 1073741824), i2);
        }
        if (!b && this.f2009f != null) {
            super.setPadding((getMeasuredWidth() - this.f2009f.getBounds().width()) / 2, getPaddingTop(), getPaddingRight(), getPaddingBottom());
        }
    }

    public void onRestoreInstanceState(Parcelable parcelable) {
        super.onRestoreInstanceState(null);
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        if (!this.f2005b.hasSubMenu() || this.f2010g == null || !this.f2010g.onTouch(this, motionEvent)) {
            return super.onTouchEvent(motionEvent);
        }
        return true;
    }

    public void setCheckable(boolean z) {
    }

    public void setChecked(boolean z) {
    }

    public void setExpandedFormat(boolean z) {
        if (this.f2012i != z) {
            this.f2012i = z;
            if (this.f2005b != null) {
                this.f2005b.mo2804h();
            }
        }
    }

    public void setIcon(Drawable drawable) {
        this.f2009f = drawable;
        if (drawable != null) {
            int intrinsicWidth = drawable.getIntrinsicWidth();
            int intrinsicHeight = drawable.getIntrinsicHeight();
            if (intrinsicWidth > this.f2015l) {
                float f = ((float) this.f2015l) / ((float) intrinsicWidth);
                intrinsicWidth = this.f2015l;
                intrinsicHeight = (int) (((float) intrinsicHeight) * f);
            }
            if (intrinsicHeight > this.f2015l) {
                float f2 = ((float) this.f2015l) / ((float) intrinsicHeight);
                intrinsicHeight = this.f2015l;
                intrinsicWidth = (int) (((float) intrinsicWidth) * f2);
            }
            drawable.setBounds(0, 0, intrinsicWidth, intrinsicHeight);
        }
        setCompoundDrawables(drawable, null, null, null);
        m2884f();
    }

    public void setItemInvoker(C0657b bVar) {
        this.f2006c = bVar;
    }

    public void setPadding(int i, int i2, int i3, int i4) {
        this.f2014k = i;
        super.setPadding(i, i2, i3, i4);
    }

    public void setPopupCallback(C0641b bVar) {
        this.f2007d = bVar;
    }

    public void setTitle(CharSequence charSequence) {
        this.f2008e = charSequence;
        m2884f();
    }
}
