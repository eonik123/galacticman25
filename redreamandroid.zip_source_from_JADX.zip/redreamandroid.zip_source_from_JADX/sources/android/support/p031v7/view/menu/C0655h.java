package android.support.p031v7.view.menu;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.p018v4.p019a.C0293a;
import android.support.p018v4.p021b.p022a.C0389a;
import android.support.p018v4.p028h.C0499s;
import android.util.SparseArray;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.KeyCharacterMap.KeyData;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;
import android.view.ViewConfiguration;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

/* renamed from: android.support.v7.view.menu.h */
public class C0655h implements C0389a {

    /* renamed from: d */
    private static final int[] f2128d = {1, 4, 5, 3, 2, 0};

    /* renamed from: A */
    private boolean f2129A;

    /* renamed from: a */
    CharSequence f2130a;

    /* renamed from: b */
    Drawable f2131b;

    /* renamed from: c */
    View f2132c;

    /* renamed from: e */
    private final Context f2133e;

    /* renamed from: f */
    private final Resources f2134f;

    /* renamed from: g */
    private boolean f2135g;

    /* renamed from: h */
    private boolean f2136h;

    /* renamed from: i */
    private C0656a f2137i;

    /* renamed from: j */
    private ArrayList<C0659j> f2138j;

    /* renamed from: k */
    private ArrayList<C0659j> f2139k;

    /* renamed from: l */
    private boolean f2140l;

    /* renamed from: m */
    private ArrayList<C0659j> f2141m;

    /* renamed from: n */
    private ArrayList<C0659j> f2142n;

    /* renamed from: o */
    private boolean f2143o;

    /* renamed from: p */
    private int f2144p = 0;

    /* renamed from: q */
    private ContextMenuInfo f2145q;

    /* renamed from: r */
    private boolean f2146r = false;

    /* renamed from: s */
    private boolean f2147s = false;

    /* renamed from: t */
    private boolean f2148t = false;

    /* renamed from: u */
    private boolean f2149u = false;

    /* renamed from: v */
    private boolean f2150v = false;

    /* renamed from: w */
    private ArrayList<C0659j> f2151w = new ArrayList<>();

    /* renamed from: x */
    private CopyOnWriteArrayList<WeakReference<C0671o>> f2152x = new CopyOnWriteArrayList<>();

    /* renamed from: y */
    private C0659j f2153y;

    /* renamed from: z */
    private boolean f2154z = false;

    /* renamed from: android.support.v7.view.menu.h$a */
    public interface C0656a {
        /* renamed from: a */
        void mo2264a(C0655h hVar);

        /* renamed from: a */
        boolean mo2267a(C0655h hVar, MenuItem menuItem);
    }

    /* renamed from: android.support.v7.view.menu.h$b */
    public interface C0657b {
        /* renamed from: a */
        boolean mo2581a(C0659j jVar);
    }

    public C0655h(Context context) {
        this.f2133e = context;
        this.f2134f = context.getResources();
        this.f2138j = new ArrayList<>();
        this.f2139k = new ArrayList<>();
        this.f2140l = true;
        this.f2141m = new ArrayList<>();
        this.f2142n = new ArrayList<>();
        this.f2143o = true;
        m2983e(true);
    }

    /* renamed from: a */
    private static int m2977a(ArrayList<C0659j> arrayList, int i) {
        for (int size = arrayList.size() - 1; size >= 0; size--) {
            if (((C0659j) arrayList.get(size)).mo2784c() <= i) {
                return size + 1;
            }
        }
        return 0;
    }

    /* renamed from: a */
    private C0659j m2978a(int i, int i2, int i3, int i4, CharSequence charSequence, int i5) {
        C0659j jVar = new C0659j(this, i, i2, i3, i4, charSequence, i5);
        return jVar;
    }

    /* renamed from: a */
    private void m2979a(int i, CharSequence charSequence, int i2, Drawable drawable, View view) {
        Resources e = mo2740e();
        if (view != null) {
            this.f2132c = view;
            this.f2130a = null;
            this.f2131b = null;
        } else {
            if (i > 0) {
                this.f2130a = e.getText(i);
            } else if (charSequence != null) {
                this.f2130a = charSequence;
            }
            if (i2 > 0) {
                this.f2131b = C0293a.m1186a(mo2742f(), i2);
            } else if (drawable != null) {
                this.f2131b = drawable;
            }
            this.f2132c = null;
        }
        mo2728b(false);
    }

    /* renamed from: a */
    private void m2980a(int i, boolean z) {
        if (i >= 0 && i < this.f2138j.size()) {
            this.f2138j.remove(i);
            if (z) {
                mo2728b(true);
            }
        }
    }

    /* renamed from: a */
    private boolean m2981a(C0681u uVar, C0671o oVar) {
        boolean z = false;
        if (this.f2152x.isEmpty()) {
            return false;
        }
        if (oVar != null) {
            z = oVar.mo2644a(uVar);
        }
        Iterator it = this.f2152x.iterator();
        while (it.hasNext()) {
            WeakReference weakReference = (WeakReference) it.next();
            C0671o oVar2 = (C0671o) weakReference.get();
            if (oVar2 == null) {
                this.f2152x.remove(weakReference);
            } else if (!z) {
                z = oVar2.mo2644a(uVar);
            }
        }
        return z;
    }

    /* renamed from: d */
    private void m2982d(boolean z) {
        if (!this.f2152x.isEmpty()) {
            mo2746h();
            Iterator it = this.f2152x.iterator();
            while (it.hasNext()) {
                WeakReference weakReference = (WeakReference) it.next();
                C0671o oVar = (C0671o) weakReference.get();
                if (oVar == null) {
                    this.f2152x.remove(weakReference);
                } else {
                    oVar.mo2647b(z);
                }
            }
            mo2748i();
        }
    }

    /* renamed from: e */
    private void m2983e(boolean z) {
        boolean z2 = true;
        if (!z || this.f2134f.getConfiguration().keyboard == 1 || !C0499s.m2183c(ViewConfiguration.get(this.f2133e), this.f2133e)) {
            z2 = false;
        }
        this.f2136h = z2;
    }

    /* renamed from: f */
    private static int m2984f(int i) {
        int i2 = (-65536 & i) >> 16;
        if (i2 < 0 || i2 >= f2128d.length) {
            throw new IllegalArgumentException("order does not contain a valid category.");
        }
        return (i & 65535) | (f2128d[i2] << 16);
    }

    /* renamed from: a */
    public int mo2696a(int i, int i2) {
        int size = size();
        if (i2 < 0) {
            i2 = 0;
        }
        while (i2 < size) {
            if (((C0659j) this.f2138j.get(i2)).getGroupId() == i) {
                return i2;
            }
            i2++;
        }
        return -1;
    }

    /* renamed from: a */
    public C0655h mo2697a(int i) {
        this.f2144p = i;
        return this;
    }

    /* access modifiers changed from: protected */
    /* renamed from: a */
    public C0655h mo2698a(Drawable drawable) {
        m2979a(0, null, 0, drawable, null);
        return this;
    }

    /* access modifiers changed from: protected */
    /* renamed from: a */
    public C0655h mo2699a(View view) {
        m2979a(0, null, 0, null, view);
        return this;
    }

    /* access modifiers changed from: protected */
    /* renamed from: a */
    public C0655h mo2700a(CharSequence charSequence) {
        m2979a(0, charSequence, 0, null, null);
        return this;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public C0659j mo2701a(int i, KeyEvent keyEvent) {
        ArrayList<C0659j> arrayList = this.f2151w;
        arrayList.clear();
        mo2710a((List<C0659j>) arrayList, i, keyEvent);
        if (arrayList.isEmpty()) {
            return null;
        }
        int metaState = keyEvent.getMetaState();
        KeyData keyData = new KeyData();
        keyEvent.getKeyData(keyData);
        int size = arrayList.size();
        if (size == 1) {
            return (C0659j) arrayList.get(0);
        }
        boolean c = mo2732c();
        for (int i2 = 0; i2 < size; i2++) {
            C0659j jVar = (C0659j) arrayList.get(i2);
            char alphabeticShortcut = c ? jVar.getAlphabeticShortcut() : jVar.getNumericShortcut();
            if ((alphabeticShortcut == keyData.meta[0] && (metaState & 2) == 0) || ((alphabeticShortcut == keyData.meta[2] && (metaState & 2) != 0) || (c && alphabeticShortcut == 8 && i == 67))) {
                return jVar;
            }
        }
        return null;
    }

    /* access modifiers changed from: protected */
    /* renamed from: a */
    public MenuItem mo2702a(int i, int i2, int i3, CharSequence charSequence) {
        int f = m2984f(i3);
        C0659j a = m2978a(i, i2, i3, f, charSequence, this.f2144p);
        if (this.f2145q != null) {
            a.mo2779a(this.f2145q);
        }
        this.f2138j.add(m2977a(this.f2138j, f), a);
        mo2728b(true);
        return a;
    }

    /* access modifiers changed from: protected */
    /* renamed from: a */
    public String mo2703a() {
        return "android:menu:actionviewstates";
    }

    /* renamed from: a */
    public void mo2704a(Bundle bundle) {
        int size = size();
        SparseArray sparseArray = null;
        for (int i = 0; i < size; i++) {
            MenuItem item = getItem(i);
            View actionView = item.getActionView();
            if (!(actionView == null || actionView.getId() == -1)) {
                if (sparseArray == null) {
                    sparseArray = new SparseArray();
                }
                actionView.saveHierarchyState(sparseArray);
                if (item.isActionViewExpanded()) {
                    bundle.putInt("android:menu:expandedactionview", item.getItemId());
                }
            }
            if (item.hasSubMenu()) {
                ((C0681u) item.getSubMenu()).mo2704a(bundle);
            }
        }
        if (sparseArray != null) {
            bundle.putSparseParcelableArray(mo2703a(), sparseArray);
        }
    }

    /* renamed from: a */
    public void mo2705a(C0656a aVar) {
        this.f2137i = aVar;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo2706a(C0659j jVar) {
        this.f2140l = true;
        mo2728b(true);
    }

    /* renamed from: a */
    public void mo2707a(C0671o oVar) {
        mo2708a(oVar, this.f2133e);
    }

    /* renamed from: a */
    public void mo2708a(C0671o oVar, Context context) {
        this.f2152x.add(new WeakReference(oVar));
        oVar.mo2637a(context, this);
        this.f2143o = true;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo2709a(MenuItem menuItem) {
        int groupId = menuItem.getGroupId();
        int size = this.f2138j.size();
        mo2746h();
        for (int i = 0; i < size; i++) {
            C0659j jVar = (C0659j) this.f2138j.get(i);
            if (jVar.getGroupId() == groupId && jVar.mo2791g() && jVar.isCheckable()) {
                jVar.mo2782b(jVar == menuItem);
            }
        }
        mo2748i();
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo2710a(List<C0659j> list, int i, KeyEvent keyEvent) {
        boolean c = mo2732c();
        int modifiers = keyEvent.getModifiers();
        KeyData keyData = new KeyData();
        if (keyEvent.getKeyData(keyData) || i == 67) {
            int size = this.f2138j.size();
            for (int i2 = 0; i2 < size; i2++) {
                C0659j jVar = (C0659j) this.f2138j.get(i2);
                if (jVar.hasSubMenu()) {
                    ((C0655h) jVar.getSubMenu()).mo2710a(list, i, keyEvent);
                }
                char alphabeticShortcut = c ? jVar.getAlphabeticShortcut() : jVar.getNumericShortcut();
                if (((modifiers & 69647) == ((c ? jVar.getAlphabeticModifiers() : jVar.getNumericModifiers()) & 69647)) && alphabeticShortcut != 0 && ((alphabeticShortcut == keyData.meta[0] || alphabeticShortcut == keyData.meta[2] || (c && alphabeticShortcut == 8 && i == 67)) && jVar.isEnabled())) {
                    list.add(jVar);
                }
            }
        }
    }

    /* renamed from: a */
    public final void mo2711a(boolean z) {
        if (!this.f2150v) {
            this.f2150v = true;
            Iterator it = this.f2152x.iterator();
            while (it.hasNext()) {
                WeakReference weakReference = (WeakReference) it.next();
                C0671o oVar = (C0671o) weakReference.get();
                if (oVar == null) {
                    this.f2152x.remove(weakReference);
                } else {
                    oVar.mo2638a(this, z);
                }
            }
            this.f2150v = false;
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public boolean mo2712a(C0655h hVar, MenuItem menuItem) {
        return this.f2137i != null && this.f2137i.mo2267a(hVar, menuItem);
    }

    /* renamed from: a */
    public boolean mo2713a(MenuItem menuItem, int i) {
        return mo2714a(menuItem, (C0671o) null, i);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:14:0x002b, code lost:
        if (r1 != false) goto L_0x002d;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:21:0x003c, code lost:
        if ((r9 & 1) == 0) goto L_0x002d;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:32:0x0068, code lost:
        if (r1 == false) goto L_0x002d;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:33:0x006b, code lost:
        return r1;
     */
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean mo2714a(android.view.MenuItem r7, android.support.p031v7.view.menu.C0671o r8, int r9) {
        /*
            r6 = this;
            android.support.v7.view.menu.j r7 = (android.support.p031v7.view.menu.C0659j) r7
            r0 = 0
            if (r7 == 0) goto L_0x006c
            boolean r1 = r7.isEnabled()
            if (r1 != 0) goto L_0x000c
            return r0
        L_0x000c:
            boolean r1 = r7.mo2783b()
            android.support.v4.h.c r2 = r7.mo1549a()
            r3 = 1
            if (r2 == 0) goto L_0x001f
            boolean r4 = r2.mo1923e()
            if (r4 == 0) goto L_0x001f
            r4 = r3
            goto L_0x0020
        L_0x001f:
            r4 = r0
        L_0x0020:
            boolean r5 = r7.mo2815n()
            if (r5 == 0) goto L_0x0031
            boolean r7 = r7.expandActionView()
            r1 = r1 | r7
            if (r1 == 0) goto L_0x006b
        L_0x002d:
            r6.mo2711a(r3)
            return r1
        L_0x0031:
            boolean r5 = r7.hasSubMenu()
            if (r5 != 0) goto L_0x003f
            if (r4 == 0) goto L_0x003a
            goto L_0x003f
        L_0x003a:
            r7 = r9 & 1
            if (r7 != 0) goto L_0x006b
            goto L_0x002d
        L_0x003f:
            r9 = r9 & 4
            if (r9 != 0) goto L_0x0046
            r6.mo2711a(r0)
        L_0x0046:
            boolean r9 = r7.hasSubMenu()
            if (r9 != 0) goto L_0x0058
            android.support.v7.view.menu.u r9 = new android.support.v7.view.menu.u
            android.content.Context r0 = r6.mo2742f()
            r9.<init>(r0, r6, r7)
            r7.mo2778a(r9)
        L_0x0058:
            android.view.SubMenu r7 = r7.getSubMenu()
            android.support.v7.view.menu.u r7 = (android.support.p031v7.view.menu.C0681u) r7
            if (r4 == 0) goto L_0x0063
            r2.mo1918a(r7)
        L_0x0063:
            boolean r7 = r6.m2981a(r7, r8)
            r1 = r1 | r7
            if (r1 != 0) goto L_0x006b
            goto L_0x002d
        L_0x006b:
            return r1
        L_0x006c:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.p031v7.view.menu.C0655h.mo2714a(android.view.MenuItem, android.support.v7.view.menu.o, int):boolean");
    }

    public MenuItem add(int i) {
        return mo2702a(0, 0, 0, this.f2134f.getString(i));
    }

    public MenuItem add(int i, int i2, int i3, int i4) {
        return mo2702a(i, i2, i3, this.f2134f.getString(i4));
    }

    public MenuItem add(int i, int i2, int i3, CharSequence charSequence) {
        return mo2702a(i, i2, i3, charSequence);
    }

    public MenuItem add(CharSequence charSequence) {
        return mo2702a(0, 0, 0, charSequence);
    }

    public int addIntentOptions(int i, int i2, int i3, ComponentName componentName, Intent[] intentArr, Intent intent, int i4, MenuItem[] menuItemArr) {
        PackageManager packageManager = this.f2133e.getPackageManager();
        List queryIntentActivityOptions = packageManager.queryIntentActivityOptions(componentName, intentArr, intent, 0);
        int size = queryIntentActivityOptions != null ? queryIntentActivityOptions.size() : 0;
        if ((i4 & 1) == 0) {
            removeGroup(i);
        }
        for (int i5 = 0; i5 < size; i5++) {
            ResolveInfo resolveInfo = (ResolveInfo) queryIntentActivityOptions.get(i5);
            Intent intent2 = new Intent(resolveInfo.specificIndex < 0 ? intent : intentArr[resolveInfo.specificIndex]);
            intent2.setComponent(new ComponentName(resolveInfo.activityInfo.applicationInfo.packageName, resolveInfo.activityInfo.name));
            MenuItem intent3 = add(i, i2, i3, resolveInfo.loadLabel(packageManager)).setIcon(resolveInfo.loadIcon(packageManager)).setIntent(intent2);
            if (menuItemArr != null && resolveInfo.specificIndex >= 0) {
                menuItemArr[resolveInfo.specificIndex] = intent3;
            }
        }
        return size;
    }

    public SubMenu addSubMenu(int i) {
        return addSubMenu(0, 0, 0, (CharSequence) this.f2134f.getString(i));
    }

    public SubMenu addSubMenu(int i, int i2, int i3, int i4) {
        return addSubMenu(i, i2, i3, (CharSequence) this.f2134f.getString(i4));
    }

    public SubMenu addSubMenu(int i, int i2, int i3, CharSequence charSequence) {
        C0659j jVar = (C0659j) mo2702a(i, i2, i3, charSequence);
        C0681u uVar = new C0681u(this.f2133e, this, jVar);
        jVar.mo2778a(uVar);
        return uVar;
    }

    public SubMenu addSubMenu(CharSequence charSequence) {
        return addSubMenu(0, 0, 0, charSequence);
    }

    /* renamed from: b */
    public int mo2724b(int i) {
        int size = size();
        for (int i2 = 0; i2 < size; i2++) {
            if (((C0659j) this.f2138j.get(i2)).getItemId() == i) {
                return i2;
            }
        }
        return -1;
    }

    /* renamed from: b */
    public void mo2725b(Bundle bundle) {
        if (bundle != null) {
            SparseArray sparseParcelableArray = bundle.getSparseParcelableArray(mo2703a());
            int size = size();
            for (int i = 0; i < size; i++) {
                MenuItem item = getItem(i);
                View actionView = item.getActionView();
                if (!(actionView == null || actionView.getId() == -1)) {
                    actionView.restoreHierarchyState(sparseParcelableArray);
                }
                if (item.hasSubMenu()) {
                    ((C0681u) item.getSubMenu()).mo2725b(bundle);
                }
            }
            int i2 = bundle.getInt("android:menu:expandedactionview");
            if (i2 > 0) {
                MenuItem findItem = findItem(i2);
                if (findItem != null) {
                    findItem.expandActionView();
                }
            }
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: b */
    public void mo2726b(C0659j jVar) {
        this.f2143o = true;
        mo2728b(true);
    }

    /* renamed from: b */
    public void mo2727b(C0671o oVar) {
        Iterator it = this.f2152x.iterator();
        while (it.hasNext()) {
            WeakReference weakReference = (WeakReference) it.next();
            C0671o oVar2 = (C0671o) weakReference.get();
            if (oVar2 == null || oVar2 == oVar) {
                this.f2152x.remove(weakReference);
            }
        }
    }

    /* renamed from: b */
    public void mo2728b(boolean z) {
        if (!this.f2146r) {
            if (z) {
                this.f2140l = true;
                this.f2143o = true;
            }
            m2982d(z);
            return;
        }
        this.f2147s = true;
        if (z) {
            this.f2148t = true;
        }
    }

    /* renamed from: b */
    public boolean mo2729b() {
        return this.f2154z;
    }

    /* renamed from: c */
    public int mo2730c(int i) {
        return mo2696a(i, 0);
    }

    /* renamed from: c */
    public void mo2731c(boolean z) {
        this.f2129A = z;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: c */
    public boolean mo2732c() {
        return this.f2135g;
    }

    /* renamed from: c */
    public boolean mo2733c(C0659j jVar) {
        boolean z = false;
        if (this.f2152x.isEmpty()) {
            return false;
        }
        mo2746h();
        Iterator it = this.f2152x.iterator();
        while (it.hasNext()) {
            WeakReference weakReference = (WeakReference) it.next();
            C0671o oVar = (C0671o) weakReference.get();
            if (oVar == null) {
                this.f2152x.remove(weakReference);
            } else {
                z = oVar.mo2643a(this, jVar);
                if (z) {
                    break;
                }
            }
        }
        mo2748i();
        if (z) {
            this.f2153y = jVar;
        }
        return z;
    }

    public void clear() {
        if (this.f2153y != null) {
            mo2739d(this.f2153y);
        }
        this.f2138j.clear();
        mo2728b(true);
    }

    public void clearHeader() {
        this.f2131b = null;
        this.f2130a = null;
        this.f2132c = null;
        mo2728b(false);
    }

    public void close() {
        mo2711a(true);
    }

    /* access modifiers changed from: protected */
    /* renamed from: d */
    public C0655h mo2737d(int i) {
        m2979a(i, null, 0, null, null);
        return this;
    }

    /* renamed from: d */
    public boolean mo2738d() {
        return this.f2136h;
    }

    /* renamed from: d */
    public boolean mo2739d(C0659j jVar) {
        boolean z = false;
        if (!this.f2152x.isEmpty()) {
            if (this.f2153y != jVar) {
                return false;
            }
            mo2746h();
            Iterator it = this.f2152x.iterator();
            while (it.hasNext()) {
                WeakReference weakReference = (WeakReference) it.next();
                C0671o oVar = (C0671o) weakReference.get();
                if (oVar == null) {
                    this.f2152x.remove(weakReference);
                } else {
                    z = oVar.mo2649b(this, jVar);
                    if (z) {
                        break;
                    }
                }
            }
            mo2748i();
            if (z) {
                this.f2153y = null;
            }
        }
        return z;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: e */
    public Resources mo2740e() {
        return this.f2134f;
    }

    /* access modifiers changed from: protected */
    /* renamed from: e */
    public C0655h mo2741e(int i) {
        m2979a(0, null, i, null, null);
        return this;
    }

    /* renamed from: f */
    public Context mo2742f() {
        return this.f2133e;
    }

    public MenuItem findItem(int i) {
        int size = size();
        for (int i2 = 0; i2 < size; i2++) {
            C0659j jVar = (C0659j) this.f2138j.get(i2);
            if (jVar.getItemId() == i) {
                return jVar;
            }
            if (jVar.hasSubMenu()) {
                MenuItem findItem = jVar.getSubMenu().findItem(i);
                if (findItem != null) {
                    return findItem;
                }
            }
        }
        return null;
    }

    /* renamed from: g */
    public void mo2744g() {
        if (this.f2137i != null) {
            this.f2137i.mo2264a(this);
        }
    }

    public MenuItem getItem(int i) {
        return (MenuItem) this.f2138j.get(i);
    }

    /* renamed from: h */
    public void mo2746h() {
        if (!this.f2146r) {
            this.f2146r = true;
            this.f2147s = false;
            this.f2148t = false;
        }
    }

    public boolean hasVisibleItems() {
        if (this.f2129A) {
            return true;
        }
        int size = size();
        for (int i = 0; i < size; i++) {
            if (((C0659j) this.f2138j.get(i)).isVisible()) {
                return true;
            }
        }
        return false;
    }

    /* renamed from: i */
    public void mo2748i() {
        this.f2146r = false;
        if (this.f2147s) {
            this.f2147s = false;
            mo2728b(this.f2148t);
        }
    }

    public boolean isShortcutKey(int i, KeyEvent keyEvent) {
        return mo2701a(i, keyEvent) != null;
    }

    /* renamed from: j */
    public ArrayList<C0659j> mo2750j() {
        if (!this.f2140l) {
            return this.f2139k;
        }
        this.f2139k.clear();
        int size = this.f2138j.size();
        for (int i = 0; i < size; i++) {
            C0659j jVar = (C0659j) this.f2138j.get(i);
            if (jVar.isVisible()) {
                this.f2139k.add(jVar);
            }
        }
        this.f2140l = false;
        this.f2143o = true;
        return this.f2139k;
    }

    /* renamed from: k */
    public void mo2751k() {
        ArrayList j = mo2750j();
        if (this.f2143o) {
            Iterator it = this.f2152x.iterator();
            boolean z = false;
            while (it.hasNext()) {
                WeakReference weakReference = (WeakReference) it.next();
                C0671o oVar = (C0671o) weakReference.get();
                if (oVar == null) {
                    this.f2152x.remove(weakReference);
                } else {
                    z |= oVar.mo2648b();
                }
            }
            if (z) {
                this.f2141m.clear();
                this.f2142n.clear();
                int size = j.size();
                for (int i = 0; i < size; i++) {
                    C0659j jVar = (C0659j) j.get(i);
                    (jVar.mo2811j() ? this.f2141m : this.f2142n).add(jVar);
                }
            } else {
                this.f2141m.clear();
                this.f2142n.clear();
                this.f2142n.addAll(mo2750j());
            }
            this.f2143o = false;
        }
    }

    /* renamed from: l */
    public ArrayList<C0659j> mo2752l() {
        mo2751k();
        return this.f2141m;
    }

    /* renamed from: m */
    public ArrayList<C0659j> mo2753m() {
        mo2751k();
        return this.f2142n;
    }

    /* renamed from: n */
    public CharSequence mo2754n() {
        return this.f2130a;
    }

    /* renamed from: o */
    public Drawable mo2755o() {
        return this.f2131b;
    }

    /* renamed from: p */
    public View mo2756p() {
        return this.f2132c;
    }

    public boolean performIdentifierAction(int i, int i2) {
        return mo2713a(findItem(i), i2);
    }

    public boolean performShortcut(int i, KeyEvent keyEvent, int i2) {
        C0659j a = mo2701a(i, keyEvent);
        boolean a2 = a != null ? mo2713a((MenuItem) a, i2) : false;
        if ((i2 & 2) != 0) {
            mo2711a(true);
        }
        return a2;
    }

    /* renamed from: q */
    public C0655h mo2759q() {
        return this;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: r */
    public boolean mo2760r() {
        return this.f2149u;
    }

    public void removeGroup(int i) {
        int c = mo2730c(i);
        if (c >= 0) {
            int size = this.f2138j.size() - c;
            int i2 = 0;
            while (true) {
                int i3 = i2 + 1;
                if (i2 >= size || ((C0659j) this.f2138j.get(c)).getGroupId() != i) {
                    mo2728b(true);
                } else {
                    m2980a(c, false);
                    i2 = i3;
                }
            }
            mo2728b(true);
        }
    }

    public void removeItem(int i) {
        m2980a(mo2724b(i), true);
    }

    /* renamed from: s */
    public C0659j mo2763s() {
        return this.f2153y;
    }

    public void setGroupCheckable(int i, boolean z, boolean z2) {
        int size = this.f2138j.size();
        for (int i2 = 0; i2 < size; i2++) {
            C0659j jVar = (C0659j) this.f2138j.get(i2);
            if (jVar.getGroupId() == i) {
                jVar.mo2780a(z2);
                jVar.setCheckable(z);
            }
        }
    }

    public void setGroupDividerEnabled(boolean z) {
        this.f2154z = z;
    }

    public void setGroupEnabled(int i, boolean z) {
        int size = this.f2138j.size();
        for (int i2 = 0; i2 < size; i2++) {
            C0659j jVar = (C0659j) this.f2138j.get(i2);
            if (jVar.getGroupId() == i) {
                jVar.setEnabled(z);
            }
        }
    }

    public void setGroupVisible(int i, boolean z) {
        int size = this.f2138j.size();
        boolean z2 = false;
        for (int i2 = 0; i2 < size; i2++) {
            C0659j jVar = (C0659j) this.f2138j.get(i2);
            if (jVar.getGroupId() == i && jVar.mo2785c(z)) {
                z2 = true;
            }
        }
        if (z2) {
            mo2728b(true);
        }
    }

    public void setQwertyMode(boolean z) {
        this.f2135g = z;
        mo2728b(false);
    }

    public int size() {
        return this.f2138j.size();
    }
}
