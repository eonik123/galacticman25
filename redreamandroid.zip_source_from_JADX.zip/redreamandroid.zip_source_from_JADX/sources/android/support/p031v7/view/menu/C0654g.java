package android.support.p031v7.view.menu;

import android.support.p031v7.view.menu.C0673p.C0674a;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import java.util.ArrayList;

/* renamed from: android.support.v7.view.menu.g */
public class C0654g extends BaseAdapter {

    /* renamed from: a */
    C0655h f2122a;

    /* renamed from: b */
    private int f2123b = -1;

    /* renamed from: c */
    private boolean f2124c;

    /* renamed from: d */
    private final boolean f2125d;

    /* renamed from: e */
    private final LayoutInflater f2126e;

    /* renamed from: f */
    private final int f2127f;

    public C0654g(C0655h hVar, LayoutInflater layoutInflater, boolean z, int i) {
        this.f2125d = z;
        this.f2126e = layoutInflater;
        this.f2122a = hVar;
        this.f2127f = i;
        mo2690b();
    }

    /* renamed from: a */
    public C0655h mo2687a() {
        return this.f2122a;
    }

    /* renamed from: a */
    public C0659j getItem(int i) {
        ArrayList m = this.f2125d ? this.f2122a.mo2753m() : this.f2122a.mo2750j();
        if (this.f2123b >= 0 && i >= this.f2123b) {
            i++;
        }
        return (C0659j) m.get(i);
    }

    /* renamed from: a */
    public void mo2689a(boolean z) {
        this.f2124c = z;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: b */
    public void mo2690b() {
        C0659j s = this.f2122a.mo2763s();
        if (s != null) {
            ArrayList m = this.f2122a.mo2753m();
            int size = m.size();
            for (int i = 0; i < size; i++) {
                if (((C0659j) m.get(i)) == s) {
                    this.f2123b = i;
                    return;
                }
            }
        }
        this.f2123b = -1;
    }

    public int getCount() {
        ArrayList m = this.f2125d ? this.f2122a.mo2753m() : this.f2122a.mo2750j();
        return this.f2123b < 0 ? m.size() : m.size() - 1;
    }

    public long getItemId(int i) {
        return (long) i;
    }

    public View getView(int i, View view, ViewGroup viewGroup) {
        if (view == null) {
            view = this.f2126e.inflate(this.f2127f, viewGroup, false);
        }
        int groupId = getItem(i).getGroupId();
        int i2 = i - 1;
        ListMenuItemView listMenuItemView = (ListMenuItemView) view;
        listMenuItemView.setGroupDividerEnabled(this.f2122a.mo2729b() && groupId != (i2 >= 0 ? getItem(i2).getGroupId() : groupId));
        C0674a aVar = (C0674a) view;
        if (this.f2124c) {
            listMenuItemView.setForceShowIcon(true);
        }
        aVar.mo636a(getItem(i), 0);
        return view;
    }

    public void notifyDataSetChanged() {
        mo2690b();
        super.notifyDataSetChanged();
    }
}
