package android.support.p031v7.view.menu;

import android.content.Context;
import android.content.res.Resources;
import android.support.p018v4.p028h.C0495r;
import android.support.p031v7.p032a.C0540a.C0544d;
import android.support.p031v7.p032a.C0540a.C0547g;
import android.support.p031v7.view.menu.C0671o.C0672a;
import android.support.p031v7.widget.C0798av;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnAttachStateChangeListener;
import android.view.View.OnKeyListener;
import android.view.ViewTreeObserver;
import android.view.ViewTreeObserver.OnGlobalLayoutListener;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.FrameLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.PopupWindow.OnDismissListener;
import android.widget.TextView;

/* renamed from: android.support.v7.view.menu.t */
final class C0678t extends C0668m implements C0671o, OnKeyListener, OnItemClickListener, OnDismissListener {

    /* renamed from: e */
    private static final int f2213e = C0547g.abc_popup_menu_item_layout;

    /* renamed from: a */
    final C0798av f2214a;

    /* renamed from: b */
    final OnGlobalLayoutListener f2215b = new OnGlobalLayoutListener() {
        public void onGlobalLayout() {
            if (C0678t.this.mo2665d() && !C0678t.this.f2214a.mo3785g()) {
                View view = C0678t.this.f2216c;
                if (view == null || !view.isShown()) {
                    C0678t.this.mo2662c();
                } else {
                    C0678t.this.f2214a.mo2655a();
                }
            }
        }
    };

    /* renamed from: c */
    View f2216c;

    /* renamed from: d */
    ViewTreeObserver f2217d;

    /* renamed from: f */
    private final Context f2218f;

    /* renamed from: g */
    private final C0655h f2219g;

    /* renamed from: h */
    private final C0654g f2220h;

    /* renamed from: i */
    private final boolean f2221i;

    /* renamed from: j */
    private final int f2222j;

    /* renamed from: k */
    private final int f2223k;

    /* renamed from: l */
    private final int f2224l;

    /* renamed from: m */
    private final OnAttachStateChangeListener f2225m = new OnAttachStateChangeListener() {
        public void onViewAttachedToWindow(View view) {
        }

        public void onViewDetachedFromWindow(View view) {
            if (C0678t.this.f2217d != null) {
                if (!C0678t.this.f2217d.isAlive()) {
                    C0678t.this.f2217d = view.getViewTreeObserver();
                }
                C0678t.this.f2217d.removeGlobalOnLayoutListener(C0678t.this.f2215b);
            }
            view.removeOnAttachStateChangeListener(this);
        }
    };

    /* renamed from: n */
    private OnDismissListener f2226n;

    /* renamed from: o */
    private View f2227o;

    /* renamed from: p */
    private C0672a f2228p;

    /* renamed from: q */
    private boolean f2229q;

    /* renamed from: r */
    private boolean f2230r;

    /* renamed from: s */
    private int f2231s;

    /* renamed from: t */
    private int f2232t = 0;

    /* renamed from: u */
    private boolean f2233u;

    public C0678t(Context context, C0655h hVar, View view, int i, int i2, boolean z) {
        this.f2218f = context;
        this.f2219g = hVar;
        this.f2221i = z;
        this.f2220h = new C0654g(hVar, LayoutInflater.from(context), this.f2221i, f2213e);
        this.f2223k = i;
        this.f2224l = i2;
        Resources resources = context.getResources();
        this.f2222j = Math.max(resources.getDisplayMetrics().widthPixels / 2, resources.getDimensionPixelSize(C0544d.abc_config_prefDialogWidth));
        this.f2227o = view;
        this.f2214a = new C0798av(this.f2218f, null, this.f2223k, this.f2224l);
        hVar.mo2708a((C0671o) this, context);
    }

    /* renamed from: h */
    private boolean m3136h() {
        if (mo2665d()) {
            return true;
        }
        if (this.f2229q || this.f2227o == null) {
            return false;
        }
        this.f2216c = this.f2227o;
        this.f2214a.mo3775a((OnDismissListener) this);
        this.f2214a.mo3773a((OnItemClickListener) this);
        this.f2214a.mo3776a(true);
        View view = this.f2216c;
        boolean z = this.f2217d == null;
        this.f2217d = view.getViewTreeObserver();
        if (z) {
            this.f2217d.addOnGlobalLayoutListener(this.f2215b);
        }
        view.addOnAttachStateChangeListener(this.f2225m);
        this.f2214a.mo3778b(view);
        this.f2214a.mo3782e(this.f2232t);
        if (!this.f2230r) {
            this.f2231s = m3085a(this.f2220h, null, this.f2218f, this.f2222j);
            this.f2230r = true;
        }
        this.f2214a.mo3784g(this.f2231s);
        this.f2214a.mo3787h(2);
        this.f2214a.mo3771a(mo2897g());
        this.f2214a.mo2655a();
        ListView e = this.f2214a.mo2666e();
        e.setOnKeyListener(this);
        if (this.f2233u && this.f2219g.mo2754n() != null) {
            FrameLayout frameLayout = (FrameLayout) LayoutInflater.from(this.f2218f).inflate(C0547g.abc_popup_menu_header_item_layout, e, false);
            TextView textView = (TextView) frameLayout.findViewById(16908310);
            if (textView != null) {
                textView.setText(this.f2219g.mo2754n());
            }
            frameLayout.setEnabled(false);
            e.addHeaderView(frameLayout, null, false);
        }
        this.f2214a.mo3774a((ListAdapter) this.f2220h);
        this.f2214a.mo2655a();
        return true;
    }

    /* renamed from: a */
    public void mo2655a() {
        if (!m3136h()) {
            throw new IllegalStateException("StandardMenuPopup cannot be used without an anchor");
        }
    }

    /* renamed from: a */
    public void mo2656a(int i) {
        this.f2232t = i;
    }

    /* renamed from: a */
    public void mo2657a(C0655h hVar) {
    }

    /* renamed from: a */
    public void mo2638a(C0655h hVar, boolean z) {
        if (hVar == this.f2219g) {
            mo2662c();
            if (this.f2228p != null) {
                this.f2228p.mo2296a(hVar, z);
            }
        }
    }

    /* renamed from: a */
    public void mo2640a(C0672a aVar) {
        this.f2228p = aVar;
    }

    /* renamed from: a */
    public void mo2658a(View view) {
        this.f2227o = view;
    }

    /* renamed from: a */
    public void mo2659a(OnDismissListener onDismissListener) {
        this.f2226n = onDismissListener;
    }

    /* renamed from: a */
    public void mo2660a(boolean z) {
        this.f2220h.mo2689a(z);
    }

    /* renamed from: a */
    public boolean mo2644a(C0681u uVar) {
        if (uVar.hasVisibleItems()) {
            C0669n nVar = new C0669n(this.f2218f, uVar, this.f2216c, this.f2221i, this.f2223k, this.f2224l);
            nVar.mo2901a(this.f2228p);
            nVar.mo2904a(C0668m.m3087b((C0655h) uVar));
            nVar.mo2903a(this.f2226n);
            this.f2226n = null;
            this.f2219g.mo2711a(false);
            int j = this.f2214a.mo3790j();
            int k = this.f2214a.mo3791k();
            if ((Gravity.getAbsoluteGravity(this.f2232t, C0495r.m2149f(this.f2227o)) & 7) == 5) {
                j += this.f2227o.getWidth();
            }
            if (nVar.mo2905a(j, k)) {
                if (this.f2228p != null) {
                    this.f2228p.mo2297a(uVar);
                }
                return true;
            }
        }
        return false;
    }

    /* renamed from: b */
    public void mo2661b(int i) {
        this.f2214a.mo3780c(i);
    }

    /* renamed from: b */
    public void mo2647b(boolean z) {
        this.f2230r = false;
        if (this.f2220h != null) {
            this.f2220h.notifyDataSetChanged();
        }
    }

    /* renamed from: b */
    public boolean mo2648b() {
        return false;
    }

    /* renamed from: c */
    public void mo2662c() {
        if (mo2665d()) {
            this.f2214a.mo2662c();
        }
    }

    /* renamed from: c */
    public void mo2663c(int i) {
        this.f2214a.mo3781d(i);
    }

    /* renamed from: c */
    public void mo2664c(boolean z) {
        this.f2233u = z;
    }

    /* renamed from: d */
    public boolean mo2665d() {
        return !this.f2229q && this.f2214a.mo2665d();
    }

    /* renamed from: e */
    public ListView mo2666e() {
        return this.f2214a.mo2666e();
    }

    public void onDismiss() {
        this.f2229q = true;
        this.f2219g.close();
        if (this.f2217d != null) {
            if (!this.f2217d.isAlive()) {
                this.f2217d = this.f2216c.getViewTreeObserver();
            }
            this.f2217d.removeGlobalOnLayoutListener(this.f2215b);
            this.f2217d = null;
        }
        this.f2216c.removeOnAttachStateChangeListener(this.f2225m);
        if (this.f2226n != null) {
            this.f2226n.onDismiss();
        }
    }

    public boolean onKey(View view, int i, KeyEvent keyEvent) {
        if (keyEvent.getAction() != 1 || i != 82) {
            return false;
        }
        mo2662c();
        return true;
    }
}
