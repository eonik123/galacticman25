package android.support.p031v7.view.menu;

import android.content.Context;
import android.support.p018v4.p021b.p022a.C0390b;
import android.support.p018v4.p028h.C0477c.C0479b;
import android.view.ActionProvider;
import android.view.ActionProvider.VisibilityListener;
import android.view.MenuItem;
import android.view.View;

/* renamed from: android.support.v7.view.menu.l */
class C0666l extends C0661k {

    /* renamed from: android.support.v7.view.menu.l$a */
    class C0667a extends C0662a implements VisibilityListener {

        /* renamed from: c */
        C0479b f2197c;

        public C0667a(Context context, ActionProvider actionProvider) {
            super(context, actionProvider);
        }

        /* renamed from: a */
        public View mo1915a(MenuItem menuItem) {
            return this.f2192a.onCreateActionView(menuItem);
        }

        /* renamed from: a */
        public void mo1917a(C0479b bVar) {
            this.f2197c = bVar;
            this.f2192a.setVisibilityListener(bVar != null ? this : null);
        }

        /* renamed from: b */
        public boolean mo1920b() {
            return this.f2192a.overridesItemVisibility();
        }

        /* renamed from: c */
        public boolean mo1921c() {
            return this.f2192a.isVisible();
        }

        public void onActionProviderVisibilityChanged(boolean z) {
            if (this.f2197c != null) {
                this.f2197c.mo1926a(z);
            }
        }
    }

    C0666l(Context context, C0390b bVar) {
        super(context, bVar);
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public C0662a mo2835a(ActionProvider actionProvider) {
        return new C0667a(this.f2070a, actionProvider);
    }
}
