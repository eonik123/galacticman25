package android.support.p031v7.view.menu;

import android.content.Context;
import android.support.p031v7.view.menu.C0655h.C0657b;
import android.support.p031v7.widget.C0869bn;
import android.util.AttributeSet;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;

/* renamed from: android.support.v7.view.menu.ExpandedMenuView */
public final class ExpandedMenuView extends ListView implements C0657b, C0673p, OnItemClickListener {

    /* renamed from: a */
    private static final int[] f2017a = {16842964, 16843049};

    /* renamed from: b */
    private C0655h f2018b;

    /* renamed from: c */
    private int f2019c;

    public ExpandedMenuView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 16842868);
    }

    public ExpandedMenuView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet);
        setOnItemClickListener(this);
        C0869bn a = C0869bn.m4638a(context, attributeSet, f2017a, i, 0);
        if (a.mo4440g(0)) {
            setBackgroundDrawable(a.mo4426a(0));
        }
        if (a.mo4440g(1)) {
            setDivider(a.mo4426a(1));
        }
        a.mo4427a();
    }

    /* renamed from: a */
    public void mo651a(C0655h hVar) {
        this.f2018b = hVar;
    }

    /* renamed from: a */
    public boolean mo2581a(C0659j jVar) {
        return this.f2018b.mo2713a((MenuItem) jVar, 0);
    }

    public int getWindowAnimations() {
        return this.f2019c;
    }

    /* access modifiers changed from: protected */
    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        setChildrenDrawingCacheEnabled(false);
    }

    public void onItemClick(AdapterView adapterView, View view, int i, long j) {
        mo2581a((C0659j) getAdapter().getItem(i));
    }
}
