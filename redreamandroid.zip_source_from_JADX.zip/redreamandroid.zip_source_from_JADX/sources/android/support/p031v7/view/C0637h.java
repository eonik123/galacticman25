package android.support.p031v7.view;

import android.support.p018v4.p028h.C0502v;
import android.support.p018v4.p028h.C0506w;
import android.support.p018v4.p028h.C0507x;
import android.view.View;
import android.view.animation.Interpolator;
import java.util.ArrayList;
import java.util.Iterator;

/* renamed from: android.support.v7.view.h */
public class C0637h {

    /* renamed from: a */
    final ArrayList<C0502v> f1995a = new ArrayList<>();

    /* renamed from: b */
    C0506w f1996b;

    /* renamed from: c */
    private long f1997c = -1;

    /* renamed from: d */
    private Interpolator f1998d;

    /* renamed from: e */
    private boolean f1999e;

    /* renamed from: f */
    private final C0507x f2000f = new C0507x() {

        /* renamed from: b */
        private boolean f2002b = false;

        /* renamed from: c */
        private int f2003c = 0;

        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public void mo2546a() {
            this.f2003c = 0;
            this.f2002b = false;
            C0637h.this.mo2544b();
        }

        /* renamed from: a */
        public void mo1966a(View view) {
            if (!this.f2002b) {
                this.f2002b = true;
                if (C0637h.this.f1996b != null) {
                    C0637h.this.f1996b.mo1966a(null);
                }
            }
        }

        /* renamed from: b */
        public void mo1967b(View view) {
            int i = this.f2003c + 1;
            this.f2003c = i;
            if (i == C0637h.this.f1995a.size()) {
                if (C0637h.this.f1996b != null) {
                    C0637h.this.f1996b.mo1967b(null);
                }
                mo2546a();
            }
        }
    };

    /* renamed from: a */
    public C0637h mo2538a(long j) {
        if (!this.f1999e) {
            this.f1997c = j;
        }
        return this;
    }

    /* renamed from: a */
    public C0637h mo2539a(C0502v vVar) {
        if (!this.f1999e) {
            this.f1995a.add(vVar);
        }
        return this;
    }

    /* renamed from: a */
    public C0637h mo2540a(C0502v vVar, C0502v vVar2) {
        this.f1995a.add(vVar);
        vVar2.mo1959b(vVar.mo1952a());
        this.f1995a.add(vVar2);
        return this;
    }

    /* renamed from: a */
    public C0637h mo2541a(C0506w wVar) {
        if (!this.f1999e) {
            this.f1996b = wVar;
        }
        return this;
    }

    /* renamed from: a */
    public C0637h mo2542a(Interpolator interpolator) {
        if (!this.f1999e) {
            this.f1998d = interpolator;
        }
        return this;
    }

    /* renamed from: a */
    public void mo2543a() {
        if (!this.f1999e) {
            Iterator it = this.f1995a.iterator();
            while (it.hasNext()) {
                C0502v vVar = (C0502v) it.next();
                if (this.f1997c >= 0) {
                    vVar.mo1954a(this.f1997c);
                }
                if (this.f1998d != null) {
                    vVar.mo1957a(this.f1998d);
                }
                if (this.f1996b != null) {
                    vVar.mo1955a((C0506w) this.f2000f);
                }
                vVar.mo1961c();
            }
            this.f1999e = true;
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: b */
    public void mo2544b() {
        this.f1999e = false;
    }

    /* renamed from: c */
    public void mo2545c() {
        if (this.f1999e) {
            Iterator it = this.f1995a.iterator();
            while (it.hasNext()) {
                ((C0502v) it.next()).mo1960b();
            }
            this.f1999e = false;
        }
    }
}
