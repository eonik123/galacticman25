package android.support.p031v7.view;

import android.content.Context;
import android.support.p018v4.p021b.p022a.C0389a;
import android.support.p018v4.p021b.p022a.C0390b;
import android.support.p018v4.p027g.C0433l;
import android.support.p031v7.view.C0627b.C0628a;
import android.support.p031v7.view.menu.C0675q;
import android.view.ActionMode;
import android.view.ActionMode.Callback;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import java.util.ArrayList;

/* renamed from: android.support.v7.view.f */
public class C0632f extends ActionMode {

    /* renamed from: a */
    final Context f1948a;

    /* renamed from: b */
    final C0627b f1949b;

    /* renamed from: android.support.v7.view.f$a */
    public static class C0633a implements C0628a {

        /* renamed from: a */
        final Callback f1950a;

        /* renamed from: b */
        final Context f1951b;

        /* renamed from: c */
        final ArrayList<C0632f> f1952c = new ArrayList<>();

        /* renamed from: d */
        final C0433l<Menu, Menu> f1953d = new C0433l<>();

        public C0633a(Context context, Callback callback) {
            this.f1951b = context;
            this.f1950a = callback;
        }

        /* renamed from: a */
        private Menu m2854a(Menu menu) {
            Menu menu2 = (Menu) this.f1953d.get(menu);
            if (menu2 != null) {
                return menu2;
            }
            Menu a = C0675q.m3129a(this.f1951b, (C0389a) menu);
            this.f1953d.put(menu, a);
            return a;
        }

        /* renamed from: a */
        public void mo2298a(C0627b bVar) {
            this.f1950a.onDestroyActionMode(mo2528b(bVar));
        }

        /* renamed from: a */
        public boolean mo2299a(C0627b bVar, Menu menu) {
            return this.f1950a.onCreateActionMode(mo2528b(bVar), m2854a(menu));
        }

        /* renamed from: a */
        public boolean mo2300a(C0627b bVar, MenuItem menuItem) {
            return this.f1950a.onActionItemClicked(mo2528b(bVar), C0675q.m3130a(this.f1951b, (C0390b) menuItem));
        }

        /* renamed from: b */
        public ActionMode mo2528b(C0627b bVar) {
            int size = this.f1952c.size();
            for (int i = 0; i < size; i++) {
                C0632f fVar = (C0632f) this.f1952c.get(i);
                if (fVar != null && fVar.f1949b == bVar) {
                    return fVar;
                }
            }
            C0632f fVar2 = new C0632f(this.f1951b, bVar);
            this.f1952c.add(fVar2);
            return fVar2;
        }

        /* renamed from: b */
        public boolean mo2301b(C0627b bVar, Menu menu) {
            return this.f1950a.onPrepareActionMode(mo2528b(bVar), m2854a(menu));
        }
    }

    public C0632f(Context context, C0627b bVar) {
        this.f1948a = context;
        this.f1949b = bVar;
    }

    public void finish() {
        this.f1949b.mo2360c();
    }

    public View getCustomView() {
        return this.f1949b.mo2366i();
    }

    public Menu getMenu() {
        return C0675q.m3129a(this.f1948a, (C0389a) this.f1949b.mo2357b());
    }

    public MenuInflater getMenuInflater() {
        return this.f1949b.mo2352a();
    }

    public CharSequence getSubtitle() {
        return this.f1949b.mo2364g();
    }

    public Object getTag() {
        return this.f1949b.mo2499j();
    }

    public CharSequence getTitle() {
        return this.f1949b.mo2363f();
    }

    public boolean getTitleOptionalHint() {
        return this.f1949b.mo2500k();
    }

    public void invalidate() {
        this.f1949b.mo2361d();
    }

    public boolean isTitleOptional() {
        return this.f1949b.mo2365h();
    }

    public void setCustomView(View view) {
        this.f1949b.mo2354a(view);
    }

    public void setSubtitle(int i) {
        this.f1949b.mo2358b(i);
    }

    public void setSubtitle(CharSequence charSequence) {
        this.f1949b.mo2355a(charSequence);
    }

    public void setTag(Object obj) {
        this.f1949b.mo2498a(obj);
    }

    public void setTitle(int i) {
        this.f1949b.mo2353a(i);
    }

    public void setTitle(CharSequence charSequence) {
        this.f1949b.mo2359b(charSequence);
    }

    public void setTitleOptionalHint(boolean z) {
        this.f1949b.mo2356a(z);
    }
}
