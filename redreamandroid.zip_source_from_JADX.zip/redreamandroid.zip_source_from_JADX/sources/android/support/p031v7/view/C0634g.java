package android.support.p031v7.view;

import android.app.Activity;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.PorterDuff.Mode;
import android.support.p018v4.p028h.C0477c;
import android.support.p018v4.p028h.C0485h;
import android.support.p031v7.p032a.C0540a.C0550j;
import android.support.p031v7.view.menu.C0659j;
import android.support.p031v7.view.menu.C0661k;
import android.support.p031v7.widget.C0768al;
import android.util.AttributeSet;
import android.util.Log;
import android.view.InflateException;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MenuItem.OnMenuItemClickListener;
import android.view.SubMenu;
import android.view.View;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import org.xmlpull.v1.XmlPullParser;

/* renamed from: android.support.v7.view.g */
public class C0634g extends MenuInflater {

    /* renamed from: a */
    static final Class<?>[] f1954a = {Context.class};

    /* renamed from: b */
    static final Class<?>[] f1955b = f1954a;

    /* renamed from: c */
    final Object[] f1956c;

    /* renamed from: d */
    final Object[] f1957d = this.f1956c;

    /* renamed from: e */
    Context f1958e;

    /* renamed from: f */
    private Object f1959f;

    /* renamed from: android.support.v7.view.g$a */
    private static class C0635a implements OnMenuItemClickListener {

        /* renamed from: a */
        private static final Class<?>[] f1960a = {MenuItem.class};

        /* renamed from: b */
        private Object f1961b;

        /* renamed from: c */
        private Method f1962c;

        public C0635a(Object obj, String str) {
            this.f1961b = obj;
            Class cls = obj.getClass();
            try {
                this.f1962c = cls.getMethod(str, f1960a);
            } catch (Exception e) {
                StringBuilder sb = new StringBuilder();
                sb.append("Couldn't resolve menu item onClick handler ");
                sb.append(str);
                sb.append(" in class ");
                sb.append(cls.getName());
                InflateException inflateException = new InflateException(sb.toString());
                inflateException.initCause(e);
                throw inflateException;
            }
        }

        public boolean onMenuItemClick(MenuItem menuItem) {
            try {
                if (this.f1962c.getReturnType() == Boolean.TYPE) {
                    return ((Boolean) this.f1962c.invoke(this.f1961b, new Object[]{menuItem})).booleanValue();
                }
                this.f1962c.invoke(this.f1961b, new Object[]{menuItem});
                return true;
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }
    }

    /* renamed from: android.support.v7.view.g$b */
    private class C0636b {

        /* renamed from: A */
        private String f1963A;

        /* renamed from: B */
        private String f1964B;

        /* renamed from: C */
        private CharSequence f1965C;

        /* renamed from: D */
        private CharSequence f1966D;

        /* renamed from: E */
        private ColorStateList f1967E = null;

        /* renamed from: F */
        private Mode f1968F = null;

        /* renamed from: a */
        C0477c f1969a;

        /* renamed from: c */
        private Menu f1971c;

        /* renamed from: d */
        private int f1972d;

        /* renamed from: e */
        private int f1973e;

        /* renamed from: f */
        private int f1974f;

        /* renamed from: g */
        private int f1975g;

        /* renamed from: h */
        private boolean f1976h;

        /* renamed from: i */
        private boolean f1977i;

        /* renamed from: j */
        private boolean f1978j;

        /* renamed from: k */
        private int f1979k;

        /* renamed from: l */
        private int f1980l;

        /* renamed from: m */
        private CharSequence f1981m;

        /* renamed from: n */
        private CharSequence f1982n;

        /* renamed from: o */
        private int f1983o;

        /* renamed from: p */
        private char f1984p;

        /* renamed from: q */
        private int f1985q;

        /* renamed from: r */
        private char f1986r;

        /* renamed from: s */
        private int f1987s;

        /* renamed from: t */
        private int f1988t;

        /* renamed from: u */
        private boolean f1989u;

        /* renamed from: v */
        private boolean f1990v;

        /* renamed from: w */
        private boolean f1991w;

        /* renamed from: x */
        private int f1992x;

        /* renamed from: y */
        private int f1993y;

        /* renamed from: z */
        private String f1994z;

        public C0636b(Menu menu) {
            this.f1971c = menu;
            mo2532a();
        }

        /* renamed from: a */
        private char m2863a(String str) {
            if (str == null) {
                return 0;
            }
            return str.charAt(0);
        }

        /* renamed from: a */
        private <T> T m2864a(String str, Class<?>[] clsArr, Object[] objArr) {
            try {
                Constructor constructor = C0634g.this.f1958e.getClassLoader().loadClass(str).getConstructor(clsArr);
                constructor.setAccessible(true);
                return constructor.newInstance(objArr);
            } catch (Exception e) {
                StringBuilder sb = new StringBuilder();
                sb.append("Cannot instantiate class: ");
                sb.append(str);
                Log.w("SupportMenuInflater", sb.toString(), e);
                return null;
            }
        }

        /* renamed from: a */
        private void m2865a(MenuItem menuItem) {
            boolean z = false;
            menuItem.setChecked(this.f1989u).setVisible(this.f1990v).setEnabled(this.f1991w).setCheckable(this.f1988t >= 1).setTitleCondensed(this.f1982n).setIcon(this.f1983o);
            if (this.f1992x >= 0) {
                menuItem.setShowAsAction(this.f1992x);
            }
            if (this.f1964B != null) {
                if (C0634g.this.f1958e.isRestricted()) {
                    throw new IllegalStateException("The android:onClick attribute cannot be used within a restricted context");
                }
                menuItem.setOnMenuItemClickListener(new C0635a(C0634g.this.mo2529a(), this.f1964B));
            }
            boolean z2 = menuItem instanceof C0659j;
            if (z2) {
                C0659j jVar = (C0659j) menuItem;
            }
            if (this.f1988t >= 2) {
                if (z2) {
                    ((C0659j) menuItem).mo2780a(true);
                } else if (menuItem instanceof C0661k) {
                    ((C0661k) menuItem).mo2836a(true);
                }
            }
            if (this.f1994z != null) {
                menuItem.setActionView((View) m2864a(this.f1994z, C0634g.f1954a, C0634g.this.f1956c));
                z = true;
            }
            if (this.f1993y > 0) {
                if (!z) {
                    menuItem.setActionView(this.f1993y);
                } else {
                    Log.w("SupportMenuInflater", "Ignoring attribute 'itemActionViewLayout'. Action view already specified.");
                }
            }
            if (this.f1969a != null) {
                C0485h.m2083a(menuItem, this.f1969a);
            }
            C0485h.m2087a(menuItem, this.f1965C);
            C0485h.m2089b(menuItem, this.f1966D);
            C0485h.m2088b(menuItem, this.f1984p, this.f1985q);
            C0485h.m2084a(menuItem, this.f1986r, this.f1987s);
            if (this.f1968F != null) {
                C0485h.m2086a(menuItem, this.f1968F);
            }
            if (this.f1967E != null) {
                C0485h.m2085a(menuItem, this.f1967E);
            }
        }

        /* renamed from: a */
        public void mo2532a() {
            this.f1972d = 0;
            this.f1973e = 0;
            this.f1974f = 0;
            this.f1975g = 0;
            this.f1976h = true;
            this.f1977i = true;
        }

        /* renamed from: a */
        public void mo2533a(AttributeSet attributeSet) {
            TypedArray obtainStyledAttributes = C0634g.this.f1958e.obtainStyledAttributes(attributeSet, C0550j.MenuGroup);
            this.f1972d = obtainStyledAttributes.getResourceId(C0550j.MenuGroup_android_id, 0);
            this.f1973e = obtainStyledAttributes.getInt(C0550j.MenuGroup_android_menuCategory, 0);
            this.f1974f = obtainStyledAttributes.getInt(C0550j.MenuGroup_android_orderInCategory, 0);
            this.f1975g = obtainStyledAttributes.getInt(C0550j.MenuGroup_android_checkableBehavior, 0);
            this.f1976h = obtainStyledAttributes.getBoolean(C0550j.MenuGroup_android_visible, true);
            this.f1977i = obtainStyledAttributes.getBoolean(C0550j.MenuGroup_android_enabled, true);
            obtainStyledAttributes.recycle();
        }

        /* renamed from: b */
        public void mo2534b() {
            this.f1978j = true;
            m2865a(this.f1971c.add(this.f1972d, this.f1979k, this.f1980l, this.f1981m));
        }

        /* renamed from: b */
        public void mo2535b(AttributeSet attributeSet) {
            TypedArray obtainStyledAttributes = C0634g.this.f1958e.obtainStyledAttributes(attributeSet, C0550j.MenuItem);
            this.f1979k = obtainStyledAttributes.getResourceId(C0550j.MenuItem_android_id, 0);
            this.f1980l = (obtainStyledAttributes.getInt(C0550j.MenuItem_android_menuCategory, this.f1973e) & -65536) | (obtainStyledAttributes.getInt(C0550j.MenuItem_android_orderInCategory, this.f1974f) & 65535);
            this.f1981m = obtainStyledAttributes.getText(C0550j.MenuItem_android_title);
            this.f1982n = obtainStyledAttributes.getText(C0550j.MenuItem_android_titleCondensed);
            this.f1983o = obtainStyledAttributes.getResourceId(C0550j.MenuItem_android_icon, 0);
            this.f1984p = m2863a(obtainStyledAttributes.getString(C0550j.MenuItem_android_alphabeticShortcut));
            this.f1985q = obtainStyledAttributes.getInt(C0550j.MenuItem_alphabeticModifiers, 4096);
            this.f1986r = m2863a(obtainStyledAttributes.getString(C0550j.MenuItem_android_numericShortcut));
            this.f1987s = obtainStyledAttributes.getInt(C0550j.MenuItem_numericModifiers, 4096);
            this.f1988t = obtainStyledAttributes.hasValue(C0550j.MenuItem_android_checkable) ? obtainStyledAttributes.getBoolean(C0550j.MenuItem_android_checkable, false) : this.f1975g;
            this.f1989u = obtainStyledAttributes.getBoolean(C0550j.MenuItem_android_checked, false);
            this.f1990v = obtainStyledAttributes.getBoolean(C0550j.MenuItem_android_visible, this.f1976h);
            this.f1991w = obtainStyledAttributes.getBoolean(C0550j.MenuItem_android_enabled, this.f1977i);
            this.f1992x = obtainStyledAttributes.getInt(C0550j.MenuItem_showAsAction, -1);
            this.f1964B = obtainStyledAttributes.getString(C0550j.MenuItem_android_onClick);
            this.f1993y = obtainStyledAttributes.getResourceId(C0550j.MenuItem_actionLayout, 0);
            this.f1994z = obtainStyledAttributes.getString(C0550j.MenuItem_actionViewClass);
            this.f1963A = obtainStyledAttributes.getString(C0550j.MenuItem_actionProviderClass);
            boolean z = this.f1963A != null;
            if (z && this.f1993y == 0 && this.f1994z == null) {
                this.f1969a = (C0477c) m2864a(this.f1963A, C0634g.f1955b, C0634g.this.f1957d);
            } else {
                if (z) {
                    Log.w("SupportMenuInflater", "Ignoring attribute 'actionProviderClass'. Action view already specified.");
                }
                this.f1969a = null;
            }
            this.f1965C = obtainStyledAttributes.getText(C0550j.MenuItem_contentDescription);
            this.f1966D = obtainStyledAttributes.getText(C0550j.MenuItem_tooltipText);
            if (obtainStyledAttributes.hasValue(C0550j.MenuItem_iconTintMode)) {
                this.f1968F = C0768al.m3839a(obtainStyledAttributes.getInt(C0550j.MenuItem_iconTintMode, -1), this.f1968F);
            } else {
                this.f1968F = null;
            }
            if (obtainStyledAttributes.hasValue(C0550j.MenuItem_iconTint)) {
                this.f1967E = obtainStyledAttributes.getColorStateList(C0550j.MenuItem_iconTint);
            } else {
                this.f1967E = null;
            }
            obtainStyledAttributes.recycle();
            this.f1978j = false;
        }

        /* renamed from: c */
        public SubMenu mo2536c() {
            this.f1978j = true;
            SubMenu addSubMenu = this.f1971c.addSubMenu(this.f1972d, this.f1979k, this.f1980l, this.f1981m);
            m2865a(addSubMenu.getItem());
            return addSubMenu;
        }

        /* renamed from: d */
        public boolean mo2537d() {
            return this.f1978j;
        }
    }

    public C0634g(Context context) {
        super(context);
        this.f1958e = context;
        this.f1956c = new Object[]{context};
    }

    /* renamed from: a */
    private Object m2860a(Object obj) {
        if (obj instanceof Activity) {
            return obj;
        }
        if (obj instanceof ContextWrapper) {
            obj = m2860a(((ContextWrapper) obj).getBaseContext());
        }
        return obj;
    }

    /* renamed from: a */
    private void m2861a(XmlPullParser xmlPullParser, AttributeSet attributeSet, Menu menu) {
        C0636b bVar = new C0636b(menu);
        int eventType = xmlPullParser.getEventType();
        while (true) {
            if (eventType != 2) {
                eventType = xmlPullParser.next();
                if (eventType == 1) {
                    break;
                }
            } else {
                String name = xmlPullParser.getName();
                if (name.equals("menu")) {
                    eventType = xmlPullParser.next();
                } else {
                    StringBuilder sb = new StringBuilder();
                    sb.append("Expecting menu, got ");
                    sb.append(name);
                    throw new RuntimeException(sb.toString());
                }
            }
        }
        int i = eventType;
        String str = null;
        boolean z = false;
        boolean z2 = false;
        while (!z) {
            switch (i) {
                case 1:
                    throw new RuntimeException("Unexpected end of document");
                case 2:
                    if (!z2) {
                        String name2 = xmlPullParser.getName();
                        if (!name2.equals("group")) {
                            if (!name2.equals("item")) {
                                if (!name2.equals("menu")) {
                                    z2 = true;
                                    str = name2;
                                    break;
                                } else {
                                    m2861a(xmlPullParser, attributeSet, bVar.mo2536c());
                                    break;
                                }
                            } else {
                                bVar.mo2535b(attributeSet);
                                break;
                            }
                        } else {
                            bVar.mo2533a(attributeSet);
                            break;
                        }
                    } else {
                        break;
                    }
                case 3:
                    String name3 = xmlPullParser.getName();
                    if (!z2 || !name3.equals(str)) {
                        if (!name3.equals("group")) {
                            if (!name3.equals("item")) {
                                if (!name3.equals("menu")) {
                                    break;
                                } else {
                                    z = true;
                                    break;
                                }
                            } else if (!bVar.mo2537d()) {
                                if (bVar.f1969a != null && bVar.f1969a.mo1923e()) {
                                    bVar.mo2536c();
                                    break;
                                } else {
                                    bVar.mo2534b();
                                    break;
                                }
                            } else {
                                break;
                            }
                        } else {
                            bVar.mo2532a();
                            break;
                        }
                    } else {
                        str = null;
                        z2 = false;
                        break;
                    }
            }
            i = xmlPullParser.next();
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public Object mo2529a() {
        if (this.f1959f == null) {
            this.f1959f = m2860a(this.f1958e);
        }
        return this.f1959f;
    }

    /* JADX WARNING: Removed duplicated region for block: B:27:0x003f  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void inflate(int r3, android.view.Menu r4) {
        /*
            r2 = this;
            boolean r0 = r4 instanceof android.support.p018v4.p021b.p022a.C0389a
            if (r0 != 0) goto L_0x0008
            super.inflate(r3, r4)
            return
        L_0x0008:
            r0 = 0
            android.content.Context r1 = r2.f1958e     // Catch:{ XmlPullParserException -> 0x0034, IOException -> 0x002b }
            android.content.res.Resources r1 = r1.getResources()     // Catch:{ XmlPullParserException -> 0x0034, IOException -> 0x002b }
            android.content.res.XmlResourceParser r3 = r1.getLayout(r3)     // Catch:{ XmlPullParserException -> 0x0034, IOException -> 0x002b }
            android.util.AttributeSet r0 = android.util.Xml.asAttributeSet(r3)     // Catch:{ XmlPullParserException -> 0x0026, IOException -> 0x0023, all -> 0x0020 }
            r2.m2861a(r3, r0, r4)     // Catch:{ XmlPullParserException -> 0x0026, IOException -> 0x0023, all -> 0x0020 }
            if (r3 == 0) goto L_0x001f
            r3.close()
        L_0x001f:
            return
        L_0x0020:
            r4 = move-exception
            r0 = r3
            goto L_0x003d
        L_0x0023:
            r4 = move-exception
            r0 = r3
            goto L_0x002c
        L_0x0026:
            r4 = move-exception
            r0 = r3
            goto L_0x0035
        L_0x0029:
            r4 = move-exception
            goto L_0x003d
        L_0x002b:
            r4 = move-exception
        L_0x002c:
            android.view.InflateException r3 = new android.view.InflateException     // Catch:{ all -> 0x0029 }
            java.lang.String r1 = "Error inflating menu XML"
            r3.<init>(r1, r4)     // Catch:{ all -> 0x0029 }
            throw r3     // Catch:{ all -> 0x0029 }
        L_0x0034:
            r4 = move-exception
        L_0x0035:
            android.view.InflateException r3 = new android.view.InflateException     // Catch:{ all -> 0x0029 }
            java.lang.String r1 = "Error inflating menu XML"
            r3.<init>(r1, r4)     // Catch:{ all -> 0x0029 }
            throw r3     // Catch:{ all -> 0x0029 }
        L_0x003d:
            if (r0 == 0) goto L_0x0042
            r0.close()
        L_0x0042:
            throw r4
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.p031v7.view.C0634g.inflate(int, android.view.Menu):void");
    }
}
