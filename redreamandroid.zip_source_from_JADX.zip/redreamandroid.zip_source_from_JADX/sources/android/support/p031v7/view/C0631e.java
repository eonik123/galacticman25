package android.support.p031v7.view;

import android.content.Context;
import android.support.p031v7.view.C0627b.C0628a;
import android.support.p031v7.view.menu.C0655h;
import android.support.p031v7.view.menu.C0655h.C0656a;
import android.support.p031v7.widget.ActionBarContextView;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import java.lang.ref.WeakReference;

/* renamed from: android.support.v7.view.e */
public class C0631e extends C0627b implements C0656a {

    /* renamed from: a */
    private Context f1941a;

    /* renamed from: b */
    private ActionBarContextView f1942b;

    /* renamed from: c */
    private C0628a f1943c;

    /* renamed from: d */
    private WeakReference<View> f1944d;

    /* renamed from: e */
    private boolean f1945e;

    /* renamed from: f */
    private boolean f1946f;

    /* renamed from: g */
    private C0655h f1947g;

    public C0631e(Context context, ActionBarContextView actionBarContextView, C0628a aVar, boolean z) {
        this.f1941a = context;
        this.f1942b = actionBarContextView;
        this.f1943c = aVar;
        this.f1947g = new C0655h(actionBarContextView.getContext()).mo2697a(1);
        this.f1947g.mo2705a((C0656a) this);
        this.f1946f = z;
    }

    /* renamed from: a */
    public MenuInflater mo2352a() {
        return new C0634g(this.f1942b.getContext());
    }

    /* renamed from: a */
    public void mo2353a(int i) {
        mo2359b((CharSequence) this.f1941a.getString(i));
    }

    /* renamed from: a */
    public void mo2264a(C0655h hVar) {
        mo2361d();
        this.f1942b.mo2980a();
    }

    /* renamed from: a */
    public void mo2354a(View view) {
        this.f1942b.setCustomView(view);
        this.f1944d = view != null ? new WeakReference<>(view) : null;
    }

    /* renamed from: a */
    public void mo2355a(CharSequence charSequence) {
        this.f1942b.setSubtitle(charSequence);
    }

    /* renamed from: a */
    public void mo2356a(boolean z) {
        super.mo2356a(z);
        this.f1942b.setTitleOptional(z);
    }

    /* renamed from: a */
    public boolean mo2267a(C0655h hVar, MenuItem menuItem) {
        return this.f1943c.mo2300a((C0627b) this, menuItem);
    }

    /* renamed from: b */
    public Menu mo2357b() {
        return this.f1947g;
    }

    /* renamed from: b */
    public void mo2358b(int i) {
        mo2355a((CharSequence) this.f1941a.getString(i));
    }

    /* renamed from: b */
    public void mo2359b(CharSequence charSequence) {
        this.f1942b.setTitle(charSequence);
    }

    /* renamed from: c */
    public void mo2360c() {
        if (!this.f1945e) {
            this.f1945e = true;
            this.f1942b.sendAccessibilityEvent(32);
            this.f1943c.mo2298a(this);
        }
    }

    /* renamed from: d */
    public void mo2361d() {
        this.f1943c.mo2301b(this, this.f1947g);
    }

    /* renamed from: f */
    public CharSequence mo2363f() {
        return this.f1942b.getTitle();
    }

    /* renamed from: g */
    public CharSequence mo2364g() {
        return this.f1942b.getSubtitle();
    }

    /* renamed from: h */
    public boolean mo2365h() {
        return this.f1942b.mo2983d();
    }

    /* renamed from: i */
    public View mo2366i() {
        if (this.f1944d != null) {
            return (View) this.f1944d.get();
        }
        return null;
    }
}
