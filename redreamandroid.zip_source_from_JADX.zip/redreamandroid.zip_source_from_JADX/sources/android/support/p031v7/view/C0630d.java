package android.support.p031v7.view;

import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.AssetManager;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.Resources.Theme;
import android.os.Build.VERSION;
import android.support.p031v7.p032a.C0540a.C0549i;
import android.view.LayoutInflater;

/* renamed from: android.support.v7.view.d */
public class C0630d extends ContextWrapper {

    /* renamed from: a */
    private int f1936a;

    /* renamed from: b */
    private Theme f1937b;

    /* renamed from: c */
    private LayoutInflater f1938c;

    /* renamed from: d */
    private Configuration f1939d;

    /* renamed from: e */
    private Resources f1940e;

    public C0630d() {
        super(null);
    }

    public C0630d(Context context, int i) {
        super(context);
        this.f1936a = i;
    }

    public C0630d(Context context, Theme theme) {
        super(context);
        this.f1937b = theme;
    }

    /* renamed from: b */
    private Resources m2834b() {
        Resources resources;
        if (this.f1940e == null) {
            if (this.f1939d == null) {
                resources = super.getResources();
            } else if (VERSION.SDK_INT >= 17) {
                resources = createConfigurationContext(this.f1939d).getResources();
            }
            this.f1940e = resources;
        }
        return this.f1940e;
    }

    /* renamed from: c */
    private void m2835c() {
        boolean z = this.f1937b == null;
        if (z) {
            this.f1937b = getResources().newTheme();
            Theme theme = getBaseContext().getTheme();
            if (theme != null) {
                this.f1937b.setTo(theme);
            }
        }
        mo2504a(this.f1937b, this.f1936a, z);
    }

    /* renamed from: a */
    public int mo2503a() {
        return this.f1936a;
    }

    /* access modifiers changed from: protected */
    /* renamed from: a */
    public void mo2504a(Theme theme, int i, boolean z) {
        theme.applyStyle(i, true);
    }

    /* access modifiers changed from: protected */
    public void attachBaseContext(Context context) {
        super.attachBaseContext(context);
    }

    public AssetManager getAssets() {
        return getResources().getAssets();
    }

    public Resources getResources() {
        return m2834b();
    }

    public Object getSystemService(String str) {
        if (!"layout_inflater".equals(str)) {
            return getBaseContext().getSystemService(str);
        }
        if (this.f1938c == null) {
            this.f1938c = LayoutInflater.from(getBaseContext()).cloneInContext(this);
        }
        return this.f1938c;
    }

    public Theme getTheme() {
        if (this.f1937b != null) {
            return this.f1937b;
        }
        if (this.f1936a == 0) {
            this.f1936a = C0549i.Theme_AppCompat_Light;
        }
        m2835c();
        return this.f1937b;
    }

    public void setTheme(int i) {
        if (this.f1936a != i) {
            this.f1936a = i;
            m2835c();
        }
    }
}
