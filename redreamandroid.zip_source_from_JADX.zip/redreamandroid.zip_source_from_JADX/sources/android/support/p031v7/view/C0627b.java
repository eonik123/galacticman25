package android.support.p031v7.view;

import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;

/* renamed from: android.support.v7.view.b */
public abstract class C0627b {

    /* renamed from: a */
    private Object f1934a;

    /* renamed from: b */
    private boolean f1935b;

    /* renamed from: android.support.v7.view.b$a */
    public interface C0628a {
        /* renamed from: a */
        void mo2298a(C0627b bVar);

        /* renamed from: a */
        boolean mo2299a(C0627b bVar, Menu menu);

        /* renamed from: a */
        boolean mo2300a(C0627b bVar, MenuItem menuItem);

        /* renamed from: b */
        boolean mo2301b(C0627b bVar, Menu menu);
    }

    /* renamed from: a */
    public abstract MenuInflater mo2352a();

    /* renamed from: a */
    public abstract void mo2353a(int i);

    /* renamed from: a */
    public abstract void mo2354a(View view);

    /* renamed from: a */
    public abstract void mo2355a(CharSequence charSequence);

    /* renamed from: a */
    public void mo2498a(Object obj) {
        this.f1934a = obj;
    }

    /* renamed from: a */
    public void mo2356a(boolean z) {
        this.f1935b = z;
    }

    /* renamed from: b */
    public abstract Menu mo2357b();

    /* renamed from: b */
    public abstract void mo2358b(int i);

    /* renamed from: b */
    public abstract void mo2359b(CharSequence charSequence);

    /* renamed from: c */
    public abstract void mo2360c();

    /* renamed from: d */
    public abstract void mo2361d();

    /* renamed from: f */
    public abstract CharSequence mo2363f();

    /* renamed from: g */
    public abstract CharSequence mo2364g();

    /* renamed from: h */
    public boolean mo2365h() {
        return false;
    }

    /* renamed from: i */
    public abstract View mo2366i();

    /* renamed from: j */
    public Object mo2499j() {
        return this.f1934a;
    }

    /* renamed from: k */
    public boolean mo2500k() {
        return this.f1935b;
    }
}
