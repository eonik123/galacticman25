package android.support.p031v7.view;

/* renamed from: android.support.v7.view.c */
public interface C0629c {
    /* renamed from: a */
    void mo2501a();

    /* renamed from: b */
    void mo2502b();
}
