package android.support.p031v7.p035c.p036a;

import android.animation.ObjectAnimator;
import android.animation.TimeInterpolator;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.Resources.Theme;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Outline;
import android.graphics.PorterDuff.Mode;
import android.graphics.Rect;
import android.graphics.drawable.Animatable;
import android.graphics.drawable.AnimationDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.support.p005c.p006a.C0052c;
import android.support.p005c.p006a.C0062i;
import android.support.p018v4.p019a.p020a.C0308g;
import android.support.p018v4.p027g.C0419f;
import android.support.p018v4.p027g.C0434m;
import android.support.p031v7.p032a.C0540a.C0550j;
import android.support.p031v7.p033b.p034a.C0606a;
import android.util.AttributeSet;
import android.util.StateSet;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

/* renamed from: android.support.v7.c.a.a */
public class C0608a extends C0621d {

    /* renamed from: a */
    private static final String f1864a = "a";

    /* renamed from: b */
    private C0611b f1865b;

    /* renamed from: c */
    private C0615f f1866c;

    /* renamed from: d */
    private int f1867d;

    /* renamed from: e */
    private int f1868e;

    /* renamed from: f */
    private boolean f1869f;

    /* renamed from: android.support.v7.c.a.a$a */
    private static class C0610a extends C0615f {

        /* renamed from: a */
        private final Animatable f1870a;

        C0610a(Animatable animatable) {
            super();
            this.f1870a = animatable;
        }

        /* renamed from: a */
        public void mo2404a() {
            this.f1870a.start();
        }

        /* renamed from: b */
        public void mo2405b() {
            this.f1870a.stop();
        }
    }

    /* renamed from: android.support.v7.c.a.a$b */
    static class C0611b extends C0622a {

        /* renamed from: a */
        C0419f<Long> f1871a;

        /* renamed from: b */
        C0434m<Integer> f1872b;

        C0611b(C0611b bVar, C0608a aVar, Resources resources) {
            C0434m<Integer> mVar;
            super(bVar, aVar, resources);
            if (bVar != null) {
                this.f1871a = bVar.f1871a;
                mVar = bVar.f1872b;
            } else {
                this.f1871a = new C0419f<>();
                mVar = new C0434m<>();
            }
            this.f1872b = mVar;
        }

        /* renamed from: f */
        private static long m2732f(int i, int i2) {
            return ((long) i2) | (((long) i) << 32);
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public int mo2406a(int i) {
            if (i < 0) {
                return 0;
            }
            return ((Integer) this.f1872b.mo1768a(i, Integer.valueOf(0))).intValue();
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public int mo2407a(int i, int i2) {
            return (int) ((Long) this.f1871a.mo1662a(m2732f(i, i2), Long.valueOf(-1))).longValue();
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public int mo2408a(int i, int i2, Drawable drawable, boolean z) {
            int a = super.mo2434a(drawable);
            long f = m2732f(i, i2);
            long j = z ? 8589934592L : 0;
            long j2 = (long) a;
            this.f1871a.mo1671c(f, Long.valueOf(j2 | j));
            if (z) {
                this.f1871a.mo1671c(m2732f(i2, i), Long.valueOf(4294967296L | j2 | j));
            }
            return a;
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public int mo2409a(int[] iArr) {
            int b = super.mo2490b(iArr);
            return b >= 0 ? b : super.mo2490b(StateSet.WILD_CARD);
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public int mo2410a(int[] iArr, Drawable drawable, int i) {
            int a = super.mo2489a(iArr, drawable);
            this.f1872b.mo1771b(a, Integer.valueOf(i));
            return a;
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public void mo2411a() {
            this.f1871a = this.f1871a.clone();
            this.f1872b = this.f1872b.clone();
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: b */
        public boolean mo2412b(int i, int i2) {
            return (((Long) this.f1871a.mo1662a(m2732f(i, i2), Long.valueOf(-1))).longValue() & 4294967296L) != 0;
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: c */
        public boolean mo2413c(int i, int i2) {
            return (((Long) this.f1871a.mo1662a(m2732f(i, i2), Long.valueOf(-1))).longValue() & 8589934592L) != 0;
        }

        public Drawable newDrawable() {
            return new C0608a(this, null);
        }

        public Drawable newDrawable(Resources resources) {
            return new C0608a(this, resources);
        }
    }

    /* renamed from: android.support.v7.c.a.a$c */
    private static class C0612c extends C0615f {

        /* renamed from: a */
        private final C0052c f1873a;

        C0612c(C0052c cVar) {
            super();
            this.f1873a = cVar;
        }

        /* renamed from: a */
        public void mo2404a() {
            this.f1873a.start();
        }

        /* renamed from: b */
        public void mo2405b() {
            this.f1873a.stop();
        }
    }

    /* renamed from: android.support.v7.c.a.a$d */
    private static class C0613d extends C0615f {

        /* renamed from: a */
        private final ObjectAnimator f1874a;

        /* renamed from: b */
        private final boolean f1875b;

        C0613d(AnimationDrawable animationDrawable, boolean z, boolean z2) {
            super();
            int numberOfFrames = animationDrawable.getNumberOfFrames();
            int i = z ? numberOfFrames - 1 : 0;
            int i2 = z ? 0 : numberOfFrames - 1;
            C0614e eVar = new C0614e(animationDrawable, z);
            ObjectAnimator ofInt = ObjectAnimator.ofInt(animationDrawable, "currentIndex", new int[]{i, i2});
            if (VERSION.SDK_INT >= 18) {
                ofInt.setAutoCancel(true);
            }
            ofInt.setDuration((long) eVar.mo2418a());
            ofInt.setInterpolator(eVar);
            this.f1875b = z2;
            this.f1874a = ofInt;
        }

        /* renamed from: a */
        public void mo2404a() {
            this.f1874a.start();
        }

        /* renamed from: b */
        public void mo2405b() {
            this.f1874a.cancel();
        }

        /* renamed from: c */
        public boolean mo2416c() {
            return this.f1875b;
        }

        /* renamed from: d */
        public void mo2417d() {
            this.f1874a.reverse();
        }
    }

    /* renamed from: android.support.v7.c.a.a$e */
    private static class C0614e implements TimeInterpolator {

        /* renamed from: a */
        private int[] f1876a;

        /* renamed from: b */
        private int f1877b;

        /* renamed from: c */
        private int f1878c;

        C0614e(AnimationDrawable animationDrawable, boolean z) {
            mo2419a(animationDrawable, z);
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public int mo2418a() {
            return this.f1878c;
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public int mo2419a(AnimationDrawable animationDrawable, boolean z) {
            int numberOfFrames = animationDrawable.getNumberOfFrames();
            this.f1877b = numberOfFrames;
            if (this.f1876a == null || this.f1876a.length < numberOfFrames) {
                this.f1876a = new int[numberOfFrames];
            }
            int[] iArr = this.f1876a;
            int i = 0;
            for (int i2 = 0; i2 < numberOfFrames; i2++) {
                int duration = animationDrawable.getDuration(z ? (numberOfFrames - i2) - 1 : i2);
                iArr[i2] = duration;
                i += duration;
            }
            this.f1878c = i;
            return i;
        }

        public float getInterpolation(float f) {
            int i = (int) ((f * ((float) this.f1878c)) + 0.5f);
            int i2 = this.f1877b;
            int[] iArr = this.f1876a;
            int i3 = 0;
            while (i3 < i2 && i >= iArr[i3]) {
                i -= iArr[i3];
                i3++;
            }
            return (((float) i3) / ((float) i2)) + (i3 < i2 ? ((float) i) / ((float) this.f1878c) : 0.0f);
        }
    }

    /* renamed from: android.support.v7.c.a.a$f */
    private static abstract class C0615f {
        private C0615f() {
        }

        /* renamed from: a */
        public abstract void mo2404a();

        /* renamed from: b */
        public abstract void mo2405b();

        /* renamed from: c */
        public boolean mo2416c() {
            return false;
        }

        /* renamed from: d */
        public void mo2417d() {
        }
    }

    public C0608a() {
        this(null, null);
    }

    C0608a(C0611b bVar, Resources resources) {
        super(null);
        this.f1867d = -1;
        this.f1868e = -1;
        mo2368a((C0619b) new C0611b(bVar, this, resources));
        onStateChange(getState());
        jumpToCurrentState();
    }

    /* renamed from: a */
    public static C0608a m2718a(Context context, Resources resources, XmlPullParser xmlPullParser, AttributeSet attributeSet, Theme theme) {
        String name = xmlPullParser.getName();
        if (!name.equals("animated-selector")) {
            StringBuilder sb = new StringBuilder();
            sb.append(xmlPullParser.getPositionDescription());
            sb.append(": invalid animated-selector tag ");
            sb.append(name);
            throw new XmlPullParserException(sb.toString());
        }
        C0608a aVar = new C0608a();
        aVar.mo2371b(context, resources, xmlPullParser, attributeSet, theme);
        return aVar;
    }

    /* renamed from: a */
    private void m2719a(TypedArray typedArray) {
        C0611b bVar = this.f1865b;
        if (VERSION.SDK_INT >= 21) {
            bVar.f1908f |= typedArray.getChangingConfigurations();
        }
        bVar.mo2437a(typedArray.getBoolean(C0550j.AnimatedStateListDrawableCompat_android_variablePadding, bVar.f1913k));
        bVar.mo2440b(typedArray.getBoolean(C0550j.AnimatedStateListDrawableCompat_android_constantSize, bVar.f1916n));
        bVar.mo2442c(typedArray.getInt(C0550j.AnimatedStateListDrawableCompat_android_enterFadeDuration, bVar.f1896C));
        bVar.mo2445d(typedArray.getInt(C0550j.AnimatedStateListDrawableCompat_android_exitFadeDuration, bVar.f1897D));
        setDither(typedArray.getBoolean(C0550j.AnimatedStateListDrawableCompat_android_dither, bVar.f1928z));
    }

    /* renamed from: b */
    private boolean m2720b(int i) {
        int i2;
        C0615f fVar;
        C0615f fVar2 = this.f1866c;
        if (fVar2 == null) {
            i2 = mo2424d();
        } else if (i == this.f1867d) {
            return true;
        } else {
            if (i != this.f1868e || !fVar2.mo2416c()) {
                i2 = this.f1867d;
                fVar2.mo2405b();
            } else {
                fVar2.mo2417d();
                this.f1867d = this.f1868e;
                this.f1868e = i;
                return true;
            }
        }
        this.f1866c = null;
        this.f1868e = -1;
        this.f1867d = -1;
        C0611b bVar = this.f1865b;
        int a = bVar.mo2406a(i2);
        int a2 = bVar.mo2406a(i);
        if (a2 == 0 || a == 0) {
            return false;
        }
        int a3 = bVar.mo2407a(a, a2);
        if (a3 < 0) {
            return false;
        }
        boolean c = bVar.mo2413c(a, a2);
        mo2423a(a3);
        Drawable current = getCurrent();
        if (current instanceof AnimationDrawable) {
            fVar = new C0613d((AnimationDrawable) current, bVar.mo2412b(a, a2), c);
        } else if (current instanceof C0052c) {
            fVar = new C0612c((C0052c) current);
        } else {
            if (current instanceof Animatable) {
                fVar = new C0610a((Animatable) current);
            }
            return false;
        }
        fVar.mo2404a();
        this.f1866c = fVar;
        this.f1868e = i2;
        this.f1867d = i;
        return true;
    }

    /* renamed from: c */
    private void m2721c(Context context, Resources resources, XmlPullParser xmlPullParser, AttributeSet attributeSet, Theme theme) {
        int depth = xmlPullParser.getDepth() + 1;
        while (true) {
            int next = xmlPullParser.next();
            if (next != 1) {
                int depth2 = xmlPullParser.getDepth();
                if (depth2 < depth && next == 3) {
                    return;
                }
                if (next == 2 && depth2 <= depth) {
                    if (xmlPullParser.getName().equals("item")) {
                        m2723e(context, resources, xmlPullParser, attributeSet, theme);
                    } else if (xmlPullParser.getName().equals("transition")) {
                        m2722d(context, resources, xmlPullParser, attributeSet, theme);
                    }
                }
            } else {
                return;
            }
        }
    }

    /* renamed from: d */
    private int m2722d(Context context, Resources resources, XmlPullParser xmlPullParser, AttributeSet attributeSet, Theme theme) {
        int next;
        TypedArray a = C0308g.m1241a(resources, theme, attributeSet, C0550j.AnimatedStateListDrawableTransition);
        int resourceId = a.getResourceId(C0550j.AnimatedStateListDrawableTransition_android_fromId, -1);
        int resourceId2 = a.getResourceId(C0550j.AnimatedStateListDrawableTransition_android_toId, -1);
        int resourceId3 = a.getResourceId(C0550j.AnimatedStateListDrawableTransition_android_drawable, -1);
        Drawable b = resourceId3 > 0 ? C0606a.m2714b(context, resourceId3) : null;
        boolean z = a.getBoolean(C0550j.AnimatedStateListDrawableTransition_android_reversible, false);
        a.recycle();
        if (b == null) {
            do {
                next = xmlPullParser.next();
            } while (next == 4);
            if (next != 2) {
                StringBuilder sb = new StringBuilder();
                sb.append(xmlPullParser.getPositionDescription());
                sb.append(": <transition> tag requires a 'drawable' attribute or child tag defining a drawable");
                throw new XmlPullParserException(sb.toString());
            }
            b = xmlPullParser.getName().equals("animated-vector") ? C0052c.m132a(context, resources, xmlPullParser, attributeSet, theme) : VERSION.SDK_INT >= 21 ? Drawable.createFromXmlInner(resources, xmlPullParser, attributeSet, theme) : Drawable.createFromXmlInner(resources, xmlPullParser, attributeSet);
        }
        if (b == null) {
            StringBuilder sb2 = new StringBuilder();
            sb2.append(xmlPullParser.getPositionDescription());
            sb2.append(": <transition> tag requires a 'drawable' attribute or child tag defining a drawable");
            throw new XmlPullParserException(sb2.toString());
        } else if (resourceId != -1 && resourceId2 != -1) {
            return this.f1865b.mo2408a(resourceId, resourceId2, b, z);
        } else {
            StringBuilder sb3 = new StringBuilder();
            sb3.append(xmlPullParser.getPositionDescription());
            sb3.append(": <transition> tag requires 'fromId' & 'toId' attributes");
            throw new XmlPullParserException(sb3.toString());
        }
    }

    /* renamed from: e */
    private int m2723e(Context context, Resources resources, XmlPullParser xmlPullParser, AttributeSet attributeSet, Theme theme) {
        int next;
        TypedArray a = C0308g.m1241a(resources, theme, attributeSet, C0550j.AnimatedStateListDrawableItem);
        int resourceId = a.getResourceId(C0550j.AnimatedStateListDrawableItem_android_id, 0);
        int resourceId2 = a.getResourceId(C0550j.AnimatedStateListDrawableItem_android_drawable, -1);
        Drawable b = resourceId2 > 0 ? C0606a.m2714b(context, resourceId2) : null;
        a.recycle();
        int[] a2 = mo2488a(attributeSet);
        if (b == null) {
            do {
                next = xmlPullParser.next();
            } while (next == 4);
            if (next != 2) {
                StringBuilder sb = new StringBuilder();
                sb.append(xmlPullParser.getPositionDescription());
                sb.append(": <item> tag requires a 'drawable' attribute or child tag defining a drawable");
                throw new XmlPullParserException(sb.toString());
            }
            b = xmlPullParser.getName().equals("vector") ? C0062i.m166a(resources, xmlPullParser, attributeSet, theme) : VERSION.SDK_INT >= 21 ? Drawable.createFromXmlInner(resources, xmlPullParser, attributeSet, theme) : Drawable.createFromXmlInner(resources, xmlPullParser, attributeSet);
        }
        if (b != null) {
            return this.f1865b.mo2410a(a2, b, resourceId);
        }
        StringBuilder sb2 = new StringBuilder();
        sb2.append(xmlPullParser.getPositionDescription());
        sb2.append(": <item> tag requires a 'drawable' attribute or child tag defining a drawable");
        throw new XmlPullParserException(sb2.toString());
    }

    /* renamed from: e */
    private void m2724e() {
        onStateChange(getState());
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public C0611b mo2372c() {
        return new C0611b(this.f1865b, this, null);
    }

    /* access modifiers changed from: protected */
    /* renamed from: a */
    public void mo2368a(C0619b bVar) {
        super.mo2368a(bVar);
        if (bVar instanceof C0611b) {
            this.f1865b = (C0611b) bVar;
        }
    }

    public /* bridge */ /* synthetic */ void applyTheme(Theme theme) {
        super.applyTheme(theme);
    }

    /* renamed from: b */
    public void mo2371b(Context context, Resources resources, XmlPullParser xmlPullParser, AttributeSet attributeSet, Theme theme) {
        TypedArray a = C0308g.m1241a(resources, theme, attributeSet, C0550j.AnimatedStateListDrawableCompat);
        setVisible(a.getBoolean(C0550j.AnimatedStateListDrawableCompat_android_visible, true), true);
        m2719a(a);
        mo2421a(resources);
        a.recycle();
        m2721c(context, resources, xmlPullParser, attributeSet, theme);
        m2724e();
    }

    public /* bridge */ /* synthetic */ boolean canApplyTheme() {
        return super.canApplyTheme();
    }

    public /* bridge */ /* synthetic */ void draw(Canvas canvas) {
        super.draw(canvas);
    }

    public /* bridge */ /* synthetic */ int getAlpha() {
        return super.getAlpha();
    }

    public /* bridge */ /* synthetic */ int getChangingConfigurations() {
        return super.getChangingConfigurations();
    }

    public /* bridge */ /* synthetic */ Drawable getCurrent() {
        return super.getCurrent();
    }

    public /* bridge */ /* synthetic */ void getHotspotBounds(Rect rect) {
        super.getHotspotBounds(rect);
    }

    public /* bridge */ /* synthetic */ int getIntrinsicHeight() {
        return super.getIntrinsicHeight();
    }

    public /* bridge */ /* synthetic */ int getIntrinsicWidth() {
        return super.getIntrinsicWidth();
    }

    public /* bridge */ /* synthetic */ int getMinimumHeight() {
        return super.getMinimumHeight();
    }

    public /* bridge */ /* synthetic */ int getMinimumWidth() {
        return super.getMinimumWidth();
    }

    public /* bridge */ /* synthetic */ int getOpacity() {
        return super.getOpacity();
    }

    public /* bridge */ /* synthetic */ void getOutline(Outline outline) {
        super.getOutline(outline);
    }

    public /* bridge */ /* synthetic */ boolean getPadding(Rect rect) {
        return super.getPadding(rect);
    }

    public /* bridge */ /* synthetic */ void invalidateDrawable(Drawable drawable) {
        super.invalidateDrawable(drawable);
    }

    public /* bridge */ /* synthetic */ boolean isAutoMirrored() {
        return super.isAutoMirrored();
    }

    public boolean isStateful() {
        return true;
    }

    public void jumpToCurrentState() {
        super.jumpToCurrentState();
        if (this.f1866c != null) {
            this.f1866c.mo2405b();
            this.f1866c = null;
            mo2423a(this.f1867d);
            this.f1867d = -1;
            this.f1868e = -1;
        }
    }

    public Drawable mutate() {
        if (!this.f1869f && super.mutate() == this) {
            this.f1865b.mo2411a();
            this.f1869f = true;
        }
        return this;
    }

    public /* bridge */ /* synthetic */ boolean onLayoutDirectionChanged(int i) {
        return super.onLayoutDirectionChanged(i);
    }

    /* access modifiers changed from: protected */
    public boolean onStateChange(int[] iArr) {
        int a = this.f1865b.mo2409a(iArr);
        boolean z = a != mo2424d() && (m2720b(a) || mo2423a(a));
        Drawable current = getCurrent();
        return current != null ? z | current.setState(iArr) : z;
    }

    public /* bridge */ /* synthetic */ void scheduleDrawable(Drawable drawable, Runnable runnable, long j) {
        super.scheduleDrawable(drawable, runnable, j);
    }

    public /* bridge */ /* synthetic */ void setAlpha(int i) {
        super.setAlpha(i);
    }

    public /* bridge */ /* synthetic */ void setAutoMirrored(boolean z) {
        super.setAutoMirrored(z);
    }

    public /* bridge */ /* synthetic */ void setColorFilter(ColorFilter colorFilter) {
        super.setColorFilter(colorFilter);
    }

    public /* bridge */ /* synthetic */ void setDither(boolean z) {
        super.setDither(z);
    }

    public /* bridge */ /* synthetic */ void setHotspot(float f, float f2) {
        super.setHotspot(f, f2);
    }

    public /* bridge */ /* synthetic */ void setHotspotBounds(int i, int i2, int i3, int i4) {
        super.setHotspotBounds(i, i2, i3, i4);
    }

    public /* bridge */ /* synthetic */ void setTintList(ColorStateList colorStateList) {
        super.setTintList(colorStateList);
    }

    public /* bridge */ /* synthetic */ void setTintMode(Mode mode) {
        super.setTintMode(mode);
    }

    public boolean setVisible(boolean z, boolean z2) {
        boolean visible = super.setVisible(z, z2);
        if (this.f1866c != null && (visible || z2)) {
            if (z) {
                this.f1866c.mo2404a();
                return visible;
            }
            jumpToCurrentState();
        }
        return visible;
    }

    public /* bridge */ /* synthetic */ void unscheduleDrawable(Drawable drawable, Runnable runnable) {
        super.unscheduleDrawable(drawable, runnable);
    }
}
