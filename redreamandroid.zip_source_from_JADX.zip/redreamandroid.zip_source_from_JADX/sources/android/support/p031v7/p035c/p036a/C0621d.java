package android.support.p031v7.p035c.p036a;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.Resources.Theme;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.support.p018v4.p019a.p020a.C0308g;
import android.support.p031v7.p032a.C0540a.C0550j;
import android.support.p031v7.p033b.p034a.C0606a;
import android.util.AttributeSet;
import android.util.StateSet;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

/* renamed from: android.support.v7.c.a.d */
class C0621d extends C0616b {

    /* renamed from: a */
    private C0622a f1930a;

    /* renamed from: b */
    private boolean f1931b;

    /* renamed from: android.support.v7.c.a.d$a */
    static class C0622a extends C0619b {

        /* renamed from: L */
        int[][] f1932L;

        C0622a(C0622a aVar, C0621d dVar, Resources resources) {
            super(aVar, dVar, resources);
            this.f1932L = aVar != null ? aVar.f1932L : new int[mo2441c()][];
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public int mo2489a(int[] iArr, Drawable drawable) {
            int a = mo2434a(drawable);
            this.f1932L[a] = iArr;
            return a;
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public void mo2411a() {
            int[][] iArr = new int[this.f1932L.length][];
            for (int length = this.f1932L.length - 1; length >= 0; length--) {
                iArr[length] = this.f1932L[length] != null ? (int[]) this.f1932L[length].clone() : null;
            }
            this.f1932L = iArr;
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: b */
        public int mo2490b(int[] iArr) {
            int[][] iArr2 = this.f1932L;
            int d = mo2444d();
            for (int i = 0; i < d; i++) {
                if (StateSet.stateSetMatches(iArr2[i], iArr)) {
                    return i;
                }
            }
            return -1;
        }

        /* renamed from: e */
        public void mo2448e(int i, int i2) {
            super.mo2448e(i, i2);
            int[][] iArr = new int[i2][];
            System.arraycopy(this.f1932L, 0, iArr, 0, i);
            this.f1932L = iArr;
        }

        public Drawable newDrawable() {
            return new C0621d(this, null);
        }

        public Drawable newDrawable(Resources resources) {
            return new C0621d(this, resources);
        }
    }

    C0621d() {
        this(null, null);
    }

    C0621d(C0622a aVar) {
        if (aVar != null) {
            mo2368a((C0619b) aVar);
        }
    }

    C0621d(C0622a aVar, Resources resources) {
        mo2368a((C0619b) new C0622a(aVar, this, resources));
        onStateChange(getState());
    }

    /* renamed from: a */
    private void m2792a(Context context, Resources resources, XmlPullParser xmlPullParser, AttributeSet attributeSet, Theme theme) {
        int next;
        C0622a aVar = this.f1930a;
        int depth = xmlPullParser.getDepth() + 1;
        while (true) {
            int next2 = xmlPullParser.next();
            if (next2 != 1) {
                int depth2 = xmlPullParser.getDepth();
                if (depth2 < depth && next2 == 3) {
                    return;
                }
                if (next2 == 2 && depth2 <= depth && xmlPullParser.getName().equals("item")) {
                    TypedArray a = C0308g.m1241a(resources, theme, attributeSet, C0550j.StateListDrawableItem);
                    Drawable drawable = null;
                    int resourceId = a.getResourceId(C0550j.StateListDrawableItem_android_drawable, -1);
                    if (resourceId > 0) {
                        drawable = C0606a.m2714b(context, resourceId);
                    }
                    a.recycle();
                    int[] a2 = mo2488a(attributeSet);
                    if (drawable == null) {
                        do {
                            next = xmlPullParser.next();
                        } while (next == 4);
                        if (next != 2) {
                            StringBuilder sb = new StringBuilder();
                            sb.append(xmlPullParser.getPositionDescription());
                            sb.append(": <item> tag requires a 'drawable' attribute or ");
                            sb.append("child tag defining a drawable");
                            throw new XmlPullParserException(sb.toString());
                        }
                        drawable = VERSION.SDK_INT >= 21 ? Drawable.createFromXmlInner(resources, xmlPullParser, attributeSet, theme) : Drawable.createFromXmlInner(resources, xmlPullParser, attributeSet);
                    }
                    aVar.mo2489a(a2, drawable);
                }
            } else {
                return;
            }
        }
    }

    /* renamed from: a */
    private void m2793a(TypedArray typedArray) {
        C0622a aVar = this.f1930a;
        if (VERSION.SDK_INT >= 21) {
            aVar.f1908f |= typedArray.getChangingConfigurations();
        }
        aVar.f1913k = typedArray.getBoolean(C0550j.StateListDrawable_android_variablePadding, aVar.f1913k);
        aVar.f1916n = typedArray.getBoolean(C0550j.StateListDrawable_android_constantSize, aVar.f1916n);
        aVar.f1896C = typedArray.getInt(C0550j.StateListDrawable_android_enterFadeDuration, aVar.f1896C);
        aVar.f1897D = typedArray.getInt(C0550j.StateListDrawable_android_exitFadeDuration, aVar.f1897D);
        aVar.f1928z = typedArray.getBoolean(C0550j.StateListDrawable_android_dither, aVar.f1928z);
    }

    /* access modifiers changed from: protected */
    /* renamed from: a */
    public void mo2368a(C0619b bVar) {
        super.mo2368a(bVar);
        if (bVar instanceof C0622a) {
            this.f1930a = (C0622a) bVar;
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public int[] mo2488a(AttributeSet attributeSet) {
        int attributeCount = attributeSet.getAttributeCount();
        int[] iArr = new int[attributeCount];
        int i = 0;
        for (int i2 = 0; i2 < attributeCount; i2++) {
            int attributeNameResource = attributeSet.getAttributeNameResource(i2);
            if (!(attributeNameResource == 0 || attributeNameResource == 16842960 || attributeNameResource == 16843161)) {
                int i3 = i + 1;
                if (!attributeSet.getAttributeBooleanValue(i2, false)) {
                    attributeNameResource = -attributeNameResource;
                }
                iArr[i] = attributeNameResource;
                i = i3;
            }
        }
        return StateSet.trimStateSet(iArr, i);
    }

    public void applyTheme(Theme theme) {
        super.applyTheme(theme);
        onStateChange(getState());
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: b */
    public C0622a mo2372c() {
        return new C0622a(this.f1930a, this, null);
    }

    /* renamed from: b */
    public void mo2371b(Context context, Resources resources, XmlPullParser xmlPullParser, AttributeSet attributeSet, Theme theme) {
        TypedArray a = C0308g.m1241a(resources, theme, attributeSet, C0550j.StateListDrawable);
        setVisible(a.getBoolean(C0550j.StateListDrawable_android_visible, true), true);
        m2793a(a);
        mo2421a(resources);
        a.recycle();
        m2792a(context, resources, xmlPullParser, attributeSet, theme);
        onStateChange(getState());
    }

    public boolean isStateful() {
        return true;
    }

    public Drawable mutate() {
        if (!this.f1931b && super.mutate() == this) {
            this.f1930a.mo2411a();
            this.f1931b = true;
        }
        return this;
    }

    /* access modifiers changed from: protected */
    public boolean onStateChange(int[] iArr) {
        boolean onStateChange = super.onStateChange(iArr);
        int b = this.f1930a.mo2490b(iArr);
        if (b < 0) {
            b = this.f1930a.mo2490b(StateSet.WILD_CARD);
        }
        return mo2423a(b) || onStateChange;
    }
}
